# The Business Brain File Contract

The single source of truth for how every Clinic Catalyst skill reads and writes files. Lock this and the 16-skill pack behaves as ONE system: each skill reliably finds what the last one made, by a fixed name in a fixed place. Break it - rename a file, move a folder - and the chain silently stops finding things. So: never rename, never improvise a path. Obey this.

## The canonical workspace

Every clinic has ONE workspace folder. Same relative structure everywhere; only the root changes by context:

- On the clinic's own machine (their install): the root is `~/Clinic/`.
- On our operator machine (Kelly or Alicia serving many clients): the root is `~/Dropbox/Clinic_Catalyst_Shared/Clients/<Clinic>/`.

Skills always work relative to the ACTIVE clinic folder (the current working directory, or the clinic named in the prompt). The structure below is identical in both.

```
<clinic-workspace>/
  CLAUDE.md                      # house rules + points every skill at Business-Brain/. Read first.
  Business-Brain/                # the knowledge spine. Skills READ here. Never guess what is in here.
    brand-guide.md               # THE spine. Voice + the paste-into-Claude context block. Every generative skill reads this FIRST.
    resonance-messaging.md       # the emotional source-of-truth (from /cc-resonance)
    offers.md                    # offers, intro/front-door offer, packages, prices
    services-machines.md         # treatments AND the actual devices/machines the clinic runs
    concerns.md                  # the skin concerns they love treating / lean into
    team.md                      # each team member + their "special interest in ..." (AHPRA-safe)
    strategy.md                  # the monthly theme + growth focus that drives everything this month
    brand-assets/                # the clinic's VISUAL brand files - every rendering skill reads from here
      logo.png                   # the clinic's logo, transparent PNG (optional)
      headline-font.ttf          # the clinic's headline/display font (optional - falls back to a clean system bold)
      body-font.ttf              # the clinic's body/subtext font (optional)
  Content/                       # generated social posts          (cc-content-engine writes here)
  Emails/                        # nurture ladder + newsletters     (cc-follow-up-agent writes here)
  Ads/                           # ad sets + keyword plans          (cc-ad-builder writes here)
```

## The rules

1. `brand-guide.md` is the SINGLE spine every generative skill reads first. The other `Business-Brain/` files are the deeper detail that `brand-guide.md` summarises and points to. A skill reads `brand-guide.md`, and pulls the specific file (offers, machines, concerns) only when it needs that depth.
2. Skills READ from `Business-Brain/`. Skills WRITE to `Content/`, `Emails/`, or `Ads/` - never into `Business-Brain/`, except the two foundation skills below.
3. Filenames are FIXED and exact (lowercase, hyphenated, as written above). Never rename, never pluralise, never add a date to the name.
4. If a required file is MISSING, the skill does not guess or fabricate. It says which file is missing and offers to run the skill that creates it (e.g. no `brand-guide.md` -> "run /cc-brand-guide first").
5. Paths are relative to the active clinic workspace. Never hardcode one clinic's absolute path into a skill.
6. VISUAL brand lives in the brain too. `brand-guide.md` carries a `## Brand colours` section with hex codes (at least an `Accent` hex). The clinic's logo + fonts live in `Business-Brain/brand-assets/` under the fixed names above. Any skill that RENDERS an image (covers, reels) reads the accent hex from `brand-guide.md` and the font/logo from `brand-assets/` - it never asks the clinic for a path or reaches into OS font folders. If a brand-asset is absent, the skill falls back gracefully (a clean system font, no logo) and says it used a fallback so the clinic can add the real asset to `brand-assets/`.

## The manifest - who reads and writes what

| Skill | Reads | Writes |
|-------|-------|--------|
| `/cc-resonance` | the live interview answers | `Business-Brain/resonance-messaging.md` |
| `/cc-brand-guide` | `Business-Brain/resonance-messaging.md` + `offers.md` + `team.md` + `services-machines.md` + `concerns.md` + `strategy.md` | `Business-Brain/brand-guide.md` |
| `/cc-content-engine` | `Business-Brain/brand-guide.md` + `strategy.md` + `concerns.md` | `Content/` |
| `/cc-follow-up-agent` | `Business-Brain/brand-guide.md` + `offers.md` | `Emails/` |
| `/cc-ad-builder` | `Business-Brain/brand-guide.md` + `offers.md` + `services-machines.md` | `Ads/` |
| `/cc-cover` | `Business-Brain/brand-guide.md` (accent hex) + `brand-assets/` (font, logo) | `Content/covers/` |

The two foundation skills (`/cc-resonance`, `/cc-brand-guide`) are the ONLY ones that write into `Business-Brain/`. Everything else reads the brain and writes output. That keeps the spine clean and trustworthy.

## The build order (foundation first)

Nothing downstream runs until the foundation exists:

1. `/cc-resonance` interviews the owner (with Alicia on the emotional + offer work) -> `resonance-messaging.md`
2. The owner fills / we capture the rest of the brain: `offers.md`, `services-machines.md`, `concerns.md`, `team.md`, `strategy.md`
3. `/cc-brand-guide` reads all of it -> `brand-guide.md` (the spine)
4. Now the system runs: content, follow-up and ads all read the brain and write into `Content/`, `Emails/`, `Ads/`

## Why this matters (the one-line version)

A skill that reads `~/Clinic/Business-Brain/brand-guide.md` by name, every time, is what turns sixteen separate skills into one clinic-shaped machine. The contract is the machine.
