# CLAUDE.md - [Clinic Name]

This is your clinic's AI workspace. Claude reads this file first, every time, so it always knows your setup, your rules, and where everything lives. Installed by Clinic Catalyst.

## Your workspace (where everything lives)

Everything runs from this one folder (`~/Clinic/`). Never move or rename these - the skills find your files by their exact names:

```
~/Clinic/
  Business-Brain/        <- everything about your clinic. The skills READ from here.
    brand-guide.md         your voice + the master context (the spine)
    resonance-messaging.md the emotional source-of-truth
    offers.md              your offers, intro offer, packages, prices
    services-machines.md   your treatments + the machines you run
    concerns.md            the skin concerns you love treating
    team.md                your team + each person's special interest
    strategy.md            this month's focus
  Content/               <- your generated social posts land here
  Emails/                <- your nurture + newsletters land here
  Ads/                   <- your ad sets land here
```

## How the skills work (the contract)

- Skills READ your Business Brain from `Business-Brain/` and WRITE finished work into `Content/`, `Emails/` or `Ads/`.
- `brand-guide.md` is the spine - every skill reads it first, so everything sounds like you.
- If a skill needs something that is not there yet (no `brand-guide.md`, no `offers.md`), it will TELL you and offer to build it - it never makes things up about your clinic.
- Foundation first: your Business Brain gets built (with us) before anything else runs.

## House rules (never break these)

- AHPRA-safe always. Concern-led, never claim-led. Never: best, leading, expert, specialist (use "has a special interest in"), guaranteed, safe, painless, before/after as a promise, patient testimonials for regulated treatments, "Botox" or any Schedule 4 product name, S4 pricing, "anti-ageing".
- Australian English. No emdashes (use hyphens with spaces). Italics, not bold, for emphasis. Never the "it is not X, it is Y" pattern.
- Never invent facts about the clinic - services, prices, results, team credentials. If unsure, ask.
- Everything you generate is a draft for a human to approve before it goes out.

## Who is who

See `Business-Brain/team.md`. Bookings, enquiries and the booking link live in there too.

## When in doubt

Read `Business-Brain/brand-guide.md`. It holds your voice and the rules for every piece of writing. If it is missing, run `/cc-brand-guide` to build it.

## Folder conventions (fixed names - skills depend on them)
- `Business-Brain/` - the knowledge spine. Skills READ here; only /cc-resonance and /cc-brand-guide write here.
- `Assets/Photos|Video|Talking-Head|Static/` - your raw material inbox. Drop phone footage in Talking-Head, real photos in Photos. Skills pull from these fixed names.
- `Content/`, `Emails/`, `Ads/` - skills WRITE here. Never store originals in these.
- `Credentials/credentials-reference.txt` - your keys and logins live in this one local file. Never paste keys into prompts, content, or anywhere online. When a skill needs your API key, point it to this file.
