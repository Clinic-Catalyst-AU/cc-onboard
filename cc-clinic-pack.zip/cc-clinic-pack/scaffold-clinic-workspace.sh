#!/bin/bash
# Scaffold a clinic's Claude workspace per the Business Brain File Contract.
# Creates the folder structure Claude Code works from, and drops in the clinic CLAUDE.md
# so Claude reads the rules + knows where everything lives. Run as part of setup.
# The Business-Brain/ folder starts EMPTY - it gets filled when they run /cc-resonance
# then /cc-brand-guide (foundation first). The system runs once those docs exist.
#
# Usage:  scaffold-clinic-workspace.sh [path]      (defaults to ~/Clinic)
set -euo pipefail

ROOT="${1:-$HOME/Clinic}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
TEMPLATE="$SCRIPT_DIR/templates/clinic-CLAUDE.md"
[ -f "$TEMPLATE" ] || TEMPLATE="$HOME/Systems/cc-aios/templates/clinic-CLAUDE.md"

say(){ printf "\n\033[1;36m%s\033[0m\n" "$*"; }

say "Scaffolding clinic workspace at: $ROOT"
# ONE folder holds all the media: Content. Everything the clinic drops in, and everything the
# system finishes, lives side by side in there. No hunting across two trees.
mkdir -p "$ROOT/Business-Brain/brand-assets" "$ROOT/Emails" "$ROOT/Ads" "$ROOT/Credentials" \
  "$ROOT/Content/Talking Head" "$ROOT/Content/Long Videos" "$ROOT/Content/Raw Clips" \
  "$ROOT/Content/Photos" "$ROOT/Content/Clips" "$ROOT/Content/Ready to Post" \
  "$ROOT/Content/Before After"

while IFS='|' read -r d text; do
  [ -f "$ROOT/Content/$d/README.md" ] || echo "$text" > "$ROOT/Content/$d/README.md"
done <<'FOLDERS'
Talking Head|# Talking Head - YOU drop files here. Film yourself talking to camera on your phone and put the video in this folder. Run /cc-reeltalkinghead - it finds the video itself, cuts your ums and ahs, captions it in your brand colours, and offers to push it to GHL.
Long Videos|# Long Videos - YOU drop files here. Full-length footage you want to pull short clips out of. Webinars, treatment walkthroughs, anything long. Run /cc-find-clip and the best moment lands in the Clips folder.
Raw Clips|# Raw Clips - YOU drop files here. Short b-roll: the treatment room, your hands working, the machines, product shots, the door. Two or three seconds each is plenty. The reel skills stitch these together.
Photos|# Photos - YOU drop files here. Real photos of your clinic, your team and your treatments. Covers and carousels pull from this folder.
Before After|# Before After - YOU drop files here. Before-and-after result photo pairs, WITH your client's written consent. Name them as pairs (e.g. neck-before.jpg + neck-after.jpg). /cc-campaign-engine uses these for the proof creatives in your ad campaigns - it will never use a result photo you didn't put here.
Clips|# Clips - THE SYSTEM puts things here. The segments /cc-find-clip pulled out of your long videos. Not finished yet - run a reel skill on one and it comes out in Ready to Post.
FOLDERS

[ -f "$ROOT/Content/Ready to Post/README.md" ] || cat > "$ROOT/Content/Ready to Post/README.md" <<'R'
# Ready to Post - THE SYSTEM puts things here.

Everything it has finished for you. Every reel, cover and carousel lands in this folder,
whichever skill made it.

Two ways to use what is in here:
- Say yes when Claude offers to push it to GHL. It writes the caption and your hashtags and
  puts a DRAFT in your Social Planner. You approve it and schedule it there.
- Or grab the file yourself and post it natively - which is what you do when you want a
  TRENDING SOUND, because those only exist inside Instagram and TikTok.
R

# Credentials - keys and logins live HERE, never in prompts or content
if [ ! -f "$ROOT/Credentials/credentials-reference.txt" ]; then
cat > "$ROOT/Credentials/credentials-reference.txt" <<'CREDS'
# Your keys and logins - kept locally in this folder, nowhere else.
# Fill these in during the workshop (we do it together, screen by screen).

Anthropic API key:
GHL login email:
GHL password hint:
GHL Private Integration token (Settings > Private Integrations - shown ONCE when created):
GHL Location ID (Settings > Business Profile, or the /location/ part of your GHL URL):
Meta Business Manager login:
Booking system (Timely/Cliniko) login:
CREDS
fi

# CLAUDE.md - the rules + the contract (Claude reads this first, every time)
if [ ! -f "$ROOT/CLAUDE.md" ]; then
  if [ -f "$TEMPLATE" ]; then cp "$TEMPLATE" "$ROOT/CLAUDE.md"; echo "  + CLAUDE.md (from template)";
  else echo "  !! template not found at $TEMPLATE - add CLAUDE.md manually"; fi
else echo "  CLAUDE.md already exists - left it"; fi

# A short signpost inside Business-Brain so the empty folder is never confusing
BBREADME="$ROOT/Business-Brain/README.md"
if [ ! -f "$BBREADME" ]; then
cat > "$BBREADME" <<'EOF'
# Business Brain - your foundation lives here

These files are the spine of your whole system. Every skill reads from here.
They get created when you run the foundation skills (do this first):

1. /cc-resonance [clinic]   -> writes resonance-messaging.md
2. /cc-brand-guide [clinic] -> writes brand-guide.md

Then the system runs: content, follow-up and ads all read these and write
into ../Content, ../Emails and ../Ads. Do not rename these files.

Expected files: brand-guide.md, resonance-messaging.md, offers.md,
services-machines.md, concerns.md, team.md, strategy.md

Visual brand lives in brand-assets/ - drop these in so covers and reels
render in YOUR branding (all optional, sensible fallbacks if absent):
  brand-assets/logo.png            your logo (transparent PNG)
  brand-assets/headline-font.ttf   your headline font
  brand-assets/body-font.ttf       your body font
  brand-assets/accent.txt          your accent colour as one hex line, e.g. #C9A24B
EOF
echo "  + Business-Brain/README.md (signpost)"
fi

say "Workspace ready."
echo "Structure:"
echo "  $ROOT/"
echo "    CLAUDE.md            <- rules + contract (read first)"
echo "    Business-Brain/      <- foundation docs go here (run /cc-resonance + /cc-brand-guide)"
echo "    Content/  Emails/  Ads/   <- the system writes finished work here"
echo ""
echo "Next: open Claude Code in $ROOT, then run /cc-resonance and /cc-brand-guide to build the foundation."
