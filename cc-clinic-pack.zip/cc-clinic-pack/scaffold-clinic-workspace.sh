#!/bin/bash
# Scaffold a clinic's Claude workspace per the Business Brain File Contract.
# Creates the folder structure Claude Code works from, and drops in the clinic CLAUDE.md
# so Claude reads the rules + knows where everything lives. Run as part of setup.
# The Business-Brain/ folder starts EMPTY - it gets filled when they run /cc-resonance
# then /cc-brand-guide (foundation first). The system runs once those docs exist.
#
# Usage:  scaffold-clinic-workspace.sh [path]      (defaults to ~/Clinic)
set -euo pipefail

ROOT="${1:-$HOME/Clinic}"
TEMPLATE="$HOME/Systems/cc-aios/templates/clinic-CLAUDE.md"

say(){ printf "\n\033[1;36m%s\033[0m\n" "$*"; }

say "Scaffolding clinic workspace at: $ROOT"
mkdir -p "$ROOT/Business-Brain/brand-assets" "$ROOT/Content" "$ROOT/Emails" "$ROOT/Ads"

# CLAUDE.md - the rules + the contract (Claude reads this first, every time)
if [ ! -f "$ROOT/CLAUDE.md" ]; then
  if [ -f "$TEMPLATE" ]; then cp "$TEMPLATE" "$ROOT/CLAUDE.md"; echo "  + CLAUDE.md (from template)";
  else echo "  !! template not found at $TEMPLATE - add CLAUDE.md manually"; fi
else echo "  CLAUDE.md already exists - left it"; fi

# A short signpost inside Business-Brain so the empty folder is never confusing
BBREADME="$ROOT/Business-Brain/README.md"
if [ ! -f "$BBREADME" ]; then
cat > "$BBREADME" <<'EOF'
# Business Brain - your foundation lives here

These files are the spine of your whole system. Every skill reads from here.
They get created when you run the foundation skills (do this first):

1. /cc-resonance [clinic]   -> writes resonance-messaging.md
2. /cc-brand-guide [clinic] -> writes brand-guide.md

Then the system runs: content, follow-up and ads all read these and write
into ../Content, ../Emails and ../Ads. Do not rename these files.

Expected files: brand-guide.md, resonance-messaging.md, offers.md,
services-machines.md, concerns.md, team.md, strategy.md

Visual brand lives in brand-assets/ - drop these in so covers and reels
render in YOUR branding (all optional, sensible fallbacks if absent):
  brand-assets/logo.png            your logo (transparent PNG)
  brand-assets/headline-font.ttf   your headline font
  brand-assets/body-font.ttf       your body font
  brand-assets/accent.txt          your accent colour as one hex line, e.g. #C9A24B
EOF
echo "  + Business-Brain/README.md (signpost)"
fi

say "Workspace ready."
echo "Structure:"
echo "  $ROOT/"
echo "    CLAUDE.md            <- rules + contract (read first)"
echo "    Business-Brain/      <- foundation docs go here (run /cc-resonance + /cc-brand-guide)"
echo "    Content/  Emails/  Ads/   <- the system writes finished work here"
echo ""
echo "Next: open Claude Code in $ROOT, then run /cc-resonance and /cc-brand-guide to build the foundation."
