#!/bin/bash
# Clinic Catalyst - install your skill pack + set up your workspace. Run from inside the unzipped pack folder.
set -uo pipefail
say(){ printf "\n\033[1;36m%s\033[0m\n" "$*"; }
HERE="$(cd "$(dirname "$0")" && pwd)"

say "[1/4] Install the Clinic Catalyst skills into Claude Code"
mkdir -p "$HOME/.claude/skills"
rsync -a "$HERE/skills/" "$HOME/.claude/skills/"
echo "  installed $(ls -1 "$HERE/skills" | wc -l | tr -d ' ') skills"

say "[2/4] Set up your clinic workspace (~/Clinic)"
[ -x "$HERE/scaffold-clinic-workspace.sh" ] && bash "$HERE/scaffold-clinic-workspace.sh" "$HOME/Clinic" || mkdir -p "$HOME/Clinic/Business-Brain/brand-assets" "$HOME/Clinic/Content" "$HOME/Clinic/Emails" "$HOME/Clinic/Ads"

say "[3/4] Reel engine (for /cc-reel - needs Node; safe to skip if not installed)"
if command -v npm >/dev/null 2>&1 && [ -d "$HERE/reel-render" ]; then
  cp -R "$HERE/reel-render" "$HOME/Clinic/.reel-render" 2>/dev/null || true
  ( cd "$HOME/Clinic/.reel-render" && npm install ) >/dev/null 2>&1 && echo "  reel engine ready" || echo "  (reel deps skipped - run npm install in ~/Clinic/.reel-render before /cc-reel)"
else echo "  (Node not found - /cc-reel needs it; install Node then npm install in the reel-render folder)"; fi

say "[4/4] Done"
echo "Your skills are in ~/.claude/skills, your workspace is ~/Clinic."
echo "Next: open Claude Code in ~/Clinic and run /cc-resonance then /cc-brand-guide to build your Business Brain."
