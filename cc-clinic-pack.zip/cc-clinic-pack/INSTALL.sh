#!/bin/bash
# Clinic Catalyst - install your skill pack + set up your workspace. Run from inside the unzipped pack folder.
set -uo pipefail
say(){ printf "\n\033[1;36m%s\033[0m\n" "$*"; }
HERE="$(cd "$(dirname "$0")" && pwd)"

say "[1/5] Tools the skills need (ffmpeg + python packages)"
# The video skills (cc-assemble, cc-find-clip, cc-content-pipeline, cc-reel) use ffmpeg.
# cc-cover uses Python/Pillow. Homebrew python is PEP-668 so use --break-system-packages.
if command -v brew >/dev/null 2>&1; then
  brew install ffmpeg node >/dev/null 2>&1 && echo "  ffmpeg + node ok" || echo "  (brew install issue - the video skills need ffmpeg)"
else echo "  !! Homebrew not found - install it first (it comes with the Claude Code install guide), then re-run."; fi
python3 -m pip install --break-system-packages Pillow requests playwright >/dev/null 2>&1 && echo "  python packages ok" || echo "  !! python deps failed - cc-cover/scrape skills need Pillow+requests"
python3 -m pip install --quiet --break-system-packages mlx-whisper >/dev/null 2>&1 && echo "  mlx-whisper ok (on-device captions)" || echo "  (mlx-whisper skipped - on Intel, /cc-reel captions need an OpenAI key)"

say "[2/5] Install the Clinic Catalyst skills into Claude Code"
mkdir -p "$HOME/.claude/skills"
rsync -a "$HERE/skills/" "$HOME/.claude/skills/"
echo "  installed $(ls -1 "$HERE/skills" | wc -l | tr -d ' ') skills"

say "[3/5] Set up your clinic workspace (~/Clinic)"
[ -x "$HERE/scaffold-clinic-workspace.sh" ] && bash "$HERE/scaffold-clinic-workspace.sh" "$HOME/Clinic" || mkdir -p "$HOME/Clinic/Business-Brain/brand-assets" "$HOME/Clinic/Content" "$HOME/Clinic/Emails" "$HOME/Clinic/Ads"

say "[4/5] Reel engine (for /cc-reel)"
if command -v npm >/dev/null 2>&1 && [ -d "$HERE/reel-render" ]; then
  cp -R "$HERE/reel-render" "$HOME/Clinic/.reel-render" 2>/dev/null || true
  ( cd "$HOME/Clinic/.reel-render" && npm install ) >/dev/null 2>&1 && echo "  reel engine ready" || echo "  (reel deps skipped - run npm install in ~/Clinic/.reel-render before /cc-reel)"
else echo "  (Node not found - /cc-reel needs it; install Node then npm install in the reel-render folder)"; fi

say "[5/5] Done"
echo "Your skills are in ~/.claude/skills, your workspace is ~/Clinic."
echo "Next: open Claude Code in ~/Clinic and run /cc-resonance then /cc-brand-guide to build your Business Brain."
