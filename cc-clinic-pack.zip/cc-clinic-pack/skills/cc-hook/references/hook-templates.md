# Hook Template Bank (clinic-safe)

Organised by stopping-power element. Fill in the blanks with the clinic's concept, voice, and real proof. Best hooks combine 2-4 templates. Every template here is concern-led and stays inside the AHPRA gate - keep it that way when you fill the blanks. No outcome promises, no superlatives, no "safe / painless / best / expert", no "Botox" (use "anti-wrinkle"). Australian English, no emdashes, italics not bold.

## Curiosity (56% of scroll-stopping content)
- "Why nobody talks about ___ when it comes to ___ skin"
- "The thing about ___ that most people get wrong"
- "What is actually going on when your skin ___"
- "You will look at ___ differently after the next 30 seconds"
- "The reason your ___ keeps coming back"
- "What we wish more people knew about ___"
- "Why ___ is more common than you think"

## Concern / Pain (39%)
- "If your skin feels ___, you are not imagining it"
- "___ that never seems to fully clear?"
- "Tired of ___ every winter?"
- "Struggling with ___ and not sure where to start?"
- "If ___ has been bothering you, here is what to look at first"
- "The ___ concern we hear about most"
- "Noticing more ___ lately? Here is why that happens"

## List Format (28%)
- "___ things to know about ___ before your next treatment"
- "___ signs your skin might be telling you about ___"
- "___ things winter does to your skin"
- "___ questions to ask at a skin consult"
- "___ everyday habits that affect ___"

## Timeliness / Seasonal (20%)
- "Why ___ flares up every winter (and what helps)"
- "Heading into summer? Here is what ___ skin needs"
- "Post-summer ___ is showing up - here is what to look at"
- "This time of year is when ___ tends to ___"
- "What your skin needs as the seasons change"

## Authority - the clinic's REAL proof (17%)
Use only what is documented in brand-guide.md / team.md / services-machines.md. Never "specialist", "expert", or "best".
- "After ___ years working in skin, here is what we see most"
- "Our team has a special interest in ___ - here is what we look for"
- "We run a ___ [named machine/device, only if true] - here is how it works"
- "What our experienced nurse looks at in a ___ consult"
- "Trained in ___, here is what we wish every client knew about ___"

## Deep Desire - feelings, never appearance guarantees (14%)
- "Wanting to feel more comfortable in your skin this ___?"
- "What it feels like to finally have a plan for your ___"
- "Imagine a skincare routine that actually fits your skin"
- "For anyone who just wants to feel good in their own skin"

## Time Frame - applied to the content, not a result (9%)
- "In 60 seconds: what causes ___ and what to look at"
- "A quick guide to ___ before your next appointment"
- "Everything you need to know about a ___ consult, in one minute"

## Beginner Friendly (8%)
- "New to skin treatments? Start here"
- "Never had a skin consult? Here is what happens"
- "If you are not sure where to begin with ___, this is for you"
- "A simple first step if ___ has been on your mind"

## Refuting Objections - never "safe / painless / no risk" (5%)
- "Nervous about your first ___ consult? Here is what to expect"
- "Not sure if ___ is right for you? Here is how we work that out"
- "Think you have to live with ___? Let us talk through your options"
- "Worried it is too much? A consult is just a conversation about your skin"

## Question Open (the strongest concern-led format)
- "Why does my ___ keep coming back?"
- "What actually causes ___?"
- "Is ___ something you can do anything about?"
- "What happens at a skin consult, anyway?"

---

## Combination Examples (strongest hooks)

*Curiosity + Concern + Authority:*
"Congestion that never fully clears? After years in skin, here is the cause we see most."

*Seasonal + List + Beginner Friendly:*
"3 things winter does to your skin - and a simple first step if you are not sure where to start."

*Concern + Question Open + Time Frame:*
"Tired of dry winter skin? Here is what is actually going on, in 60 seconds."

*Concern + Authority + Refuting Objections:*
"If pigmentation has been bothering you since summer, a consult is just a conversation - here is what we look at."
