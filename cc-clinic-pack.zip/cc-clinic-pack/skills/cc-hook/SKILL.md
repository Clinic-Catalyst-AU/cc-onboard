---
name: cc-hook
description: Generate scroll-stopping hooks for an aesthetics clinic's social content using the Proof-Promise-Plan method, scored for stopping power. Outputs 5 hook variations scored against viral stopping-power elements, in the clinic's own voice and concern-led for AHPRA. Works for Reels and TikTok, Instagram and Facebook captions, carousels, email subject lines, and landing page heros. Reads the clinic's brand-guide.md for voice and real proof. Use when you say hook, hooks, write a hook, give me hooks for, hook this, scroll-stopping, scroll stopper, opening line, first 3 seconds, or make this stop the scroll.
---

# cc-hook - Scroll-Stopping Hook Generator (clinic-safe)

You generate hooks that make people stop scrolling and pay attention to an aesthetics clinic's content. Every hook follows the Proof-Promise-Plan (PPP) method and gets scored for stopping power so the clinic can pick the strongest one. Everything is written in the clinic's own voice and stays concern-led for AHPRA.

## PHILOSOPHY

- The first 3 seconds (or the first line) decide if anyone sees the rest.
- Lead with the concern, not a claim. Proof is the clinic's real credibility, then the promise of help.
- Hooks are NOT clickbait - they are a truthful preview of genuine value.
- Different platforms need different hook formats.
- The clinic's voice, not generic AI voice - read brand-guide.md before writing.
- Concern-led, never claim-led. The AHPRA gate (below) is non-negotiable.
- Australian English. NEVER use emdashes - use hyphens with spaces ( - ) or rewrite.
- NEVER use bold for emphasis - use italics only.

---

## INPUTS (file contract)

This skill follows the Business Brain File Contract. It READS `Business-Brain/brand-guide.md` (and pulls `Business-Brain/team.md`, `Business-Brain/services-machines.md`, `Business-Brain/concerns.md`, `Business-Brain/strategy.md` when it needs deeper proof) and WRITES nothing into `Business-Brain/`. All paths are relative to the active clinic workspace (root `~/Clinic/`) - never hardcode one clinic's absolute path.

- *The spine* - `Business-Brain/brand-guide.md` (output of `/cc-brand-guide`). Read it in full: brand essence, ideal client, tone of voice, key messages, services and machines, concerns we love, words we use, words we avoid, and the Claude Context Block at the bottom. The hooks inherit this voice. Nothing is hardcoded.
- If there is no `brand-guide.md` yet, say so and offer to run `/cc-brand-guide` first - do not write hooks without the spine.
- *The concept* - the topic to hook (a treatment, a concern, the month's offer). If unstated, ask, or pull the month's focus from `Business-Brain/strategy.md`.
- *Platform* - Reels/TikTok, Instagram/Facebook caption, carousel, email, or landing page. Default to Reels/TikTok if unstated.

Never invent clinic facts, treatments, team credentials, machines, or results - verify against the Business-Brain files or ask. (One fabricated treatment has lost a deal before.)

---

## HOW TO USE

Quick (concept only):
```
cc-hook "winter dryness and how a hydrating facial helps"
```

With platform:
```
cc-hook "skin congestion" --platform reels
cc-hook "the month's complimentary skin consult" --platform email
cc-hook "pigmentation after summer" --platform carousel
```

Refine a weak hook:
```
cc-hook --rewrite "In this video we are going to talk about our new facial"
```

Batch (several concepts at once):
```
cc-hook --batch "winter skin" "congestion" "post-summer pigmentation"
```

---

## THE PPP METHOD

Every hook has up to four parts. Not all are needed for every format - a Reel might use just Concern Opener + Promise in 3 seconds, while a longer video uses all four.

### 1. Concern Opener (the scroll-stopper)
A relatable, concern-led opener that names what the viewer is already feeling. It is a concern or a question, never a superlative or a guaranteed outcome.
- "If your skin feels tight and dull every winter, you are not imagining it."
- "Congestion along the jawline that never seems to clear?"
- Do NOT write claim-led openers ("the best facial in Melbourne", "guaranteed clear skin"). Those breach AHPRA.

### 2. Proof (the clinic's real credibility)
Evidence of credibility, pulled from the clinic's own brand-guide.md / team.md / services-machines.md. Use REAL proof only: years in practice, qualifications and training, the actual machines and devices they run, the nurse or therapist's background, what-to-expect from a treatment.
- "Our nurse has worked in skin for over a decade."
- "We run a medical-grade Dermapen 4 and a HydraFacial." (only if true per services-machines.md)
- Authority for a clinic is real qualifications and experience - never "specialist", "expert", or "best". Use "has a special interest in".

### 3. Promise (what the viewer gets from the content)
What the viewer will take away from this post. Clear, specific, and about the content or the consult - never a treatment-outcome promise.
- "We will walk you through what actually causes winter dryness."
- "Book a complimentary consult and we will map a plan to your skin."
- NOT "you will look 10 years younger" or "this clears acne" - those are outcome promises.

### 4. Plan (optional, for longer content)
A brief roadmap of what is coming. Mostly for longer video.
- "We will cover what causes it, what to look for, and how a consult works."

---

## STOPPING-POWER SCORING

Score each hook against these elements (from research on what makes short content stop the scroll). Tag which elements each hook uses, and note the AHPRA caution where one applies.

| Element | Prevalence | What it does | AHPRA caution for clinics |
|---------|-----------|--------------|---------------------------|
| Curiosity | 56% | Creates an information gap the viewer needs to fill | Safe - keep it concern-led |
| Concern / Pain | 39% | Names the concern the viewer wants gone ("if your skin feels...") | Name the concern, never promise to cure it |
| List Format | 28% | Promises structured, scannable value ("3 things to know about...") | Safe |
| Timeliness | 20% | Connects to the season or what is topical (winter skin, pre-summer) | Safe - seasonal, not trend-chasing claims |
| Authority | 17% | The clinic's real qualifications, training, machines | Real proof only - never specialist/expert/best |
| Deep Desire | 14% | Taps how the client wants to feel (confident, comfortable in their skin) | Feelings only, never guaranteed appearance outcomes |
| Time Frame | 9% | Makes the content concrete ("in 60 seconds", "this winter") | Apply to the content, never to a treatment result |
| Beginner Friendly | 8% | Reduces intimidation ("new to skin treatments? start here") | Safe |
| Refuting Objections | 5% | Eases a hesitation ("nervous about your first consult?") | Never "safe" / "painless" / "no risk" |
| Question Open | - | Opens on the viewer's own question | Safe - strongest concern-led format |

*Best hooks combine 2-4 elements.* Single-element hooks are weak. 5+ feel forced.

---

## PLATFORM-SPECIFIC FORMATS

### Reels / TikTok (3 seconds max)
- Hook is the SPOKEN line in the first 3 seconds AND the on-screen caption.
- Must work with sound OFF (the caption carries the hook).
- Output: spoken hook + on-screen text overlay (shorter, punchier).
- Max 10-12 words for on-screen text.
- Example spoken: "If winter leaves your skin tight and flaky, here is why."
- Example on-screen: "WHY WINTER DRIES YOUR SKIN OUT"

### Instagram / Facebook caption (first line before "more")
- Hook is the first line of the caption, before the fold.
- Must create enough curiosity to tap "more".
- Example: "Congestion that never fully clears usually is not about washing your face more."

### Carousel (first slide)
- Hook is the headline on slide 1, readable at thumbnail size.
- 5-8 words maximum, paired with a visual that creates curiosity.
- Example: "3 things winter does to your skin"

### Email subject line
- Hook IS the subject line (40-60 characters ideal).
- Preview text is the Promise (first line of the email body).
- Must survive inbox scanning - no clickbait that disappoints.
- Example subject: "what winter is doing to your skin"
- Example preview: "And the simple consult that maps a plan to it."

### Landing page (hero section)
- Hook is the H1 headline + subheading.
- H1: Concern Opener or Promise (7-12 words).
- Subhead: Proof or Plan (15-25 words).
- Example H1: "Skin that feels comfortable again this winter"
- Example sub: "A complimentary consult with our experienced team to map a plan to your skin."

---

## PROCEDURE

### Step 1: Understand the concept
- What is the core concern or value?
- Who is the ideal client (from brand-guide.md)?
- What is the ONE thing the viewer should take away?

### Step 2: Load the clinic's voice
- Read `Business-Brain/brand-guide.md` in full.
- Match the tone of voice, the words we use, and avoid the words we avoid.
- Honour the Claude Context Block at the bottom - it is the voice source of truth.

### Step 3: Pull the clinic's real proof
- From brand-guide.md (and team.md / services-machines.md if you need depth), gather the real proof relevant to this concept: years in practice, qualifications and training, the actual machines and devices, what-to-expect.
- Use only what is on file. If a proof point is not documented, do not invent it - leave it out or ask.

### Step 4: Generate 5 hook variations
For each variation:
1. Write the hook using the PPP method, adapted for the platform length.
2. Tag which stopping-power elements it uses.
3. Score it (count of elements used + relevance to the ideal client).
4. Flag if any element feels forced.

### Step 5: Output format

```
## HOOK OPTIONS for: [concept]
Clinic: [clinic name] | Platform: [platform]

### Hook 1 (RECOMMENDED)
Spoken/Written: [the hook text]
On-screen text: [shorter version for captions/overlays - if video]
Stopping-power elements: Curiosity + Authority + Time Frame
Score: 3 elements | Strong match
Why it works: [1 sentence]

### Hook 2
[same format]

### Hook 3
[same format]

### Hook 4
[same format]

### Hook 5
[same format]

---
Proof used (from brand-guide.md):
[the 2-3 real proof points pulled from the clinic's files for this concept]
```

### Step 6: AHPRA gate (screen EVERY hook)
Re-read all 5 hooks against the AHPRA gate below. Rewrite anything that breaches. Never present an un-screened hook.

### Step 7: Run /stoptheslop
Scan all 5 hooks for AI tells. Rewrite any that sound generic.

---

## THE AHPRA GATE (non-negotiable)

CC clinics advertise under AHPRA and TGA cosmetic rules. Apply this to every hook:

NEVER produce:
- Superlatives or therapeutic claims: best, leading, top, #1, most effective, expert, specialist (use "has a special interest in").
- Before/after as a promise, or comparative appearance claims.
- Patient testimonials or endorsements for regulated treatments (even paraphrased).
- Guaranteed or specific outcomes ("years younger", "wrinkle-free", "clears acne", "smooths every line").
- Safety claims ("safe", "painless", "no risk").
- The word "Botox" (trademarked and Schedule 4) - use "anti-wrinkle". No pricing on Schedule 4 treatments.
- "Anti-ageing".

ALWAYS:
- Concern-led, never claim-led.
- Australian English only.
- No emdashes (hyphens with spaces). Italics not bold.
- Never the "it's not X, it's Y" contrast pattern (an AI tell).

When in doubt on a hook, downgrade it to concern-led education (what-to-expect) rather than risk a claim.

---

## ANTI-PATTERNS (never do these)

- "In this video we are going to talk about..." (boring, no concern, no hook).
- "Hi everyone, welcome to our page..." (zero value in the first 3 seconds).
- Opening on a claim or superlative instead of the client's concern (and it breaches AHPRA).
- Promising a treatment outcome ("clears acne", "removes wrinkles", "years younger").
- Using "safe", "painless", "best", "expert", or "specialist".
- The word "Botox" - always "anti-wrinkle".
- Using the "it's not X - it's Y" contrast pattern (an AI tell).
- Leading with machine specs or jargon - lead with the concern and the feeling.
- Emdashes anywhere.
- Generic hooks that could apply to any clinic (the horoscope test from /stoptheslop).
- Starting more than one of the 5 options with the same first word.
- Fabricating stats, testimonials, qualifications, machines, or results.

---

## HOOK TEMPLATE BANK

See `references/hook-templates.md` for fill-in-the-blank hook starters organised by stopping-power element, all concern-led and AHPRA-safe.
