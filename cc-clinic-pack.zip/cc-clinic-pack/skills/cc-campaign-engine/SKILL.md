---
name: cc-campaign-engine
description: The Clinic Catalyst campaign generator - drop ALL your campaign assets (videos, images, offer details) into a Campaign_Drop folder and get back a full Meta campaign, 15 creatives (stills, carousels, reels) with AHPRA-safe copy, presented on a branded review dashboard with download and copy buttons ready to load straight into one Meta flexible ad. Renders the framework's proven ad template layouts (offer circles, header bars, tick checklists, colour blocks) re-skinned with your clinic's colours, fonts, text, and media. Use when the user says campaign engine, generate a campaign, ad generator, 15 creatives, build my ads, or wants a full Meta ad campaign generated from their own footage.
---

# Campaign Engine

One command in, full campaign out. The review dashboard at the end is the deliverable.

## THE DESIGN CONTRACT (never violate)
The template LAYOUTS are fixed - offer circles, header bars, checklists, banner blocks
stay in their proven positions and proportions (see `references/TEMPLATE-SPEC.md`).
What swaps per clinic: text, colours, fonts, and the clinic's own photos/videos in the
media zones. You are a renderer of a proven system, not a designer.

## THE CAMPAIGN TRUTH
This is ONE ad, not 15. One campaign, one offer, one booking destination, one lead form -
the 15 creatives are the asset pool Meta's Andromeda tests to find what converts. All 15
share the SAME offer, price, link, and lead form; what varies is angle + format.

## INPUTS (gather before generating anything)
1. MEDIA - two sources, in priority order:
   a. THE CAMPAIGN DROP - `Campaign_Drop_<name>/` at the TOP of the clinic workspace
      (e.g. `~/Clinic/Campaign_Drop_Jawline_Special/`) - visible right next to Content
      so it's impossible to miss in Finder. Create it with the SAME four subfolders as
      the Content library (`Talking Head/`, `Raw Clips/`, `Photos/`, `Before After/`)
      so there is ONE mental model for what goes where - same folders, campaign-only
      media. Media here was filmed FOR this offer, so it always wins over library media.
      SELECTION LOGIC (run this first, every time):
      - Scan the workspace root for `Campaign_Drop_*` folders.
      - NONE found → ask the campaign/offer name, CREATE `Campaign_Drop_<name>/` with
        a README ("media filmed for this campaign only - used first"), tell them the
        path, and offer: drop files in now, or run straight from the Content library.
      - EXACTLY ONE → use it automatically; confirm its name matches the offer being
        run ("Building from Campaign_Drop_Jawline_Special - that the one?").
      - MORE THAN ONE → list them and ASK which campaign this run is for. Never guess.
      When the campaign is finished and approved, offer to move the drop folder into
      `Ads/Campaign_<name>/` so the campaign archive (Drop + creatives + copy +
      dashboard) lives together. Never delete a drop folder.
   b. THE EVERGREEN LIBRARY - the clinic's existing workspace folders, recyclable
      across every engine, used to fill whatever the campaign Drop doesn't cover:
      - `Content/Talking Head/` - person to camera (feeds the UGC banner reel)
      - `Content/Raw Clips/` - short b-roll: treatment, device, reception, product
      - `Content/Photos/` - stills: treatment shots, clinic, staff
      - `Content/Before After/` - paired result images (consent required) - CREATE
        with a README if missing
      - `Business-Brain/brand-assets/` - logo, fonts
   Fallback for non-standard installs: any folder of loose files - AUTO-CLASSIFY via
   ffprobe duration + extracted frames (LOOK at them) + audio transcription. Person
   facing camera + continuous speech = talking head; short clip, no meaningful
   speech = b-roll; paired same-area stills = before/after.
   Tag everything by treatment type + body area + shot type before generating.
2. The clinic's Business Brain / brand-guide.md - colours (hex), fonts, voice, concerns.
3. The offer - treatment name (outcome-led), real price + true anchor, inclusions,
   scarcity, and the clinic's REAL booking link / lead capture destination.
   If any of these are missing, ask ONCE for the lot - never invent prices, anchors,
   or claims.

## COPY METHOD (RUN THE SKILL, don't imitate it)
Copy generation = actually running /cc-metaad-builder for the campaign's offer. That
produces the full Campaign Details contract: 5 headline options, 5 neuro-emotive hooks,
5 COMPREHENSIVE primary text variants (Andromeda-friendly, full value stack),
5 descriptions, best CTA + conversion triggers - all AHPRA-screened, outcome-led.
Never write ad copy freehand in this engine.
Then PAIR the pool across the 15 creatives: each creative gets one headline + one primary
variant matched to its angle (concern-hook creative gets a pain hook variant, objection
killer gets the mechanism-led variant, closer gets urgency). All variants feed the same
flexible ad - Andromeda tests copy x creative combinations.
On-image text (checklist ticks, badge, banner lines) derives from the same output -
short forms of the value stack and concern lines, never new claims.
Every line (on-image AND ad copy) passes the AHPRA gate: no guaranteed results, genuine
benefits only, pricing on non-S4 only, before/afters only clinic-supplied with consent.

## CAMPAIGN STRUCTURE - generate SETS, not one-offs
The template library works as ~5-angle sets per offer:
1. Concern hook ("GOODBYE TURKEY NECK")
2. Mechanism / checklist (4 ticks + price badge)
3. Proof (before/after pair if supplied, else strongest treatment shot)
   BEFORE/AFTER PLACEMENT RULES (never violate): a before/after NEVER appears on the
   FIRST screen/frame of any creative - it lives on the SECOND screen of a video, and
   it either flashes briefly (~1-2s) or occupies a SMALL inset of the frame, never
   full-bleed as the opener. Statics built around a before/after are the exception
   (max ONE per campaign, clearly disclaimed) - everything else shows results in
   motion, briefly, mid-sequence.
4. Objection killer ("Minimal Downtime", "Safe Around Eyes")
5. Urgency + closer ("Last Chance! Only 5 Left" / reception BOOK NOW with clinic signage)

Default 15-creative mix - ANIMATED-FIRST (the top-performing real ads are mostly
motion; only a couple of stills per campaign):
- ~4-5 statics across the static DNAs (max 1 built around a before/after)
- ~5-6 animated statics/motion ads - single-scene motion: a b-roll clip or Ken Burns
  photo under the static DNA overlays (checklist, badge, banner rendered over moving
  footage - same layouts, alive)
- ~2-3 assembly reels - b-roll cut to the Ritual / Checklist Build DNAs (~4s/screen);
  before/after appears as a brief flash or small inset on screen TWO, never screen one
- ~1-2 talking-head reels - educational, UGC banner DNA
- ~1 carousel (via /cc-carousel with the same copy)
Never pad with stock or AI-generated people. Short on media = fewer creatives +
"needs media: film this" flags (which double as the clinic's phone shot list), never filler.

## MEDIA-TO-CAMPAIGN MATCHING (never violate)
The image/video in each creative MUST match that campaign's offer - neck footage for a
neck offer, IPL-in-progress for an IPL offer, reception/signage only for closer frames.
Select per creative from matching tags only. No appropriate media = FLAG it, never
substitute an unrelated photo.

## RENDERING
Statics: `engine/render_static.py job.json` - templates: `checklist`, `colourblock`
(supports `ribbon`), `editorial`, `photo_panel` (photo top + tick panel below +
straddling badge), `banner_save` (soft tinted saving banner + full-bleed photo),
`strip3` (3-photo strip + labelled checklist + price band; media is a LIST of 3).
Brand tokens + text + media path in, 1080x1350 (or 1080x1080) PNG out.

TEMPLATE VARIETY (hard rule): a campaign must look like a creative TEAM made it.
NEVER use the same template layout more than TWICE across a campaign's statics.
Rotate through the library (checklist, photo_panel, banner_save, colourblock,
colourblock+ribbon, strip3, editorial, the before/after proof stack) and VARY the
badge position and pairing per creative. Carousel slides are the one exception -
slides within one carousel should share a consistent layout.
Reels: `engine/render_reel.py reel-job.json` - screens of ~4s each, styles `ritual`,
`checklist` (ticks accumulate screen to screen), `banner` (persistent offer banner).
Clips fill each screen; still images get an automatic Ken Burns zoom so photo-only
clinics still get motion. Talking-head captions: transcribe locally (whisper) and pass
each spoken line as the `caption` of its screen.
SOUND: reels perform better with audio - add a music/ambience bed via the job's
`music` key ({"file": path, "volume": 0.35}). ROYALTY-FREE tracks only (commercial
music in ads = rights strikes) - the clinic drops theirs in `Business-Brain/
brand-assets/` or the campaign drop. Volume ~0.35-0.5 for non-speech reels (check
mean_volume lands around -20 to -28dB; quiet source tracks need 1.5-2.5), ~0.12
under talking heads so speech stays clear.
STRATEGIC POSITIONING: LOOK at every photo first - set `text_side` and `media_x_bias`
so text sits in the clear zone, never over a face. LOOK at every render before accepting:
text fits, badge clear of faces, crop keeps the subject. Re-render until right.
No generation APIs needed - Pillow + ffmpeg + local whisper only, all on this machine.

## COPY FORMATTING - paste-ready, always
Headline and primary text are handed over EXACTLY as they go into Meta Ads Manager:
- Headline: plain text, <= 40 chars target, no markdown
- Primary text: plain text with real line breaks, emoji bullets (🔥 ✔) where the value
  stack calls for them, hook on the first line
- Description: <= 30 chars target
- CTA: the Meta button label + the clinic's REAL booking link, verified live before it
  goes on the dashboard

## LEAD FORM (one per campaign)
Run /cc-fb-leadform ONCE per campaign. Meta lead form FIELDS are fixed: Name, Phone,
Email prefill only - never add custom questions (friction kills form-to-submit
conversion). The skill's job is the form COPY: the form headline and description are
where conversion is won - same neuro-emotive level as the ad copy, restating the offer
+ anchor + what happens next, plus privacy line and thank-you screen. It appears on the
dashboard as its own card - the single destination every creative drives to.

## DESCRIPTION QUALITY BAR
The ad description field (<= 30 chars) must hit neuro-emotive punch on EVERY creative -
"No needles. No downtime." is the bar. Short objection-kill or desire fragments from
the model, never filler like "Book today" or the treatment name repeated.

## OUTPUT + DASHBOARD
Save under `Ads/Campaign_<offer>_<date>/` in the clinic's workspace, in EXACTLY this
structure - the folder must be legible at a glance, never a flat dump:
- `campaign-dashboard.html` + `campaign.json` at the top (the thing they open + manifest)
- `Creatives/` - the finished assets only (numbered PNGs + MP4s the dashboard shows;
  creative `file` paths in campaign.json are `Creatives/<name>`)
- `Copy/` - the campaign sheet .xlsx + .csv from the metaad-builder run
- `_working/` - frames, reel job files, intermediates (leading underscore, out of sight)
Nothing loose in `Ads/` itself - every file belongs to a campaign folder.
Build the dashboard with `engine/make_dashboard.py campaign.json` - a branded review
page with, per creative: the visual (reels playable inline), DOWNLOAD button (exact
final file), per-field COPY buttons + "Copy all campaign copy", AHPRA badge, any
"needs media" flags, the lead form card, and a "Load into Meta" strip explaining:
1 campaign → 1 ad set → one flexible ad carrying these assets → Andromeda finds the
winners. Open it in the browser. That dashboard IS the deliverable - make it gorgeous.
The strip also links two helpers (baked into make_dashboard.py - keep them):
- "Plug Claude into your ad account" → the read-only Meta connector guide at
  clinic-catalyst-au.github.io/workshop-toolkit/advertising-system.html#connect
- the full advertising system page (campaign engine demo video lives there)

## VERIFY BEFORE REPORTING DONE
- Every creative visually checked (open the images, play the reels)
- Copy AHPRA-screened, prices match the clinic's real offer, booking link verified
- Dashboard opens, every asset loads, every copy button works
- Report as SHIPPED only when the files exist and the dashboard renders
