# Ad Template Layout Spec (clinic-clean)

The framework's proven Meta ad layouts, captured from top-performing aesthetics
campaigns. The engine renders these EXACTLY - layouts fixed, brand tokens + text +
media swapped per clinic.

## VIDEO DNA 1 - "Luxury Ritual Reel" (6 x ~4s screens)
Spaced-out letter-tracked caps + elegant serif sub-line over clinic footage,
thin-outline circular offer badge bottom-right.
Screen arc: HOOK (treatment name + 3-word tagline + offer badge) → HOOK variant
(different footage/badge) → PROCESS step name → BENEFIT outcome → BENEFIT outcome →
CTA "BOOK NOW!" over reception footage.

## VIDEO DNA 2 - "Checklist Build Reel" (8 x ~4s screens)
Header bar + tick checklist that ACCUMULATES one line per screen over device footage.
Arc: hook + price badge → 4 checklist-build screens (concerns in patient language) →
offer screen (logo + outcome-led treatment name + intro badge) → 2 brand-close screens
(logo + positioning line over soft b-roll).

## VIDEO DNA 3 - "UGC Banner Reel" (~6 x 4s screens)
Talking-head educational video with a PERSISTENT top banner (treatment name serif +
"ONLY $X" gold spaced caps) and spoken-word caption pills bottom. Optional
before/after insets. Script arc: problem callout → one-device solution → mechanism →
mechanism benefit → price anchor → save + book now.

## STATIC DNA 1 - "Soft Editorial" (4 layouts)
Muted palette, full-bleed photo, serif headline over a soft top gradient, circular
offer badge in a corner. Variants: logo + before/after collage + benefit strip;
full-bleed face + headline + strikethrough badge; framed before/after + month offer.

## STATIC DNA 2 - "Checklist Library" (the workhorse, 30 reference layouts)
Formula: full-width header bar (outcome-led treatment name) + 4 tick benefit
checklist + photo + circular badge with strikethrough anchor ("$399 ONLY $160
Limited Time"). Colour theme swaps per brand.
Campaigns ship as SETS of ~5 angles per offer: concern hook → mechanism/checklist →
proof (before/after) → objection killer ("Minimal Downtime", "Safe Around Eyes") →
urgency closer ("Last Chance! Only 5 Left") + a reception BOOK NOW frame using the
clinic's own signage footage.

## STATIC DNA 3 - "Colour-Block Banner" (12 layouts)
Bold two-colour diagonal system: top banner headline, angled bottom-left treatment
block + bottom-right SAVE/price block, circular scarcity badge top-right ("Only 10
Discounted Packages"), diagonal "SALE ENDS MONDAY" ribbon variant, 3-photo strip +
TONE/ELASTICITY/TEXTURE checklist variant, "This is NOT just a Facial" reframe.

## MOTION GRAMMAR (measured from the top-performing finished renders)
- Screens run ~3s (2-3.5s), joined with ~0.5s CROSSFADES - never hard cuts
- Overlay text FADES/SLIDES in over ~0.45s at each screen start - never pops
- Checklist reels: ticks accumulate one at a time (~1.2-2.5s apart) WITHIN one
  continuous shot (render_reel `clip_start` pulls sequential chunks of the same clip)
- Talking-head ads: persistent offer banner all the way through + caption pill per
  spoken line + a device/treatment CUTAWAY mid-video while captions carry the story
- BEFORE/AFTER = a timed small INSET (`ba_inset`, ~44-46% width, beside the subject,
  white frame + BEFORE/AFTER labels) that fades in for 3-4s then leaves - used ~twice
  per talking-head ad (concern moment + price moment), NEVER the opening frame,
  NEVER full-screen
- Every reel closes on either a reception/logo shot or a full-bleed END CARD
  ("BOOK NOW / SAVE $X" + brand line) of ~4-5s
- Brand-close variant: soft botanical b-roll + logo + bottom caption bar with the
  positioning line
- B/A SHOWCASE loop (~7s animated static, reel style `ba_showcase`): BLURRED soft
  video underlay (warm botanical/texture footage) playing throughout + logo top +
  outlined offer badge top-right (fades in, HOLDS) + framed BEFORE panel pops
  upper-left (~0.7s) then framed AFTER pops lower-right overlapping (~1.4s) - both
  HOLD to the end - + persistent branded colour banner bottom with the concern line.
  The highest-converting proof format: motion + held proof + offer in one loop.

## THE REPEATED DNA (what gets parameterized)
- Headline: PROBLEM or OUTCOME + OFFER in patient language - never device-led
  (device appears only as mechanism/quality proof)
- Benefit checklist: 4 ticks, concern-led, mirroring what patients type into Google
- Offer badge: circular, strikethrough anchor + ONLY $X + "Limited Time"
- Scarcity: "Only N packages", "Sale ends Monday", month-named specials
- CTA: Book Now / Claim Your Offer pill
- ALL type, colours, badges = clinic brand tokens, NOTHING hardcoded
- Video screens average ~4 seconds each

## AHPRA NOTES
Source layouts include claim-style lines and before/afters. The engine must run every
generated line through the AHPRA gate (concern-led phrasing, non-guaranteed benefits,
pricing on non-S4 only) and use before/afters only when clinic-supplied with consent.
