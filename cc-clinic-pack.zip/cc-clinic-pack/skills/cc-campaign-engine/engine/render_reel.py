#!/usr/bin/env python3
"""
CC Campaign Engine - reel renderer v2 (motion grammar from the reference renders).

Motion language encoded from the top-performing ad renders:
- ~3s screens joined with 0.5s CROSSFADES (not hard cuts)
- overlay text FADES IN over ~0.45s at each screen start
- tick checklists ACCUMULATE within one continuous shot (use clip_start to pull
  sequential chunks of the SAME clip across screens)
- before/after appears as a timed small INSET (ba_inset) - flashes in beside the
  subject, never full-screen, never on the first frame
- talking-head audio is PRESERVED (crossfaded); assembly reels stay silent
- closer can be a full-bleed END CARD ("BOOK NOW / SAVE $X" + logo line)

Usage: python3 render_reel.py reel-job.json

reel-job.json:
{
  "out": "...mp4", "size": [1080, 1350], "fps": 30,
  "crossfade": 0.5,                  // 0 = hard cuts
  "brand": { ...tokens... },
  "screens": [
    {"clip": "path.mp4|jpg", "clip_start": 0, "duration": 3, "style": "ritual",
     "audio": true,                  // keep this clip's own audio (talking head)
     "text": {...},
     "ba_inset": {"before": "b.png", "after": "a.png",   // optional timed flash
                  "start": 1.0, "dur": 3.0, "width": 0.46, "y": 0.18}},
    {"style": "endcard", "clip": "photo.jpg", "duration": 4,
     "text": {"lines": ["BOOK NOW", "SAVE $150"], "sub": "The Glow Reset",
              "logo_line": "LUMIERE SKIN & BODY"}}
  ]
}
"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).parent))
from render_static import (find_font, hex_rgb, spaced, draw_centred,  # noqa: E402
                           draw_checklist, draw_price_badge)

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".avi", ".webm", ".mkv"}


def overlay_ritual(d, img, W, H, brand, text):
    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.rectangle([0, 0, W, H], fill=(0, 0, 0, 62))
    img.alpha_composite(shadow)
    d = ImageDraw.Draw(img)
    f_main = find_font(brand["font_sans"], 46)
    f_sub = find_font(brand["font_serif"], 40)
    y = int(H * 0.16)
    for ln in text.get("lines", []):
        draw_centred(d, W / 2 + 2, y + 2, spaced(ln.upper()), f_main, (20, 15, 10))
        draw_centred(d, W / 2, y, spaced(ln.upper()), f_main, hex_rgb(brand["cream"]))
        y += 78
    if text.get("sub"):
        draw_centred(d, W / 2 + 2, y + 10, text["sub"], f_sub, (20, 15, 10))
        draw_centred(d, W / 2, y + 8, text["sub"], f_sub, hex_rgb(brand["cream"]))
    if text.get("badge"):
        b = text["badge"]
        r = 140
        cx, cy = W - r - 70, H - r - 110
        d.ellipse([cx - r, cy - r, cx + r, cy + r],
                  outline=hex_rgb(brand["cream"]), width=4)
        f_l = find_font(brand["font_serif"], 40)
        f_p = find_font(brand["font_serif"], 64)
        draw_centred(d, cx, cy - 66, b.get("label", "Intro Offer"), f_l,
                     hex_rgb(brand["cream"]))
        draw_centred(d, cx, cy - 8, b.get("price", ""), f_p, hex_rgb(brand["cream"]))
    return img


def overlay_checklist(d, img, W, H, brand, text):
    d = ImageDraw.Draw(img)
    if text.get("header"):
        f = find_font(brand["font_sans"], 40)
        bar_h = 90
        d.rectangle([0, 0, W, bar_h], fill=(*hex_rgb(brand["accent"]), 235))
        draw_centred(d, W / 2, 24, spaced(text["header"].upper()), f,
                     hex_rgb(brand["accent_text"]))
    if text.get("ticks"):
        panel = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        pd = ImageDraw.Draw(panel)
        ph = 50 + len(text["ticks"]) * 56 + 26
        pd.rectangle([0, 110, int(W * 0.68), 110 + ph], fill=(255, 255, 255, 140))
        img.alpha_composite(panel)
        d = ImageDraw.Draw(img)
        draw_checklist(d, 50, 156, text["ticks"], brand, hex_rgb(brand["dark"]))
    if text.get("badge"):
        b = text["badge"]
        draw_price_badge(img, d, (W - 220, H - 240), 150, brand,
                         b.get("anchor", ""), b.get("price", ""),
                         b.get("label", "Limited Time"))
    return img


def overlay_banner(d, img, W, H, brand, text):
    d = ImageDraw.Draw(img)
    bar_h = 150
    d.rectangle([0, 0, W, bar_h], fill=(*hex_rgb(brand["accent"]), 240))
    f_t = find_font(brand["font_serif"], 52)
    f_p = find_font(brand["font_sans"], 34)
    draw_centred(d, W / 2, 18, text.get("banner_top", ""), f_t,
                 hex_rgb(brand["accent_text"]))
    draw_centred(d, W / 2, 92, spaced(text.get("banner_price", "").upper()), f_p,
                 hex_rgb(brand.get("tick", brand["secondary"])))
    if text.get("caption"):
        cap = text["caption"]
        pad = 26
        size = 40
        f_c = find_font(brand["font_sans"], size)
        while d.textbbox((0, 0), cap, font=f_c)[2] + pad * 2 > W - 60 and size > 26:
            size -= 2
            f_c = find_font(brand["font_sans"], size)
        ch = size + 26
        bbox = d.textbbox((0, 0), cap, font=f_c)
        cw = bbox[2] - bbox[0] + pad * 2
        x0 = (W - cw) / 2
        y0 = H - 210
        d.rounded_rectangle([x0, y0, x0 + cw, y0 + ch], radius=14,
                            fill=(0, 0, 0, 170))
        d.text((x0 + pad, y0 + 11), cap, font=f_c, fill=(255, 255, 255))
    return img


def overlay_endcard(d, img, W, H, brand, text):
    """Full-bleed branded closer: big stacked CTA lines + logo line (BOOK NOW card)."""
    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.rectangle([0, 0, W, H], fill=(15, 12, 10, 80))
    img.alpha_composite(shadow)
    d = ImageDraw.Draw(img)
    y = int(H * 0.14)
    for i, ln in enumerate(text.get("lines", [])):
        f = find_font(brand["font_sans"], 96 if i == 0 else 66)
        draw_centred(d, W / 2 + 3, y + 3, ln.upper(), f, (20, 15, 10))
        draw_centred(d, W / 2, y, ln.upper(), f,
                     hex_rgb(brand["cream"]) if i == 0
                     else hex_rgb(brand.get("tick", brand["secondary"])))
        y += (110 if i == 0 else 84)
    if text.get("sub"):
        f_s = find_font(brand["font_serif"], 46)
        draw_centred(d, W / 2, y + 8, text["sub"], f_s, hex_rgb(brand["cream"]))
    if text.get("logo_line"):
        f_l = find_font(brand["font_serif"], 40)
        draw_centred(d, W / 2, H - 140, spaced(text["logo_line"].upper(), " "),
                     f_l, hex_rgb(brand["cream"]))
    return img


def overlay_ba_showcase(d, img, W, H, brand, text):
    """B/A showcase over a blurred underlay: logo top, outlined offer badge top-right
    (holds), branded banner bottom with the concern line. The before/after panels
    are timed 'panels' overlays - they pop in and HOLD."""
    d = ImageDraw.Draw(img)
    if text.get("logo_line"):
        f_l = find_font(brand["font_serif"], 58)
        draw_centred(d, W * 0.32, 44, text["logo_line"], f_l, hex_rgb(brand["cream"]))
        if text.get("logo_sub"):
            f_ls = find_font(brand["font_sans"], 24)
            draw_centred(d, W * 0.42, 116, text["logo_sub"], f_ls,
                         hex_rgb(brand["cream"]))
    if text.get("badge"):
        b = text["badge"]
        r = 128
        cx, cy = W - r - 60, r + 60
        d.ellipse([cx - r, cy - r, cx + r, cy + r],
                  outline=hex_rgb(brand["cream"]), width=4)
        f_lab = find_font(brand["font_sans"], 26)
        f_p = find_font(brand["font_serif"], 62)
        f_sm = find_font(brand["font_sans"], 20)
        for j, ln in enumerate(b.get("label", "Special Offer").upper().split()):
            draw_centred(d, cx, cy - 92 + j * 28, spaced(ln), f_lab,
                         hex_rgb(brand["cream"]))
        draw_centred(d, cx, cy - 26, b.get("price", ""), f_p, hex_rgb(brand["cream"]))
        draw_centred(d, cx, cy + 52, b.get("small", "Limited Time"), f_sm,
                     hex_rgb(brand["cream"]))
    lines = text.get("banner_lines", [])
    if lines:
        bar_h = 64 + len(lines) * 52
        tint = hex_rgb(brand.get("banner", brand["secondary"]))
        d.rectangle([0, H - bar_h, W, H], fill=(*tint, 225))
        f_b = find_font(brand["font_sans"], 38)
        y = H - bar_h + 28
        for ln in lines:
            draw_centred(d, W / 2, y, ln, f_b, (255, 255, 255))
            y += 52
    return img


OVERLAYS = {"ritual": overlay_ritual, "checklist": overlay_checklist,
            "banner": overlay_banner, "endcard": overlay_endcard,
            "ba_showcase": overlay_ba_showcase}


def make_panel(image, W, spec, path):
    """A single framed pop-in panel (thick white frame, close-crop)."""
    pw = int(W * spec.get("w", 0.42))
    ph = int(pw * spec.get("ratio", 0.78))
    border = 14
    img = Image.new("RGB", (pw + border * 2, ph + border * 2), (255, 255, 255))
    im = Image.open(image).convert("RGB")
    zoom = spec.get("zoom", 2.2)  # close-crop into the skin area like the reference
    cw, chh = int(im.width / zoom), int(im.width / zoom * ph / pw)
    x0 = (im.width - cw) // 2
    y0 = int(im.height * spec.get("focus_y", 0.45)) - chh // 2
    y0 = max(0, min(y0, im.height - chh))
    im = im.crop((x0, y0, x0 + cw, y0 + chh)).resize((pw, ph), Image.LANCZOS)
    img.paste(im, (border, border))
    img.save(path)


def make_overlay_png(screen, brand, W, H, path):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    img = OVERLAYS[screen["style"]](d, img, W, H, brand, screen.get("text", {}))
    img.save(path)


def make_ba_inset(spec, brand, W, path):
    """Side-by-side before/after inset with labels - the conversion flash."""
    iw = int(W * spec.get("width", 0.46))
    cell_w = iw // 2
    cell_h = int(cell_w * 1.25)
    img = Image.new("RGBA", (iw + 8, cell_h + 8), (255, 255, 255, 235))
    for i, (key, label) in enumerate([("before", "BEFORE"), ("after", "AFTER")]):
        im = Image.open(spec[key]).convert("RGB")
        ratio = max(cell_w / im.width, cell_h / im.height)
        im = im.resize((int(im.width * ratio), int(im.height * ratio)))
        x0 = (im.width - cell_w) // 2
        im = im.crop((x0, int(im.height * 0.08), x0 + cell_w,
                      int(im.height * 0.08) + cell_h))
        img.paste(im, (4 + i * cell_w, 4))
        d = ImageDraw.Draw(img)
        f = find_font(brand["font_sans"], 20)
        d.rectangle([4 + i * cell_w, 4, 4 + i * cell_w + 108, 36],
                    fill=hex_rgb(brand["accent"]))
        d.text((14 + i * cell_w, 9), label, font=f, fill=hex_rgb(brand["accent_text"]))
    img.save(path)


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write(r.stderr[-2500:])
        raise SystemExit("ffmpeg failed")


def render_segment(screen, brand, W, H, fps, tmp, i):
    src = Path(screen["clip"])
    dur = screen.get("duration", 3)
    start = screen.get("clip_start", 0)
    keep_audio = bool(screen.get("audio"))
    ov = tmp / f"ov{i}.png"
    make_overlay_png(screen, brand, W, H, ov)
    blur = ",boxblur=12:2" if screen.get("blur") else ""
    fit = (f"scale={W}:{H}:force_original_aspect_ratio=increase,"
           f"crop={W}:{H}{blur},fps={fps},format=yuv420p")
    inputs, filters = [], []
    if src.suffix.lower() in VIDEO_EXT:
        inputs += ["-ss", str(start), "-t", str(dur), "-i", str(src)]
        filters.append(f"[0:v]{fit}[base]")
    else:
        frames = int(dur * fps)
        inputs += ["-loop", "1", "-t", str(dur), "-i", str(src)]
        filters.append(
            f"[0:v]scale={W * 2}:-2,"
            f"zoompan=z='min(1.0+0.0009*on,1.12)':x='iw/2-(iw/zoom/2)':"
            f"y='ih/5-(ih/zoom/5)':d={frames}:s={W}x{H}:fps={fps},format=yuv420p[base]")
    # overlay text with fade-in (the reference renders never hard-pop text)
    inputs += ["-loop", "1", "-t", str(dur), "-i", str(ov)]
    filters.append("[1:v]format=rgba,fade=t=in:st=0:d=0.45:alpha=1[ovl]")
    chain = "[base][ovl]overlay=0:0"
    n_in = 2
    ba = screen.get("ba_inset")
    if ba:
        bp = tmp / f"ba{i}.png"
        make_ba_inset(ba, brand, W, bp)
        s, du = ba.get("start", 1.0), ba.get("dur", 3.0)
        inputs += ["-loop", "1", "-t", str(dur), "-i", str(bp)]
        filters.append(
            f"[{n_in}:v]format=rgba,fade=t=in:st={s}:d=0.35:alpha=1,"
            f"fade=t=out:st={s + du - 0.35}:d=0.35:alpha=1[ba]")
        chain += "[v1];[v1][ba]overlay=x=W-w-40:y=" + str(int(H * ba.get("y", 0.18))) \
                 + f":enable='between(t,{s},{s + du})'"
        n_in += 1
    for pi, panel in enumerate(screen.get("panels", [])):
        pp = tmp / f"panel{i}_{pi}.png"
        make_panel(panel["image"], W, panel, pp)
        s = panel.get("start", 0.6)
        inputs += ["-loop", "1", "-t", str(dur), "-i", str(pp)]
        filters.append(f"[{n_in}:v]format=rgba,"
                       f"fade=t=in:st={s}:d=0.35:alpha=1[p{pi}]")
        px = f"W*{panel.get('x', 0.05)}"
        py = f"H*{panel.get('y', 0.15)}"
        chain += f"[vp{pi}];[vp{pi}][p{pi}]overlay=x={px}:y={py}" \
                 f":enable='gte(t,{s})'"
        n_in += 1
    filters.append(chain + "[vout]")
    if keep_audio and src.suffix.lower() in VIDEO_EXT:
        amap = ["-map", "0:a?", "-c:a", "aac", "-b:a", "128k",
                "-af", f"atrim=0:{dur},asetpts=PTS-STARTPTS"]
    else:
        inputs += ["-f", "lavfi", "-t", str(dur), "-i", "anullsrc=r=48000:cl=stereo"]
        amap = ["-map", f"{n_in}:a", "-c:a", "aac", "-b:a", "128k"]
    seg = tmp / f"seg{i}.mp4"
    run(["ffmpeg", "-y"] + inputs + ["-filter_complex", ";".join(filters),
         "-map", "[vout]"] + amap + ["-t", str(dur), "-c:v", "libx264",
         "-preset", "fast", "-crf", "19", "-r", str(fps), str(seg)])
    return seg, dur


def join(segs, durs, xf, out, fps):
    if xf <= 0 or len(segs) == 1:
        tmp = segs[0].parent
        concat = tmp / "concat.txt"
        concat.write_text("".join(f"file '{s}'\n" for s in segs))
        run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat),
             "-c", "copy", str(out)])
        return
    inputs = []
    for s in segs:
        inputs += ["-i", str(s)]
    vf, af = [], []
    vprev, aprev = "[0:v]", "[0:a]"
    offset = 0.0
    for i in range(1, len(segs)):
        offset += durs[i - 1] - xf
        vo, ao = f"[vx{i}]", f"[ax{i}]"
        vf.append(f"{vprev}[{i}:v]xfade=transition=fade:duration={xf}:"
                  f"offset={offset:.3f}{vo}")
        af.append(f"{aprev}[{i}:a]acrossfade=d={xf}{ao}")
        vprev, aprev = vo, ao
    run(["ffmpeg", "-y"] + inputs + ["-filter_complex",
         ";".join(vf + af), "-map", vprev, "-map", aprev,
         "-c:v", "libx264", "-preset", "fast", "-crf", "19", "-r", str(fps),
         "-c:a", "aac", "-b:a", "128k", str(out)])


def add_music(video, music, out):
    """Mix a music/ambience bed under the reel's existing audio. Music loops to
    fit, sits at the given volume (default 0.35 - lower ~0.12 under speech), and
    fades out over the last second. Royalty-free tracks only."""
    vol = music.get("volume", 0.35)
    dur = float(subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=nw=1:nk=1", str(video)],
        capture_output=True, text=True).stdout.strip())
    run(["ffmpeg", "-y", "-i", str(video), "-stream_loop", "-1", "-i",
         str(music["file"]), "-filter_complex",
         f"[1:a]volume={vol},atrim=0:{dur:.3f},"
         f"afade=t=out:st={max(0, dur - 1):.3f}:d=1[m];"
         f"[0:a][m]amix=inputs=2:duration=first:normalize=0[aout]",
         "-map", "0:v", "-map", "[aout]", "-c:v", "copy",
         "-c:a", "aac", "-b:a", "128k", str(out)])


def main(job_path):
    cfg = json.loads(Path(job_path).read_text())
    W, H = cfg.get("size", [1080, 1350])
    fps = cfg.get("fps", 30)
    xf = cfg.get("crossfade", 0.5)
    brand = cfg["brand"]
    tmp = Path(tempfile.mkdtemp(prefix="ccreel-"))
    segs, durs = [], []
    for i, screen in enumerate(cfg["screens"]):
        seg, dur = render_segment(screen, brand, W, H, fps, tmp, i)
        segs.append(seg)
        durs.append(dur)
    music = cfg.get("music")
    if music:
        raw = tmp / "joined.mp4"
        join(segs, durs, xf, raw, fps)
        add_music(raw, music, cfg["out"])
    else:
        join(segs, durs, xf, cfg["out"], fps)
    print(cfg["out"])


if __name__ == "__main__":
    main(sys.argv[1])
