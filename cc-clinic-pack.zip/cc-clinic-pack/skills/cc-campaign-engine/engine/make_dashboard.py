#!/usr/bin/env python3
"""
CC Campaign Engine - review dashboard generator.

Takes a campaign.json and writes campaign-dashboard.html next to it:
branded review grid, per-creative DOWNLOAD button, per-field COPY buttons,
"Copy all campaign copy", AHPRA badges, needs-media flags, lead form card,
and the Load-into-Meta strip.

campaign.json:
{
  "clinic": "Skin Rejuvenate",
  "accent": "#0E3634", "gold": "#C9A96A",          // dashboard theme (CC teal default)
  "offer": {"name": "Collagen Lift Facial", "price": "$150", "anchor": "$330",
            "link": "https://...", "cta_label": "Book Now"},
  "creatives": [
    {"file": "01-concern-checklist.png", "type": "static", "angle": "Concern hook",
     "headline": "...", "primary": "...", "description": "...",
     "ahpra": true, "flag": ""},
    {"file": "09-ritual-reel.mp4", "type": "reel", ...},
    {"file": "", "type": "static", "angle": "Proof", "flag": "needs media: film a
      10s clip of the neck treatment in progress", ...}
  ],
  "leadform": {"headline": "...", "description": "...",   // the conversion copy
               "privacy": "...", "thankyou": "..."}
               // fields are ALWAYS Name / Phone / Email prefill - never custom questions
}
"""
import html
import json
import sys
from pathlib import Path


def esc(s):
    return html.escape(str(s or ""))


def creative_card(c, i):
    file = c.get("file", "")
    is_reel = c.get("type") == "reel" or file.endswith((".mp4", ".mov"))
    flag = c.get("flag", "")
    if flag:
        art = f'<div class="art flagged">🎬<span>{esc(flag)}</span></div>'
        dl = ""
    elif is_reel:
        art = (f'<div class="art"><span class="tag">{esc(c.get("angle",""))} · Reel</span>'
               f'<video src="{esc(file)}" controls playsinline></video></div>')
        dl = f'<a class="btn" href="{esc(file)}" download>Download</a>'
    else:
        art = (f'<div class="art"><span class="tag">{esc(c.get("angle",""))}</span>'
               f'<img src="{esc(file)}" alt="creative {i}"></div>')
        dl = f'<a class="btn" href="{esc(file)}" download>Download</a>'
    ahpra = ('<span class="ahpra">✓ AHPRA safe</span>' if c.get("ahpra")
             else '<span class="ahpra warn">⚠ review</span>')

    def block(label, key):
        val = c.get(key, "")
        if not val:
            return ""
        return (f'<div class="block"><small>{label}'
                f'<button class="copy" data-copy="{esc(val)}">Copy</button></small>'
                f'<div class="val">{esc(val)}</div></div>')

    return f"""
  <div class="card">
    {art}
    <div class="copy-col">
      <h3>{esc(c.get("headline", c.get("angle", f"Creative {i}")))}</h3>
      {block("Headline", "headline")}
      {block("Primary text", "primary")}
      {block("Description", "description")}
      {block("CTA link", "cta_link")}
      <div class="row">{ahpra}{dl}</div>
    </div>
  </div>"""


def main(path):
    cfg = json.loads(Path(path).read_text())
    accent = cfg.get("accent", "#0E3634")
    gold = cfg.get("gold", "#C9A96A")
    offer = cfg.get("offer", {})
    cards = "\n".join(creative_card(c, i + 1)
                      for i, c in enumerate(cfg.get("creatives", [])))
    lf = cfg.get("leadform")
    lf_html = ""
    if lf:
        lf_text = "\n".join(filter(None, [
            f"FORM HEADLINE: {lf.get('headline', '')}",
            f"FORM DESCRIPTION:\n{lf.get('description', '')}",
            "FIELDS: Name / Phone / Email (prefill - no custom questions)",
            f"PRIVACY: {lf.get('privacy', '')}",
            f"THANK YOU: {lf.get('thankyou', '')}"]))

        def lf_block(label, key):
            val = lf.get(key, "")
            if not val:
                return ""
            return (f'<div class="block"><small>{label}'
                    f'<button class="copy" data-copy="{esc(val)}">Copy</button></small>'
                    f'<div class="val">{esc(val)}</div></div>')

        lf_html = f"""
  <h2 class="set">Lead Form <span>one form - every creative drives here · fields are
  Name / Phone / Email prefill only, the COPY does the converting</span></h2>
  <div class="leadform"><h3>{esc(lf.get("headline", "Lead form"))}
    <button class="copy" data-copy="{esc(lf_text)}">Copy full form spec</button></h3>
    {lf_block("Form headline", "headline")}
    {lf_block("Form description", "description")}
    <p class="small"><b>Fields:</b> Name · Phone · Email (prefill - do NOT add custom
    questions, friction kills submissions)</p>
    <p class="small"><b>Privacy:</b> {esc(lf.get("privacy", ""))}</p>
    <p class="small"><b>Thank you screen:</b> {esc(lf.get("thankyou", ""))}</p></div>"""

    all_copy = []
    for i, c in enumerate(cfg.get("creatives", []), 1):
        if c.get("headline"):
            all_copy.append(f"--- Creative {i} ({c.get('angle','')}) ---\n"
                            f"HEADLINE: {c.get('headline','')}\n"
                            f"PRIMARY:\n{c.get('primary','')}\n"
                            f"DESCRIPTION: {c.get('description','')}")
    all_copy_text = "\n\n".join(all_copy)

    doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Campaign Review - {esc(cfg.get('clinic',''))}</title>
<style>
:root{{--teal:{accent};--gold:{gold};--cream:#F4EFE6;--ink:#0B1F1E}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:linear-gradient(160deg,#092523,var(--teal) 60%,#0C4340);
 font-family:'Avenir Next','Segoe UI',sans-serif;color:var(--cream);min-height:100vh}}
header{{padding:44px 52px 24px;border-bottom:1px solid rgba(201,169,106,.35);
 display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:14px}}
header small{{display:block;letter-spacing:.45em;font-size:11px;color:var(--gold);
 text-transform:uppercase;margin-bottom:8px}}
h1{{font-family:Didot,Georgia,serif;font-weight:400;font-size:36px}}
h1 em{{color:var(--gold);font-style:normal}}
.meta{{text-align:right;font-size:13px;line-height:1.8;opacity:.85}}
.meta b{{color:var(--gold)}}
.toolbar{{padding:20px 52px;display:flex;gap:14px;flex-wrap:wrap}}
.btn{{background:var(--gold);color:var(--ink);border:none;font-weight:700;font-size:12px;
 letter-spacing:.14em;text-transform:uppercase;padding:11px 22px;border-radius:24px;
 cursor:pointer;text-decoration:none;display:inline-block}}
h2.set{{padding:24px 52px 4px;font-size:13px;letter-spacing:.4em;text-transform:uppercase;
 color:var(--gold)}}
h2.set span{{color:rgba(244,239,230,.55);letter-spacing:.03em;text-transform:none;
 margin-left:12px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(560px,1fr));gap:24px;
 padding:16px 52px 36px}}
.card{{background:#11413E;border:1px solid rgba(201,169,106,.22);border-radius:18px;
 overflow:hidden;display:grid;grid-template-columns:290px 1fr}}
.art{{position:relative;background:#000;min-height:300px}}
.art img,.art video{{width:100%;height:100%;object-fit:cover;display:block}}
.art.flagged{{display:flex;flex-direction:column;align-items:center;justify-content:center;
 font-size:44px;gap:14px;background:rgba(201,169,106,.08);border-right:1px dashed var(--gold)}}
.art.flagged span{{font-size:13px;line-height:1.6;color:var(--gold);text-align:center;
 padding:0 18px}}
.tag{{position:absolute;top:12px;left:12px;background:rgba(9,37,35,.85);color:var(--gold);
 font-size:10px;letter-spacing:.2em;text-transform:uppercase;padding:6px 12px;
 border-radius:20px;border:1px solid rgba(201,169,106,.5);z-index:2}}
.copy-col{{padding:20px 22px;display:flex;flex-direction:column;gap:11px}}
h3{{font-family:Didot,Georgia,serif;font-weight:400;font-size:20px;line-height:1.25}}
.block{{background:rgba(9,37,35,.55);border-radius:10px;padding:11px 13px;font-size:12.5px}}
.block small{{display:flex;justify-content:space-between;align-items:center;font-size:9.5px;
 letter-spacing:.26em;text-transform:uppercase;color:var(--gold);margin-bottom:6px}}
.block .val{{white-space:pre-wrap;line-height:1.6;color:rgba(244,239,230,.9)}}
.copy{{background:transparent;border:1px solid var(--gold);color:var(--gold);font-size:9px;
 letter-spacing:.12em;text-transform:uppercase;padding:4px 10px;border-radius:12px;
 cursor:pointer}}
.copy.done{{background:var(--gold);color:var(--ink)}}
.row{{display:flex;gap:10px;align-items:center;margin-top:auto;justify-content:space-between}}
.ahpra{{font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:#8FD6A8;
 border:1px solid rgba(143,214,168,.45);padding:6px 12px;border-radius:20px}}
.ahpra.warn{{color:#F0C674;border-color:rgba(240,198,116,.5)}}
.leadform{{margin:14px 52px 30px;background:#11413E;border:1px solid rgba(201,169,106,.3);
 border-radius:16px;padding:24px 28px;max-width:900px}}
.leadform h3{{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}}
.leadform ol{{margin:0 0 14px 20px;line-height:2}}
.small{{font-size:12px;opacity:.75;line-height:1.7}}
.strip{{margin:6px 52px 40px;background:rgba(201,169,106,.1);border:1px solid
 rgba(201,169,106,.4);border-radius:14px;padding:18px 24px;font-size:13.5px;line-height:1.8}}
.strip b{{color:var(--gold)}}
footer{{padding:22px 52px 44px;font-size:12px;opacity:.5;
 border-top:1px solid rgba(201,169,106,.2)}}
</style></head><body>
<header><div><small>Clinic Catalyst · Campaign Engine</small>
 <h1>Campaign Review <em>— {esc(cfg.get('clinic',''))}</em></h1></div>
 <div class="meta">Offer: <b>{esc(offer.get('name',''))} · {esc(offer.get('price',''))}
 (was {esc(offer.get('anchor',''))})</b><br>
 CTA: {esc(offer.get('cta_label','Book Now'))} → {esc(offer.get('link',''))}</div></header>
<div class="toolbar">
 <button class="btn" id="copyall">Copy all campaign copy</button>
 <a class="btn" href="{esc(offer.get('link',''))}" target="_blank">Test booking link</a>
</div>
<div class="strip"><b>Load into Meta:</b> this is ONE ad. Create 1 campaign → 1 ad set →
one flexible ad. Upload every creative below as assets, paste the headline + primary text
variants into the text fields, attach the lead form, publish. Andromeda tests the
combinations and finds your winners.<br>
<b>Helpful:</b>
<a href="https://clinic-catalyst-au.github.io/workshop-toolkit/advertising-system.html#connect"
target="_blank" style="color:var(--gold)">Plug Claude into your ad account (read-only, 5 min)
→</a> &nbsp;·&nbsp;
<a href="https://clinic-catalyst-au.github.io/workshop-toolkit/advertising-system.html"
target="_blank" style="color:var(--gold)">The full advertising system + campaign engine
demo video →</a></div>
<h2 class="set">Creatives <span>{len(cfg.get('creatives',[]))} assets · one offer · one ad</span></h2>
<div class="grid">{cards}</div>
{lf_html}
<footer>Clinic Catalyst · Campaign Engine · every creative AHPRA-screened before it
reaches this page</footer>
<textarea id="allcopy" style="position:absolute;left:-9999px">{esc(all_copy_text)}</textarea>
<script>
document.querySelectorAll('.copy').forEach(b=>b.addEventListener('click',async()=>{{
 await navigator.clipboard.writeText(b.dataset.copy||'');
 b.textContent='Copied';b.classList.add('done');
 setTimeout(()=>{{b.textContent='Copy';b.classList.remove('done')}},1600);}}));
document.getElementById('copyall').addEventListener('click',async()=>{{
 const t=document.getElementById('allcopy').value;
 await navigator.clipboard.writeText(t);
 const b=document.getElementById('copyall');b.textContent='All copy copied ✓';
 setTimeout(()=>b.textContent='Copy all campaign copy',2000);}});
</script></body></html>"""
    out = Path(path).parent / "campaign-dashboard.html"
    out.write_text(doc)
    print(out)


if __name__ == "__main__":
    main(sys.argv[1])
