#!/usr/bin/env python3
"""
CC Campaign Engine - static ad renderer.

Reproduces the house ad template layouts (see the template spec in the
shared ad-templates folder) as
parameterized Pillow renders. The LAYOUT is fixed - header bars, tick
checklists, circular strikethrough offer badges, colour-block banners sit
exactly where the templates put them. Everything else (text, colours, fonts, media)
comes from the job config.

Usage:
    python3 render_static.py job.json

job.json:
{
  "template": "checklist" | "colourblock" | "editorial",
  "size": [1080, 1350],
  "out": "/path/out.png",
  "media": "/path/clinic-photo-or-video-frame.jpg",
  "brand": {
    "accent": "#2D4A3E",        // header bar / badge fill
    "accent_text": "#FFFFFF",
    "secondary": "#C9A96A",      // ticks, gold blocks
    "dark": "#1A1A1A",
    "cream": "#F5EFE0",
    "font_serif": "Didot",       // header font (name or path)
    "font_sans": "Montserrat-SemiBold",
    "font_script": "SnellRoundhand"   // optional flourish ("with Smart Scan")
  },
  "text": {
    "header": "GOODBYE TURKEY NECK",
    "subheader": "",                        // optional second header line
    "ticks": ["Tightens & plumps skin", ...],   // checklist template
    "anchor": "$330", "price": "$150",
    "badge_label": "Limited Time",          // or "FULL FACE IPL TREATMENT"
    "scarcity": "Only 10 Discounted Packages",  // colourblock circle badge
    "block_left": "NON-SURGICAL LIPOSUCTION",   // colourblock bottom-left
    "block_right": "Save 50%",                  // colourblock bottom-right
    "flourish": ""                          // script note e.g. "with Smart Scan"
  },
  "badge_pos": "bottom-left" | "bottom-right" | "top-right"
}
"""
import json
import math
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

FONT_DIRS = [
    Path.home() / "Library/Fonts",
    Path("/System/Library/Fonts/Supplemental"),
    Path("/System/Library/Fonts"),
    Path("/Library/Fonts"),
]


def find_font(name: str, size: int) -> ImageFont.FreeTypeFont:
    """Resolve a font by path, filename, or fuzzy name; fall back to Georgia."""
    if not name:
        name = "Georgia"
    p = Path(name)
    if p.exists():
        return ImageFont.truetype(str(p), size)
    candidates = []
    for d in FONT_DIRS:
        if d.exists():
            candidates += list(d.glob("*.ttf")) + list(d.glob("*.ttc")) + list(d.glob("*.otf"))
    lowered = name.lower().replace(" ", "")
    for c in candidates:
        if c.stem.lower().replace(" ", "").replace("-", "") == lowered.replace("-", ""):
            return ImageFont.truetype(str(c), size)
    for c in candidates:
        if lowered.split("-")[0] in c.stem.lower().replace(" ", ""):
            return ImageFont.truetype(str(c), size)
    return ImageFont.truetype("/System/Library/Fonts/Supplemental/Georgia.ttf", size)


def hex_rgb(h: str):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def cover_crop(img: Image.Image, w: int, h: int, x_bias: float = 0.5) -> Image.Image:
    """Scale + crop media to fill a zone. x_bias 0..1 slides the crop window left/right
    so the SUBJECT can be placed opposite the text (the layouts keep the clear
    zone for ticks/badges - set x_bias per photo after LOOKING at it)."""
    ratio = max(w / img.width, h / img.height)
    nw, nh = math.ceil(img.width * ratio), math.ceil(img.height * ratio)
    img = img.resize((nw, nh), Image.LANCZOS)
    x = int((nw - w) * max(0.0, min(1.0, x_bias)))
    y = min((nh - h) // 3, nh - h)  # bias toward top third - faces live there
    return img.crop((x, y, x + w, y + h))


def spaced(text: str, gap: str = " " * 3) -> str:
    """Letter-space caps the way the template header bars do."""
    return gap.join(list(text))


def draw_centred(d, cx, y, text, font, fill, tracking=0):
    if tracking:
        text = spaced(text)
    bbox = d.textbbox((0, 0), text, font=font)
    d.text((cx - (bbox[2] - bbox[0]) / 2, y), text, font=font, fill=fill)
    return bbox[3] - bbox[1]


def draw_header_bar(d, W, brand, text, subtext, serif=False, bar_h=None):
    lines = [text] + ([subtext] if subtext else [])
    bar_h = bar_h or (95 if len(lines) == 1 else 150)
    d.rectangle([0, 0, W, bar_h], fill=hex_rgb(brand["accent"]))
    if serif:
        f = find_font(brand["font_serif"], 56 if len(lines) == 1 else 46)
        tracking = 0
    else:
        f = find_font(brand["font_sans"], 42 if len(lines) == 1 else 36)
        tracking = 1
    y = (bar_h - len(lines) * (62 if len(lines) == 1 else 52)) / 2 + 4
    for ln in lines:
        ln = ln if serif else ln.upper()
        draw_centred(d, W / 2, y, spaced(ln) if tracking else ln, f,
                     hex_rgb(brand["accent_text"]))
        y += 62 if len(lines) == 1 else 52
    return bar_h


def draw_tick(d, x, y, size, colour):
    """The brushy gold tick - thick stroke with a subtle drop shadow so the
    gold reads against any photo."""
    w = size
    shadow = (0, 0, 0, 90) if len(colour) == 3 else colour
    for dx, dy, c, width in [(2, 2, (60, 45, 10), 9), (0, 0, colour, 9)]:
        d.line([(x + dx, y + dy + w * 0.55), (x + dx + w * 0.35, y + dy + w * 0.95)],
               fill=c, width=width)
        d.line([(x + dx + w * 0.35, y + dy + w * 0.95), (x + dx + w * 1.15, y + dy)],
               fill=c, width=width)


def draw_checklist(d, x, y, items, brand, text_colour, line_gap=54, font_size=30):
    f = find_font(brand["font_sans"], font_size)
    tick_colour = hex_rgb(brand.get("tick", brand["secondary"]))
    for item in items:
        draw_tick(d, x, y - 4, 30, tick_colour)
        d.text((x + 56, y), item.upper(), font=f, fill=text_colour)
        y += line_gap
    return y


def draw_price_badge(img, d, centre, radius, brand, anchor, price, label,
                     ring=True):
    """The circular offer badge: strikethrough anchor, ONLY, big price, label."""
    cx, cy = centre
    fill = hex_rgb(brand["accent"])
    txt = hex_rgb(brand["accent_text"])
    if ring:
        d.ellipse([cx - radius - 8, cy - radius - 8, cx + radius + 8, cy + radius + 8],
                  fill=hex_rgb(brand["cream"]))
    d.ellipse([cx - radius, cy - radius, cx + radius, cy + radius], fill=fill)
    f_anchor = find_font(brand["font_serif"], int(radius * 0.42))
    f_only = find_font(brand["font_sans"], int(radius * 0.19))
    f_price = find_font(brand["font_serif"], int(radius * 0.52))
    f_label = find_font(brand["font_sans"], int(radius * 0.13))
    y = cy - radius * 0.62
    if anchor:
        bbox = d.textbbox((0, 0), anchor, font=f_anchor)
        aw = bbox[2] - bbox[0]
        d.text((cx - aw / 2, y), anchor, font=f_anchor, fill=txt)
        ah = bbox[3] - bbox[1]
        d.line([(cx - aw / 2 - 10, y + ah * 0.75), (cx + aw / 2 + 10, y + ah * 0.35)],
               fill=txt, width=5)
        y += radius * 0.46
    draw_centred(d, cx, y, spaced("ONLY"), f_only, txt)
    y += radius * 0.24
    draw_centred(d, cx, y, price, f_price, txt)
    y += radius * 0.6
    if label:
        for i, ln in enumerate(label.upper().split("\n")):
            draw_centred(d, cx, y + i * radius * 0.16, ln, f_label, txt)


def draw_circle_badge(d, centre, radius, brand, text):
    """Colour-block scarcity badge: navy circle, gold ring, small stacked text."""
    cx, cy = centre
    d.ellipse([cx - radius - 6, cy - radius - 6, cx + radius + 6, cy + radius + 6],
              fill=hex_rgb(brand["cream"]))
    d.ellipse([cx - radius, cy - radius, cx + radius, cy + radius],
              fill=hex_rgb(brand["accent"]))
    d.ellipse([cx - radius + 8, cy - radius + 8, cx + radius - 8, cy + radius - 8],
              outline=hex_rgb(brand["secondary"]), width=3)
    words = text.split()
    lines, cur = [], ""
    for w in words:
        if len(cur + " " + w) > 12 and cur:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    lines.append(cur)
    f = find_font(brand["font_sans"], max(20, int(radius * 0.24) - 2 * len(lines)))
    y = cy - len(lines) * radius * 0.15 - radius * 0.08
    for ln in lines:
        draw_centred(d, cx, y, ln, f, hex_rgb(brand["accent_text"]))
        y += radius * 0.3


def render_checklist(cfg):
    """IMAGE PACK 2 DNA: header bar + media + 4 ticks + circular price badge."""
    W, H = cfg.get("size", [1080, 1350])
    brand, text = cfg["brand"], cfg["text"]
    img = Image.new("RGB", (W, H), hex_rgb(brand["cream"]))
    d = ImageDraw.Draw(img)
    bar_h = draw_header_bar(d, W, brand, text["header"], text.get("subheader", ""),
                            serif=cfg.get("serif_header", False))
    media = Image.open(cfg["media"]).convert("RGB")
    img.paste(cover_crop(media, W, H - bar_h, cfg.get("media_x_bias", 0.5)), (0, bar_h))
    d = ImageDraw.Draw(img)
    side = cfg.get("text_side", "left")  # checklist goes in the media's CLEAR zone
    if text.get("ticks"):
        # translucent light wash behind the checklist for readability
        overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        wash_h = 40 + len(text["ticks"]) * 54 + 30
        wash_w = int(W * 0.62)
        wash_box = ([0, bar_h, wash_w, bar_h + wash_h] if side == "left"
                    else [W - wash_w, bar_h, W, bar_h + wash_h])
        od.rectangle(wash_box, fill=(255, 255, 255, 130))
        img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
        d = ImageDraw.Draw(img)
        tick_x = 55 if side == "left" else W - wash_w + 55
        draw_checklist(d, tick_x, bar_h + 42, text["ticks"], brand, hex_rgb(brand["dark"]))
    pos = cfg.get("badge_pos", "bottom-left")
    r = 170
    coords = {"bottom-left": (r + 80, H - r - 90),
              "bottom-right": (W - r - 80, H - r - 90),
              "top-right": (W - r - 70, int(H * 0.42))}[pos]
    draw_price_badge(img, d, coords, r, brand, text.get("anchor", ""),
                     text["price"], text.get("badge_label", "Limited Time"))
    if text.get("flourish"):
        f = find_font(brand.get("font_script", "SnellRoundhand"), 54)
        d.text((coords[0] - r - 30, coords[1] + r + 16), text["flourish"],
               font=f, fill=hex_rgb(brand["dark"]))
    img.save(cfg["out"], quality=95)


def render_colourblock(cfg):
    """IMAGE PACK 3 DNA: full-bleed media, top banner, angled bottom blocks, scarcity circle."""
    W, H = cfg.get("size", [1080, 1350])
    brand, text = cfg["brand"], cfg["text"]
    img = Image.new("RGB", (W, H), hex_rgb(brand["cream"]))
    media = Image.open(cfg["media"]).convert("RGB")
    img.paste(cover_crop(media, W, H), (0, 0))
    d = ImageDraw.Draw(img)
    if text.get("header"):
        bar_h = 78
        d.rectangle([0, 0, W, bar_h], fill=hex_rgb(brand["accent"]))
        f = find_font(brand["font_sans"], 40)
        draw_centred(d, W / 2, 16, text["header"], f, hex_rgb(brand["accent_text"]))
    # angled bottom blocks - navy left, gold right, mirroring the template diagonals
    bh = 190
    d.polygon([(0, H - bh), (int(W * 0.60), H - bh), (int(W * 0.52), H), (0, H)],
              fill=hex_rgb(brand["accent"]))
    d.polygon([(int(W * 0.60), H - bh - 60), (W, H - bh - 60), (W, H),
               (int(W * 0.52), H)], fill=hex_rgb(brand["secondary"]))
    f_left = find_font(brand["font_sans"], 44)
    y = H - bh + 34
    for ln in text.get("block_left", "").upper().split("\n"):
        d.text((45, y), ln, font=f_left, fill=hex_rgb(brand["accent_text"]))
        y += 56
    f_r1 = find_font(brand["font_sans"], 52)
    f_r2 = find_font(brand["font_serif"], 74)
    parts = text.get("block_right", "").split(" ", 1)
    rx = int(W * 0.70)
    d.text((rx, H - bh - 10), parts[0], font=f_r1, fill=hex_rgb(brand["cream"]))
    if len(parts) > 1:
        d.text((rx, H - bh + 52), parts[1], font=f_r2, fill=hex_rgb(brand["cream"]))
    if text.get("scarcity"):
        draw_circle_badge(d, (W - 165, 215), 110, brand, text["scarcity"])
    if text.get("ribbon"):
        draw_ribbon(img, text["ribbon"], brand)
    img.save(cfg["out"], quality=95)


def render_editorial(cfg):
    """IMAGE PACK 1 DNA: full-bleed soft media, serif headline top, badge corner."""
    W, H = cfg.get("size", [1080, 1350])
    brand, text = cfg["brand"], cfg["text"]
    img = Image.new("RGB", (W, H), hex_rgb(brand["cream"]))
    media = Image.open(cfg["media"]).convert("RGB")
    img.paste(cover_crop(media, W, H), (0, 0))
    # gradient wash top for headline contrast - strong enough for light footage
    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    for i in range(420):
        od.line([(0, i), (W, i)], fill=(0, 0, 0, int(165 * (1 - i / 420))))
    img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
    d = ImageDraw.Draw(img)
    f = find_font(brand["font_serif"], 54)
    y = 70
    for ln in text["header"].split("\n"):
        draw_centred(d, W / 2 + 2, y + 2, ln, f, (25, 22, 18))
        draw_centred(d, W / 2, y, ln, f, hex_rgb(brand["cream"]))
        y += 74
    r = 150
    draw_price_badge(img, d, (W - r - 80, H - r - 90), r, brand,
                     text.get("anchor", ""), text["price"],
                     text.get("badge_label", "Limited Time"))
    img.save(cfg["out"], quality=95)


def render_photo_panel(cfg):
    """Pack 2 p17-21 DNA ('Safe Around Eyes'): header bar + photo top ~60% + solid
    panel below with ticks left and a circle badge STRADDLING the boundary right,
    optional script flourish under the badge."""
    W, H = cfg.get("size", [1080, 1350])
    brand, text = cfg["brand"], cfg["text"]
    img = Image.new("RGB", (W, H), hex_rgb(brand.get("panel", "#FFFFFF")))
    d = ImageDraw.Draw(img)
    bar_h = draw_header_bar(d, W, brand, text["header"], text.get("subheader", ""),
                            serif=cfg.get("serif_header", True))
    photo_h = int(H * 0.60)
    media = Image.open(cfg["media"]).convert("RGB")
    img.paste(cover_crop(media, W, photo_h, cfg.get("media_x_bias", 0.5)), (0, bar_h))
    d = ImageDraw.Draw(img)
    panel_y = bar_h + photo_h
    if text.get("ticks"):
        draw_checklist(d, 55, panel_y + 45, text["ticks"], brand,
                       hex_rgb(brand["dark"]), line_gap=56, font_size=28)
    r = 155
    draw_price_badge(img, d, (W - r - 65, panel_y - 30), r, brand,
                     text.get("anchor", ""), text["price"],
                     text.get("badge_label", "Limited Time"))
    if text.get("flourish"):
        f = find_font(brand.get("font_script", "SnellRoundhand"), 52)
        d.text((W - r * 2 - 90, panel_y + r + 4), text["flourish"],
               font=f, fill=hex_rgb(brand["dark"]))
    img.save(cfg["out"], quality=95)


def render_banner_save(cfg):
    """Pack 2 p14 DNA ('Save $200 on Full Face IPL'): soft tinted banner top with a
    two-line serif saving headline, full-bleed photo below, outlined badge bottom-left."""
    W, H = cfg.get("size", [1080, 1350])
    brand, text = cfg["brand"], cfg["text"]
    img = Image.new("RGB", (W, H), hex_rgb(brand["cream"]))
    d = ImageDraw.Draw(img)
    bar_h = 200
    tint = hex_rgb(brand.get("banner_tint", brand["secondary"]))
    tint = tuple(int(c + (255 - c) * 0.55) for c in tint)
    d.rectangle([0, 0, W, bar_h], fill=tint)
    f = find_font(brand["font_serif"], 58)
    y = 30
    for ln in text["header"].split("\n"):
        draw_centred(d, W / 2, y, ln, f, hex_rgb(brand["dark"]))
        y += 72
    media = Image.open(cfg["media"]).convert("RGB")
    img.paste(cover_crop(media, W, H - bar_h, cfg.get("media_x_bias", 0.5)), (0, bar_h))
    d = ImageDraw.Draw(img)
    r = 150
    draw_price_badge(img, d, (r + 75, H - r - 85), r,
                     {**brand, "accent": brand.get("badge_fill", brand["accent"])},
                     text.get("anchor", ""), text["price"],
                     text.get("badge_label", "Limited Time"))
    img.save(cfg["out"], quality=95)


def render_strip3(cfg):
    """Pack 3 Tribella DNA: headline bar, 3-photo strip, labelled checklist, price band.
    cfg['media'] is a LIST of three image paths; text['ticks'] like 'TONE: ...'."""
    W, H = cfg.get("size", [1080, 1350])
    brand, text = cfg["brand"], cfg["text"]
    img = Image.new("RGB", (W, H), hex_rgb(brand["cream"]))
    d = ImageDraw.Draw(img)
    bar_h = draw_header_bar(d, W, brand, text["header"], text.get("subheader", ""),
                            serif=cfg.get("serif_header", False))
    strip_y, strip_h = bar_h + 26, 430
    cell = (W - 4 * 26) // 3
    for i, m in enumerate(cfg["media"][:3]):
        im = cover_crop(Image.open(m).convert("RGB"), cell, strip_h)
        img.paste(im, (26 + i * (cell + 26), strip_y))
    d = ImageDraw.Draw(img)
    y = strip_y + strip_h + 45
    f_lbl = find_font(brand["font_sans"], 30)
    f_body = find_font(brand.get("font_sans_light", brand["font_sans"]), 28)
    for item in text.get("ticks", []):
        draw_tick(d, 55, y - 4, 30, hex_rgb(brand.get("tick", brand["secondary"])))
        if ":" in item:
            lbl, rest = item.split(":", 1)
            d.text((111, y), lbl.upper() + ":", font=f_lbl, fill=hex_rgb(brand["secondary"]))
            lw = d.textbbox((0, 0), lbl.upper() + ":", font=f_lbl)[2]
            d.text((111 + lw + 12, y), rest.strip(), font=f_body, fill=hex_rgb(brand["dark"]))
        else:
            d.text((111, y), item, font=f_body, fill=hex_rgb(brand["dark"]))
        y += 62
    band_h = 130
    d.rectangle([0, H - band_h, W, H], fill=hex_rgb(brand["accent"]))
    f_price = find_font(brand["font_serif"], 56)
    f_sub = find_font(brand["font_sans"], 26)
    draw_centred(d, W / 2, H - band_h + 18, text.get("band", ""), f_price,
                 hex_rgb(brand["accent_text"]))
    if text.get("band_sub"):
        draw_centred(d, W / 2, H - band_h + 88, spaced(text["band_sub"].upper()), f_sub,
                     hex_rgb(brand.get("tick", brand["secondary"])))
    img.save(cfg["out"], quality=95)


def draw_ribbon(img, text, brand):
    """Pack 3 diagonal corner ribbon ('SALE ENDS MONDAY')."""
    W = img.width
    band = Image.new("RGBA", (900, 92), (0, 0, 0, 0))
    bd = ImageDraw.Draw(band)
    bd.rectangle([0, 0, 900, 92], fill=(*hex_rgb(brand["secondary"]), 255))
    f = find_font(brand["font_sans"], 40)
    bbox = bd.textbbox((0, 0), spaced(text.upper()), font=f)
    bd.text(((900 - bbox[2]) / 2, 22), spaced(text.upper()), font=f,
            fill=hex_rgb(brand["dark"]))
    band = band.rotate(35, expand=True)
    img.paste(band, (-170, -60), band)


RENDERERS = {"checklist": render_checklist,
             "colourblock": render_colourblock,
             "editorial": render_editorial,
             "photo_panel": render_photo_panel,
             "banner_save": render_banner_save,
             "strip3": render_strip3}

if __name__ == "__main__":
    cfg = json.loads(Path(sys.argv[1]).read_text())
    RENDERERS[cfg["template"]](cfg)
    print(cfg["out"])
