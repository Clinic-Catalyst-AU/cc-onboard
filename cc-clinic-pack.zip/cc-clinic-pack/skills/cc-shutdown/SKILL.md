---
name: cc-shutdown
description: End-of-session closeout for your clinic system. Reports everything touched this session as DONE / NEEDS YOU / IN PROGRESS, saves what matters to memory, checks nothing is sitting half-finished (drafts waiting for approval, imports mid-run), and leaves a clean starting point for next time. Use when you say shutdown, wrap up, end session, close out, save and exit, done for the day, or session end.
---

# Clinic Shutdown - End of Session Closeout

Run this at the end of every working session. It takes two minutes and means tomorrow starts clean instead of confused.

## What to do

1. *Session report.* List everything touched this session, each under exactly one heading:
   - *DONE* - finished and verified (posted, sent, loaded, live). Say what shipped, one line each.
   - *NEEDS YOU* - waiting on one action from the owner (an approval, a reply, a login, a decision). State the exact one-click action.
   - *IN PROGRESS* - genuinely half-done. Say what remains and what the next step is, so next session picks it up cold.

2. *Half-finished checks.* Before reporting, actually check for the usual dangling pieces:
   - Draft social posts sitting unapproved in the GHL Social Planner
   - Emails or newsletters written this session but not loaded or not approved
   - A client-list import mid-sequence (more batches still to go - when is the next one due?)
   - Files created this session that landed outside the Clinic folder
   - Anything the session promised to do "after" something else

3. *Memory.* Save short memory notes for anything that matters next session: decisions made, offers changed, where a multi-day job is up to. One fact per note. If the offer or prices changed today, remind the owner the Business Brain files are the place that change lives - never scattered in chat.

4. *Business Brain touch-up.* If anything learned this session belongs in the Business Brain (a new service, a price change, a tone note, a new FAQ), update the right file now or list it under NEEDS YOU.

5. *Close.* End with the single most important thing for next session, one line.

## Rules

- Never report something DONE that was not verified. "The file exists" is not "it was sent".
- Never skip the report because the session was short - a two-line report is still a report.
- No jargon. The owner reads this at the end of a long day - keep it warm, plain and short.
- If something broke this session and stayed broken, it goes in NEEDS YOU or IN PROGRESS with what happened - never silently dropped.
- Anything stuck that Claude cannot fix: point the owner at their setup + help page chat - the team is watching it.
