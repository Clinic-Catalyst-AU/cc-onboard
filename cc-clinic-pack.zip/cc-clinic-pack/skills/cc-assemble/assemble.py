#!/usr/bin/env python3
"""
cc-assemble - stitch video clips together (+ optional music) into one social-ready video.
Deterministic ffmpeg. Stdlib only. NOT AI editing - it joins clips you give it, in order.

Usage:
  python3 assemble.py --clips a.mp4 b.mp4 c.mp4 --aspect reel --out out.mp4
  python3 assemble.py --folder ./clips --music track.mp3 --music-vol 0.25 --out out.mp4
  python3 assemble.py --clips a.mp4 b.mp4 --crossfade --out out.mp4

--aspect: reel (1080x1920, default) | square (1080x1080) | landscape (1920x1080)
--music:  optional mp3/m4a/wav laid UNDER the video; loops to length, fades out, ducked
          so any talking in the clips stays audible (--music-vol, default 0.22).
--crossfade: 0.5s dissolve between clips (default is clean hard cuts).
Clips are scaled+centre-cropped to the target frame and normalised before joining,
so mixed sources/resolutions still stitch cleanly.
"""
import argparse, json, os, subprocess, sys, tempfile

ASPECTS = {"reel": (1080, 1920), "square": (1080, 1080), "landscape": (1920, 1080)}
FPS = 30
XF = 0.5  # crossfade seconds
VIDEO_EXT = (".mp4", ".mov", ".m4v", ".webm", ".mkv", ".avi")


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write("FFMPEG ERROR:\n" + r.stderr[-1500:] + "\n")
        raise SystemExit(1)
    return r


def probe_dur(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", path], capture_output=True, text=True)
    try:
        return float(r.stdout.strip())
    except ValueError:
        return 0.0


def has_audio(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a",
                        "-show_entries", "stream=index", "-of", "csv=p=0", path],
                       capture_output=True, text=True)
    return bool(r.stdout.strip())


def normalize(src, dst, W, H):
    vf = (f"scale={W}:{H}:force_original_aspect_ratio=increase,"
          f"crop={W}:{H},setsar=1,fps={FPS},format=yuv420p")
    if has_audio(src):
        cmd = ["ffmpeg", "-y", "-i", src, "-vf", vf, "-c:v", "libx264", "-preset",
               "veryfast", "-crf", "20", "-c:a", "aac", "-ar", "44100", "-ac", "2", dst]
    else:
        cmd = ["ffmpeg", "-y", "-i", src, "-f", "lavfi", "-i",
               "anullsrc=channel_layout=stereo:sample_rate=44100", "-vf", vf,
               "-shortest", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
               "-c:a", "aac", "-ar", "44100", "-ac", "2", dst]
    run(cmd)


def concat_hardcut(parts, dst, tmp):
    lst = os.path.join(tmp, "list.txt")
    with open(lst, "w") as f:
        for p in parts:
            f.write(f"file '{p}'\n")
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", dst])


def concat_crossfade(parts, durs, dst, W, H):
    # chain xfade (video) + acrossfade (audio) across all clips
    inputs = []
    for p in parts:
        inputs += ["-i", p]
    fc = []
    vlab, alab = "0:v", "0:a"
    offset = 0.0
    for i in range(1, len(parts)):
        offset += durs[i - 1] - XF
        nv, na = f"v{i}", f"a{i}"
        fc.append(f"[{vlab}][{i}:v]xfade=transition=fade:duration={XF}:offset={offset:.3f}[{nv}]")
        fc.append(f"[{alab}][{i}:a]acrossfade=d={XF}[{na}]")
        vlab, alab = nv, na
    cmd = ["ffmpeg", "-y"] + inputs + ["-filter_complex", ";".join(fc),
           "-map", f"[{vlab}]", "-map", f"[{alab}]", "-c:v", "libx264", "-preset",
           "veryfast", "-crf", "20", "-c:a", "aac", dst]
    run(cmd)


def add_music(video, music, vol, dst):
    dur = probe_dur(video)
    fade_st = max(0.0, dur - 2.0)
    fc = (f"[1:a]volume={vol},afade=t=out:st={fade_st:.2f}:d=2[mu];"
          f"[0:a][mu]amix=inputs=2:duration=first:dropout_transition=2[aout]")
    run(["ffmpeg", "-y", "-i", video, "-stream_loop", "-1", "-i", music,
         "-filter_complex", fc, "-map", "0:v", "-map", "[aout]",
         "-c:v", "copy", "-c:a", "aac", "-movflags", "+faststart", dst])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clips", nargs="*", default=[])
    ap.add_argument("--folder")
    ap.add_argument("--music")
    ap.add_argument("--music-vol", type=float, default=0.22)
    ap.add_argument("--aspect", choices=list(ASPECTS), default="reel")
    ap.add_argument("--crossfade", action="store_true")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    clips = list(a.clips)
    if a.folder:
        clips += [os.path.join(a.folder, f) for f in sorted(os.listdir(a.folder))
                  if f.lower().endswith(VIDEO_EXT)]
    clips = [c for c in clips if os.path.isfile(c)]
    if not clips:
        print("No clips found. Pass --clips a.mp4 b.mp4 or --folder DIR.")
        raise SystemExit(2)
    if a.music and not os.path.isfile(a.music):
        print(f"Music file not found: {a.music}")
        raise SystemExit(2)

    W, H = ASPECTS[a.aspect]
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    print(f"Assembling {len(clips)} clip(s) at {a.aspect} {W}x{H}"
          f"{' + music' if a.music else ''}{' + crossfade' if a.crossfade else ''}")

    with tempfile.TemporaryDirectory() as tmp:
        parts = []
        for i, c in enumerate(clips):
            dst = os.path.join(tmp, f"n{i}.mp4")
            print(f"  normalising {os.path.basename(c)}")
            normalize(c, dst, W, H)
            parts.append(dst)

        stitched = os.path.join(tmp, "stitched.mp4")
        if a.crossfade and len(parts) > 1:
            durs = [probe_dur(p) for p in parts]
            concat_crossfade(parts, durs, stitched, W, H)
        else:
            concat_hardcut(parts, stitched, tmp)

        if a.music:
            add_music(stitched, a.music, a.music_vol, a.out)
        else:
            run(["ffmpeg", "-y", "-i", stitched, "-c", "copy",
                 "-movflags", "+faststart", a.out])

    print(f"DONE -> {a.out}  ({probe_dur(a.out):.1f}s)")


if __name__ == "__main__":
    main()
