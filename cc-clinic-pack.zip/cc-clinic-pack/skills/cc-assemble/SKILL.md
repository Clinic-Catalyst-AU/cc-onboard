---
name: cc-assemble
description: Stitch several video clips together into one social-ready video, with optional music laid underneath and optional crossfades. Joins clips you provide, in order (from a list or a folder), normalises mixed resolutions, and adds a music track that ducks under any talking. Use when the user says stitch, put these clips together, join videos, combine clips, make a montage, add music to a video, music over this, assemble a reel, b-roll reel, or hype reel. This is deterministic editing (ffmpeg), NOT AI editing of a talking head.
---

# CC ASSEMBLE - Stitch Clips + Add Music

Joins video clips into one finished video for social. It does the mechanical editing a clinic actually needs day to day: put a few clips together in order, lay a music track under them, optionally crossfade between them, and export at the right size for Reels, feed, or landscape.

## WHAT THIS DOES (and does not)
- DOES: stitch clips in the order given, normalise mixed sources to one frame size, add music under the video (ducked so talking stays audible), crossfade between clips, export reel/square/landscape.
- DOES NOT: re-cut or "tidy up" a talking-head video, remove filler words, pick the best take, or make editing decisions. It joins what you give it. For finding the best moment in a long video use `/cc-find-clip`; for captions use `/cc-reeltalkinghead`. (AI editing of a talking head is not a reliable capability - do not promise it.)

## ENGINE
Driven by the bundled `assemble.py` (ffmpeg). No Remotion needed. ffmpeg is installed by the CC bootstrap.

## HOW TO USE
```
# stitch three clips into a vertical reel with music under them
/cc-assemble --clips intro.mp4 treatment.mp4 outro.mp4 --music calm.mp3

# stitch everything in a folder (sorted by filename) with crossfades
/cc-assemble --folder ~/Clinic/Content/footage --crossfade --music track.mp3

# square feed video, no music
/cc-assemble --clips a.mp4 b.mp4 --aspect square
```

## PROCEDURE
1. VALIDATE
   - `which ffmpeg ffprobe` (installed by the bootstrap).
   - Gather the clips: an explicit `--clips` list (order preserved) OR a `--folder` (sorted by filename). Confirm the order with the user if it matters.
   - If music is requested, confirm the music file path. Only use music the clinic has the right to use (their own, or a licensed/royalty-free track) - flag this, never assume.

2. CHOOSE THE FRAME
   - `--aspect reel` (1080x1920, default) for Reels/TikTok, `square` (1080x1080) for feed, `landscape` (1920x1080) for YouTube. Clips are scaled and centre-cropped to fit, so mixed sizes are fine.

3. RUN
   ```bash
   python3 ~/.claude/skills/cc-assemble/assemble.py \
     --clips [clip1] [clip2] ... [--folder DIR] \
     [--music track.mp3 --music-vol 0.22] [--crossfade] \
     --aspect [reel|square|landscape] \
     --out ~/Clinic/Content/reels/[slug]-$(date +%Y-%m-%d).mp4
   ```
   - `--music-vol` default 0.22 keeps the music under any talking. Raise toward 0.4 for pure b-roll with no speech.
   - `--crossfade` adds a 0.5s dissolve between clips; default is clean hard cuts.

3b. VOICE-OVER (narration OVER the cut)
   - Content-Library convention: a `voiceover.m4a` (or `.mp3`) inside a raw-footage batch subfolder
     means "lay this narration over the assembled video". Also accept an explicit `--voiceover file`.
   - assemble.py has no dedicated flag yet, so build it as two deterministic passes:
     1. Assemble the visual cut as normal (no `--music`).
     2. Mix the narration on top, clip audio ducked hard, optional music bed under both:
     ```bash
     ffmpeg -y -i cut.mp4 -i voiceover.m4a [-i music.mp3] -filter_complex \
       "[0:a]volume=0.08[clips];[1:a]volume=1.0[vo];[clips][vo]amix=inputs=2:duration=first[a]" \
       -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k out.mp4
     ```
     (with music: three-way amix, music at ~0.15). Trim or pad: if the voice-over runs longer than
     the cut, tell the user by how much - never silently truncate narration mid-sentence.
   - The voice-over is speech: after this, `/cc-reeltalkinghead` captions come from the VOICE-OVER audio.

4. REPORT + NEXT STEP
   - Give the output path and duration.
   - Offer the natural next steps: `/cc-reel` to burn captions onto it, `/cc-reel-cover` for a cover image, `/cc-content-engine` for the caption that posts alongside it.

## OUTPUT
A single `.mp4` in `~/Clinic/Content/reels/`. The clinic's own content - no agency branding is added by this skill.

## IMPORTANT RULES
- This is deterministic assembly, not AI editing. Be honest about that with the clinic.
- Only use music the clinic is licensed to use - confirm, never assume.
- NEVER use emdashes in any output.
- Output lands in `~/Clinic/Content/reels/`, never in the operator's personal folders.
