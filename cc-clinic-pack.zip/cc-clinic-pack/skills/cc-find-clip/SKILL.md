---
name: cc-find-clip
description: Finds the single best ~2 minute clip from a longer clinic video using mlx-whisper transcription + audio energy analysis + AI scoring. Extracts the clip ready for /cc-content-pipeline. Use when the user says find clip, find the best clip, best moment, find me a clip, chop this, extract clip, pull a clip, best 2 minutes, or clip this video.
---

# CC FIND CLIP - Best Moment Extractor

Takes a long clinic video (a treatment walk-through, a piece-to-camera, an education reel), finds the single strongest ~2 minute segment for social media, and extracts it ready for `/cc-content-pipeline`.

## PHILOSOPHY

- The best clip is the one that stops the scroll in the first 3 seconds
- A complete thought beats a perfect soundbite - never cut mid-sentence
- Energy + quotability + standalone clarity = viral potential
- Speed matters - clips, not analysis paralysis
- AHPRA: never select a clip that makes a therapeutic/outcome claim or names a prescription product. Concern-led content only.

---

## HOW TO USE

### Find the best 2-min clip (default):
```
/cc-find-clip ~/Downloads/recording.mp4
/cc-find-clip ~/Clinic/Content/raw/treatment-walkthrough.mov
```

### Specify target duration:
```
/cc-find-clip ~/Downloads/recording.mp4 --duration 60
/cc-find-clip ~/Downloads/recording.mp4 --duration 90
/cc-find-clip ~/Downloads/recording.mp4 --duration 120
```

### Find multiple clips (top N):
```
/cc-find-clip ~/Downloads/recording.mp4 --top 3
/cc-find-clip ~/Downloads/recording.mp4 --top 5
```

### Name the output (slug for file naming):
```
/cc-find-clip ~/Downloads/recording.mp4 --name skin-consult
```

### Crop to vertical (9:16 for Reels/TikTok):
```
/cc-find-clip ~/Downloads/recording.mp4 --vertical
```

### Skip straight to extraction (if you already know timestamps):
```
/cc-find-clip ~/Downloads/recording.mp4 --start 05:32 --end 07:30
```

---

## PIPELINE PROCEDURE

### STEP 0: VALIDATE

1. Check the input file exists and is video (`.mp4`, `.mov`, `.avi`, `.mkv`, `.webm`)
2. Check dependencies:
   ```bash
   which ffmpeg
   which mlx_whisper
   ```
   - ffmpeg is required (installed by the CC bootstrap)
   - mlx_whisper gives fast on-device transcription on Apple Silicon. If it is missing (e.g. Intel Mac), fall back to the OpenAI Whisper API (see the /transcribe skill) - do NOT install slow local openai-whisper.
3. Get video duration:
   ```bash
   ffprobe -v error -show_entries format=duration -of csv=p=0 "[input]"
   ```
4. Parse flags:
   - `--duration N` - target clip length in seconds (default: 120)
   - `--top N` - number of clips to extract (default: 1)
   - `--name SLUG` - slug for output naming (default: derived from the input filename)
   - `--vertical` - crop to 9:16 after extraction
   - `--start MM:SS --end MM:SS` - skip analysis, extract directly
   - `--model [tiny|base|small|medium]` - Whisper model size (default: small)

5. If `--start` and `--end` are provided, skip to STEP 4 directly.

---

### STEP 1: TRANSCRIBE WITH WORD-LEVEL TIMESTAMPS

Use mlx-whisper for fast Apple Silicon transcription with word-level timestamps.

```bash
mlx_whisper "[input-file]" \
  --model mlx-community/whisper-small-mlx \
  --output-format json \
  --word-timestamps True \
  --output-dir /tmp/cc-find-clip/
```

**Model options (for --model flag):**
- `tiny` - fastest, rougher timestamps. Use for videos over 60 min
- `base` - fast, decent accuracy
- `small` - good balance (DEFAULT) - best for clip finding because word timestamps are more precise
- `medium` - high accuracy, slower. Use when a perfect transcript is needed

The JSON output includes segments with word-level timestamps like:
```json
{
  "segments": [
    {
      "start": 0.0,
      "end": 5.2,
      "text": " And this is the thing that changed everything for me.",
      "words": [
        {"word": "And", "start": 0.0, "end": 0.3},
        {"word": "this", "start": 0.3, "end": 0.5}
      ]
    }
  ]
}
```

If mlx_whisper is unavailable, transcribe via the OpenAI Whisper API (the /transcribe method) and build the same timestamped transcript.

**Parse the JSON output** and build a timestamped transcript where each line has `[MM:SS]` timestamps.

---

### STEP 2: AUDIO ENERGY ANALYSIS

Run ffmpeg to get per-second volume (RMS) levels - no extra libraries needed.

```bash
ffmpeg -i "[input-file]" -af "astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=/tmp/cc-find-clip/energy.txt" -f null - 2>/dev/null
```

Then parse the energy data into a simple format. Use Python to process:

```bash
python3 << 'PYEOF'
import re

energy_data = []
with open('/tmp/cc-find-clip/energy.txt') as f:
    lines = f.readlines()

current_time = 0
for i, line in enumerate(lines):
    if 'lavfi.astats.Overall.RMS_level' in line:
        match = re.search(r'=(-?[\d.]+)', line)
        if match:
            rms = float(match.group(1))
            energy_data.append((current_time, rms))
            current_time += 1

# Calculate rolling average energy per 10-second window
window = 10
rolling = []
for i in range(len(energy_data) - window):
    chunk = energy_data[i:i+window]
    avg_rms = sum(e[1] for e in chunk) / window
    rolling.append((energy_data[i][0], avg_rms))

# Find the hottest windows (most energy = loudest/most animated speech)
rolling.sort(key=lambda x: x[1], reverse=True)

# Output top 10 hot zones (timestamps in seconds)
print("HOT ZONES (highest energy):")
seen = set()
count = 0
for ts, rms in rolling:
    minute = ts // 30
    if minute not in seen and count < 10:
        seen.add(minute)
        mins = int(ts // 60)
        secs = int(ts % 60)
        print(f"  [{mins:02d}:{secs:02d}] RMS: {rms:.1f} dB")
        count += 1
PYEOF
```

**What this tells you:**
- Higher RMS (closer to 0 dB) = louder, more energetic speech
- Lower RMS (more negative, like -40 dB) = quiet, pauses, low energy
- Hot zones are where the speaker is most animated/passionate

---

### STEP 3: AI CLIP SCORING

Now combine the transcript + energy data and score segments.

**Build the scoring prompt** with this structure:

```
You are a viral content editor for an aesthetics/skin clinic. Find the single best ~[DURATION]-second clip from this recording for social media. It must be concern-led and AHPRA-safe (no therapeutic/outcome claims, no prescription product names).

TRANSCRIPT (with timestamps):
[paste the timestamped transcript]

AUDIO ENERGY HOT ZONES (most animated moments):
[paste the hot zones from Step 2]

TOTAL VIDEO DURATION: [duration]

SCORING CRITERIA (in order of importance):
1. HOOK STRENGTH (40%) - Does it open with something that stops the scroll? A bold (but compliant) claim, a relatable concern, an emotional moment, or a provocative question in the first 5 seconds?
2. STANDALONE CLARITY (25%) - Does it make complete sense without any other context? Would someone landing on this clip cold understand and be engaged?
3. EMOTIONAL ENERGY (20%) - Is there genuine warmth, conviction, or care? Cross-reference with the audio energy hot zones.
4. CLEAN BOUNDARIES (15%) - Does it start and end on complete thoughts? Natural pause points? Never cut mid-sentence.

RULES:
- Target duration: ~[DURATION] seconds (can be 10-20 seconds shorter or longer if the thought requires it)
- The clip MUST start with a strong hook
- The clip MUST end on a complete thought
- Prefer segments that overlap with audio energy hot zones
- A clear "how it works" or "what to expect" education moment is almost always a great clip
- A warm, human, behind-the-scenes moment is almost always a great clip
- REJECT any segment that makes a therapeutic/outcome guarantee or names a prescription product

Return EXACTLY this format for each clip (return [TOP_N] clips ranked best to worst):

CLIP 1:
START: [MM:SS]
END: [MM:SS]
DURATION: [N seconds]
HOOK: [the opening line that grabs attention]
SUMMARY: [one sentence - what this clip is about]
SCORE: [1-10]
WHY: [one sentence - why this is the best clip]

CLIP 2:
...
```

**Read the response** and extract the START/END timestamps for each clip.

**Present the clips to the user** before extracting:
- Show each clip's hook, summary, score, and why
- Ask: "Extract these? Or want me to adjust?"
- If approved, proceed to Step 4
- If changes are wanted, re-run with that guidance

---

### STEP 4: EXTRACT THE CLIP(S)

For each approved clip, extract with ffmpeg.

**Lossless extraction (fast, no re-encode):**
```bash
ffmpeg -ss [START_TIME] -to [END_TIME] -i "[input]" -c copy -avoid_negative_ts make_zero "[output]" -y
```

**If lossless extraction has sync issues** (audio drift, bad keyframe), re-encode:
```bash
ffmpeg -ss [START_TIME] -to [END_TIME] -i "[input]" -c:v libx264 -preset fast -crf 18 -c:a aac -b:a 192k "[output]" -y
```

**If `--vertical` flag is set**, crop to 9:16 centre-crop:
```bash
ffmpeg -ss [START_TIME] -to [END_TIME] -i "[input]" -vf "crop=ih*9/16:ih" -c:v libx264 -preset fast -crf 18 -c:a aac -b:a 192k "[output]" -y
```

**Output naming:**
```
~/Downloads/clip-[YYYY-MM-DD]-[slug]-[N].mp4
```
- `slug` from `--name`, or derived from the input filename (lowercase, hyphens, no extension)
- `N` is clip number (01, 02, etc.)

Examples:
```
~/Downloads/clip-2026-06-30-skin-consult-01.mp4
~/Downloads/clip-2026-06-30-treatment-walkthrough-01.mp4
~/Downloads/clip-2026-06-30-treatment-walkthrough-02.mp4
```

---

### STEP 5: SUMMARY AND NEXT STEPS

After extraction, tell the user:

1. **What was extracted:**
   - Clip path(s)
   - Duration of each clip
   - The hook/opening line of each clip

2. **Suggested next step:**
   ```
   Turn this into captions + post copy + hashtags:
   /cc-content-pipeline ~/Downloads/[clip-filename].mp4
   ```

3. **Clean up temp files:**
   ```bash
   rm -rf /tmp/cc-find-clip/
   ```

---

## BATCH MODE

When multiple videos are provided, process them sequentially:

```
/cc-find-clip ~/Downloads/video1.mp4 ~/Downloads/video2.mp4 ~/Downloads/video3.mp4
```

For each video:
1. Run the full pipeline (Steps 1-4)
2. Present all clips together at the end
3. Get approval before extracting

---

## EDGE CASES

- **Video under 3 minutes:** Skip energy analysis, just trim dead air from start/end. The whole video IS the clip.
- **Video over 2 hours:** Use `--model tiny` for speed. Warn that transcription will take a few minutes.
- **No clear "best" moment:** Present top 3 and let the user choose. Say "None of these jumped out as a clear winner - here are the top 3, which one feels right?"
- **Audio-only file:** Works the same - skip `--vertical`, output as `.mp3` not `.mp4`
- **Multiple speakers:** Note which segments have the strongest single-speaker moments (multi-speaker clips are harder to follow on social)

---

## CAPTION DETECTION

Before processing, check if the source video already has captions burned in. **Never double-layer captions.**

A video likely HAS hardcoded captions if ANY of these are true:
- Filename contains "caption", "captioned", "edited", "cropped", or "subtitled" (case-insensitive)
- File is inside an `edited/` folder
- File is inside a `Ready_to_Post/` or `Posted_Archive/` folder

If captions are detected:
1. **Flag it:** "This file looks like it already has captions burned in - skipping caption generation."
2. Set `--no-captions` context for the downstream skill (/cc-content-pipeline)
3. Still extract the clip normally - just don't add captions on top

When in doubt, **ask** before adding captions. Double-layered captions look amateur and kill credibility.

---

## IMPORTANT RULES

- NEVER extract without showing the clip selections first (unless told "just do it" or "auto")
- NEVER re-encode if lossless copy works - check the output plays correctly
- NEVER use emdashes in any output
- NEVER select a clip that breaches AHPRA (therapeutic/outcome claims, prescription product names)
- NEVER add captions to a video that already has them burned in (see Caption Detection above)
- ALWAYS clean up /tmp/cc-find-clip/ when done
- ALWAYS suggest /cc-content-pipeline as the next step
- If mlx_whisper fails for any reason, fall back to the OpenAI Whisper API (see the /transcribe skill for the API method)
