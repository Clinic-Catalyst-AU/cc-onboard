---
name: cc-enquiry-sweep
description: The agent that never leaves an enquiry behind. Sweeps the clinic's GHL conversations for "the queue of quiet" - enquiries that were answered but went silent 24+ hours ago, AND inbound enquiries nobody ever answered - then reads each actual thread, drafts a reply that continues that exact conversation in the clinic's voice from the Business Brain, SHOWS the owner the whole queue with drafts to approve/edit/skip per thread, and on approval sends each reply back into the same channel (SMS, email, FB, IG) and verifies it landed in the thread. Use when the clinic says enquiry sweep, queue of quiet, follow up my DMs, unanswered enquiries, silent leads, who went quiet, chase up enquiries, check my conversations, or as a morning routine alongside the daily check-in. Companion to /cc-follow-up-agent (scheduled nurture) - THIS is the conversational one-to-one layer.
---

# CC Enquiry Sweep - Nobody Left Behind

Every clinic has a queue of quiet: the person who asked about microneedling on Tuesday, got one reply, and then silence. The DM nobody saw. They were interested enough to reach out - and nobody followed up. This skill finds every one of them, drafts a reply that picks up *their* conversation where it left off, and sends it (owner-approved) back into the same thread, same channel.

*Why an agent and not a workflow* - a canned drip cannot continue a conversation about someone's rosacea downtime. The reply has to come from reading the actual thread. That is what Claude is for; the script handles the deterministic parts (find, filter, send, verify).

## File contract

Follows the Business Brain File Contract (your workspace `CLAUDE.md`). READS `Business-Brain/brand-guide.md` + `resonance-messaging.md` (the voice for every draft). WRITES exactly two files per run: `Emails/enquiry-sweep/[YYYY-MM-DD]-queue.md` (the review doc) and `[YYYY-MM-DD]-queue.json` (the working payload) - nothing else. Never writes into `Business-Brain/`.

*GHL access* - read the clinic's PIT + Location ID from `Credentials/credentials-reference.txt`. The PIT needs the *conversations (read), conversation messages (read + write), and contacts (read + write)* scopes - if the sweep fails with a scope error, walk the owner through adding them (Settings > Private Integrations > edit).

## HOW TO USE

```
/cc-enquiry-sweep            (default: 24h+ quiet, last 14 days)
/cc-enquiry-sweep 48h        (custom quiet threshold)
```

## RUN STEPS

1. *Find the queue* (deterministic - the bundled script):
   ```
   python3 sweep_enquiries.py list --location <LOCATION_ID> --out Emails/enquiry-sweep/[date]-queue.json
   ```
   (Windows: `python`.) It returns every thread in the window that is (a) *WENT_QUIET* - the clinic spoke last, 24h+ ago, or (b) *UNANSWERED* - an inbound enquiry nobody replied to (worse - surface these FIRST). It already excludes anyone tagged `booked`, `client` or `enquiry-swept`, and skips non-message activity (no-shows, system events).
2. *Read the Business Brain* - `brand-guide.md` + `resonance-messaging.md`. Every draft must sound like the clinic (OPEN words, tone do/don't), not like a bot.
3. *Draft each reply from the THREAD* - read the included message history and continue that exact conversation: reference what they asked about, answer anything left hanging, and end with one gentle next step. Warm, short, human - the length of a text a real person sends. *AHPRA note:* a solicited one-to-one follow-up to an existing enquiry is transactional, NOT advertising - and it STAYS that way only if there is no promo line. Never add offers, discounts or promotional language to a sweep reply; that flips it into advertising and changes the rules. No outcome promises, no restricted words, ever.
4. *Show the owner the queue* - the review doc lists every thread: who, channel, how long quiet, the conversation so far, and the drafted reply. Approval is PER THREAD: approve / edit / skip each one. Never send anything the owner has not seen.
5. *Send the approved set*:
   ```
   python3 sweep_enquiries.py send Emails/enquiry-sweep/[date]-queue.json --location <LOCATION_ID>
   ```
   (Only items where the owner's approved text sits in the `reply` field are sent.) The script sends into the original channel, RE-READS each thread to verify the message actually landed, then tags the contact `enquiry-swept` so this quiet spell is never chased twice. Hard cap 15 sends per run - if the approved set is bigger, that is a signal to check the queue, not to raise the cap casually.
6. *Report honestly* - sent+verified / MANUAL / failed. *MANUAL means Meta's rules, not a bug:* Facebook and Instagram only allow replies within 24 hours of the contact's last message, so an IG/FB thread that has been quiet longer usually cannot be messaged by API. The report tells the owner exactly which threads to answer inside the app (or the draft can go by SMS/email instead if the contact has one - offer that swap at the approval step).

## RULES

- NEVER send without per-thread owner approval. The queue doc is the approval surface.
- NEVER add promotional content to a sweep reply - it is a follow-up, not a campaign (this is the AHPRA line).
- ONE send attempt per thread per run; failures are reported, never retried blind. Respect the 15-send cap.
- NEVER report sent without the script's re-read verification. "The API returned 200" is not "it landed".
- Never invent clinic facts, prices or availability in a draft - if the thread asks something the Business Brain does not answer, the draft says the clinic will confirm, or the thread is flagged for the owner to answer personally.
- The `enquiry-swept` tag is the re-run guard. If someone replies again later, they re-enter the queue naturally on the next quiet spell only if the owner removes the tag - mention this in the report.
- Contacts tagged `booked` or `client` are never swept.

Pairs with `/cc-follow-up-agent` (the scheduled nurture lanes) and `/cc-newsletter-engine` (the weekly newsletter) - the sweep is the one-to-one conversational layer on top.
