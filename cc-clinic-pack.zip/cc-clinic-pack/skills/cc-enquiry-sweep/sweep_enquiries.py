#!/usr/bin/env python3
"""
CC Enquiry Sweep - find "the queue of quiet" in a clinic's GHL conversations and
(after owner approval) send the drafted replies back into the same threads.
Stdlib only (urllib).

The queue of quiet = threads where an enquiry was answered but the person went
silent (clinic spoke last, 24h+ ago, no `booked` tag), plus genuinely UNANSWERED
inbound enquiries. These people were never followed up - this skill makes sure
nobody is left behind.

Modes:
  # find the queue (writes queue JSON to stdout or --out):
  python3 sweep_enquiries.py list --location <LOC> [--hours 24] [--window-days 14] [--out queue.json]
  # send the APPROVED drafts (payload = queue JSON with a "reply" added per item):
  python3 sweep_enquiries.py send approved.json --location <LOC> [--max-sends 15]

Auth: PIT from $GHL_PIT. Required scopes: conversations (read), conversation
messages (read + write), contacts (read + write).

Send safety: refuses items without an owner-approved "reply"; hard cap per run
(default 15); ONE attempt per thread; tags the contact `enquiry-swept` after a
verified send so the same quiet spell is never chased twice; IG/FB sends outside
Meta's 24h window fail cleanly and are reported as MANUAL (reply inside the app).
"""
import sys, os, json, time, argparse, urllib.request, urllib.error

BASE = "https://services.leadconnectorhq.com"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# conversation lastMessageType -> send channel for POST /conversations/messages
CHANNEL = {"TYPE_SMS": "SMS", "TYPE_EMAIL": "Email", "TYPE_FACEBOOK": "FB",
           "TYPE_INSTAGRAM": "IG", "TYPE_WHATSAPP": "WhatsApp",
           "TYPE_WEBCHAT": "Live_Chat", "TYPE_LIVE_CHAT": "Live_Chat",
           "TYPE_GMB": "GMB"}
SKIP_TAGS = {"booked", "client", "enquiry-swept"}


def api(method, path, pit, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method)
    for k, v in [("Authorization", f"Bearer {pit}"), ("Version", "2021-07-28"),
                 ("Accept", "application/json"), ("User-Agent", UA)]:
        req.add_header(k, v)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        return {"_err": e.code, "_msg": e.read().decode()[:200]}


def thread_messages(conv_id, pit, limit=8):
    res = api("GET", f"/conversations/{conv_id}/messages?limit={limit}", pit)
    if "_err" in res:
        return []
    msgs = res.get("messages", {})
    if isinstance(msgs, dict):
        msgs = msgs.get("messages", [])
    out = []
    for m in msgs:
        body = (m.get("body") or "").strip()
        if not body:
            continue
        out.append({"direction": m.get("direction", "?"),
                    "type": m.get("messageType", "?"),
                    "date": m.get("dateAdded", ""),
                    "body": body[:600]})
    return list(reversed(out))  # oldest first for reading


def cmd_list(args):
    now_ms = time.time() * 1000
    res = api("GET", f"/conversations/search?locationId={args.location}&limit=100&sort=desc&sortBy=last_message_date", args.pit)
    if "_err" in res:
        print(f"!! conversations search failed: HTTP {res['_err']} {res['_msg']}\n"
              "   Check the PIT has the conversations read scopes."); sys.exit(1)
    queue, skipped = [], {"fresh_or_old": 0, "not_message": 0, "tagged": 0, "booked_appt": 0}
    for c in res.get("conversations", []):
        last = c.get("lastMessageDate") or 0
        age_h = (now_ms - last) / 3600000.0
        if age_h < args.hours or age_h > args.window_days * 24:
            skipped["fresh_or_old"] += 1; continue
        mtype = c.get("lastMessageType", "")
        if mtype not in CHANNEL:
            skipped["not_message"] += 1; continue
        direction = c.get("lastMessageDirection")
        unanswered = direction == "inbound"
        if not unanswered and direction != "outbound":
            skipped["not_message"] += 1; continue
        contact = api("GET", f"/contacts/{c.get('contactId')}", args.pit).get("contact", {})
        tags = {t.lower() for t in contact.get("tags", [])}
        if tags & SKIP_TAGS:
            skipped["tagged"] += 1; continue
        thread = thread_messages(c["id"], args.pit)
        if not thread:
            skipped["not_message"] += 1; continue
        queue.append({
            "conversationId": c["id"], "contactId": c.get("contactId"),
            "name": contact.get("firstName", "") or c.get("contactName", ""),
            "fullName": (contact.get("firstName", "") + " " + contact.get("lastName", "")).strip(),
            "email": contact.get("email"), "phone": contact.get("phone"),
            "channel": CHANNEL[mtype], "silence_hours": round(age_h),
            "status": "UNANSWERED" if unanswered else "WENT_QUIET",
            "thread": thread, "reply": None
        })
    out = {"generated_at_ms": int(now_ms), "location": args.location,
           "found": len(queue), "skipped": skipped, "queue": queue}
    text = json.dumps(out, indent=1)
    if args.out:
        open(args.out, "w").write(text)
        print(f"Queue of quiet: {len(queue)} thread(s) -> {args.out}")
        for q in queue:
            print(f"  [{q['status']}] {q['fullName'] or q['name']} via {q['channel']} - quiet {q['silence_hours']}h")
        print(f"Skipped: {skipped}")
    else:
        print(text)


def cmd_send(args):
    data = json.load(open(args.payload))
    items = [q for q in data.get("queue", []) if q.get("reply")]
    if not items:
        print("Nothing to send - no items carry an approved 'reply'."); sys.exit(1)
    if len(items) > args.max_sends:
        print(f"!! ABORT: {len(items)} approved sends exceeds the cap of {args.max_sends}. "
              "Raise --max-sends deliberately if this is genuinely intended."); sys.exit(1)
    sent, manual, failed = [], [], []
    for q in items:
        body = {"type": q["channel"], "contactId": q["contactId"]}
        if q["channel"] == "Email":
            body["subject"] = q.get("subject") or "Following up on your enquiry"
            body["html"] = q["reply"].replace("\n", "<br>")
        else:
            body["message"] = q["reply"]
        res = api("POST", "/conversations/messages", args.pit, body)
        if "_err" in res:
            (manual if q["channel"] in ("IG", "FB") else failed).append(
                (q, f"HTTP {res['_err']} {res['_msg']}"))
            continue
        # verify: the message must actually appear in the thread
        time.sleep(1.5)
        tail = thread_messages(q["conversationId"], args.pit, limit=4)
        landed = any(q["reply"][:60] in m["body"] for m in tail)
        if not landed:
            failed.append((q, "sent but NOT found in thread on re-read")); continue
        api("POST", f"/contacts/{q['contactId']}/tags", args.pit, {"tags": ["enquiry-swept"]})
        sent.append(q)
        print(f"  SENT + VERIFIED: {q['fullName'] or q['name']} via {q['channel']}")
    for q, why in manual:
        print(f"  MANUAL (reply inside the app - Meta 24h window): {q['fullName'] or q['name']} via {q['channel']} - {why}")
    for q, why in failed:
        print(f"  FAILED: {q['fullName'] or q['name']} via {q['channel']} - {why}")
    print(f"\n{len(sent)} sent+verified, {len(manual)} manual, {len(failed)} failed of {len(items)} approved.")
    sys.exit(0 if not failed else 1)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="mode", required=True)
    pl = sub.add_parser("list"); pl.add_argument("--location", required=True)
    pl.add_argument("--hours", type=float, default=24); pl.add_argument("--window-days", type=float, default=14)
    pl.add_argument("--out"); pl.set_defaults(fn=cmd_list)
    ps = sub.add_parser("send"); ps.add_argument("payload"); ps.add_argument("--location", required=True)
    ps.add_argument("--max-sends", type=int, default=15); ps.set_defaults(fn=cmd_send)
    for p in (pl, ps):
        p.add_argument("--pit", default=os.environ.get("GHL_PIT") or os.environ.get("CC_GHL_PIT"))
    args = ap.parse_args()
    if not args.pit:
        print("No PIT. Set $GHL_PIT."); sys.exit(2)
    args.fn(args)


if __name__ == "__main__":
    main()
