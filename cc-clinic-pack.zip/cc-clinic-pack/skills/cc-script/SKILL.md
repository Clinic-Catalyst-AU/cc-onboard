---
name: cc-script
description: The Video Script Agent from the workshop - turns a clinic's Business Brain into recordable, AHPRA-safe video scripts for ads and social. Six script types (30-second ad, 60-second ad, problem-aware, offer, educational, remarketing/warm audience), each with a scroll-stopping 3-second hook, a talking-head script AND a demo/b-roll shot list, plus on-screen text lines. Use when you say video script, script agent, cc script, write me an ad script, script for [treatment/offer], remarketing video, or educational video script.
user_invocable: true
---

# CC Script - the Video Script Agent

Turns your Business Brain into scripts you can record on a phone TODAY. This is the agent built
in the Day 1 "Video Script Agent & Ad Creation Framework" session - it sits between your OFFER
(what to say) and PRODUCTION (recording, CapCut/editing, then /cc-find-clip -> /cc-assemble ->
/cc-reeltalkinghead -> /cc-cover). Script in, shot list out, camera on.

## File contract

READS (never writes): `Business-Brain/resonance-messaging.md` (the emotional source of truth - see
NEURO-EMOTIVE WIRING below) + `Business-Brain/brand-guide.md` (voice), `Business-Brain/resonance-messaging.md`
(ideal patient, #1 pain, desires, AND the remarketing pain points list), `Business-Brain/offers.md`
(the offer architecture: name, prices, inclusions, urgency, scarcity).
WRITES: `Content/scripts/<slug>-<type>.md`. Paths relative to the clinic workspace (`~/Clinic/`).
Missing brain files: say which one, offer the skill that builds it (`/cc-resonance`, `/cc-brand-guide`).
Never fabricate prices, results or reviews.

## NEURO-EMOTIVE WIRING (mandatory - this is what makes the script land, not read like any clinic)

Run the shared engine before writing a line: `cc-resonance/references/neuro-emotive-engine.md` (installed alongside this skill). In short:
1. READ `Business-Brain/resonance-messaging.md` - the emotional stack, the arc, the OPEN/CLOSE language bank, the headline angles, the proof map - as well as `brand-guide.md`. If `resonance-messaging.md` is missing, offer `/cc-resonance`; never generate off the brand-guide alone (that is what makes scripts thin).
2. APPLY the 21 neuro-emotive models (`cc-resonance/references/model-library.md`), mapped to the script: the 3-second hook = Curiosity Spark (open loop / pattern interrupt); the body = Emotional Proof + Empathy Echo + Pain Diffuser; problem-aware framing = Believability Bridge (contrast, never before/after); the close = Guided Choice Maker; Voiceprint Precision throughout.
3. GROUND every line in the clinic's real offer + their OPEN language bank. You should be able to point at any line and name the model firing AND the OPEN word it used. A generic script that ignores the resonance doc is a FAILED run - regenerate.

## The six script types (from the workshop framework)

| Type | Length | Job |
|---|---|---|
| 30-second ad | ~65-80 words | The offer, fast: hook -> problem -> offer -> CTA |
| 60-second ad | ~130-160 words | Room to build the problem before the offer lands |
| Problem-aware ad | 30-60s | Speaks to someone who knows the problem but not the fix - education first, offer soft |
| Offer ad | 30s | The offer IS the star: architecture verbatim (name, price, inclusions, urgency, scarcity) |
| Educational | 60-90s | Value, no pitch - builds trust and feeds organic/remarketing pools |
| Remarketing / warm | 30-45s | Hits a DIFFERENT pain point than the first ad (pull from the remarketing pain-points list in the Business Brain) - warmer tone, lower friction CTA |

Default: generate the type asked for. "Give me the set" = all six for one offer.

## Every script gets ALL of this

1. **The hook (first 3 seconds) - one option per hook type**, using the Agent Framework's
   5 hook types (matches the Day 1 deck's Hook Framework Reference). Mark which is which.
   The hook must stop the scroll BEFORE the viewer knows what the video is about.
   | Hook type | Shape (deck example) |
   |-----------|----------------------|
   | Pattern interrupt | "Stop scrolling. This is for you if you..." |
   | Curiosity | "Most people don't know there's a way to [result] without [pain point]..." |
   | Pain-based | "Tired of looking [tired/dull/older]? You're not alone." |
   | Desire-based | "Imagine waking up and actually loving what you see..." |
   | Social proof | "Over 200 patients have tried this in our [suburb] clinic..." - aggregate numbers ONLY, must be TRUE for this clinic, never a testimonial or a result claim |
2. **Talking-head script** - written for SPEECH: short sentences, contractions, no marketing-speak.
   Read-aloud time marked. Direction notes in [brackets] (e.g. [hold up product], [lean in]).
3. **Demo / b-roll alternative** - the same message as a shot list over footage (treatment shots,
   clinic b-roll, hands, results-adjacent visuals) with a voiceover line per shot. This is the
   version for owners who hate talking to camera.
4. **On-screen text lines** - the 3-5 caption cards that carry the message with sound OFF.
5. **CTA + conversion triggers** - from the offer architecture only (urgency, scarcity, bonus).
   Never invent a trigger the clinic didn't set.

## The rules (non-negotiable)

- **Outcome, never technology.** No device names, no brand names, no RF/IPL acronyms in the
  spoken script. Read `~/.claude/skills/cc-metaad-builder/references/perfect-ad-examples.md` BEFORE
  writing - those two examples are the bar for tone and structure.
- **Their words, not marketing words.** Pull pain language verbatim from the Business Brain
  ("I look tired even when I'm not") - the script should sound like the patient's own thoughts.
- **AHPRA gate (mandatory, last step):** screen every line - no "specialist/expert/best/leading",
  no testimonials, no guaranteed results, no S4 pricing or product
  names (no "Botox" - "anti-wrinkle" only), no "safe/no risk". If a line fails, rewrite it and
  say so. Never hand over a non-compliant script.
- **Before/after visuals in a script:** skin-treatment before/afters (non-Schedule-4 - IPL, skin
  needling, LED, HIFU, facials, peels) are allowed in a video shot list, provided they are genuine,
  consented, realistic (same lighting, not misleading) and never framed as a guaranteed result.
  Injectable (Schedule 4) before/afters must NEVER appear in a public ad or social video - they
  are permitted only in direct channels (email, or after a consult). Always defer to the clinic's
  own resonance-messaging.md / brand-guide.md boundaries (some brands use none at all). Never a
  patient testimonial that claims a treatment result.
- **/stoptheslop pass** on all copy. No em-dashes. Speakable > clever.

## Handoffs

- Record it -> `/cc-find-clip` (best take) -> `/cc-assemble` (stitch + music) -> `/cc-reeltalkinghead`
  (captions) -> `/cc-cover` (thumbnail) -> post via the content engine.
- The matching WRITTEN ad copy (headlines, primary text) comes from `/cc-metaad-builder` -
  same offer, same pain points, so the video and the copy tell one story.
