#!/usr/bin/env python3
"""
CC Content Engine validator.
Checks a month of organic social posts against AHPRA/TGA rules + structural sanity.
Mirrors cc-googlead-builder/validate.py, extended for organic content (longer captions,
hooks, testimonials, before/after, pillar mix).

Usage:
  python3 validate.py posts.json
JSON shape (see references/output-format.md):
  {"clinic":"...","month":"...","offer_is_free_consult":true,
   "posts":[{"id":1,"pillar":"Educate","hook":"...","body":"...","cta":"...",
             "hashtags":["..."],"image_direction":"...","offer_linked":true}]}
Exit 0 = clean, exit 1 = violations found (printed).
"""
import sys, json, re

# Instagram caption hard cap is ~2200 chars. Hook (first line) should stay punchy.
BODY_MAX, HOOK_MAX = 2200, 125
PILLARS = {"Educate", "Connect", "Proof", "Offer"}

# AHPRA / TGA banned - therapeutic claims, restricted terms, regulated-treatment proof.
# Case-insensitive, word-ish boundaries. Same spine as the ad builder, plus organic additions.
BANNED = [
    r"#1", r"\bbest\b", r"\bleading\b", r"\bmost effective\b", r"\bexpert\b",
    r"\bspecialist\b", r"\btop\b", r"\bbefore\s*/?\s*&?\s*after\b", r"\bb\s*&\s*a\b",
    r"\bguarantee", r"\bsafe\b", r"\bno risk\b", r"\bpainless\b", r"\bbotox\b",
    r"\bdysport\b", r"\bxeomin\b", r"\bcure\b", r"\bpermanent\b",
    r"wrinkle[- ]free", r"\byears younger\b", r"anti[- ]ag(e)?ing", r"\bmiracle\b",
    r"\bno downtime\b", r"\bproven results\b", r"\bflawless\b",
    # claim-context only (not bare process verbs): "clears your acne", "removes pigmentation"
    r"\bclears?\b[^.]{0,20}\b(acne|pigment|wrinkle|scar)", r"\beliminat\w*\b[^.]{0,20}\b(acne|pigment|wrinkle|line)",
    r"\bremoves?\b[^.]{0,20}\b(pigment|wrinkle|sun damage|scar)",
]
# Testimonial / endorsement tells for regulated treatments (hard fail in Proof/any post).
TESTIMONIAL = [
    r"\bmy skin has never\b", r"\bbest decision\b", r"\bhighly recommend\b",
    r"\blife[- ]changing\b", r"\bcouldn'?t be happier\b", r"\breview from\b",
    r"\bclient says\b", r"\btestimonial\b", r"\b5[- ]star\b", r"\bobsessed with my results\b",
]
# Flag for human review (medium risk), not a hard fail.
WARN = [
    r"natural[- ]looking", r"\bproven\b", r"\bamazing\b", r"\btransform", r"\byounger\b",
    r"\bglow\b", r"\bconfidence\b", r"\bresults\b",
]
# AI-tell / style backstop (Slop should have caught these; this is the safety net).
# Emdash is a hard CC house-rule breach. The contrast pattern ("not just X, it's Y") is the classic AI tell.
SLOP = [
    r"—", r"\bisn'?t just\b", r"\bnot just (a|an|about)\b",
    r"\bunlock\b", r"\belevate\b", r"\bdive in\b", r"\bgame[- ]changer\b",
]


def scan(text, patterns):
    return [p for p in patterns if re.search(p, text, re.I)]


def main():
    if len(sys.argv) < 2:
        print("usage: validate.py posts.json"); sys.exit(2)
    data = json.load(open(sys.argv[1]))
    posts = data.get("posts", [])
    errors, warnings = [], []

    if not posts:
        print("No posts found in JSON."); sys.exit(2)

    mix = {p: 0 for p in PILLARS}

    for post in posts:
        pid = post.get("id", "?")
        pillar = post.get("pillar", "")
        if pillar not in PILLARS:
            errors.append(f"Post {pid}: pillar '{pillar}' not one of {sorted(PILLARS)}")
        else:
            mix[pillar] += 1

        hook = post.get("hook", "")
        body = post.get("body", "")
        cta = post.get("cta", "")
        full = " ".join([hook, body, cta] + post.get("hashtags", []))

        if not hook:
            errors.append(f"Post {pid}: missing hook (the first line does the work)")
        elif len(hook) > HOOK_MAX:
            warnings.append(f"Post {pid}: hook is {len(hook)} chars (>{HOOK_MAX}), tighten it")
        if len(body) > BODY_MAX:
            errors.append(f"Post {pid}: body is {len(body)} chars (>{BODY_MAX} IG cap)")

        b = scan(full, BANNED)
        if b: errors.append(f"Post {pid} AHPRA term {b}")
        t = scan(full, TESTIMONIAL)
        if t: errors.append(f"Post {pid} testimonial/endorsement (banned for regulated tx) {t}")
        s = scan(full, SLOP)
        if s: errors.append(f"Post {pid} AI-tell/emdash {s} - re-run /stoptheslop")
        w = scan(full, WARN)
        if w: warnings.append(f"Post {pid} review {w}")

    # Pillar mix sanity - value before the ask. Offer should not dominate.
    total = len(posts)
    if total:
        offer_share = mix["Offer"] / total
        if offer_share > 0.25:
            errors.append(f"Offer is {offer_share:.0%} of posts (>25%) - too salesy, rebalance to value")
        if mix["Educate"] < mix["Offer"]:
            warnings.append("Educate posts < Offer posts - the feed leans sales over value")

    print("=== CC Content Engine validation ===")
    print(f"Posts: {total} | mix: " + ", ".join(f"{k} {mix[k]}" for k in ["Educate","Connect","Proof","Offer"]))
    if warnings:
        print(f"\n{len(warnings)} to review (medium risk):")
        for w in warnings: print("  ! " + w)
    if errors:
        print(f"\n{len(errors)} ERRORS - fix before presenting:")
        for e in errors: print("  X " + e)
        sys.exit(1)
    print("\nAll clear: AHPRA OK, no testimonials/before-after, lengths OK, mix balanced.")
    sys.exit(0)


if __name__ == "__main__":
    main()
