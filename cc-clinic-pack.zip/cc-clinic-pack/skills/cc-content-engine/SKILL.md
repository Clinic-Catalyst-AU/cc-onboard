---
name: cc-content-engine
description: Generate a month of organic social content for an aesthetics clinic, on-brand and AHPRA-safe, driven by the month's offer strategy. Reads the clinic's brand-guide.md, plans posts across the four content pillars (Educate, Connect, Proof, Offer) along the know-like-trust-then-offer arc, drafts in the clinic's voice, then runs every post through /cc-marketing-genius and /stoptheslop and a hard AHPRA gate before delivery. Outputs a pillar-tagged review doc, a GHL Social Planner push, and a CSV fallback. Use when you say cc content engine, content engine, build the content, monthly content, social content for [clinic], content calendar, or content plan for [clinic]. This is the organic counterpart to /cc-metaad-builder (paid Meta) or /cc-googlead-builder (Google) (which does paid).
---

# CC Content Engine - Monthly Organic Social Generator

Turns a clinic's brand-guide.md plus the month's offer into a full month of organic social posts that build know-like-trust before they ask for the booking. The last link in the flagship chain: `/cc-resonance` -> `/cc-brand-guide` -> *this*.

This is the ORGANIC engine. Paid search ads are a different job - that is `/cc-metaad-builder (paid Meta) or /cc-googlead-builder (Google)`. Same brand spine (`brand-guide.md`), different output. Organic warms a relationship over weeks; ads catch existing intent. Do not collapse them.

## When to use

- you say "content engine", "build the content", "monthly content for [clinic]", "content calendar".
- A clinic has a brand-guide.md and needs a month of on-brand posts queued.
- Anytime a clinic would otherwise hand-write captions or pay an agency for organic.

## The principle (why pillars)

People buy from people they know, like and trust. So organic has to earn that in order: educate (Know), build the relationship (Like + Trust), show results within the rules (Trust), then make the offer (Convert). Random posts do not move anyone. A pillar system does.

Every post belongs to one of four pillars, and every pillar that month points at the month's hero offer. One message, every channel - the same offer drives the organic feed, the day-7 nurture email, and the ads. See `references/content-pillars.md`.

## Inputs

*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/brand-guide.md` + `Business-Brain/strategy.md` + `Business-Brain/concerns.md` and WRITES to `Content/` - never into `Business-Brain/`. All paths are relative to your clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If a required file is missing, say which one and offer to run the skill that creates it (no `brand-guide.md` -> run `/cc-brand-guide` first); never fabricate.

1. *The spine* - the clinic's `Business-Brain/brand-guide.md` (output of `/cc-brand-guide`). Read it in full: brand essence, ideal client, tone of voice, key messages, words-we-use / words-we-avoid, the emoji policy, the preferred hashtags, the aesthetic, and the Claude Context Block at the bottom. Everything inherits this. Nothing is hardcoded. If there is no `brand-guide.md` yet, run `/cc-brand-guide` first - do not write content without the spine.
2. *The monthly brief* - the offer-strategy input that aligns everything. Pull from `Business-Brain/strategy.md` (the month's theme + growth focus) and `Business-Brain/concerns.md` (the concern the offer answers); ask only for anything those files do not cover:
   - The month (and the season / what is topical - e.g. winter skin, pre-summer, Mother's Day).
   - The hero offer for the month (e.g. a complimentary skin consult, a winter peel focus). Flag if it touches Schedule 4 (anti-wrinkle) so pricing is blocked.
   - The single concern the offer answers (e.g. dull winter skin, congestion, pigmentation).
   - The booking link / CTA destination.
3. *Cadence* - posts per week and platforms (default: 4 posts/week across Instagram + Facebook feed, with a note on which suit Reels vs static). Ask if unspecified; default to 4/week = ~16 posts for the month.

If any input is missing, ask the few questions. Never invent clinic facts, treatments, team credentials, or results - verify against the brand-guide or ask. (The You Beauty deal died from one fabricated treatment.)

## The engine flow (run in this order)

```
read brand-guide.md  +  monthly brief
   |
1. plan the month   ->  assign pillars across the weeks at the target ratio,
                        each post tied to the month's offer/concern
   |
2. draft each post  ->  in the clinic's voice, using words-we-use, avoiding words-we-avoid
   |
3. /cc-marketing-genius  ->  sharpen the hook (first line) + the CTA + the angle
   |
4. /stoptheslop             ->  strip AI tells, humanise, enforce Australian English + no emdashes
   |
5. validate.py              ->  HARD AHPRA gate + length + hook checks. Fix + re-run until clean.
   |
deliver: month of posts, pillar-tagged, GHL-ready
```

Steps 3-5 are baked in, not optional. A brand guide alone is not enough - without the Marketing Genius + Slop + AHPRA passes the output reads like AI and risks a breach. Quality is baked in, not bolted on.

## The four pillars (the backbone)

| Pillar | Stage | Target weight | Job |
|--------|-------|---------------|-----|
| Educate | Know | ~40% | Concern-led education - explain the concern, the treatment, bust a myth |
| Connect | Like + Trust | ~25% | The people, values, why, behind-the-scenes, real qualifications |
| Proof | Trust | ~20% | Show results WITHIN AHPRA limits (see `references/proof-pillar-ahpra.md`) |
| Offer | Convert | ~15% | The month's offer + booking CTA, concern-led |

Value before the ask. For ~16 posts that is roughly 6 Educate, 4 Connect, 3 Proof, 3 Offer. Sequence them so the month opens on Educate/Connect and the Offer posts land once trust is built, not on day one. Full detail, examples, and per-pillar AHPRA notes in `references/content-pillars.md`.

## Funnel mapping (every post does a job)
Map each pillar to a funnel stage so the month covers the whole journey, not just one part of it:
- *Top of funnel (awareness)* = Educate + Connect - reach new people, build know + like.
- *Middle (consideration)* = Proof + deeper Educate - what to expect, honest process, build trust.
- *Bottom (conversion)* = Offer - the month's offer + booking CTA.
Aim roughly 50% top / 30% middle / 20% bottom across the month. Tag each post TOFU/MOFU/BOFU in the review doc so the owner sees the balance.

## Platform rules (apply per post - tag platform + format)
- *Facebook* rewards longer, story-led captions - let FB posts run longer and more narrative.
- *Instagram feed* wants shorter, punchier captions; the algorithm favours Reels for reach. Use carousels for the deeper educational pieces (for people who land on the profile and want to learn).
- *Reels (IG/TikTok)*: hook in the first line, on-screen text short, the caption supports rather than repeats.
- *TikTok* is the easiest place to edit a talking-head, then cross-post the same clip to IG + FB. Treat TikTok-first for talking-head video.

## Emoji + hashtags (read from the brain)
- *Emoji:* follow the clinic's emoji policy in `brand-guide.md` (yes/no + which regulars). If none is set, default to none or very sparse - clinical brands usually read cleaner without.
- *Hashtags:* use the clinic's preferred top hashtags from `brand-guide.md` if set; otherwise build 3-5 per post mixing broad + niche + local ("near me" / suburb). If asked, research what is currently working in the clinic's niche before finalising rather than guessing.

## The AHPRA gate (screen EVERY post - non-negotiable)

CC clinics advertise under AHPRA + TGA cosmetic rules. The Proof pillar is where clinics get fined, so it has its own rules file: `references/proof-pillar-ahpra.md`. The hard line, applied to every post:

NEVER produce:
- Superlatives / therapeutic claims: best, leading, top, #1, most effective, expert, specialist (use "has a special interest in").
- Before/after as a promise, or comparative appearance claims.
- Patient testimonials / endorsements for regulated treatments (even paraphrased).
- Guaranteed or specific outcomes ("years younger", "wrinkle-free", "clears acne").
- Safety claims ("safe", "painless", "no risk").
- The word "Botox" (trademarked + S4) - use "anti-wrinkle". No pricing on Schedule 4 treatments.
- "Anti-ageing". Australian English only. No emdashes (hyphens with spaces). Italics not bold. Never the "it's not X, it's Y" pattern.

`validate.py` enforces these mechanically. Never present un-validated content.

## Process

1. Read the brand-guide.md and gather the monthly brief (ask the few missing inputs).
2. Plan the month: pillar mix + sequence, every post tied to the offer/concern.
3. Draft all posts in voice.
4. Run the drafts through /cc-marketing-genius then /stoptheslop.
5. Write the post set to JSON and run `validate.py posts.json`. Fix anything flagged, re-run until clean.
6. Produce outputs (below).

## Outputs

See `references/output-format.md` for exact schemas. All file outputs are written to `Content/` in the active clinic workspace (never into `Business-Brain/`).

- *Review doc* (`Content/<clinic>-content-<month>.md`) - the month of posts for human eyes: each post tagged `pillar / week / platform / format / hook / body / CTA / hashtags / image direction`. Image direction is a brief only - generation is a separate skill, not this one.
- *GHL Social Planner push* - native to the clinic's GHL via `mcp__gohighlevel__create-post`. The live path. Confirm the location + connected social accounts before any push, and never push to a live client account without explicit go-ahead (default: queue as drafts / scheduled, never auto-publish).
- *CSV fallback* (`Content/<clinic>-content-<month>.csv`) - for your social scheduler or manual import if the clinic is not GHL-social-connected. Columns in `references/output-format.md`.

## Notes

- Pairs with `/cc-metaad-builder (paid Meta) or /cc-googlead-builder (Google)` (paid) and the Get Found SEO/GEO subsystem - the same monthly concern feeds the organic posts, the ads, and the concern/treatment pages.
- The Proof pillar is the legal risk. When in doubt on a Proof post, downgrade it to Educate (what-to-expect) rather than risk a claim.
- The nurture ladder + weekly newsletter (the Follow-Up Agent face) is a SEPARATE skill that shares this same spine. This skill is organic social only.
- Gold-standard worked example (the quality bar): `references/example-lumiere-july.md` - a full 16-post month for Lumiere Skin & Body, passed clean through validate.py. Match its tone, pillar mix, and AHPRA-safe Proof phrasing.
