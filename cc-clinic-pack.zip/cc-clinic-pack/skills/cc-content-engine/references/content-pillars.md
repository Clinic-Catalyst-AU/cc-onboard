# Content pillars - the organic backbone

The content engine never posts at random. Every post belongs to one of four pillars, sequenced along the way people actually buy: they get to know you, then like you, then trust you, and only then do they act on an offer. This is the organic counterpart to the ads - ads catch intent that already exists; organic builds the relationship that creates it.

The pillars are a rhythm, not a rota. Weight the month toward value, open on trust-building, and let the offer land once the audience is warm.

## The four pillars

### 1. Educate (Know) - target ~40%
The biggest pillar. The clinic becomes the calm, knowledgeable voice on the concerns their clients actually have. This is how strangers first find and trust them.

- Explain a concern (what causes congestion / dullness / pigmentation / texture).
- Explain a treatment in plain language - what it does, who it suits, what to expect.
- Bust a common myth.
- Answer the question clients are too shy to ask.
- Seasonal skin education (winter barrier repair, pre-summer prep).

*AHPRA:* concern-led, never claim-led. Educate about the concern and the process, do not promise the outcome. Safest pillar - but still no "cures", "clears", "eliminates".

### 2. Connect (Like + Trust) - target ~25%
People book people, not clinics. This pillar is the humans, the values, and the why. It is what no agency and no competitor can copy.

- Meet the team - real names, real qualifications ("Sophie, our Clinic Director and RN with 14 years in skin").
- Behind the scenes - the room, the standards, the care taken.
- Why we do this / what we believe about skin.
- The clinic's standards and ethics (consult-first, honest advice, no pressure).
- A day in the clinic, the little rituals.

*AHPRA:* state credentials only if true and verifiable. Never "expert" or "specialist" - use "has a special interest in [area]". No claims dressed up as personality.

### 3. Proof (Trust, hardened) - target ~20%
The pillar that converts the fence-sitters - and the one that gets clinics fined. Read `proof-pillar-ahpra.md` before writing any Proof post. For regulated treatments you cannot use before/after as a promise or patient testimonials. Compliant proof instead:

- What to expect, step by step (sets honest expectations - reads as confidence).
- Process transparency - how a consult works, how the clinic decides what suits you.
- Realistic-outcome education (what is and is not achievable, honestly).
- Google reviews where the platform / treatment context allows (general experience, not regulated-treatment outcome claims).
- Experience and volume as fact ("14 years", "thousands of consults") - never as a superiority claim.
- The qualifications and standards behind the work.

*AHPRA:* when a Proof idea risks a claim, downgrade it to Educate (what-to-expect). Better a safe post than a breach.

### 4. Offer (Convert) - target ~15%
The smallest pillar. The month's hero offer and the booking CTA. Concern-led, never hypey. Because the other three pillars did the warming, the offer can be simple and direct.

- The month's offer, tied to the concern it solves.
- A clear, low-friction CTA (book a consult, claim the [month] focus).
- Gentle urgency only if real (limited consult spots this month).

*AHPRA:* no Schedule 4 pricing, no guaranteed outcome, no "anti-ageing". The offer is an invitation to a consult, not a promise of a result.

## Offer-strategy alignment (the rule that makes it an engine)

One offer per month drives everything. The monthly brief sets: the hero offer, the single concern it answers, the booking link. Then:

- Every Educate post that month teaches around that concern.
- Connect posts feature the people who deliver that treatment.
- Proof posts show what-to-expect for that treatment.
- Offer posts make the ask.

So the organic feed, the day-7 nurture email, and the month's ads all sing one note. This is the SPINE principle: one message, every channel.

## Sequencing a 16-post month (4 posts/week)

Roughly 6 Educate, 4 Connect, 3 Proof, 3 Offer. Order matters - earn trust before the ask:

- Week 1: Educate, Connect, Educate, Connect (introduce the concern + the people).
- Week 2: Educate, Proof, Educate, Connect (deepen + first proof).
- Week 3: Educate, Proof, Offer, Connect (proof builds, first soft offer).
- Week 4: Educate, Proof, Offer, Offer (concern fully framed, clear asks to close the month).

Never open the month on an Offer post. Front-load value; let the asks land warm.

## Mix it across formats

Within the pillars, vary the format so the feed breathes: carousels for Educate (teach in steps), Reels/video for Connect (faces, voices), static for Offer (clean CTA), Stories for the softer day-to-day. The engine notes a suggested format per post; it does not generate the image (that is a separate skill).
