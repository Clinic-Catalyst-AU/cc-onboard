# WORKED EXAMPLE - Lumiere Skin & Body, July content

This is the quality bar. Generated from Lumiere's brand-guide (warm-but-clinical voice, Mosman, Sophie Laurent RN, consult-first ethos), passed clean through validate.py. Use it as the reference for tone, pillar mix, and AHPRA-safe phrasing. Note how Proof posts show process and honest expectations, never a promise or a testimonial.

Hero offer: Winter Skin Reset consult, $50, redeemable against first treatment
Concern: dull, dry, tired winter skin (compromised barrier)
Booking: link in bio
Pillar mix: 6 Educate / 4 Connect / 3 Proof / 3 Offer (16 posts, 4/week)
Cadence: Instagram + Facebook, mixed formats

---

## Week 1 - introduce the concern + the people

### Post 1 - Educate - Carousel
*Hook:* Your skin feels tight, flat and tired this month? Winter is the reason.
Cold air holds less moisture. Indoor heating dries it further. And those long hot showers you love are quietly stripping the oils your skin barrier needs to hold water. The result is the dull, papery feeling so many of us notice from June onward. The fix is not more product. It is the right support for your barrier: lukewarm water, a gentler cleanser, and a richer moisturiser while the cold lasts. If your skin still feels off, that is worth a proper look.
*CTA:* Save this for your next shower. Questions? Send us a message.
*Image direction:* Warm gold and soft cream palette. Close, calm shot of textured skin or a steaming cup by a window. No faces in frame.

### Post 2 - Connect - Reel
*Hook:* Meet the woman who will tell you not to book a treatment.
Sophie founded Lumiere in 2019 after 14 years as a registered nurse and dermal therapist across some of Sydney's busiest clinics. She started Lumiere for one reason: to do skin honestly. Sophie personally runs every new client consult, and if a treatment is not right for you, she will say so. That is rarer than it should be. It is also the whole point of this place.
*CTA:* Come and meet her. A consult is where every Lumiere journey starts.
*Image direction:* Reel: Sophie in the consult suite, natural light, warm and unhurried. Lower-third with her name and credentials.

### Post 3 - Educate - Carousel
*Hook:* Three winter habits that work against your skin (most people do all three).
1. Over-exfoliating. When skin feels rough we scrub harder. In winter that breaks down an already fragile barrier. 2. Skipping SPF. Grey skies still carry UV. Sun exposure does not take the season off. 3. Hot showers. Lovely for five minutes, drying for the rest of the day. None of these are about willpower. They are easy swaps once you know which ones matter.
*CTA:* Which one were you doing? Tell us below.
*Image direction:* Carousel, one habit per slide. Soft cream background, warm gold numerals, muted stone text.

### Post 4 - Connect - Static
*Hook:* Why we start with a consult, every single time.
It would be quicker to just book you in. We do not work that way. Every skin is different, so we start by understanding yours: your concern, your history, your goals, and what is realistic. Only then do we suggest a plan. A consult at Lumiere is $50, and it comes off the cost of your first treatment. You leave with a clear picture either way.
*CTA:* Book a skin consult through the link in our bio.
*Image direction:* Static: the consultation suite, two chairs, warm and calm. Brand gold accent on the caption card.

---

## Week 2 - deepen the education + first proof

### Post 5 - Educate - Carousel
*Hook:* What actually happens in a HydraFacial, step by step.
A HydraFacial cleanses, gently lifts away dead surface cells, and delivers hydrating serums in one session. No needles, no recovery time needed. It suits skin that feels congested, dull or dehydrated, which is most of us by mid-winter. It is not a one-and-done fix. Think of it as a reset that keeps your skin in better condition while the cold lingers.
*CTA:* Curious if it suits your skin? Ask us in a consult.
*Image direction:* Carousel walking through the steps. Soft cream slides, warm gold step markers.

### Post 6 - Proof - Reel
*Hook:* What to expect at your first Lumiere consult, start to finish.
No pressure, no hard sell. Here is the actual flow. You arrive and Jess settles you in. Sophie sits down with you to talk through your skin, your concerns and your history. She assesses your skin properly. Then she walks you through what she would and would not recommend, and why. You leave with a plan that fits your skin and your budget. The $50 consult fee comes off your first treatment.
*CTA:* That is it. Book yours through the link in bio.
*Image direction:* Reel: hands, paperwork, the consult room, Sophie talking. Calm pacing, warm tones.

### Post 7 - Educate - Carousel
*Hook:* Microneedling, explained honestly: what it does and how long it really takes.
Microneedling uses fine needles to create tiny channels in the skin, which prompts your own collagen to rebuild over the following weeks. We use Dermapen 4. Most concerns respond to a series of three sessions, spaced four to six weeks apart, not a single visit. That honest timeline matters. Anyone promising an overnight change is not telling you the truth about how skin works.
*CTA:* Want to know if your skin is suited to it? Start with a consult.
*Image direction:* Carousel. Diagram-style slides on soft cream. Warm gold line work.

### Post 8 - Connect - Reel
*Hook:* The second pair of hands you will get to know at Lumiere.
Megan is our dermal therapist, and a lot of your in-chair time will be with her. She holds an Advanced Diploma of Dermal Therapies and is certified in HydraFacial and BioRePeel, among others. She has a particular interest in treating congestion and dull, tired skin, which is exactly what winter brings through the door. Warm, thorough, and genuinely good at what she does.
*CTA:* Say hello to Megan at your next visit.
*Image direction:* Reel: Megan in treatment room 2, prepping calmly. Name lower-third with credentials.

---

## Week 3 - proof builds, first offer lands warm

### Post 9 - Educate - Static
*Hook:* Winter is peel season. Here is the reason most people get backwards.
Chemical peels lift away dull, built-up surface cells so fresher skin can come through. After a peel your skin is more sensitive to sun for a while. That is why cooler months, with shorter days and less harsh sun, are a sensible time to do a course, as long as you stay diligent with SPF. From a light lactic peel to a medium BioRePeel, the right strength depends entirely on your skin.
*CTA:* Not sure which peel suits you? That is a consult conversation.
*Image direction:* Static: textured close-up, soft cream and blush rose. Calm, clinical-but-warm.

### Post 10 - Proof - Carousel
*Hook:* What a course of peels actually looks like, week by week (the honest version).
We will not show you a dramatic promise. We will show you the process. Week 1: your first peel and how your skin may feel for a day or two after. Weeks 2 to 3: barrier support and SPF while the skin settles. Week 4 to 6: your next peel, building gradually. Skin responds at its own pace. A steady series tends to serve people far better than chasing one big appointment.
*CTA:* We map the full plan for you in a consult.
*Image direction:* Carousel timeline. One step per slide, soft cream, warm gold week markers. No before/after imagery.

### Post 11 - Offer - Static
*Hook:* Winter Skin Reset: a proper look at your skin for $50, redeemable against your first treatment.
If your skin has felt flat and tired this winter, this is the month to do something measured about it. Book a Winter Skin Reset consult. Sophie or Megan will assess your skin, talk through your concerns, and map a plan that fits you, with no pressure to book anything on the day. The $50 fee comes straight off your first treatment, so the advice effectively costs you nothing if you go ahead.
*CTA:* Book your Winter Skin Reset consult via the link in bio.
*Image direction:* Static offer card. Warm gold on soft cream, Cormorant Garamond headline. Clean and uncluttered.

### Post 12 - Connect - Reel
*Hook:* A quiet morning before the doors open at Lumiere.
Rooms wiped down twice. Tools laid out. Notes read so we remember where each client is up to. The little rituals are not glamorous, but they are the reason a visit here feels calm and considered rather than rushed. We built Lumiere in a quiet corner of Mosman to feel exactly like this. Looked after, start to finish.
*CTA:* Come and feel the difference for yourself.
*Image direction:* Reel: morning light, treatment rooms being set up, hands, detail shots. Warm and unhurried.

---

## Week 4 - concern fully framed, clear asks to close the month

### Post 13 - Educate - Carousel
*Hook:* Five minutes a night that will carry your skin through the cold.
Your barrier is the wall that holds water in and keeps irritation out. Winter is hard on it. Supporting it at home makes everything we do in clinic work better. Lukewarm water, not hot. A gentle cleanser. A richer moisturiser while it is cold. A few drops of a hydrating serum on damp skin. SPF every morning, grey skies included. Simple, consistent, and far more useful than a cupboard full of actives.
*CTA:* Screenshot this as your winter routine.
*Image direction:* Carousel routine, one step per slide. Soft cream, warm gold numerals.

### Post 14 - Proof - Static
*Hook:* Why we will often recommend a series instead of a single treatment.
It is not about selling you more. It is about how skin actually changes. Collagen rebuilds over weeks. Surface cells turn over on a cycle. A single appointment can refresh your skin, but lasting change usually comes from a planned series, spaced to match your skin's own rhythm. We will always tell you the honest number, even when it is fewer sessions than you expected.
*CTA:* Ask us what a realistic plan looks like for your skin.
*Image direction:* Static: calm clinical detail, muted stone and gold. Quote-style layout.

### Post 15 - Offer - Reel
*Hook:* Our winter consult diary is filling. A heads-up before July closes.
Sophie runs every new client consult herself, so the number she can see each week is genuinely limited. If a Winter Skin Reset has been on your list, this is your nudge to lock it in before the month wraps up. $50 to sit down with us and understand your skin properly, redeemable against your first treatment.
*CTA:* Book your spot through the link in bio.
*Image direction:* Reel: a hand turning pages of an appointment diary, the consult suite, warm light. Gentle, not hypey.

### Post 16 - Offer - Static
*Hook:* Last call for July: your Winter Skin Reset consult, $50 toward your first treatment.
If your skin has felt dull and tired this season, do not let another month go by guessing at it. One unhurried appointment. A proper assessment. A plan that fits your skin and your life, with no pressure to decide anything on the day. We would love to help you head into spring with skin that feels looked after.
*CTA:* Book before the end of July via the link in bio.
*Image direction:* Static closing offer card. Warm gold on soft cream, elegant Cormorant Garamond headline.
