# Proof pillar - AHPRA rules (read before writing any Proof post)

The Proof pillar is the legal minefield. AHPRA and the TGA regulate how clinics may advertise regulated treatments (anything Schedule 4 - anti-wrinkle and similar - and cosmetic medical procedures generally). "Show your results" is the instinct, and it is exactly what gets a clinic reported, fined, or named publicly. This file is the guardrail. When in doubt, downgrade the post to Educate.

## NEVER (hard fail - validate.py blocks these)

- *Before/after as a promise.* No before/after images or wording framed as what the reader will get. (Even where a before/after image is technically permitted with consent + disclaimers for some non-S4 contexts, the content engine does not produce them - the risk is not worth it. Show process, not promise.)
- *Patient testimonials / endorsements for regulated treatments.* No "my skin has never looked better", no paraphrased patient quotes, no review screenshots about a regulated treatment outcome. This includes testimonials the clinic genuinely received - they still cannot be used for regulated treatments.
- *Guaranteed or specific outcomes.* No "wrinkle-free", "years younger", "clears your acne", "removes pigmentation", "permanent". No number-of-shades / percentage-improvement claims.
- *Superlatives + therapeutic claims.* best, leading, top, #1, most effective, expert, specialist, miracle, transform(ation as a promise).
- *Safety claims.* "safe", "painless", "no risk", "no downtime" (as an absolute).
- *Schedule 4 specifics.* No "Botox" (use "anti-wrinkle"), no pricing on S4 treatments, no dosing.
- *"Anti-ageing".* Australian English. No emdashes. Italics not bold. Never "it's not X, it's Y".

## INSTEAD - compliant ways to show proof

- *What to expect, step by step.* Walk through a treatment honestly - the consult, the appointment, the recovery, the realistic timeline. Honesty reads as confidence and quietly proves competence.
- *Process transparency.* How the clinic assesses skin, how it decides what suits someone, why it might say "not yet" or "not this".
- *Realistic-outcome education.* What a treatment can and cannot do, said plainly. This builds more trust than any hype.
- *Experience as fact, not superiority.* "14 years in skin", "Dermapen 4", "thousands of consults" - stated, never ranked against others.
- *Qualifications + standards.* The training, the registration, the protocols, the aftercare. Facts that must be true and verifiable.
- *General reviews, carefully.* A general "people feel looked after here" sentiment can be fine; a review describing a regulated-treatment outcome is not. If unsure, leave it out.
- *Education the clinic is known for.* Myth-busting and straight talk is itself proof of expertise (without the word "expert").

## The downgrade rule

If a Proof idea cannot be expressed without edging toward a claim, rewrite it as an Educate post about what-to-expect. A safe, useful post beats a breach every time. The validator is the backstop, not the strategy - write compliant from the start.

## One-line test for any Proof post

"Does this state a fact about our process or experience (safe), or does it promise the reader a result (breach)?" Facts pass. Promises do not.
