# Output formats - review doc, validator JSON, GHL push, CSV

Three deliverables from one post set. Write the post set once as JSON (for the validator), then render the review doc, the GHL push, and the CSV from it.

## The post object (the single source of truth)

Each post is:

```json
{
  "id": 1,
  "pillar": "Educate",
  "week": 1,
  "platform": "Instagram + Facebook",
  "format": "Carousel",
  "hook": "Winter is quietly wrecking your skin barrier. Here is why.",
  "body": "Full caption text in the clinic's voice. Australian English. No emdashes. Concern-led.",
  "cta": "Book a winter skin consult - link in bio.",
  "hashtags": ["#skinhealth", "#melbourneskin", "#dermapen"],
  "image_direction": "Brief for the image/video - mood, subject, brand colours. NOT generated here.",
  "offer_linked": true
}
```

- `pillar` is one of: Educate, Connect, Proof, Offer.
- `hook` is the first line / scroll-stopper - it is checked separately because it does the work.
- `image_direction` is a brief only. Image generation is a separate skill.
- `offer_linked` - true if the post ties to the month's hero offer (most should, per the alignment rule).

## 1. Validator JSON (`posts.json`)

The shape `validate.py` reads:

```json
{
  "clinic": "Lumiere Skin & Body",
  "month": "July",
  "offer_is_free_consult": true,
  "posts": [ { ...post object... }, ... ]
}
```

`offer_is_free_consult` mirrors the ad-builder flag - it tells the validator not to treat "free" as a problem when the month's offer is a free consult. Run `python3 validate.py posts.json`, fix every error, re-run until it exits clean. Warnings are for human review, not auto-fixed.

## 2. Review doc (`<clinic>-content-<month>.md`)

For you / the clinic to read and approve before anything is pushed. One section per post, grouped by week:

```markdown
# [Clinic] - [Month] content
Hero offer: [offer] | Concern: [concern] | Booking: [link]
Pillar mix: 6 Educate / 4 Connect / 3 Proof / 3 Offer

## Week 1

### Post 1 - Educate - Carousel - Instagram + Facebook
*Hook:* [hook]
[body]
*CTA:* [cta]
*Hashtags:* #...
*Image direction:* [brief]
```

Open with the month's offer, concern, booking link, and the pillar mix so the strategy is visible at a glance.

## 3. GHL Social Planner push

Native to the clinic's GHL via `mcp__gohighlevel__create-post`. Flow:

1. Confirm the GHL location (the clinic's, never CC's own) and the connected social accounts. Read the tool's current schema at run time (field names for account IDs, caption/summary, media, scheduleDate, status) - do not assume; verify.
2. Create one post per item as *scheduled or draft* - never auto-publish. Default to draft / scheduled-future so a human approves in GHL.
3. Map: caption = hook + body + CTA + hashtags; schedule across the month at the chosen cadence; attach media only if the clinic has supplied it (this skill does not generate images).
4. After pushing, read the posts back (`get-posts`) to confirm they landed, and report the count. Never report pushed without verifying.

Never push to a live client account without explicit go-ahead from you.

## 4. CSV fallback (`<clinic>-content-<month>.csv`)

For your social scheduler or manual import when the clinic is not GHL-social-connected. Columns:

```
Date,Platform,Pillar,Format,Caption,Hashtags,ImageDirection
```

`Caption` = hook + body + CTA combined. `Date` = the scheduled date at the chosen cadence. This matches a standard social-scheduler import shape.
