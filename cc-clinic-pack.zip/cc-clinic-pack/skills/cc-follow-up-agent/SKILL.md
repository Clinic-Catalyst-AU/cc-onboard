---
name: cc-follow-up-agent
description: Repopulate a clinic's nurture engine in their own voice - the 7-email follow-up ladder, the weekly newsletter, the pre-appointment flow and the win-back flow. The GHL plumbing (schema, template shells, workflow, booked-exit) ships once as a snapshot; this skill is the brand-pack layer that reads the clinic's brand-guide.md and writes the COPY into the snapshot's template shells via the GHL email API, after chaining every draft through /cc-marketing-genius and /stoptheslop and a hard AHPRA gate. Use when you say follow-up agent, nurture, nurture ladder, follow-up sequence, build the nurture, newsletter engine, repopulate nurture, or nurture for [clinic]. The behavioural face of the system - counterpart to /cc-content-engine (organic) and /cc-ad-builder (paid).
---

# CC Follow-Up Agent - Nurture brand-pack layer

Writes a clinic's entire follow-up system in their own voice and loads it into GHL. The "nobody gets left behind" engine: every enquiry caught, nurtured with value, walked gently toward a booking - and the instant they book they exit the chase into pre-appointment care.

## The architecture (read this first - it makes the skill simple)

The GHL plumbing is built ONCE and shipped as a snapshot, not rebuilt per clinic. The labour splits cleanly:

- *Snapshot (the engine plumbing)* - tags + custom fields + custom values + the 7 ladder email shells + the ladder workflow + the native `booked` exit goal. Built once in a master location, exported, reused forever. NOT this skill's job.
- *This skill (the brand-pack layer)* - reads the clinic's brand-guide.md and writes / overwrites the COPY inside the snapshot's template shells (and the newsletter, pre-appointment and win-back flows), in the clinic's voice, through the quality gates. It does NOT build or rebuild the workflow.

So installing for a new CC clinic is: (1) push the snapshot, (2) run this skill to repopulate the templates in their voice, (3) swap the 3 merge values (`booking_link`, company-name source, sender). Done.

Build the engine once, set it up for your clinic. A brand pack = audience + voice + offer/CTA + booking link + newsletter themes + merge values.

## When to use

- you say "build the nurture", "repopulate nurture for [clinic]", "follow-up ladder", "newsletter engine".
- A clinic has the snapshot installed and a brand-guide.md, and needs the copy written in their voice and pushed to their GHL templates.

## Inputs

*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/brand-guide.md` + `Business-Brain/offers.md` and WRITES to `Emails/` - never into `Business-Brain/`. All paths are relative to your clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If a required file is missing, say which one and offer to run the skill that creates it (no `brand-guide.md` -> run `/cc-brand-guide` first); never fabricate an offer.

1. *The spine* - the clinic's `Business-Brain/brand-guide.md` (voice + their Resonance Profile baked in, from `/cc-brand-guide`). Read it in full. If there is none, run `/cc-brand-guide` first.
2. *The clinic's real offer + CTA* - from `Business-Brain/offers.md`. NEVER invent a promotion. The month's `{{hero_treatment}}` and value-add `{{monthly_bonus}}` are written into the copy from the clinic's real plan.
3. *The monthly theme* - the same hero offer/concern driving `/cc-content-engine` and the ads that month (one message, every channel).
4. *GHL access* - the clinic's own PIT (Private Integration Token) + a browser User-Agent header. See `references/ghl-assembly.md`.

The three live GHL merge fields stay as tokens; everything else (hero treatment, bonus, the month's concern) is written into the copy each cycle:
- `{{contact.first_name}}`, `{{contact.company_name}}` (= clinic name), `{{custom_values.booking_link}}`.

## The engine flow (run in this order)

```
read brand-guide.md  +  the clinic's real offer  +  monthly theme
   |
1. draft the 7 ladder emails (the Validate -> Permission arc), newsletter, pre-appt + win-back
   |
2. /cc-marketing-genius  ->  sharpen subject lines + the one CTA per email
3. /stoptheslop             ->  strip AI tells, humanise, Australian English, no emdashes
4. validate.py              ->  HARD AHPRA gate + subject length + no-S4-discount + token balance. Fix + re-run.
   |
5. push to GHL  ->  repopulate the snapshot's template shells by name/id (2-step API, see assembly)
   |
deliver: GHL-loaded copy + the docs + the verify links
```

Steps 2-4 are the bake-in and they are non-negotiable. The skill reads the Business Brain (voice + resonance) and auto-runs every draft through Stop The Slop + Marketing Genius BEFORE anything is handed over. Without this it sounds like AI even with a brand guide. Quality baked in, not bolted on.

## The four flows it writes

1. *Ladder (System A)* - 7 emails, the behavioural arc (matches the live template names):
   Day 1 Validate, Day 3 Disarm, Day 5 Prove (Education) - Day 7 Invite, Day 12 Bridge, Day 18 Objection, Day 25 Permission (Great Offer). Day 30+ -> Nobody Left Behind pool + newsletter. Exits the instant `booked` fires.
2. *Newsletter (System B)* - weekly, one monthly theme, 4-week rotation: product of the week / treatment spotlight / staff spotlight / theme deep-dive.
3. *Pre-appointment flow* - confirm / prep / reminder / show-up, once they have booked.
4. *Win-back flow* - for lapsed clients (`rebook-needed`), two gentle re-invitations.

Full structure: `references/ladder-and-newsletter.md`.

## AHPRA gate (screen EVERY message - non-negotiable)

- NEVER: superlatives/therapeutic claims (best, leading, expert, specialist - use "has a special interest in"); before/after as a promise; patient testimonials for regulated treatments; guaranteed outcomes; safety claims (safe, painless); "Botox" / any S4 brand name; pricing or discounts on Schedule 4 treatments; "anti-ageing".
- The Great Offer is a value-add bonus, never a price discount on a regulated treatment. For injectable months the bonus is a complimentary consult/analysis only.
- Australian English. No emdashes. Italics not bold. Never the "it's not X, it's Y" pattern.

`validate.py` enforces these mechanically. Never push un-validated copy.

## Outputs

All file outputs are written to `Emails/` in the active clinic workspace (never into `Business-Brain/`).

- *GHL templates repopulated* - the 7 ladder shells overwritten in the clinic's voice via the 2-step API, verified by previewUrl. See `references/ghl-assembly.md` and `push_templates.py`.
- *Ladder + newsletter + pre-appt + win-back docs* (`Emails/<clinic>-nurture-*.md`) - human-readable copy with per-email compliance notes and the SMS variants (held until the number is live).
- *Assembly notes* - which snapshot pieces are in play, the booking_link to swap, the verify links.

## Boundaries (what this skill does NOT do)

- *Quality is baked in.* Every draft passes through /cc-marketing-genius + /stoptheslop before you see it - that is what keeps the copy on-brand and human, not a bolt-on.
- *Does not invent offers* - uses the clinic's real offer/CTA only.
- *Does not build the GHL workflow per clinic* - that is the snapshot's job.
- *The MIRROR (GHL-native booking + GHL -> Timely Zap) is infra, set up at install, not generated here.*
- *SMS rungs stay drafted but OFF* until the clinic number + AU regulatory bundle land.
- *Speed-to-lead* (immediate first response) is its own adjacent queued piece - do not fold it into the ladder logic.

## Process

1. Read brand-guide.md + the clinic's real offer + monthly theme.
2. Draft the four flows per the structure.
3. Run drafts through /cc-marketing-genius then /stoptheslop.
4. Write to JSON, run `validate.py`, fix + re-run until clean.
5. Push to the snapshot's template shells (`push_templates.py`), verify previewUrls.
6. Produce the docs + assembly notes.

## Notes

- Build record + the live schema + template ids + API recipe: `~/Projects/clinic-catalyst/cc-nurture-ghl-build.md`.
- Gold-standard reference output (the quality bar the skill must reproduce): `~/Projects/clinic-catalyst/nurture-ladder-CC-own.html` (CC's own 7 emails, full pipeline).
- Pairs with `/cc-content-engine` and `/cc-ad-builder` - same brand spine, same monthly theme, one message every channel.
