# GHL assembly - snapshot model + the email API recipe

The plumbing ships as a snapshot. This skill only repopulates the copy inside it. Full build record, live schema, and template ids live with the snapshot.

## The snapshot (built once, reused forever)

A GHL snapshot bundles, in one installable push: tags + custom fields + custom values + email templates + the workflow itself. Installing for a new clinic = push the snapshot, and all of it lands wired together. No per-clinic API gymnastics, no UI clicking.

Built once in a master location, then installed into your clinic's own GHL location. Contents:

- *Tags (9):* `cc-lead`, `in-nurture`, `booked`, `patient`, `client`, `nobody-left-behind`, `long-term-nurture`, `rebook-needed`, `dnc-nurture`.
- *Custom fields (4):* `cc_next_appt_date` (DATE), `cc_nurture_stage` (TEXT), `cc_lead_source` (TEXT), `cc_interest` (TEXT).
- *Custom value:* `booking_link` (swap to the clinic's branded booking page URL at install).
- *7 ladder email shells* (live, branded HTML) - this skill overwrites the copy in these.
- *Workflow + booked exit goal* - built in the GHL UI (workflows cannot be made via API), then exported into the snapshot. NOT rebuilt per clinic.

## The 3 live merge fields (stay as tokens)

Everything else (hero treatment, the month's bonus, the concern) is written into the copy by this skill each cycle - only these stay as GHL merge tokens:

- `{{contact.first_name}}`
- `{{contact.company_name}}` (= the clinic name)
- `{{custom_values.booking_link}}`

## The email API recipe (two steps - create alone stores only a placeholder)

Auth: the clinic's own PIT + a browser User-Agent header (Cloudflare 1010-bans a plain UA). A generic GoHighLevel MCP may not be scoped for your location - use your PIT via curl/python, which is what `push_templates.py` does.

To repopulate an existing shell you only need step 2 (the shell already has an id from the snapshot). To create one fresh:

1. `POST /emails/builder` body `{locationId, type:"html", title, updatedBy, builderVersion:"2", isPlainText:false}` -> returns `{id}`.
2. `POST /emails/builder/data` body `{locationId, templateId, updatedBy, html, editorType:"html", isPlainText:false, subject, previewText}` -> stores the content. `editorType` is REQUIRED ("html" or "builder").

Verify: `GET /emails/builder?locationId=..&limit=50` -> `builders[].previewUrl` (public firebase URL) - fetch it and grep for the new copy.
Delete: `DELETE /emails/builder/{locationId}/{templateId}`.

## Repopulating for a clinic (what push_templates.py does)

1. GET the location's builders, match the 7 shells by title prefix ("CC Ladder 01 - Day 1 - Validate" ... "CC Ladder 07 - Day 25 - Permission").
2. For each, POST /emails/builder/data with the new voice copy (html, subject, previewText).
3. Fetch each previewUrl and confirm the new copy landed. Report the count. Never report pushed without verifying.

## The MIRROR (infra, set up at install - not this skill)

GHL is the booking brain. Best case is 100% GHL-native booking (two-way calendar-synced for real conflict checking) so the `booked` exit signal is automatic. A Zap then pushes the booking GHL -> Timely so Timely stays identical. Confirm the clinic's Timely plan exposes what the Zap needs. Avoid Fresha (no Zap possible).

## Still owned by the snapshot / install, not this skill

The ladder workflow, the native `booked` exit goal, the booked-tag automation (fires when the appointment is booked), and speed-to-lead are all part of the install. This skill writes copy; it does not wire workflows.

## SMS - paused

SMS variants are written but held until the clinic's number is provisioned (AU regulatory bundle - via GHL support). Do not enable SMS steps until the number is live.
