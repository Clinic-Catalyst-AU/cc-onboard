# The four flows - structure, voice, merge tokens

The voice bar is the reference build: `~/Projects/clinic-catalyst/nurture-ladder-CC-own.html` (CC's own 7 emails) and `nurture-ladder-copy.html` (the clinic patient template). Gentle by design - the goal is to relax the nervous system, never to pressure. Warm, honest, outcome-led. Read before drafting; the skill must reproduce this quality.

## Merge tokens

Only three stay as live GHL tokens. Everything else (hero treatment, the month's bonus, the concern) is written directly into the copy each cycle, from the clinic's real plan.

- `{{contact.first_name}}` - per contact.
- `{{contact.company_name}}` - the clinic name.
- `{{custom_values.booking_link}}` - the booking calendar. They exit the ladder the instant they book.

## 1. The ladder (System A) - 7 emails

Runs only while the contact has NOT booked. The `booked` tag is the exit at any point. The arc matches the live snapshot template names:

### Rung 1 - Education (Days 1, 3, 5)
Enquired but did not book in 24 hours. Build trust with value. No selling.

- *Day 1 - Validate* - a warm hello, no pressure. "There's no rush. Over the next few days I'll share what to expect so the decision feels easy when you're ready." Soft booking link.
- *Day 3 - Disarm* - "How [the treatment] actually works (the honest version)." What it does, what it does not, who it suits. The first appointment is an honest conversation, no commitment on the day. *Compliance note required.*
- *Day 5 - Prove* - "Why people choose [clinic]." The clinic's approach + qualifications, not claims. "We'd rather talk you out of something than into it." *Compliance note required.*

### Rung 2 - The Great Offer (Days 7, 12, 18, 25)
Still not booked at day 7. One warm reason to book this month - the value-add bonus, never a discount on a regulated treatment.

- *Day 7 - Invite* - "A little welcome gift when you book this month." Introduce the month's bonus as a thank-you. *Compliance: value-add, not a price cut. SMS variant.*
- *Day 12 - Bridge* - "That feeling when you catch your reflection." Less treatment, more how they will feel. Bonus still available.
- *Day 18 - Objection* - "Is this actually right for me?" Answer the honest question, address hesitation, no pressure.
- *Day 25 - Permission* - last warm call on the month's bonus before it rolls over. Gentle, gives them permission to come when ready.

### Rung 3 - Nobody Left Behind (Day 30+)
Still no booking and no appointment. Tag `nobody-left-behind` + `long-term-nurture`, move to the weekly newsletter forever. Never deleted, never chased - kept warm.

Each email: subject, preview, body (voice + the 3 merge tokens), ONE CTA, a one-line compliance note for any treatment-specific email, and an SMS variant (held until the number is live).

## 2. The newsletter (System B - the spine)

Weekly, to the long-term pool + existing clients. One monthly theme (the same hero offer/concern driving the ads + the day-7 offer - one message, every channel). 4-week rotation:

- *Week 1 - Product of the week* - a retail product or at-home tip tied to the theme.
- *Week 2 - Treatment spotlight* - the month's hero treatment, concern-led (no claims, no S4 pricing).
- *Week 3 - Staff spotlight* - a team member, their qualifications and what they care about.
- *Week 4 - Theme deep-dive* - the month's concern explored, with a light invitation to book.

## 3. Pre-appointment flow (once they have booked)

Triggered by `booked` / `cc_next_appt_date`. The point is a calm, prepared, show-up client.

- *Confirm* - immediately after booking. Warm confirmation, what to expect, how to find us.
- *Prep* - a day or two before. Any prep (arrive with clean skin, avoid X), what to bring.
- *Reminder* - the day before / morning of. Time, place, a friendly "see you soon".
- *Show-up / aftercare hello* - just after, if appropriate. Thank you + how to reach us with questions.

No claims, no upsell pressure. Care, not selling.

## 4. Win-back flow (lapsed clients)

Triggered by `rebook-needed`. Two gentle re-invitations for someone who has not been in for a while.

- *Check-in* - "We were thinking of you." Warm, no guilt, a soft door back in.
- *Invitation* - a light reason to return this month (the value-add bonus, never a regulated-treatment discount).

## Compliance carried through every flow

No before/after as a promise, no patient testimonials for regulated treatments, no S4 brand names or pricing, no guaranteed outcomes, value-add bonuses only. Australian English, no emdashes, italics not bold. `validate.py` is the backstop - write compliant from the start.
