#!/usr/bin/env python3
"""
CC Follow-Up Agent validator.
Checks nurture ladder emails + newsletter sends against AHPRA/TGA rules,
the value-add-not-discount rule, subject-line length, and merge-token sanity.
Shares the AHPRA spine with cc-content-engine and cc-googlead-builder.

Usage:
  python3 validate.py messages.json
JSON shape (see references/ladder-and-newsletter.md):
  {"clinic":"...","month":"...","hero_treatment_is_s4":false,
   "messages":[{"id":"day1","type":"ladder","subject":"...","preview":"...",
                "body":"...","cta":"...","sms":"..."}]}
Exit 0 = clean, exit 1 = violations found.
"""
import sys, json, re

SUBJECT_MAX = 60  # warn beyond this - long subjects truncate in inbox

# AHPRA / TGA banned - same spine as cc-content-engine.
BANNED = [
    r"#1", r"\bbest\b", r"\bleading\b", r"\bmost effective\b", r"\bexpert\b",
    r"\bspecialist\b", r"\btop\b", r"\bbefore\s*/?\s*&?\s*after\b", r"\bb\s*&\s*a\b",
    r"\bguarantee", r"\bsafe\b", r"\bno risk\b", r"\bpainless\b", r"\bbotox\b",
    r"\bdysport\b", r"\bxeomin\b", r"\bcure\b", r"\bpermanent\b",
    r"wrinkle[- ]free", r"\byears younger\b", r"anti[- ]ag(e)?ing", r"\bmiracle\b",
    r"\bno downtime\b", r"\bproven results\b", r"\bflawless\b",
    r"\bclears?\b[^.]{0,20}\b(acne|pigment|wrinkle|scar)",
    r"\beliminat\w*\b[^.]{0,20}\b(acne|pigment|wrinkle|line)",
    r"\bremoves?\b[^.]{0,20}\b(pigment|wrinkle|sun damage|scar)",
]
TESTIMONIAL = [
    r"\bmy skin has never\b", r"\bbest decision\b", r"\bhighly recommend\b",
    r"\blife[- ]changing\b", r"\bcouldn'?t be happier\b", r"\breview from\b",
    r"\bclient says\b", r"\btestimonial\b", r"\b5[- ]star\b",
]
# Price-discount language. The Great Offer must be a value-add bonus, not a discount.
DISCOUNT = [r"\d+%\s*off", r"\$\d+\s*off", r"\bdiscount\b", r"\bsave \$\d", r"\bhalf price\b", r"\b% off\b"]
WARN = [r"natural[- ]looking", r"\bproven\b", r"\bamazing\b", r"\btransform", r"\byounger\b", r"\bresults\b"]
SLOP = [
    r"—", r"\bisn'?t just\b", r"\bnot just (a|an|about)\b",
    r"\bunlock\b", r"\belevate\b", r"\bdive in\b", r"\bgame[- ]changer\b",
]


def scan(text, patterns):
    return [p for p in patterns if re.search(p, text, re.I)]


def main():
    if len(sys.argv) < 2:
        print("usage: validate.py messages.json"); sys.exit(2)
    data = json.load(open(sys.argv[1]))
    msgs = data.get("messages", [])
    s4 = data.get("hero_treatment_is_s4", False)
    errors, warnings = [], []

    if not msgs:
        print("No messages found in JSON."); sys.exit(2)

    for m in msgs:
        mid = m.get("id", "?")
        subject = m.get("subject", "")
        full = " ".join(str(m.get(k, "")) for k in ("subject", "preview", "body", "cta", "sms"))

        if not subject:
            errors.append(f"{mid}: missing subject line")
        elif len(subject) > SUBJECT_MAX:
            warnings.append(f"{mid}: subject {len(subject)} chars (>{SUBJECT_MAX}), will truncate in inbox")
        if not m.get("body"):
            errors.append(f"{mid}: missing body")

        b = scan(full, BANNED)
        if b: errors.append(f"{mid} AHPRA term {b}")
        t = scan(full, TESTIMONIAL)
        if t: errors.append(f"{mid} testimonial/endorsement (banned for regulated tx) {t}")
        s = scan(full, SLOP)
        if s: errors.append(f"{mid} AI-tell/emdash {s} - re-run /stoptheslop")
        d = scan(full, DISCOUNT)
        if d:
            if s4:
                errors.append(f"{mid} price-discount on a Schedule 4 treatment month {d} - bonus must be value-add only")
            else:
                warnings.append(f"{mid} discount language {d} - the Great Offer should be a value-add bonus, not a price cut")
        w = scan(full, WARN)
        if w: warnings.append(f"{mid} review {w}")

        # Merge-token sanity: catch unclosed {{ }} braces.
        if full.count("{{") != full.count("}}"):
            errors.append(f"{mid}: unbalanced merge-token braces {{ }}")

    print("=== CC Follow-Up Agent validation ===")
    print(f"Messages: {len(msgs)} | hero_treatment_is_s4: {s4}")
    if warnings:
        print(f"\n{len(warnings)} to review (medium risk):")
        for w in warnings: print("  ! " + w)
    if errors:
        print(f"\n{len(errors)} ERRORS - fix before presenting:")
        for e in errors: print("  X " + e)
        sys.exit(1)
    print("\nAll clear: AHPRA OK, no testimonials/before-after, no S4 discount, tokens balanced.")
    sys.exit(0)


if __name__ == "__main__":
    main()
