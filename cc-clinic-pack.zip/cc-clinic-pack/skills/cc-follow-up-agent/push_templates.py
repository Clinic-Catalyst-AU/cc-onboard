#!/usr/bin/env python3
"""
CC Follow-Up Agent - repopulate the snapshot's GHL email template shells with
new voice copy, via the two-step GHL email API. Stdlib only (urllib).

The snapshot already created the 7 ladder shells in the clinic's location. This
matches them by title and overwrites their content (step 2 of the API recipe).

Usage:
  # dry run (default) - matches templates, validates, writes nothing:
  python3 push_templates.py messages.json --location <LOCATION_ID>
  # actually push:
  python3 push_templates.py messages.json --location <LOCATION_ID> --push

Auth: PIT from $GHL_PIT (your clinic's GHL token; or --pit). $CC_GHL_PIT also accepted (operator). A browser User-Agent is sent (a plain UA
gets Cloudflare 1010-banned). Never report pushed without the verify step.

messages.json: the validated post set. Each ladder message needs:
  {"id":"day1","type":"ladder","template_title":"CC Ladder 01 - Day 1 - Validate",
   "subject":"...","preview":"...","html":"<p>...</p>"}
Only type=="ladder" messages are pushed; others are ignored.
"""
import sys, os, json, argparse, urllib.request, urllib.error

BASE = "https://services.leadconnectorhq.com"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")


def api(method, path, pit, body=None):
    url = BASE + path
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {pit}")
    req.add_header("Version", "2021-07-28")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", UA)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        print(f"  ! HTTP {e.code} on {method} {path}: {e.read().decode()[:300]}")
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("messages")
    ap.add_argument("--location", required=True)
    ap.add_argument("--pit", default=os.environ.get("GHL_PIT") or os.environ.get("CC_GHL_PIT"))
    ap.add_argument("--push", action="store_true", help="actually write (default: dry run)")
    args = ap.parse_args()

    if not args.pit:
        print("No PIT. Set $GHL_PIT (your GHL token) or pass --pit."); sys.exit(2)

    data = json.load(open(args.messages))
    ladder = [m for m in data.get("messages", []) if m.get("type") == "ladder"]
    if not ladder:
        print("No ladder messages in JSON."); sys.exit(2)
    for m in ladder:
        if not m.get("template_title"):
            print(f"Message {m.get('id')} has no template_title - cannot match a shell."); sys.exit(2)

    print(f"=== Matching {len(ladder)} ladder emails to template shells in {args.location} ===")
    listing = api("GET", f"/emails/builder?locationId={args.location}&limit=100", args.pit)
    if not listing:
        print("Could not list builders. Check PIT + location."); sys.exit(1)
    builders = listing.get("builders", listing.get("data", []))
    by_title = {b.get("name", b.get("title", "")): b.get("id") for b in builders}

    plan = []
    for m in ladder:
        tid = by_title.get(m["template_title"])
        status = "OK" if tid else "NOT FOUND"
        print(f"  [{status}] {m['template_title']} -> {tid}")
        if tid:
            plan.append((m, tid))

    missing = len(ladder) - len(plan)
    if missing:
        print(f"\n{missing} shell(s) not found - is the snapshot installed in this location? Aborting.")
        sys.exit(1)

    if not args.push:
        print(f"\nDRY RUN: {len(plan)} templates matched and ready. Re-run with --push to write.")
        sys.exit(0)

    print(f"\n=== Pushing copy into {len(plan)} shells ===")
    ok = 0
    for m, tid in plan:
        res = api("POST", "/emails/builder/data", args.pit, {
            "locationId": args.location, "templateId": tid, "updatedBy": "cc-follow-up-agent",
            "html": m["html"], "editorType": "html", "isPlainText": False,
            "subject": m.get("subject", ""), "previewText": m.get("preview", ""),
        })
        if res is not None:
            ok += 1
            print(f"  pushed: {m['template_title']}")

    print(f"\nPushed {ok}/{len(plan)}. VERIFY: GET /emails/builder?locationId={args.location} "
          "and fetch each previewUrl to confirm the new copy landed.")
    sys.exit(0 if ok == len(plan) else 1)


if __name__ == "__main__":
    main()
