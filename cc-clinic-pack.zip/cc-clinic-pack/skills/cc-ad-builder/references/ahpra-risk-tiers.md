# AHPRA risk tiers for ad copy (Clinic Catalyst reference)

The quick traffic-light reference for screening every line of Google + Meta ad copy. From the Clinic Catalyst Google RSA Ad Builder. Use it alongside `validate.py` (which enforces the hard fails mechanically). When a line is amber, rewrite it greener. When in doubt, drop to a plain service-or-action line.

## GREEN - compliant, use freely

- "Book a consultation" / "Free Skin Consultation - [Suburb]" - a call to action, no outcome implied.
- "Skin treatments in [Suburb] - Book Online" - service + location, no claim.
- "[Clinic Name] - Cosmetic Injections [City]" - pure identity + location.
- Treatment names as descriptors - HIFU, dermal filler, skin needling, IPL, LED, facials.
- Pricing for NON-Schedule-4 treatments - HIFU, LED, skin needling, facials, IPL.
- "From $[price]" on a non-S4 treatment, e.g. "HIFU Face & Neck - From $[price]".

## AMBER - use sparingly, only if true, expect possible scrutiny

- "Natural-looking results" - an implied outcome claim. Use rarely, never as the hook.
- "Experienced injector" - fine if true and verifiable. NEVER "expert" or "specialist" (use "has a special interest in").
- "Proven" / "advanced" - soften or drop if it edges toward an outcome promise.

## RED - never produce (hard fail, validate.py blocks these)

- Before/after comparisons or any comparative appearance imagery or wording.
- Testimonials or patient endorsements - even paraphrased, even invented.
- Guaranteed results or specific outcomes - "look 10 years younger", "wrinkle-free", "clears acne".
- Specific pricing for Schedule 4 treatments (anti-wrinkle injections are S4 - pricing restricted).
- Superlatives - "#1", "best", "leading", "top", "most effective".
- Safety claims - "safe", "no risk", "painless".
- The word "Botox" (trademarked + S4) - use "anti-wrinkle". Map "botox near me" search demand to anti-wrinkle keywords, but never put "Botox" in the copy.

## The one-line test for any ad line

"Does this describe a service or invite an action (green), or does it promise the reader a result / rank us / show a comparison (red)?" Services and invitations pass. Promises, rankings and comparisons do not.
