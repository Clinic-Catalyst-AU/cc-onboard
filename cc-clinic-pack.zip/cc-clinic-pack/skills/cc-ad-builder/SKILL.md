---
name: cc-ad-builder
description: Generate AHPRA-compliant Google Responsive Search Ad copy + Exact/Phrase keyword plans for aesthetic and medical clinics, fast. Produces 15 headlines (<=30 chars), 4 descriptions (<=90), paths, grouped keywords and negatives - all char-checked and compliance-screened. Outputs paste-ready blocks, a filled-sheet CSV, and Google Ads Editor import files. Use when you say cc ad builder, ad builder, build google ads, RSA copy, ad copy for [clinic], fill the ad sheet, or wants Google Ads copy generated for a clinic (replaces the by-hand RSA build).
---

# CC Ad Builder - Google RSA + Keyword Generator

Turns a clinic's details into a complete, AHPRA-compliant Google Ads package in ~2 minutes instead of an hour by hand. Built for the Clinic Catalyst workshop. Exact + Phrase match only (no Broad except negatives).

## When to use

- you say "ad builder", "build google ads for [clinic]", "RSA copy", "fill the ad sheet".
- A workshop attendee needs their Google Ads copy generated from their Business Brain.
- Anytime you would otherwise hand-write RSA headlines/descriptions + keywords.

## Inputs (pull from the clinic Business Brain / intake, or ask)

*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/brand-guide.md` (voice spine) + `Business-Brain/offers.md` (the offer) + `Business-Brain/services-machines.md` (treatments and the actual devices/machines) and WRITES to `Ads/` - never into `Business-Brain/`. All paths are relative to your clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If a required file is missing, say which one and offer to run the skill that creates it (no `brand-guide.md` -> run `/cc-brand-guide` first); never fabricate.

- Clinic name, suburb, city - from `Business-Brain/brand-guide.md`.
- Service list - from `Business-Brain/services-machines.md`; flag which are Schedule 4 (anti-wrinkle / botulinum toxin) so pricing is blocked on those.
- USPs / credentials that are TRUE and verifiable (registered nurse, female-led, years open, AHPRA registration) - from the brand guide. Never invent these.
- The offer (e.g. free skin consult) - from `Business-Brain/offers.md`.
- Final URL.
- Brand voice notes (from `Business-Brain/brand-guide.md`); any genuine, named, verifiable awards.

## The AHPRA hard rules (screen EVERY line - non-negotiable)

NEVER produce:
- Superlatives: `#1`, `best`, `leading`, `top`, `most effective`, `expert` (therapeutic claims).
- Before/after wording or comparative appearance claims.
- Testimonials / patient endorsements (even paraphrased or invented).
- Guaranteed results / specific outcomes ("look 10 years younger", "wrinkle-free").
- Pricing on Schedule 4 treatments (anti-wrinkle injections). Pricing is fine for non-S4: HIFU, LED, skin needling, facials.
- Safety claims ("safe", "no risk").
- The word "Botox" in copy (trademarked + S4) - use "anti-wrinkle".

USE SPARINGLY (medium risk): "natural-looking results", "experienced injector" (never "expert").

ALWAYS: mirror the search intent in headlines; lead the offer with a low-friction action; only state a credential/USP if true for THAT clinic.

Full traffic-light reference (green / amber / red, with examples) - screen every line against it: `references/ahpra-risk-tiers.md`.

## Generation spec

Headlines - 15, each <=30 chars, spread across the Angle taxonomy in this row order (matches the RSA Ad Builder sheet):
1-2 Intent Match, 3 Keyword, 4-5 USP, 6-7 Differentiation, 8-9 Offer, 10-11 Trust, 12-13 CTA, 14-15 Theme Test.

Descriptions - 4, each <=90 chars, across Focus: Core Value, Offer, Differentiation, CTA.

Paths - 2, each <=15 chars (service category + suburb).

Keywords - Exact + Phrase only, grouped into ad groups by service, tagged intent (Transactional / Local / Informational). Map "botox near me" demand to anti-wrinkle keywords; never use Botox in copy.

Negatives - DIY, at home, cheap, jobs, salary, training, course, certification, "how to inject", "side effects". CRITICAL: do NOT add `free` as a negative if the clinic runs a free-consult offer - it blocks their own searchers.

## Process

1. Gather inputs (Business Brain or ask the few missing).
2. Generate headlines, descriptions, paths, keywords, negatives per the spec.
3. Run `validate.py` on the output - it checks every char limit AND scans for banned AHPRA terms. Fix anything it flags and re-run until clean. Never present un-validated copy.
4. Produce outputs (below).

## Outputs

All file outputs are written to `Ads/` in the active clinic workspace (never into `Business-Brain/`).

- Paste-ready blocks: the Headline column (15 lines) and Description column (4 lines) in order, so they paste straight down the sheet columns.
- Filled-sheet CSV (`Ads/<clinic>-rsa.csv`): the full builder layout (headlines, descriptions, paths, keywords, negatives, AHPRA reference) - create as a Google Sheet via the Drive create_file tool (text/csv converts to a Sheet), or hand over for File > Import.
- Google Ads Editor import files (the real automation - imports straight into the account):
  - `Ads/<clinic>-rsa-ads.csv` columns: `Campaign,Ad Group,Headline 1,...,Headline 15,Description 1,...,Description 4,Path 1,Path 2,Final URL`
  - `Ads/<clinic>-keywords.csv` columns: `Campaign,Ad Group,Keyword,Match Type`
  - `Ads/<clinic>-negatives.csv` columns: `Campaign,Keyword,Match Type` (Negative)

## Notes

- The connected Google tools can read sheets and CREATE new ones, but cannot write into the cells of an existing sheet. To "fill" a sheet, either create a new filled Sheet or hand the user paste-ready columns.
- Pairs with the Get Found SEO/GEO subsystem - the same keyword research feeds both the ads and the organic concern/treatment pages.
- This skill's output mirrors the Clinic Catalyst "Google RSA Ad Builder" workshop sheet EXACTLY - same 15-headline angle taxonomy, the 4 description focuses (Core Value / Offer / Differentiation / CTA), paths, and keyword intent tiers (Transactional / Local / Informational + negatives). So the generated package drops straight into the format clinics learn in the workshop - the system fills the sheet they would otherwise fill by hand. Keep it aligned if the workshop sheet is revised.
- Gold-standard reference + worked example: `~/Projects/clinic-catalyst/workshop-build/06-advertising-ai.md`.
