#!/usr/bin/env python3
"""
CC Ad Builder validator.
Checks RSA copy against Google char limits + AHPRA banned terms.
Usage:
  python3 validate.py copy.json
JSON shape:
  {"headlines": ["..."], "descriptions": ["..."], "paths": ["...","..."],
   "keywords": [{"keyword":"...","match":"Exact"}], "negatives": ["..."],
   "offer_is_free_consult": true}
Exit 0 = clean, exit 1 = violations found (printed).
"""
import sys, json, re

H_MAX, D_MAX, P_MAX = 30, 90, 15

# AHPRA banned - therapeutic claims / restricted (case-insensitive, word-ish boundaries)
BANNED = [
    r"#1", r"\bbest\b", r"\bleading\b", r"\bmost effective\b", r"\bexpert\b",
    r"\btop\b", r"\bbefore\s*/?\s*after\b", r"\bguarantee", r"\bsafe\b",
    r"\bno risk\b", r"\bbotox\b", r"\bpainless\b", r"\bcure\b", r"\bpermanent\b",
    r"wrinkle[- ]free", r"\byears younger\b",
]
# Flag for human review (medium risk), not a hard fail
WARN = [r"natural[- ]looking", r"\bproven\b", r"\bamazing\b"]

def scan(text, patterns):
    hits = []
    for p in patterns:
        if re.search(p, text, re.I):
            hits.append(p)
    return hits

def main():
    if len(sys.argv) < 2:
        print("usage: validate.py copy.json"); sys.exit(2)
    data = json.load(open(sys.argv[1]))
    errors, warnings = [], []

    for i, h in enumerate(data.get("headlines", []), 1):
        if len(h) > H_MAX: errors.append(f"Headline {i} is {len(h)} chars (>30): {h!r}")
        b = scan(h, BANNED)
        if b: errors.append(f"Headline {i} AHPRA term {b}: {h!r}")
        w = scan(h, WARN)
        if w: warnings.append(f"Headline {i} review {w}: {h!r}")

    for i, d in enumerate(data.get("descriptions", []), 1):
        if len(d) > D_MAX: errors.append(f"Description {i} is {len(d)} chars (>90): {d!r}")
        b = scan(d, BANNED)
        if b: errors.append(f"Description {i} AHPRA term {b}: {d!r}")
        w = scan(d, WARN)
        if w: warnings.append(f"Description {i} review {w}: {d!r}")

    for i, p in enumerate(data.get("paths", []), 1):
        if len(p) > P_MAX: errors.append(f"Path {i} is {len(p)} chars (>15): {p!r}")

    for k in data.get("keywords", []):
        m = k.get("match", "")
        if m not in ("Exact", "Phrase"):
            errors.append(f"Keyword {k.get('keyword')!r} match '{m}' must be Exact or Phrase")

    negs = [n.lower() for n in data.get("negatives", [])]
    if data.get("offer_is_free_consult") and "free" in negs:
        errors.append("'free' is in negatives but the offer is a free consult - it will block your own searchers. Remove it.")

    print("=== CC Ad Builder validation ===")
    if warnings:
        print(f"\n{len(warnings)} to review (medium risk):")
        for w in warnings: print("  ! " + w)
    if errors:
        print(f"\n{len(errors)} ERRORS - fix before presenting:")
        for e in errors: print("  X " + e)
        sys.exit(1)
    print("\nAll clear: char limits OK, no AHPRA violations, Exact/Phrase only.")
    sys.exit(0)

if __name__ == "__main__":
    main()
