# brand-guide.md - output template + claude_context_block spec

The deliverable is ONE markdown file. Fill every section. No emdashes, italics not bold, Australian English.

## The template

```markdown
# BRAND GUIDE - [Business Name]
# Paste this into your Claude Project custom instructions (or the top of any chat) so everything
# Claude writes for you sounds like your brand. Built by Clinic Catalyst | [date]

## Brand essence
[2-3 sentences: what they are, the feeling, the promise of care]

## Ideal client
[3-4 sentences: who they are, what they want, what they struggle with, what they value]

## Tone of voice
[1-2 line description of how they sound]
Do: [4-5 voice do's]
Don't: [4-5 voice don'ts - include AHPRA don'ts for clinics]

## Key messages
- [4-5 core messages / pillars the brand keeps returning to]

## Services and machines
[one line: the core treatments + the actual devices/machines they run - e.g. Dermapen 4, HydraFacial, named lasers. The full detail lives in services-machines.md]

## Concerns we love
[one line: the skin concerns they lean into and want more of. The full detail lives in concerns.md]

## This month
[one line: the current strategic focus - the one treatment or concern being pushed this month. The full detail lives in strategy.md]

## Words we use
[8-10 on-brand words/phrases - their real language]

## Words we avoid
[6-8 off-brand words - include AHPRA-banned for clinics: specialist, expert, best, safe, painless, guaranteed, anti-ageing, etc.]

## Tagline
[their tagline, or the chosen one]

## Elevator pitch
[3-4 sentences, spoken, natural]

## Brand colours
Accent: [#RRGGBB] - the main brand colour (also written to brand-assets/accent.txt for the render skills)
Ink: [#RRGGBB] - the dark colour for text/contrast (default near-black if none given)

## Brand look & feel
Fonts: headline [name] / body [name] - the actual .ttf files live in brand-assets/ (headline-font.ttf, body-font.ttf); a clean default is used if absent
Logo: [yes -> brand-assets/logo.png | none]
Aesthetic: [clinical & minimal | warm & luxe | soft & natural | bold & modern] - steers the image direction in every post
Admired look (optional): [a brand whose visual style they like]

> These are NOT reference-only. /cc-cover and /cc-carousel render in these colours + fonts, and every skill's image direction follows the aesthetic. Capture them properly or the visuals come out generic.

---

## YOUR CLAUDE CONTEXT BLOCK
[the 250-400 word block below - this is what does the work]
```

## The claude_context_block (the star of the file)
A 250-400 word block addressed TO Claude. It is the part that makes every future output sound on-brand.
Structure it like this (prose, not headers):

- Open: "You are writing as [Business Name], [one-liner]."
- Who they serve + the emotional state to create (from the resonance doc / intake).
- How they sound (the voice description + the personality adjectives).
- The words to USE and the words/phrases to NEVER use (pull the language bank in directly).
- The non-negotiables / never-dos.
- For clinics, the AHPRA rules stated plainly: concern-led not claim-led; never use specialist/expert
  (use "has a special interest in"); no best/safe/painless/guaranteed/anti-ageing; no treatment-outcome
  promises; no patient testimonials about regulated treatments; no before/after as a promise; Australian English.
- Close: "Every piece you write should make the reader feel [target feeling] and trace back to these rules."

Write it so a fresh Claude with zero other context could write perfectly on-brand copy from this block alone.
That test - "would this block alone produce on-brand output?" - is the quality bar for the whole skill.
