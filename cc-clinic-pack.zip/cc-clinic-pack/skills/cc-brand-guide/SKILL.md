---
name: cc-brand-guide
description: Turn a clinic's resonance-messaging.md (or a short questionnaire) into a brand-guide.md - a clean, paste-into-Claude brand context file so every output they generate sounds like their brand. Simple by design - questions in, one .md out, no HTML. AHPRA-aware for clinics. Use when you say brand guide, cc brand guide, build their brand guide, claude context file, brand .md, make their Claude sound like them, or AFTER running /cc-resonance (the resonance doc feeds straight in).
---

# CC BRAND GUIDE - the paste-into-Claude brand file (simple version)

FOUNDATION WORKBOOK HAND-OFF: a `*-foundation.md` intake from the workshop Foundation Workbook carries
sections mapped to every brain file (the arrows in its headings: -> strategy.md, -> offers.md, etc).
When one is provided, split it into those Business-Brain/ files as part of the build - the workbook
answers are the source of truth; only ask about "(to fill in together)" gaps.

Produces ONE deliverable: `brand-guide.md` - a brand context file the clinic pastes into their Claude
(Project custom instructions, or the top of a chat) so everything Claude writes for them sounds on-brand.
That is the whole payoff: better input = better output. No HTML, no theming - keep it low-fuss.

It chains off the resonance work: `/cc-resonance -> resonance-messaging.md -> /cc-brand-guide -> brand-guide.md`.

*File contract* - this skill follows the Business Brain File Contract
(your workspace `CLAUDE.md` documents it). It is a foundation skill: it READS
`Business-Brain/resonance-messaging.md` (plus `offers.md`, `team.md`, `services-machines.md`,
`concerns.md` and `strategy.md` for the deeper detail) and WRITES `Business-Brain/brand-guide.md` - all
fixed names. Every path is relative to the active clinic workspace: the root is `~/Clinic/` (your clinic workspace). Never hardcode
one clinic's absolute path. If a required Business-Brain file is missing, say which one and offer to run
the skill that creates it (e.g. no `resonance-messaging.md` -> run `/cc-resonance` first); never fabricate.

## Two ways to run
1. FROM RESONANCE (preferred - almost no extra questions):
   `/cc-brand-guide [Clinic]` when `Business-Brain/resonance-messaging.md` exists in the active clinic
   workspace. Read it (and pull `offers.md`, `team.md`, `services-machines.md`, `concerns.md`,
   `strategy.md` when you need that depth), then ask ONLY the few identity gaps (below).
2. STANDALONE (no resonance doc yet): ask the short questionnaire (below), then build.

## The questions
If a resonance doc exists, you already have audience, voice, language bank, key messages, values - DON'T
re-ask those. Only ask the identity gaps:
- Business name (confirm)
- One-liner: what you do + for whom (confirm/refine)
- Tagline you like (or say "suggest some" and offer 3)
- 3-5 vibe/personality words (if not already clear from resonance)
- Mission in one line (optional)

Then the LOOK & FEEL set (these are NOT optional any more - the cover + carousel skills RENDER in them, so
capture them properly or every visual comes out generic instead of on-brand):
- Your main brand colour - the accent. Ask for a hex if they know it; if they say "warm gold" or "soft rose",
  map it to the closest hex yourself and confirm it back.
- A darker colour for text/contrast (optional - default to a near-black if none).
- Your fonts - headline + body. Tell them: drop the actual `.ttf` files into `Business-Brain/brand-assets/`
  (`headline-font.ttf`, `body-font.ttf`) for an exact match; without them the visuals use a clean default.
- A logo? If yes, drop it at `Business-Brain/brand-assets/logo.png` (transparent PNG).
- Overall aesthetic - one of: clinical & minimal / warm & luxe / soft & natural / bold & modern (this steers
  the image direction in every post). Optionally: a brand whose look they admire.

Then the BUSINESS DETAILS (customer-facing - used in posts, landing pages, the Google profile, and every CTA):
- Public phone, public email, clinic address.
- Website, Instagram, Facebook.
- Booking link - the CTA destination used everywhere.
- Team: each person + their "special interest in ..." (AHPRA-safe, never "specialist"). This feeds `team.md`.

If STANDALONE (no resonance doc), ask this light set instead: business name; what you do; location;
ideal client (who, what they want, what they struggle with); 3-5 vibe words; what makes you different;
voice (how you want to sound); words you love / words you hate; tagline (or suggest) - then the LOOK & FEEL
set above.

Always ask one at a time, keep their strong phrases verbatim.

## Build the identity, then write the .md
From the answers (and/or the resonance doc), assemble these fields and write them into the output:
business_name, tagline, one_liner, brand_essence (2-3 sentences), mission, ideal_client (3-4 sentences),
brand_personality (5-6 adjectives), tone_of_voice {description, do[4-5], dont[4-5]}, key_messages (4-5),
words_we_use (8-10), words_we_avoid (6-8), elevator_pitch (3-4 sentences, spoken),
brand_look {accent_hex, ink_hex (text/contrast), headline_font, body_font, has_logo, aesthetic}, and the
claude_context_block (the star - see references/output-format.md for the exact spec + .md template).

After writing brand-guide.md, also write `Business-Brain/brand-assets/accent.txt` containing just the accent
hex (one line) so the render skills pick the colour up automatically. Remind the owner to drop their font
`.ttf` files and `logo.png` into `Business-Brain/brand-assets/` if they have them.

When reading a resonance-messaging.md, map it straight in:
- Sec 1 Brand Truth -> ideal_client + one_liner + mission + values
- Sec 3 Language Bank (OPEN/CLOSE) -> words_we_use / words_we_avoid + tone do/don't
- Sec 4 Integrated Core Messaging + headlines -> key_messages + tagline candidates + voice
- Sec 5 Alignment -> the AHPRA gate

## Output
Write `brand-guide.md` per the template in `references/output-format.md`, ending with the
claude_context_block. Save to `Business-Brain/brand-guide.md` in the active clinic workspace (root
`~/Clinic/` (your clinic workspace) - never hardcode one clinic's absolute path; any non-clinic brand -> that brand's folder). Tell
them: paste this into your Claude Project's custom
instructions (or the top of any chat) and Claude writes as your brand from then on.

## AHPRA guard (clinics) + house rules
Concern-led, never claim-led. No specialist/expert (use "special interest in"); no best/safe/painless/
guaranteed/anti-ageing; no treatment-outcome promises; no patient testimonials for regulated treatments;
no before/after as a promise. Australian English. No emdashes (hyphens with spaces). Italics not bold.
Never the "it's not X, it's Y" pattern.

## Rules
- Keep it SIMPLE - questions in, one .md out. The claude_context_block is the most important part; make it excellent.
- Don't re-ask what the resonance doc already answered. Minimum fuss.
- Use their real words. The .md should sound like them, not like a template.
- The full HTML-themed generator is a separate product - this is the lean version.
