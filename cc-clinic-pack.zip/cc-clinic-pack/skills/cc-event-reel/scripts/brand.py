#!/usr/bin/env python3
"""Load a brand's video look from its Business Brain into the Remotion project.

usage: brand.py <Business-Brain dir> <slug> [--project ~/Clinic/.reel-render]

Reads  <Business-Brain>/brand-assets/reel-brand.json  (asset paths relative to brand-assets/)
Copies every asset it names (texture, logo, fonts) into  <project>/public/reel-brands/<slug>/
Writes <project>/public/reel-brands/<slug>.json with paths the engine can load - use it as "brand" in a plan.

No reel-brand.json yet? Build one from brand-guide.md with templates/brand-template.json
(every colour from the guide's colour table - never invent), save it in brand-assets/, then run this.
"""
import json, os, shutil, sys

a = sys.argv[1:]
proj = os.path.expanduser("~/Clinic/.reel-render")
if "--project" in a:
    i = a.index("--project"); proj = os.path.expanduser(a[i + 1]); del a[i:i + 2]
brain, slug = os.path.expanduser(a[0]), a[1]
assets = os.path.join(brain, "brand-assets")
b = json.load(open(os.path.join(assets, "reel-brand.json")))
dest = os.path.join(proj, "public", "reel-brands", slug)
os.makedirs(dest, exist_ok=True)

def bring(rel):
    if not rel:
        return rel
    src = os.path.join(assets, rel)
    if not os.path.exists(src):
        sys.exit(f"missing asset: {src}")
    out = os.path.join(dest, rel.replace("/", "_"))
    shutil.copy2(src, out)
    return f"reel-brands/{slug}/{os.path.basename(out)}"

b["texture"] = bring(b.get("texture", ""))
b["logo"] = bring(b.get("logo", ""))
b["fonts"] = [[fam, bring(f), w] for fam, f, w in b.get("fonts", [])]
out = os.path.join(proj, "public", "reel-brands", f"{slug}.json")
json.dump(b, open(out, "w"), indent=2)
print(out)
