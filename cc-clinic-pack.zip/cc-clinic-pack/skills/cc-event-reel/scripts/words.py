#!/usr/bin/env python3
"""Word-level caption timings for a clip.
With an OPENAI_API_KEY (env or ~/Clinic/.env): OpenAI whisper-1, the most accurate word timestamps.
Without one: the free on-laptop Whisper the clinic install already set up (mlx-whisper on Apple chip
Macs, faster-whisper on Intel Macs and Windows). Check the timings on the contact sheet either way.

usage: words.py <video> <out.json> [--env ~/Clinic/.env] [--local]
Writes @remotion/captions Caption[]: [{text, startMs, endMs, timestampMs, confidence}]
Also prints a readable 'sec:word' line so you can pick in/out points.
"""
import json, os, subprocess, sys, tempfile, urllib.request

def key(env_path):
    k = os.environ.get("OPENAI_API_KEY")
    if k:
        return k
    p = os.path.expanduser(env_path)
    if os.path.exists(p):
        for line in open(p):
            if line.startswith("OPENAI_API_KEY="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return None

def openai_words(mp3, k):
    boundary = "----eventreel"
    parts = []
    for name, val in [("model", "whisper-1"), ("response_format", "verbose_json"), ("timestamp_granularities[]", "word")]:
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{val}\r\n'.encode())
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="a.mp3"\r\nContent-Type: audio/mpeg\r\n\r\n'.encode() + open(mp3, "rb").read() + b"\r\n")
    body = b"".join(parts) + f"--{boundary}--\r\n".encode()
    req = urllib.request.Request("https://api.openai.com/v1/audio/transcriptions", data=body, method="POST",
                                 headers={"Authorization": f"Bearer {k}", "Content-Type": f"multipart/form-data; boundary={boundary}"})
    r = json.load(urllib.request.urlopen(req, timeout=300))
    return [(w["word"], w["start"], w["end"]) for w in r.get("words", [])]

def local_words(wav):
    try:
        import mlx_whisper
        r = mlx_whisper.transcribe(wav, path_or_hf_repo="mlx-community/whisper-small-mlx", word_timestamps=True)
        return [(w["word"], w["start"], w["end"]) for s in r["segments"] for w in s.get("words", [])]
    except ImportError:
        pass
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        sys.exit("No OPENAI_API_KEY and no local Whisper installed - re-run the clinic install, or add OPENAI_API_KEY to ~/Clinic/.env")
    segs, _ = WhisperModel("small", compute_type="int8").transcribe(wav, word_timestamps=True)
    return [(w.word, w.start, w.end) for s in segs for w in (s.words or [])]

def main():
    a = sys.argv[1:]
    env = "~/Clinic/.env"
    local = "--local" in a
    if local:
        a.remove("--local")
    if "--env" in a:
        i = a.index("--env"); env = a[i + 1]; del a[i:i + 2]
    src, out = a
    k = None if local else key(env)
    with tempfile.TemporaryDirectory() as t:
        # temp audio only - the source file is never touched
        ext = "a.mp3" if k else "a.wav"
        aud = os.path.join(t, ext)
        cmd = ["ffmpeg", "-v", "error", "-i", src, "-vn", "-ac", "1", "-ar", "16000"] + (["-b:a", "48k"] if k else []) + ["-y", aud]
        subprocess.run(cmd, check=True)
        words = openai_words(aud, k) if k else local_words(aud)
        print("(word timings: " + ("OpenAI whisper-1" if k else "local Whisper") + ")")
    caps = [{"text": " " + w.strip(), "startMs": round(s * 1000), "endMs": round(e * 1000),
             "timestampMs": round(s * 1000), "confidence": 1} for w, s, e in words if w.strip()]
    json.dump(caps, open(out, "w"))
    print(" ".join(f"{c['startMs']/1000:.2f}:{c['text'].strip()}" for c in caps))
    print(f"\n{len(caps)} words -> {out}")

if __name__ == "__main__":
    main()
