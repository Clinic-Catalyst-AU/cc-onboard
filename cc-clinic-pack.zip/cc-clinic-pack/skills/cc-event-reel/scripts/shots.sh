#!/bin/bash
# Find the cut points inside a clip that is already an edit (e.g. a hero loop), so name labels
# never land on the wrong person. Prints scene-change times; then strip.sh either side of each.
# usage: shots.sh <video> [threshold=0.25]
ffmpeg -v error -i "$1" -vf "select='gt(scene,${2:-0.25})',metadata=print" -an -f null - 2>&1 | grep -o "pts_time:[0-9.]*" | cut -d: -f2
