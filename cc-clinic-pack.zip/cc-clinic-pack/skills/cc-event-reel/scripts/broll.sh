#!/bin/bash
# Portrait 1080x1920 H.264 WORKING copies of b-roll for the render (originals are never touched or replaced).
# Handles phone rotation flags, HEVC and 4K. Audio dropped (b-roll plays under someone's voice).
# usage: broll.sh <out-dir> <prefix> <file1> [file2 ...]    -> <out-dir>/<prefix>01.mp4 ...
set -e
O="$1"; P="$2"; shift 2; mkdir -p "$O"; n=0
for f in "$@"; do n=$((n+1)); out="$O/$P$(printf %02d $n).mp4"
  ffmpeg -v error -i "$f" -an -vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30" -c:v libx264 -crf 18 -preset veryfast -pix_fmt yuv420p -y "$out" </dev/null
  echo "$out <- $f"; done
