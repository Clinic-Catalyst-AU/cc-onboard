#!/bin/bash
# Catalogue a folder of event footage: length, size, audio loudness per clip + numbered contact sheets.
# usage: catalogue.sh <footage-folder> <work-dir>
# Output: <work-dir>/clips.txt (n|file|seconds|WxH|audio|mean dB) and <work-dir>/sheet-N.jpg (one middle frame per clip, numbered)
# Mean dB around -20 to -28 usually means speech; below -31 is usually room noise / b-roll.
set -e
SRC="$1"; W="$2"; mkdir -p "$W/thumbs"; : > "$W/clips.txt"; n=0
find "$SRC" -maxdepth 2 -type f \( -iname "*.mov" -o -iname "*.mp4" -o -iname "*.m4v" \) | sort | while read -r f; do
  n=$((n+1)); id=$(printf %03d $n)
  d=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$f" </dev/null)
  r=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=p=0 "$f" </dev/null | tr -d '\n')
  a=$(ffprobe -v error -select_streams a -show_entries stream=codec_name -of csv=p=0 "$f" </dev/null | head -1)
  v=""; [ -n "$a" ] && v=$(ffmpeg -v info -t 20 -i "$f" -vn -af volumedetect -f null - 2>&1 </dev/null | grep mean_volume | awk '{print $5}')
  echo "$id|$f|$d|$r|$a|$v" >> "$W/clips.txt"
  ffmpeg -v error -ss "$(python3 -c "print(max(0.1,float('$d')/2))")" -i "$f" -frames:v 1 -vf "scale=-2:240" -y "$W/thumbs/$id.jpg" </dev/null || true
done
python3 - "$W" <<'PY'
import glob, os, sys
from PIL import Image, ImageDraw
W = sys.argv[1]; fs = sorted(glob.glob(W + "/thumbs/*.jpg")); cw, ch = 240, 180
for p in range(0, len(fs), 40):
    s = Image.new("RGB", (cw * 8, ch * 5), "black"); d = ImageDraw.Draw(s)
    for k, f in enumerate(fs[p:p + 40]):
        im = Image.open(f); im.thumbnail((cw, ch)); x, y = (k % 8) * cw, (k // 8) * ch
        s.paste(im, (x + (cw - im.width) // 2, y + (ch - im.height) // 2))
        d.rectangle([x, y, x + 44, y + 22], fill="yellow"); d.text((x + 4, y + 4), os.path.basename(f)[:3], fill="black")
    s.save(f"{W}/sheet-{p // 40 + 1}.jpg")
print("sheets:", sorted(glob.glob(W + "/sheet-*.jpg")))
PY
wc -l < "$W/clips.txt"
