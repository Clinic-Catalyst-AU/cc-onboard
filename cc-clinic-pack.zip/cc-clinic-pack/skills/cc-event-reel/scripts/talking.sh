#!/bin/bash
# Working copy of a talking-head / testimonial clip WITH audio, portrait 1080x1920 H.264.
# usage: talking.sh <in> <out.mp4>
ffmpeg -v error -i "$1" -vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30" -c:v libx264 -crf 18 -preset veryfast -pix_fmt yuv420p -c:a aac -b:a 192k -y "$2" && echo "$2"
