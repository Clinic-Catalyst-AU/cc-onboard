#!/bin/bash
# Frames of one clip at chosen times, side by side - use it to map shots (who is on screen when)
# and to confirm a face is inside the frame before choosing an in-point.
# usage: strip.sh <video> <out.jpg> <t1> <t2> ...   e.g. strip.sh t-client1.mp4 /tmp/s.jpg 24 25 26 27 28
set -e
V="$1"; O="$2"; shift 2; T=$(mktemp -d); i=0
for t in "$@"; do i=$((i+1)); ffmpeg -v error -ss "$t" -i "$V" -frames:v 1 -vf scale=160:-1 -y "$T/$(printf %03d $i).png"; done
python3 - "$T" "$O" <<'PY'
import glob, sys
from PIL import Image
fs = sorted(glob.glob(sys.argv[1] + "/*.png")); ims = [Image.open(f) for f in fs]
w, h = ims[0].size; c = Image.new("RGB", (w * len(ims), h)); [c.paste(im, (i * w, 0)) for i, im in enumerate(ims)]; c.save(sys.argv[2])
PY
rm -rf "$T"; echo "$O"
