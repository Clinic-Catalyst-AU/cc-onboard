#!/bin/bash
# QA a finished render: duration, loudness, and a contact sheet at N frames per second.
# LOOK at the sheet before showing anyone: faces in frame, labels over the right person,
# nothing stacked on burned-in captions, end card clean.
# usage: check.sh <video.mp4> <sheet.jpg> [fps=1]
V="$1"; O="$2"; F="${3:-1}"
echo "duration: $(ffprobe -v error -show_entries format=duration -of csv=p=0 "$V")s"
ffmpeg -hide_banner -i "$V" -vn -af volumedetect -f null /dev/null 2>&1 | grep -E "mean_volume|max_volume" | sed 's/.*\] //'
ffmpeg -v error -i "$V" -vf "fps=$F,scale=150:-1,tile=10x4" -frames:v 1 -y "$O" && echo "$O"
