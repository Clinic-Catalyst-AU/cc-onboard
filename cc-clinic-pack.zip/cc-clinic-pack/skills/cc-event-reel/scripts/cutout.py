#!/usr/bin/env python3
"""AI cut-out of the people in a photo (rembg, runs locally - nothing leaves the machine).

usage:
  cutout.py <photo> <out-prefix> [--erase x0,y0,x1,y1 ...] [--together]

Writes:
  <out-prefix>-cut.png       same size as the photo (for 'still' + 'behind' text: words sit between photo and people)
  <out-prefix>-cut-trim.png  cropped to the people (for 'cutout' segments on a brand backdrop)
  <out-prefix>-check.jpg     the cut-out on a flat colour - LOOK AT IT before using

--erase     clear leftover background scraps (logo pieces, lecterns) in original-photo pixel coords.
            Only matters on a flat backdrop; over the same photo, scraps are invisible.
--together  people standing far apart on a stage: split them by the gap between them, match their
            heights, and place them side by side (overlapping slightly) -> <out-prefix>-together.png

Rules: people must be FULL - if the photo crops a face or a table hides the legs, a cutout segment
floats a half-body. Pick a different photo or use --together with the frame bottom as a natural edge.
Never use a photo that crops out either founder.
"""
import sys
import numpy as np
from PIL import Image, ImageOps
from rembg import remove, new_session  # Python API - the rembg CLI can break on a missing 'filetype' module

def main():
    a = sys.argv[1:]
    src, pre = a[0], a[1]
    erase = [tuple(int(v) for v in a[i + 1].split(",")) for i, x in enumerate(a) if x == "--erase"]
    im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
    cut = remove(im, session=new_session("u2net_human_seg"))
    arr = np.array(cut)
    for x0, y0, x1, y1 in erase:
        arr[y0:y1, x0:x1, 3] = 0
    cut = Image.fromarray(arr)
    cut.save(pre + "-cut.png")
    bb = cut.getchannel("A").point(lambda v: 255 if v > 20 else 0).getbbox()
    cut.crop(bb).save(pre + "-cut-trim.png")
    show = cut
    if "--together" in a:
        alpha = np.array(cut)[:, :, 3]
        cols = np.where((alpha > 40).sum(0) > 20)[0]
        runs, s, p = [], cols[0], cols[0]
        for x in cols[1:]:
            if x - p > 30:
                runs.append((s, p)); s = x
            p = x
        runs.append((s, p))
        people = [cut.crop((max(0, r0 - 10), 0, min(cut.width, r1 + 10), cut.height)) for r0, r1 in runs]
        people = [pp.crop(pp.getbbox()) for pp in people]
        H = max(pp.height for pp in people)
        people = [pp.resize((round(pp.width * H * 0.97 / pp.height), round(H * 0.97))) if pp.height < H * 0.9 else pp for pp in people]
        H = max(pp.height for pp in people)
        W = sum(pp.width for pp in people) - 40 * (len(people) - 1)
        cv = Image.new("RGBA", (W, H), (0, 0, 0, 0)); x = W
        for pp in reversed(people):  # right-most drawn first, left person on top
            x -= pp.width
            cv.alpha_composite(pp, (x, H - pp.height)); x += 40
        cv.save(pre + "-together.png"); show = cv
        print("people found:", len(runs), runs)
    bg = Image.new("RGBA", show.size, (20, 60, 60, 255)); bg.alpha_composite(show)
    b = bg.convert("RGB"); b.thumbnail((900, 900)); b.save(pre + "-check.jpg")
    print("wrote", pre + "-cut.png", pre + "-cut-trim.png", pre + "-check.jpg")

if __name__ == "__main__":
    main()
