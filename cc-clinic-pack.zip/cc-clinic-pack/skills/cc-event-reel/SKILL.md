---
name: cc-event-reel
description: Turns a pile of clinic footage (the clinic space, the team at work, reception, events, open days, the owner talking to camera, photos) into short branded vertical videos for Instagram, TikTok and Facebook - word-highlight captions, b-roll cutaways under the speaker's voice, text-behind-people cut-outs, name labels, pop words and a branded end card. Reads the clinic's look from its Business Brain. AHPRA-safe by default - never a client testimonial about a treatment, never before-and-after. Delivers rough cuts + caption-free masters + a cut sheet for the final human edit. Use when the clinic says event reel, clinic reel, highlight reel, sizzle reel, cut my footage, make videos from this footage, video from the event, open day video, team video, behind the scenes video, or drops footage and wants short videos from it.
---

# /cc-event-reel - clinic footage into branded short videos

Machine cuts are ROUGH CUTS. The clinic does the final pass (music, last trims) in CapCut or natively in Instagram / TikTok. Never call a cut final.

## Definition of done
Every requested cut is rendered, checked frame by frame (contact sheet looked at, not just generated), saved to `~/Clinic/Content/Reels/<date>-<name>/` with a CUT-SHEET.md, and opened for the clinic to watch.

## AHPRA - read before touching any footage (Australian clinics)
These are hard rules. If a clip breaks one, it is not used. Say which clip and why.
- NO testimonials about regulated treatments. A client saying how good their injectables, skin treatment, laser or any procedure was = never used, not even as audio under b-roll.
- NO before-and-after images or anything that implies a result (close-ups of "after" skin, side-by-sides).
- NO outcome promises on cards, pops or the end card ("look 10 years younger", "flawless", "guaranteed", "safe", "pain-free").
- NO "specialist" or "expert" unless the practitioner holds that registered title. Use "has a special interest in".
- NO treatment names used to lure (no "Botox", "anti-wrinkle" as a hook). Lead with the concern or the experience of the clinic.
- SAFE to use: the clinic space, reception, treatment rooms with no client in them, the team at work, the owner or practitioners talking about their clinic, values and approach, events, open days, community, education about a skin concern (no promised result), and client words about the SERVICE (the welcome, the team, feeling looked after) that never mention a treatment or result.
- Anyone on camera who is not the team must have said yes to being shown. Not sure = internal rough cut only, and say so on the cut sheet.
If in doubt, leave it out and tell the clinic why.

## 0. Setup (once per computer - check, then fix only what is missing)
The clinic install already set up the video engine at `~/Clinic/.reel-render`, plus ffmpeg, Python and Whisper.
1. Copy the engine in (safe to repeat):
   - `engine/EventReel.tsx` -> `~/Clinic/.reel-render/src/compositions/EventReel.tsx`
   - `engine/public-duo/` -> `~/Clinic/.reel-render/public/duo/` (fonts + a neutral texture)
2. Register it: open `~/Clinic/.reel-render/src/Root.tsx`. If it has no `id="EventReel"` composition, add the import and the `<Composition>` from `engine/register-snippet.tsx` exactly. Leave every other composition alone.
3. Make sure the engine's packages are in: in `~/Clinic/.reel-render` run `npm install` (it needs `@remotion/captions`, which is already listed).
4. Python extras for photo cut-outs: `python3 -m pip install --break-system-packages rembg numpy onnxruntime` on a Mac, `python -m pip install --user rembg numpy onnxruntime` on Windows.
5. Word timings: `scripts/words.py` uses an `OPENAI_API_KEY` from `~/Clinic/.env` if there is one (most accurate), otherwise the free Whisper already on the laptop. Both work. No key is needed.
Low-memory laptops: render ONE cut at a time with `--concurrency=2 --timeout=120000`. Bundle once (`npx remotion bundle src/index.ts --out-dir <dir>`) and render every cut from that bundle.

The paths to this skill's own files: `~/.claude/skills/cc-event-reel/` (call it `SK` below). Run everything from inside `~/Clinic/.reel-render` so `public/` is the engine's public folder.

## 1. Read before touching footage
1. `~/Clinic/Business-Brain/`: the brand guide (colours, fonts, logo, voice), the offers file (for the end card call to action), and the testimonials file (WHO HAS SAID YES to being shown).
2. Ask the clinic for the footage folder if they haven't given it.
3. If the Business Brain is empty, stop and run /cc-brand-guide first - the reel takes its whole look from it.

## 2. Brand file (once per clinic)
The skill holds NO brand. The clinic's video look lives in `~/Clinic/Business-Brain/brand-assets/reel-brand.json`, with asset paths relative to `brand-assets/`.
- Exists: `python3 SK/scripts/brand.py ~/Clinic/Business-Brain <slug>` copies the texture, logo and fonts into the engine and writes `public/reel-brands/<slug>.json`. Use that file as `"brand"` in every plan.
- Missing: build it from `SK/templates/brand-template.json`, filling every field from the brand guide (colour table, fonts, logo, texture). Never invent a colour. The clinic's word beats the guide. Save it in `brand-assets/`, then run `brand.py`.
- `style`: `bold` (heavy uppercase display type, e.g. Montserrat Black) or `elegant` (serif, sentence case, italic pop words).
- `refined: true` (optional, luxe serif brands): captions in the heading serif with the spoken word in accent italic, serif name labels on a thin accent rule.
- `texture`: the clinic's REAL texture file if it has one. Otherwise leave the neutral one.
- `logo`: a clean transparent PNG, or leave "" and set `wordmark` to match the clinic's text logo.
- Every font it names must exist in `public/` and be listed in `fonts`.

## 3. Catalogue the footage
```
bash SK/scripts/catalogue.sh "<footage folder>" <work-dir>
```
Look at every `sheet-N.jpg`. Sort clips into: the owner or team talking to camera, the team at work, the space (reception, rooms, details), events, photos. Apply the AHPRA rules here - drop anything that breaks them before planning. Mean dB near -20 to -28 = speech; below -31 = room noise. Most phone b-roll carries music or chatter - it plays MUTED under someone's voice.

Talking-head working copy: `bash SK/scripts/talking.sh <in> public/<slug>/t-<name>.mp4`.
B-roll working copies: `bash SK/scripts/broll.sh public/<slug>/ b <files...>`, then `bash SK/scripts/strip.sh` each at 20/50/80% - some clips drift to an empty wall.
Originals are NEVER re-encoded, compressed or replaced. Working copies only.

## 4. Words + shots
- Word timings: `python3 SK/scripts/words.py public/<slug>/t-<name>.mp4 public/<slug>/cap-<name>.json`. The printed `sec:word` line is how you pick in/out points.
- Pick the clinic's named lines first, then the strongest lines about the clinic, the team and the care. Cut any interviewer questions out; if a question gives context, put it on a `card`.
- WHO IS ON SCREEN: before any `label`, run `strip.sh` across that range. A camera often stays on one person while the next starts talking. Cover the move with a b-roll cutaway, then start the labelled segment once the speaker is centred.
- A clip that is already an edit: `bash SK/scripts/shots.sh` to find its internal cuts, then map who is on screen between them.
- Faces: check the in-point frame. A face on the frame edge = pick another moment.
- Out-points: end a segment BETWEEN the speaker's last word and the next word in the list, never on top of the next word.

## 5. Plan the cut
One JSON plan per cut: `{ "brand": <brand json object>, "segs": [...], "sfx": false, "captions": true }`. Example: `SK/templates/plan-example.json` (its words are placeholders - write the clinic's own). Segment kinds:
- `video` - `src, from, dur` (+ `caps`, `label {title, sub}`, `pops [{text, at, dur}]`, `broll [{src, from, at, dur}]`, `enter` whip|punch|flash|leak, `zoom [a,b]`, `speed: "ramp"`, `muted`)
- `still` - photo with slow zoom; `cut` + `behind` puts huge text BETWEEN the photo and the people; `pos` keeps people in the portrait crop
- `cutout` - people cut out onto the brand backdrop with an outlined title behind
- `card` - eyebrow + title on the backdrop (questions, context)
- `grid` - 2x2 wall of faces
- `end` - logo/wordmark, title, sub, CTA button

Shapes that work for clinics (12-25s for ads, up to 40s for a montage):
- Meet the clinic: cold open on the owner's strongest 1-2 second line, then the space and the team as cutaways under their voice, one pop word on the spoken beat, end card.
- Behind the scenes: a day in the clinic, b-roll led, a few cards in the clinic's voice, end card.
- Event or open day: the room, the people, two or three short lines, end card.
- Short hook (about 12s): the one line that stops the scroll, the line that backs it up, the end card.

## 6. Photos: cut-outs
```
python3 SK/scripts/cutout.py <photo> public/<slug>/img/<name> [--erase x0,y0,x1,y1] [--together]
```
LOOK at `<name>-check.jpg`. Clear leftover logo or furniture scraps with `--erase` (original-photo pixel coords). People must be whole: a desk hiding legs or a cropped face means a different photo. People far apart in one shot: `--together` matches their heights and brings them side by side.

## 7. Render + check
```
npx remotion render <bundle> EventReel <out>.mp4 --props=<plan>.json --concurrency=2 --timeout=120000
bash SK/scripts/check.sh <out>.mp4 <sheet>.jpg 1
```
LOOK at the sheet: every face in frame, labels over the right person, captions readable and changing page to page, nothing stacked on burned-in captions or graphics, end card clean, and the AHPRA rules held on every frame. Fix and re-render before anyone sees it. For each cut, also render a caption-free master (`"captions": false`).

## 8. Deliver
- Save to `~/Clinic/Content/Reels/<date>-<name>/` with the plans in `plans/` and a CUT-SHEET.md (on screen / source / in-out / effect / AHPRA note).
- Replacing an existing file: move the old one into `_previous/` first. Never delete.
- Open the cuts for the clinic to watch (Mac: `open <files>`; Windows: `start <file>`).

## Rules
- NO synthetic sound effects. `sfx: false` always. The clinic adds its own sound or trending audio on the platform.
- No music baked in.
- Never put captions or pop words over a clip that already has burned-in captions or graphics.
- Evergreen by default: no dates or days of the week on screen unless the clinic asks.
- Anyone not marked YES in the testimonials file = internal rough cut only. Say so on the cut sheet and when delivering.
- Never send a real person's face to an outside AI video service without their explicit OK.
- Copy on cards and end cards: plain words a new client understands, the clinic's own voice, no "it's not X, it's Y".
