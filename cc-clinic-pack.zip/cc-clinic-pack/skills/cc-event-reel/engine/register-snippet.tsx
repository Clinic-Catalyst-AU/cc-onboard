// Add to src/Root.tsx (imports at top):
import { DuoLab as EventReel, labDuration, FPS as LAB_FPS, type LabProps } from "./compositions/EventReel";

// Inside the RemotionRoot fragment:
<Composition
  id="EventReel"
  component={EventReel}
  durationInFrames={300}
  fps={LAB_FPS}
  width={1080}
  height={1920}
  defaultProps={{ brand: "cc", segs: [{ kind: "card", dur: 2, title: "Test" }], sfx: false } as LabProps}
  calculateMetadata={({ props }) => ({ durationInFrames: labDuration(props.segs) })}
/>
