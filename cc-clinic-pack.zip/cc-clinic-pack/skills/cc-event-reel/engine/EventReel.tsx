// EventReel - event footage into branded short vertical videos (testimonials, b-roll with effects)
// Built 29 Sep 2026. Every segment is data, so a new cut = a new array, not new code.
import { useEffect, useState } from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  OffthreadVideo,
  Sequence,
  continueRender,
  delayRender,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import type { Caption } from "@remotion/captions";

export const FPS = 30;
const s = (sec: number) => Math.round(sec * FPS);

// ---------- brands ----------
// Every brand-specific look lives in a LabBrand. /event-reel writes one per brand (from the
// Business Brain brand guide) as JSON and passes it in props - nothing brand-specific is hardcoded.
export type LabBrand = {
  name: string;
  style: "bold" | "elegant"; // bold = heavy uppercase display type; elegant = serif, sentence case, italic pops
  bg: string; // backdrop colour
  ink: string; // body text on backdrop (elegant style)
  headInk: string; // titles on backdrop
  accent: string; // highlight (caption word, label, rules)
  onAccent: string; // text sitting on the accent colour
  pop: string; // pop-word shadow, sub tags
  eyebrow: string; // small caps line above card titles
  subInk: string; // sub line on cards
  endSubInk: string; // sub line on the end card
  lowerSub: string; // sub line over footage/photos
  panel: string; // grid gutter colour
  cta: string; // CTA button background (colour or CSS gradient)
  head: string; // headline font family
  headWeight: number;
  upper: boolean;
  ui: string; // font for captions + name labels
  fonts: [string, string, number][]; // [family, file under public/, weight] to load
  texture: string; // backdrop texture image under public/
  textureOpacity: number;
  glow: string; // optional CSS background layered over the texture ("" for none)
  logo: string; // logo image under public/ ("" to use wordmark)
  wordmark?: { text: string; color: string }[]; // text logo when there is no clean image logo
  grade: string; // CSS filter on footage
  leak: string; // light leak colour
  grain: number;
  vignette: number;
  refined?: boolean; // luxe serif text: Georgia captions with gold-italic active word, no boxes, tracked small-caps labels
};

export const CC: LabBrand = {
  name: "Bold Default",
  style: "bold",
  bg: "#0A2A28",
  ink: "#FFFFFF",
  headInk: "#FFFFFF",
  accent: "#00D4BC",
  onAccent: "#0A2A28",
  pop: "#E84040",
  eyebrow: "#00D4BC",
  subInk: "rgba(255,255,255,0.85)",
  endSubInk: "#00D4BC",
  lowerSub: "#00D4BC",
  panel: "#0A2A28",
  cta: "#E84040",
  head: "Montserrat",
  headWeight: 900,
  upper: true,
  ui: "Montserrat",
  fonts: [
    ["Montserrat", "duo/fonts/Montserrat-Black.ttf", 900],
    ["Montserrat", "duo/fonts/Montserrat-ExtraBold.ttf", 800],
  ],
  texture: "duo/brand/texture-linen.png",
  textureOpacity: 0.9,
  glow: "",
  logo: "",
  wordmark: [
    { text: "YOUR ", color: "#FFFFFF" },
    { text: "CLINIC", color: "#00D4BC" },
  ],
  grade: "contrast(1.08) saturate(1.05)",
  leak: "rgba(0,212,188,0.55)",
  grain: 0.1,
  vignette: 0.5,
};

export const WARM: LabBrand = {
  name: "Warm Elegant",
  style: "elegant",
  bg: "#F5F0EB",
  ink: "#3B3229",
  headInk: "#3B3229",
  accent: "#B7634B",
  onAccent: "#FFFFFF",
  pop: "#B7634B",
  eyebrow: "#6B7A5F",
  subInk: "#5C4F44",
  endSubInk: "#5C4F44",
  lowerSub: "#F5F0EB",
  panel: "#E4DDD3",
  cta: "linear-gradient(135deg, #B7634B 0%, #C4765E 50%, #A8553D 100%)",
  head: "Cormorant Garamond",
  headWeight: 600,
  upper: false,
  ui: "Inter",
  fonts: [["Cormorant Garamond", "duo/fonts/CormorantGaramond-SemiBold.ttf", 600]],
  texture: "duo/brand/texture-linen.png",
  textureOpacity: 0.22,
  glow: "radial-gradient(circle at 50% 35%, rgba(255,255,255,0.55), rgba(245,240,235,0) 60%)",
  logo: "",
  grade: "contrast(1.04) saturate(0.95) sepia(0.08)",
  leak: "rgba(255,190,140,0.6)",
  grain: 0.07,
  vignette: 0.3,
};

// ---------- fonts ----------
const BASE_FONTS: [string, string, number][] = [
  ["Inter", "duo/fonts/Inter-Bold.ttf", 700],
  ["Inter", "duo/fonts/Inter-ExtraBold.ttf", 800],
  ["Inter", "duo/fonts/Inter-SemiBold.ttf", 600],
];
let fontsLoaded = false;
const useFonts = (brandFonts: [string, string, number][]) => {
  const FONT_FILES = [...BASE_FONTS, ...brandFonts];
  const [handle] = useState(() => (fontsLoaded ? null : delayRender("fonts")));
  useEffect(() => {
    if (!handle) return;
    Promise.all(
      FONT_FILES.map(([family, file, weight]) => {
        const f = new FontFace(family, `url(${staticFile(file)})`, { weight: String(weight) });
        return f.load().then((l) => document.fonts.add(l)).catch(() => undefined);
      }),
    ).then(() => {
      fontsLoaded = true;
      continueRender(handle);
    });
  }, [handle]);
};

// ---------- captions ----------
const capCache: Record<string, Caption[]> = {};
const useCaptions = (file?: string) => {
  const [caps, setCaps] = useState<Caption[] | null>(file ? capCache[file] ?? null : null);
  const [handle] = useState(() => (file && !capCache[file] ? delayRender("caps " + file) : null));
  useEffect(() => {
    if (!file || !handle) return;
    fetch(staticFile(file))
      .then((r) => r.json())
      .then((j: Caption[]) => {
        capCache[file] = j;
        setCaps(j);
        continueRender(handle);
      });
  }, [file, handle]);
  return caps;
};

// ---------- effects ----------
export const Grain: React.FC<{ opacity?: number }> = ({ opacity = 0.09 }) => {
  const frame = useCurrentFrame();
  const seed = frame % 8;
  return (
    <AbsoluteFill style={{ opacity, mixBlendMode: "overlay", pointerEvents: "none" }}>
      <svg width="100%" height="100%">
        <filter id={`g${seed}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed={seed} />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter={`url(#g${seed})`} />
      </svg>
    </AbsoluteFill>
  );
};

export const Vignette: React.FC<{ strength?: number }> = ({ strength = 0.55 }) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,${strength}) 100%)`,
      pointerEvents: "none",
    }}
  />
);

// Warm/teal light leak that sweeps across at a cut
const LightLeak: React.FC<{ color: string; dur: number }> = ({ color, dur }) => {
  const frame = useCurrentFrame();
  const t = frame / dur;
  const o = interpolate(t, [0, 0.3, 1], [0, 0.9, 0], { extrapolateRight: "clamp" });
  const x = interpolate(t, [0, 1], [-30, 130]);
  return (
    <AbsoluteFill
      style={{
        opacity: o,
        mixBlendMode: "screen",
        background: `radial-gradient(circle at ${x}% 40%, ${color} 0%, rgba(0,0,0,0) 45%),
          radial-gradient(circle at ${100 - x}% 80%, ${color} 0%, rgba(0,0,0,0) 35%)`,
      }}
    />
  );
};

const Flash: React.FC = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{ background: "#fff", opacity: interpolate(frame, [0, 5], [0.95, 0], { extrapolateRight: "clamp" }) }} />;
};

// ---------- segment types ----------
type Pop = { text: string; at: number; dur?: number };
type Broll = { src: string; from: number; at: number; dur: number; rate?: number };
type Label = { title: string; sub?: string };

export type Seg =
  | {
      kind: "video";
      src: string;
      from: number;
      dur: number;
      rate?: number;
      muted?: boolean;
      zoom?: [number, number];
      origin?: string;
      caps?: string; // caption json for this source
      label?: Label;
      pops?: Pop[];
      broll?: Broll[];
      enter?: "whip" | "flash" | "leak" | "punch" | "none";
      speed?: "ramp"; // fast first third, then real speed
      volume?: number;
    }
  | {
      kind: "still";
      src: string;
      cut?: string; // subject cut-out png, same framing
      dur: number;
      zoom: [number, number];
      origin?: string;
      behind?: string; // huge text between photo and cut-out
      pos?: string; // objectPosition - keeps BOTH founders inside the portrait crop
      title?: string;
      sub?: string;
      enter?: "whip" | "flash" | "leak" | "punch" | "none";
    }
  | { kind: "card"; dur: number; eyebrow?: string; title: string; sub?: string }
  | { kind: "cutout"; cut: string; dur: number; title: string; sub?: string }
  | { kind: "grid"; dur: number; cells: { src: string; from: number; name?: string }[] }
  | { kind: "end"; dur: number; title: string; sub?: string; cta?: string };

export type LabProps = {
  brand: "cc" | "aws" | LabBrand; // preset key, or a full brand object from /event-reel
  segs: Seg[];
  sfx?: boolean;
  captions?: boolean;
  width?: number;
  height?: number;
};

export const labDuration = (segs: Seg[]) => segs.reduce((a, g) => a + s(g.dur), 0);

// ---------- caption renderer ----------
const Captions: React.FC<{ file: string; from: number; brand: LabBrand; bottom?: boolean }> = ({ file, from, brand }) => {
  const caps = useCaptions(file);
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  if (!caps) return null;
  const nowMs = from * 1000 + (frame / FPS) * 1000;
  const endMs = from * 1000 + (durationInFrames / FPS) * 1000;
  const words = caps.filter((w) => w.startMs >= from * 1000 - 50 && w.startMs < endMs);
  // pages of max 3 words, break on long gaps
  const pages: Caption[][] = [];
  let cur: Caption[] = [];
  words.forEach((w, i) => {
    const prev = words[i - 1];
    if (cur.length >= 3 || (prev && w.startMs - prev.endMs > 450)) {
      pages.push(cur);
      cur = [];
    }
    cur.push(w);
  });
  if (cur.length) pages.push(cur);
  const page = pages.find((p, i) => {
    const next = pages[i + 1];
    return nowMs >= p[0].startMs && (!next || nowMs < next[0].startMs) && nowMs < p[p.length - 1].endMs + 600;
  });
  if (!page) return null;
  const pageStartFrame = ((page[0].startMs - from * 1000) / 1000) * FPS;
  const pop = spring({ frame: frame - pageStartFrame, fps: FPS, config: { damping: 14, stiffness: 220 } });
  const bold = brand.style === "bold";
  if (brand.refined) {
    return (
      <AbsoluteFill style={{ justifyContent: "flex-start", alignItems: "center", paddingTop: 1200 }}>
        <div style={{ opacity: interpolate(pop, [0, 1], [0, 1]), display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "4px 16px", maxWidth: "84%", fontFamily: brand.head, fontWeight: 400, fontSize: 66, lineHeight: 1.18 }}>
          {page.map((w, wi) => {
            const active = nowMs >= w.startMs && nowMs < Math.max(w.endMs, w.startMs + 120);
            return (
              <span key={wi} style={{ color: active ? brand.accent : brand.ink, fontStyle: active ? "italic" : "normal", textShadow: "0 3px 16px rgba(0,0,0,0.85), 0 0 3px rgba(0,0,0,0.9)" }}>
                {w.text.trim()}
              </span>
            );
          })}
        </div>
      </AbsoluteFill>
    );
  }
  return (
    <AbsoluteFill style={{ justifyContent: "flex-start", alignItems: "center", paddingTop: 1180 }}>
      <div
        style={{
          transform: `scale(${interpolate(pop, [0, 1], [0.8, 1])})`,
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "6px 18px",
          maxWidth: "86%",
          fontFamily: brand.ui,
          fontWeight: bold ? 900 : 800,
          fontSize: bold ? 78 : 70,
          lineHeight: 1.08,
          textTransform: bold ? "uppercase" : "none",
          letterSpacing: bold ? -1 : -0.5,
        }}
      >
        {page.map((w, wi) => {
          const active = nowMs >= w.startMs && nowMs < Math.max(w.endMs, w.startMs + 120);
          return (
            <span
              key={wi}
              style={{
                color: active ? brand.onAccent : "#FFFFFF",
                background: active ? brand.accent : "transparent",
                padding: "2px 14px",
                textShadow: active ? "none" : "0 4px 18px rgba(0,0,0,0.75), 0 0 3px rgba(0,0,0,0.9)",
              }}
            >
              {w.text.trim()}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

// ---------- building blocks ----------
const useEnter = (enter: string | undefined) => {
  const frame = useCurrentFrame();
  if (enter === "whip") {
    // starts part-way across (no black gap), motion blur carries the move
    const t = interpolate(frame, [0, 7], [1, 0], { extrapolateRight: "clamp", easing: (x) => x * x });
    return { transform: `translateX(${t * 28}%) scale(${1 + t * 0.12})`, filter: `blur(${t * 36}px)` };
  }
  if (enter === "punch") {
    const p = spring({ frame, fps: FPS, config: { damping: 11, stiffness: 180 } });
    return { transform: `scale(${interpolate(p, [0, 1], [1.25, 1])})`, filter: "none" };
  }
  return { transform: "none", filter: "none" };
};

const Label: React.FC<{ label: Label; brand: LabBrand }> = ({ label, brand }) => {
  const frame = useCurrentFrame();
  const inn = spring({ frame: frame - 6, fps: FPS, config: { damping: 16 } });
  if (brand.refined) {
    return (
      <AbsoluteFill style={{ justifyContent: "flex-start", paddingTop: 290, paddingLeft: 64 }}>
        <div style={{ opacity: inn, transform: `translateX(${interpolate(inn, [0, 1], [-40, 0])}px)`, background: "linear-gradient(90deg, rgba(32,29,32,0.78), rgba(32,29,32,0))", borderLeft: `3px solid ${brand.accent}`, padding: "18px 60px 20px 28px" }}>
          <div style={{ fontFamily: brand.head, fontWeight: 400, fontSize: 58, color: brand.ink, lineHeight: 1.1 }}>{label.title}</div>
          {label.sub && (
            <div style={{ marginTop: 12, fontFamily: brand.ui, fontWeight: 500, fontSize: 25, letterSpacing: 6, textTransform: "uppercase", color: brand.accent }}>{label.sub}</div>
          )}
        </div>
      </AbsoluteFill>
    );
  }
  return (
    <AbsoluteFill style={{ justifyContent: "flex-start", paddingTop: 300, paddingLeft: 64 }}>
      <div style={{ transform: `translateX(${interpolate(inn, [0, 1], [-700, 0])}px)` }}>
        <div
          style={{
            display: "inline-block",
            background: brand.accent,
            color: brand.onAccent,
            fontFamily: brand.ui,
            fontWeight: 900,
            fontSize: 64,
            padding: "8px 26px",
            textTransform: "uppercase",
            letterSpacing: 2,
          }}
        >
          {label.title}
        </div>
        {label.sub && (
          <div
            style={{
              marginTop: 10,
              display: "inline-block",
              background: "rgba(0,0,0,0.55)",
              color: "#fff",
              fontFamily: "Inter",
              fontWeight: 700,
              fontSize: 40,
              padding: "6px 22px",
              letterSpacing: 1,
            }}
          >
            {label.sub}
          </div>
        )}
      </div>
    </AbsoluteFill>
  );
};

const PopWord: React.FC<{ text: string; brand: LabBrand }> = ({ text, brand }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const p = spring({ frame, fps: FPS, config: { damping: 9, stiffness: 200 } });
  const out = interpolate(frame, [durationInFrames - 6, durationInFrames], [1, 0], { extrapolateLeft: "clamp" });
  const shake = frame < 8 ? (random(frame) - 0.5) * 18 : 0;
  if (brand.refined) {
    return (
      <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", opacity: out * interpolate(p, [0, 1], [0, 1]) }}>
        <div style={{ transform: `translateY(-260px) scale(${interpolate(p, [0, 1], [1.12, 1])})`, fontFamily: brand.head, fontWeight: 400, fontStyle: "italic", fontSize: 150 * (Math.max(...text.split(" ").map((w) => w.length)) > 7 ? 0.72 : 1), color: brand.accent, textAlign: "center", lineHeight: 1.0, textShadow: "0 8px 40px rgba(0,0,0,0.75)", maxWidth: "90%" }}>
          {text}
        </div>
      </AbsoluteFill>
    );
  }
  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", opacity: out }}>
      <div
        style={{
          transform: `translate(${shake}px, -260px) rotate(-4deg) scale(${interpolate(p, [0, 1], [2.2, 1])})`,
          fontFamily: brand.head,
          fontWeight: brand.headWeight,
          fontStyle: brand.style === "bold" ? "normal" : "italic",
          fontSize: (brand.style === "bold" ? 170 : 190) * (Math.max(...text.split(" ").map((w) => w.length)) > 7 ? 0.68 : 1),
          color: "#fff",
          textTransform: brand.upper ? "uppercase" : "none",
          textAlign: "center",
          lineHeight: 0.9,
          textShadow: `6px 6px 0 ${brand.pop}, 0 10px 40px rgba(0,0,0,0.6)`,
          maxWidth: "92%",
        }}
      >
        {text}
      </div>
    </AbsoluteFill>
  );
};

const VideoSeg: React.FC<{ g: Extract<Seg, { kind: "video" }>; brand: LabBrand; captions: boolean }> = ({ g, brand, captions }) => {
  const frame = useCurrentFrame();
  const dur = s(g.dur);
  const [z0, z1] = g.zoom ?? [1.0, 1.06];
  const z = interpolate(frame, [0, dur], [z0, z1]);
  const enter = useEnter(g.enter);
  // speed ramp: first third at 2.4x, rest at real speed (source consumed accordingly)
  const rampFrames = g.speed === "ramp" ? Math.round(dur / 3) : 0;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ ...enter, filter: `${enter.filter === "none" ? "" : enter.filter} ${brand.grade}` }}>
        <AbsoluteFill style={{ transform: `scale(${z})`, transformOrigin: g.origin ?? "50% 40%" }}>
          {g.speed === "ramp" ? (
            <>
              <Sequence durationInFrames={rampFrames}>
                <OffthreadVideo src={staticFile(g.src)} startFrom={s(g.from)} playbackRate={2.4} muted style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </Sequence>
              <Sequence from={rampFrames}>
                <OffthreadVideo
                  src={staticFile(g.src)}
                  startFrom={s(g.from) + Math.round(rampFrames * 2.4)}
                  muted
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
              </Sequence>
            </>
          ) : (
            <OffthreadVideo
              src={staticFile(g.src)}
              startFrom={s(g.from)}
              playbackRate={g.rate ?? 1}
              muted={g.muted ?? false}
              volume={g.volume ?? 1}
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          )}
        </AbsoluteFill>
      </AbsoluteFill>
      {(g.broll ?? []).map((b, i) => (
        <Sequence key={i} from={s(b.at)} durationInFrames={s(b.dur)}>
          <BrollCut b={b} brand={brand} />
        </Sequence>
      ))}
      {captions && g.caps && <Captions file={g.caps} from={g.from} brand={brand} />}
      {g.label && (
        <Sequence durationInFrames={Math.min(dur, s(2.6))}>
          <Label label={g.label} brand={brand} />
        </Sequence>
      )}
      {(g.pops ?? []).map((p, i) => (
        <Sequence key={i} from={s(p.at)} durationInFrames={s(p.dur ?? 1.4)}>
          <PopWord text={p.text} brand={brand} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};

const BrollCut: React.FC<{ b: Broll; brand: LabBrand }> = ({ b, brand }) => {
  const frame = useCurrentFrame();
  const dur = s(b.dur);
  const o = interpolate(frame, [0, 5, dur - 5, dur], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const z = interpolate(frame, [0, dur], [1.12, 1.0]);
  return (
    <AbsoluteFill style={{ opacity: o, overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${z})`, filter: brand.grade }}>
        <OffthreadVideo src={staticFile(b.src)} startFrom={s(b.from)} playbackRate={b.rate ?? 1} muted style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

const StillSeg: React.FC<{ g: Extract<Seg, { kind: "still" }>; brand: LabBrand }> = ({ g, brand }) => {
  const frame = useCurrentFrame();
  const dur = s(g.dur);
  const z = interpolate(frame, [0, dur], g.zoom);
  const enter = useEnter(g.enter);
  const tIn = spring({ frame: frame - 4, fps: FPS, config: { damping: 18 } });
  const photo: React.CSSProperties = { width: "100%", height: "100%", objectFit: "cover", objectPosition: g.pos ?? "50% 30%" };
  const layer: React.CSSProperties = { transform: `scale(${z})`, transformOrigin: g.origin ?? "50% 45%" };
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ ...enter, filter: `${enter.filter === "none" ? "" : enter.filter} ${brand.grade}` }}>
        <AbsoluteFill style={layer}>
          <Img src={staticFile(g.src)} style={photo} />
        </AbsoluteFill>
        {g.behind && (
          <AbsoluteFill style={{ justifyContent: "flex-start", alignItems: "center", paddingTop: 170 }}>
            <div
              style={{
                fontFamily: brand.refined ? brand.head : "Montserrat",
                fontWeight: brand.refined ? 400 : 900,
                fontStyle: brand.refined ? "italic" : "normal",
                fontSize: brand.refined ? 230 : 250,
                lineHeight: brand.refined ? 0.95 : 0.84,
                letterSpacing: brand.refined ? 0 : -8,
                textAlign: "center",
                color: brand.accent,
                textTransform: brand.refined ? "none" : "uppercase",
                opacity: tIn,
                transform: `translateY(${interpolate(tIn, [0, 1], [120, 0])}px) scale(${interpolate(frame, [0, dur], [1.0, 1.08])})`,
                textShadow: "0 12px 50px rgba(0,0,0,0.45)",
              }}
            >
              {g.behind}
            </div>
          </AbsoluteFill>
        )}
        {g.cut && (
          <AbsoluteFill style={layer}>
            <Img src={staticFile(g.cut)} style={{ ...photo, filter: "drop-shadow(0 20px 40px rgba(0,0,0,0.45))" }} />
          </AbsoluteFill>
        )}
      </AbsoluteFill>
      {(g.title || g.sub) && <LowerText title={g.title} sub={g.sub} brand={brand} />}
    </AbsoluteFill>
  );
};

const LowerText: React.FC<{ title?: string; sub?: string; brand: LabBrand }> = ({ title, sub, brand }) => {
  const frame = useCurrentFrame();
  const words = (title ?? "").split(" ");
  const bold = brand.style === "bold";
  return (
    <AbsoluteFill style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 520 }}>
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "0 22px",
          maxWidth: "88%",
          fontFamily: brand.head,
          fontWeight: brand.headWeight,
          fontSize: bold ? 96 : 110,
          lineHeight: 1.0,
          textTransform: brand.upper ? "uppercase" : "none",
          color: "#fff",
          textShadow: "0 6px 30px rgba(0,0,0,0.7)",
        }}
      >
        {words.map((w, i) => {
          const p = spring({ frame: frame - 6 - i * 4, fps: FPS, config: { damping: 14 } });
          return (
            <span key={i} style={{ opacity: p, transform: `translateY(${interpolate(p, [0, 1], [60, 0])}px)`, display: "inline-block" }}>
              {w}
            </span>
          );
        })}
      </div>
      {sub && (
        <div
          style={{
            marginTop: 26,
            fontFamily: brand.refined ? brand.ui : "Inter",
            fontWeight: brand.refined ? 500 : 700,
            fontSize: brand.refined ? 30 : 40,
            letterSpacing: brand.refined ? 8 : 6,
            textTransform: "uppercase",
            color: brand.lowerSub,
            opacity: interpolate(frame, [18, 30], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
            textShadow: "0 4px 20px rgba(0,0,0,0.7)",
          }}
        >
          {sub}
        </div>
      )}
    </AbsoluteFill>
  );
};

const Backdrop: React.FC<{ brand: LabBrand }> = ({ brand }) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: brand.bg, overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${1.1 + frame * 0.0008}) rotate(${frame * 0.01}deg)`, opacity: brand.textureOpacity }}>
        <Img src={staticFile(brand.texture)} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      </AbsoluteFill>
      {brand.glow && <AbsoluteFill style={{ background: brand.glow }} />}
    </AbsoluteFill>
  );
};

const CardSeg: React.FC<{ g: Extract<Seg, { kind: "card" }>; brand: LabBrand }> = ({ g, brand }) => {
  const frame = useCurrentFrame();
  const bold = brand.style === "bold";
  const words = g.title.split(" ");
  const line = spring({ frame: frame - 2, fps: FPS, config: { damping: 20 } });
  return (
    <AbsoluteFill>
      <Backdrop brand={brand} />
      <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", padding: 90 }}>
        {g.eyebrow && (
          <div
            style={{
              fontFamily: brand.refined ? brand.ui : "Inter",
              fontWeight: brand.refined ? 500 : 700,
              fontSize: brand.refined ? 30 : 38,
              letterSpacing: brand.refined ? 9 : 10,
              textTransform: "uppercase",
              color: brand.eyebrow,
              marginBottom: 34,
              opacity: line,
            }}
          >
            {g.eyebrow}
          </div>
        )}
        <div style={{ width: interpolate(line, [0, 1], [0, brand.refined ? 140 : 220]), height: brand.refined ? 2 : 6, background: brand.accent, marginBottom: 40 }} />
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "center",
            gap: "0 24px",
            fontFamily: brand.head,
            fontWeight: brand.headWeight,
            fontSize: bold ? 104 : 124,
            lineHeight: 1.02,
            textTransform: brand.upper ? "uppercase" : "none",
            color: brand.headInk,
            textAlign: "center",
          }}
        >
          {words.map((w, i) => {
            const p = spring({ frame: frame - 4 - i * 3, fps: FPS, config: { damping: 13 } });
            return (
              <span key={i} style={{ display: "inline-block", opacity: p, transform: `translateY(${interpolate(p, [0, 1], [70, 0])}px) rotate(${interpolate(p, [0, 1], [6, 0])}deg)` }}>
                {w}
              </span>
            );
          })}
        </div>
        {g.sub && (
          <div
            style={{
              marginTop: 44,
              fontFamily: brand.refined ? brand.head : "Inter",
              fontWeight: brand.refined ? 400 : 600,
              fontStyle: brand.refined ? "italic" : "normal",
              fontSize: 46,
              color: brand.subInk,
              textAlign: "center",
              opacity: interpolate(frame, [14, 26], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
            }}
          >
            {g.sub}
          </div>
        )}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

const CutoutSeg: React.FC<{ g: Extract<Seg, { kind: "cutout" }>; brand: LabBrand }> = ({ g, brand }) => {
  const frame = useCurrentFrame();
  const dur = s(g.dur);
  const rise = spring({ frame, fps: FPS, config: { damping: 15, stiffness: 90 } });
  return (
    <AbsoluteFill>
      <Backdrop brand={brand} />
      <AbsoluteFill style={{ justifyContent: "flex-start", alignItems: "center", paddingTop: 210 }}>
        <div
          style={{
            fontFamily: "Montserrat",
            fontWeight: 900,
            fontSize: Math.max(...g.title.split(" ").map((w) => w.length)) > 6 ? 150 : 210,
            lineHeight: 0.85,
            letterSpacing: -4,
            color: "transparent",
            WebkitTextStroke: `4px ${brand.accent}`,
            textTransform: "uppercase",
            textAlign: "center",
            transform: `translateX(${interpolate(frame, [0, dur], [40, -40])}px)`,
          }}
        >
          {g.title}
        </div>
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          transform: `translateY(${interpolate(rise, [0, 1], [500, 60])}px) scale(${interpolate(frame, [0, dur], [1.0, 1.06])})`,
          transformOrigin: "50% 100%",
        }}
      >
        <Img src={staticFile(g.cut)} style={{ position: "absolute", left: "6%", width: "88%", bottom: 0, height: "72%", objectFit: "contain", objectPosition: "50% 100%", filter: "drop-shadow(0 30px 60px rgba(0,0,0,0.5))" }} />
      </AbsoluteFill>
      {g.sub && (
        <AbsoluteFill style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 170 }}>
          <div
            style={{
              background: brand.pop,
              color: "#fff",
              fontFamily: "Montserrat",
              fontWeight: 900,
              fontSize: 54,
              padding: "12px 30px",
              textTransform: "uppercase",
              letterSpacing: 2,
              opacity: interpolate(frame, [16, 24], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
            }}
          >
            {g.sub}
          </div>
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};

const GridSeg: React.FC<{ g: Extract<Seg, { kind: "grid" }>; brand: LabBrand }> = ({ g, brand }) => {
  const frame = useCurrentFrame();
  const n = g.cells.length;
  const cols = 2;
  const rows = Math.ceil(n / cols);
  return (
    <AbsoluteFill style={{ background: brand.panel, padding: 14, display: "grid", gridTemplateColumns: `repeat(${cols}, 1fr)`, gridTemplateRows: `repeat(${rows}, 1fr)`, gap: 14 }}>
      {g.cells.map((c, i) => {
        const p = spring({ frame: frame - i * 4, fps: FPS, config: { damping: 14 } });
        return (
          <div key={i} style={{ position: "relative", overflow: "hidden", transform: `scale(${interpolate(p, [0, 1], [0.6, 1])})`, opacity: p }}>
            <OffthreadVideo src={staticFile(c.src)} startFrom={s(c.from)} muted style={{ width: "100%", height: "100%", objectFit: "cover", filter: brand.grade }} />
            {c.name && (
              <div style={{ position: "absolute", left: 16, bottom: 16, background: brand.accent, color: "#fff", fontFamily: "Inter", fontWeight: 800, fontSize: 30, padding: "4px 14px" }}>{c.name}</div>
            )}
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

const EndSeg: React.FC<{ g: Extract<Seg, { kind: "end" }>; brand: LabBrand }> = ({ g, brand }) => {
  const frame = useCurrentFrame();
  const p = spring({ frame, fps: FPS, config: { damping: 14 } });
  const bold = brand.style === "bold";
  return (
    <AbsoluteFill>
      <Backdrop brand={brand} />
      <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", padding: 80 }}>
        {!brand.logo && brand.wordmark ? (
          // text wordmark (matches the clinic's live site nav)
          <div style={{ fontFamily: brand.head, fontWeight: brand.headWeight, fontSize: 92, letterSpacing: 6, textAlign: "center", transform: `scale(${interpolate(p, [0, 1], [0.8, 1])})`, opacity: p, marginBottom: 60 }}>
            {brand.wordmark.map((w, i) => (
              <span key={i} style={{ color: w.color }}>{w.text}</span>
            ))}
          </div>
        ) : (
          <Img src={staticFile(brand.logo)} style={{ width: 700, transform: `scale(${interpolate(p, [0, 1], [0.8, 1])})`, opacity: p, marginBottom: 60 }} />
        )}
        <div
          style={{
            fontFamily: brand.head,
            fontWeight: brand.headWeight,
            fontSize: bold ? 84 : 104,
            color: brand.headInk,
            textTransform: brand.upper ? "uppercase" : "none",
            textAlign: "center",
            lineHeight: 1.05,
            opacity: interpolate(frame, [8, 20], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          }}
        >
          {g.title}
        </div>
        {g.sub && (
          <div style={{ marginTop: 30, fontFamily: brand.refined ? brand.ui : "Inter", fontWeight: brand.refined ? 500 : 600, fontSize: brand.refined ? 30 : 44, letterSpacing: brand.refined ? 7 : 0, textTransform: brand.refined ? "uppercase" : "none", color: brand.endSubInk, textAlign: "center", opacity: interpolate(frame, [16, 28], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
            {g.sub}
          </div>
        )}
        {g.cta && (
          <div
            style={{
              marginTop: 60,
              background: brand.cta,
              color: brand.refined ? brand.onAccent : "#fff",
              fontFamily: brand.refined ? brand.ui : "Inter",
              fontWeight: brand.refined ? 500 : 800,
              fontSize: brand.refined ? 32 : 46,
              padding: brand.refined ? "22px 56px" : "22px 48px",
              letterSpacing: brand.refined ? 7 : 2,
              textTransform: "uppercase",
              transform: `scale(${1 + Math.sin(frame / 6) * 0.025})`,
              opacity: interpolate(frame, [22, 32], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
            }}
          >
            {g.cta}
          </div>
        )}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

// ---------- the timeline ----------
export const DuoLab: React.FC<LabProps> = ({ brand: bk, segs, sfx = false, captions = true }) => {
  const brand: LabBrand = typeof bk === "string" ? (bk === "cc" ? CC : WARM) : bk;
  useFonts(brand.fonts);
  let t = 0;
  const placed = segs.map((g) => {
    const start = t;
    t += s(g.dur);
    return { g, start, dur: s(g.dur) };
  });
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      {placed.map(({ g, start, dur }, i) => (
        <Sequence key={i} from={start} durationInFrames={dur}>
          {g.kind === "video" && <VideoSeg g={g} brand={brand} captions={captions} />}
          {g.kind === "still" && <StillSeg g={g} brand={brand} />}
          {g.kind === "card" && <CardSeg g={g} brand={brand} />}
          {g.kind === "cutout" && <CutoutSeg g={g} brand={brand} />}
          {g.kind === "grid" && <GridSeg g={g} brand={brand} />}
          {g.kind === "end" && <EndSeg g={g} brand={brand} />}
        </Sequence>
      ))}
      {/* cut-point effects */}
      {placed.map(({ g, start }, i) => {
        const enter = "enter" in g ? g.enter : undefined;
        if (i === 0 && !enter) return null;
        return (
          <Sequence key={"fx" + i} from={start} durationInFrames={s(0.8)}>
            {enter === "flash" && <Flash />}
            {enter === "leak" && <LightLeak color={brand.leak} dur={s(0.8)} />}
            {sfx && enter && enter !== "none" && (
              <Audio src={staticFile(enter === "whip" ? "sfx/whoosh.mp3" : enter === "punch" ? "sfx/pop.mp3" : "sfx/rise.mp3")} volume={enter === "whip" ? 0.35 : 0.3} />
            )}
          </Sequence>
        );
      })}
      <Grain opacity={brand.grain} />
      <Vignette strength={brand.vignette} />
    </AbsoluteFill>
  );
};
