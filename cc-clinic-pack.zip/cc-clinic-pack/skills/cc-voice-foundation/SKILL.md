---
name: cc-voice-foundation
description: Capture how a clinic ACTUALLY talks - research their real Instagram, Facebook, website and Google reviews for their natural voice, then interview them for what the internet cannot show, and write voice-foundation.md (the paste-into-Claude block that makes every future output sound like them). Built to run in Claude Desktop, no scripts needed. Use this whenever someone says voice foundation, brand voice, capture our voice, how we talk, tone of voice, make Claude sound like us, our writing style, analyse our Instagram voice, we sound like a robot, everything Claude writes sounds generic, or is setting up a new clinic in Claude for the first time. Also use it BEFORE /cc-brand-guide, /cc-content-engine, /cc-script or any copy work when no voice-foundation.md exists yet - the voice comes first or everything downstream reads like a template.
---

# CC VOICE FOUNDATION - how this clinic actually talks

The problem this solves: a clinic asks Claude for a caption and gets back something that could belong
to any clinic in the country. Not because Claude is bad at writing, but because nobody ever told it
what *this* clinic sounds like. Generic in, generic out.

So this skill goes and finds out. Two sources, in this order:

1. **What they already published.** Their captions, their website, their replies to reviews. This is
   their voice with no self-consciousness attached, which makes it far more honest than anything they
   would tell you in an interview.
2. **What the internet cannot show you.** How they talk in the treatment room, who they are secretly
   trying to sound like, the words that make them cringe, the thing they refuse to say.

Then it writes ONE file: `voice-foundation.md`, ending in a paste-into-Claude block.

`/cc-voice-foundation -> voice-foundation.md -> /cc-brand-guide -> brand-guide.md -> every content skill`

## Running in Claude Desktop

The clinic runs this themselves, in Desktop, usually on their own. So:

- Never assume a terminal, a script or a file system. Do the work in the conversation.
- Deliver the finished doc as an artifact they can copy, and tell them plainly where to save it
  (`Business-Brain/voice-foundation.md` in their clinic folder) and what to do with the context block.
- Web search and web fetch are the only research tools you need. If a fetch fails, say so and ask them
  for the material instead. A clinic owner would much rather paste ten captions than be handed
  invented ones.

*File contract* - this skill follows the Business Brain File Contract. It READS nothing (it is the
first foundation skill, it can run on a completely cold start) and WRITES
`Business-Brain/voice-foundation.md`, a fixed name, never renamed. If they already have a
`resonance-messaging.md` or `brand-guide.md`, read those first and treat this run as a voice REFRESH -
do not re-ask what those files already answer.

---

## Step 1 - get the handles, then go look

Open by asking for exactly three things at once, because they are quick and everything else depends
on them:

> Before I ask you anything about your voice, I want to go and read how you already write. Can you
> give me: your website, your Instagram handle, and your Facebook page?

Then research. Work through these in order, and stop when you have enough (roughly 15 to 20 real
samples of their own writing is plenty):

- **Their website** - the About page first. It is usually the most "them" page on the site, because
  they wrote it themselves. Then a treatment page, to see how they explain something technical.
- **Instagram** - fetch the public profile. Instagram frequently blocks this. If you get a login wall
  or an empty result, do not pretend otherwise and do not fill the gap with a guess. Say: *"Instagram
  is blocking me from reading your posts directly. Can you copy and paste the captions from your last
  10 posts? That is the single most useful thing you can give me."* Their pasted captions are better
  data than anything you could have scraped anyway.
- **Facebook** - often readable when Instagram is not, and it usually carries the same captions.
- **Google reviews** - specifically their REPLIES to reviews. This is gold. Review replies are written
  fast, by the owner, without a content plan, so they show the unguarded voice better than any caption.
- **Anywhere else they show up** - a local directory listing, a press mention, a podcast description.

Tell them what you found before you start asking questions. It changes the whole tone of the
interview when they can see you have actually read their work: *"I have read your About page, 14
Instagram captions and your last 20 review replies. A few things already stand out ..."*

If they have no online presence at all, say so plainly and run the interview alone. The doc will be
thinner and it is worth telling them that, so they know why.

## Step 2 - extract the voice DNA from what you found

This is the analytical heart of the skill, and it is where most voice work goes wrong. Vague
adjectives like "warm and professional" are useless downstream, because every clinic in Australia
would tick those boxes. What makes a voice reproducible is the mechanical detail.

Read `references/voice-dna.md` for the full extraction checklist. In short, you are looking for:
sentence length and rhythm, how they open a post, how they close it, question habits, emoji habits,
punctuation tics, whether they say "we" or "I", how they name treatments, how much they explain
versus assert, warmth signals, and their repeated phrases.

Two rules while you do this:

- **Quote, do not paraphrase.** Every observation should be able to point at a real line they wrote.
  A voice doc full of verbatim evidence survives handoff to another skill; a voice doc full of
  adjectives does not.
- **Separate the voice from the accident.** If every caption ends with a booking link, that is a
  content habit, not a voice trait. If every caption opens with a question, that is voice.

## Step 3 - interview for what you could not see

Now ask. Read `references/interview-questions.md` for the full set, and follow the guidance there
about which ones to skip once your research has already answered them. There is no prize for asking
all of them; there is a real cost to making a busy clinic owner answer something you could have
worked out yourself.

Ask ONE question at a time and reflect back what you hear. Keep their strong phrases word for word,
including the messy ones. "I hate when clinics sound up themselves" is far more usable than
"prefers an approachable tone".

The questions that earn their keep are the ones about what they will NOT say, who they do not want
to sound like, and what they actually say out loud to a nervous patient. Those three shape a voice
more than any positive description.

## Step 4 - the honesty pass on what you found

Sometimes the research turns up a voice that is working against them, and it would be a disservice
to encode it. Two things to check before writing:

- **AHPRA breaches in their own copy.** If their captions say "the best results in Melbourne" or
  "completely safe" or call someone a "specialist" without registration, do NOT carry that into the
  voice doc. Flag it kindly and once: *"Three of your captions use wording AHPRA does not allow. I
  have kept your voice but left those phrases out, and here is what to use instead."* Their voice is
  worth keeping, the breach is not.
- **The gap between how they talk and how they write.** Very common: warm and funny in person, stiff
  and clinical online, because they think that is what professional looks like. If the interview
  answers sound alive and the captions sound flat, say so. That gap IS the finding, and the voice doc
  should encode the spoken version, not the stiff one. Tell them why.

## Step 5 - write voice-foundation.md

Follow the template in `references/output-format.md` exactly. The document ends with a
**YOUR CLAUDE VOICE BLOCK** - a 250 to 400 word block addressed to Claude, written in second person,
carrying the real phrases. That block is the entire payoff of the skill. Everything above it is
supporting evidence for the humans; the block is what actually changes future output.

Then tell them, in one short paragraph, the three things they need to know:

1. Save it as `Business-Brain/voice-foundation.md`.
2. Paste the voice block into their Claude Project custom instructions, so every chat starts on-brand.
3. Run `/cc-brand-guide` next, which folds this into their full brand file.

## Handoff

`/cc-brand-guide` reads this file and maps it straight through: the voice description and do/don't
lists feed tone_of_voice, the phrase bank feeds words_we_use, the never-say list feeds words_we_avoid,
and the voice block seeds the claude_context_block. So write those sections cleanly enough to be
lifted without editing.

If they never run `/cc-brand-guide`, this file still works on its own. That matters, because plenty
of clinics will run exactly one skill and then get busy.

## House rules

Australian English. No emdashes, use hyphens with spaces. Italics, never bold, for emphasis. Never
the "it's not X, it's Y" construction. Say "Claude", not "AI". Never invent a caption, a review, a
phrase or a statistic - if you did not read it or they did not say it, it does not go in the file.
AHPRA applies to every example you write: concern-led, never claim-led, and "has a special interest
in" rather than specialist or expert.
