# The interview - what the internet cannot show you

Your research has already answered a lot. The point of the interview is the rest: intention, taste,
and the things they say out loud but have never written down.

## How to run it
Ask ONE at a time. Reflect back what you hear before moving on, because clinic owners often correct
themselves on the second pass and the correction is the real answer.

Skip anything your research already answered, and say that you are skipping it: *"I can already see
from your captions that you write like you talk, so I will not ask about that."* This signals you did
the work and it keeps the interview to about ten minutes, which is roughly the honest limit of a
clinic owner's patience between patients.

Keep every strong phrase word for word, including the unpolished ones. "I hate sounding up myself" is
more usable than any tidy paraphrase, because it tells you exactly what to avoid and it sounds like a
person.

## The core set

**1. Voice you admire**
"Whose content do you love? It does not have to be a clinic."
Then: "What is it about how they write that you like?" The second question is the useful one.

**2. Voice you cannot stand**
"Whose clinic content makes you cringe?"
The strongest voice constraint you will get all interview. People are far more articulate about what
they hate than what they like.

**3. The room**
"A patient sits down, clearly nervous, first time having anything done. What do you actually say to
them?"
Ask for the real words, not a summary. This is often the warmest and most distinctive language in the
entire process, and it almost never appears on their Instagram.

**4. The thing you refuse to say**
"Is there any phrase or claim you would never put your name to, even if it worked?"
Draws out both taste and ethics. Often produces the never-say list on its own.

**5. Explainer or reassurer**
"When someone asks how a treatment works, do you enjoy explaining the science, or would you rather
just tell them how they will feel?"
Both are valid voices. Getting this wrong makes every future output feel off, because it decides
whether captions teach or soothe.

**6. Who you are actually talking to**
"Picture your favourite patient. Not the ideal-client-avatar version, an actual person. Who are
they?"
Chase for specifics: age, what they do, what they said when they walked in.

**7. Formality dial**
"On Instagram, are you talking to a friend, a client, or a room?"
Then read back two of their real captions and ask which one sounds more like them. Comparing their
own work beats asking them to describe themselves in the abstract.

**8. The words**
"Any words you love and use all the time? Any words you are sick of seeing in this industry?"
Prompt with what you found if they stall. Common clinic pet hates worth testing: journey, glow up,
transformation, tweakments, snatched, anti-ageing.

**9. We or I**
Only if the research was ambiguous, or if a solo practitioner is writing as "we".
"You are a solo clinic writing as 'we' - is that deliberate, or would you rather sound like you?"
Handle lightly; some have a reason, and it is theirs to make.

**10. What they wish they sounded like**
"If your content sounded exactly right, what would people say about you after reading it?"
The closing question. It surfaces the aspiration, which matters because a voice doc should stretch
slightly toward who they want to be, not just record where they are.

## When the gap appears
If their spoken answers are alive and their captions are flat, name it directly and gently:
*"You just described that treatment in a way I would happily read. Your captions do not sound like
that. Can I build the voice doc from how you just spoke instead?"*

They almost always say yes, and it is the single highest-value moment in the whole process.
