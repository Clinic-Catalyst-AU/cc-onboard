# voice-foundation.md - the output template

ONE markdown file. Australian English, no emdashes, italics not bold. Every quoted line must be
something they actually wrote or said - never a plausible-sounding invention.

## The template

```markdown
# VOICE FOUNDATION - [Clinic Name]
# How this clinic actually talks. Save as Business-Brain/voice-foundation.md
# Built by Clinic Catalyst | [date]

## What I read
[Plain list of the real sources: website pages, number of Instagram captions, Facebook posts, number
of Google review replies, anything else. If a source was blocked or empty, say so here. This section
is short but it matters - it tells the reader how much evidence sits behind the rest.]

## The voice in one paragraph
[4-5 sentences. How they sound, written so a stranger could pick their caption out of a line-up.
Concrete, not adjectival.]

## How they build a sentence
- Length and rhythm: [with a real example]
- Openers: [their actual habit, with 2 real first lines]
- Closers and CTAs: [their actual habit, with a real example]
- Person: [we / I / you, and whether it is working for them]
- Punctuation and emoji: [the real pattern]

## How they handle the technical
[Do they name devices and ingredients or keep it plain? Do they explain the mechanism or the feeling?
Teach or reassure? One short paragraph with a real example either side.]

## Phrase bank - their words, verbatim
[10-15 phrases they genuinely repeat, in quote marks. This is the section downstream skills lift
directly, so keep it clean and keep it real.]

## Never say
[8-10 items. Split into two groups and label them:
 - Their taste: words and phrases they told you they hate
 - AHPRA: specialist, expert (unless registered), best, #1, most effective, safe, painless, risk-free,
   guaranteed, cure, no downtime as a promise, treatment-outcome claims, patient testimonials for
   regulated treatments]

## The spoken voice vs the written voice
[Only include if there is a real gap. Name it, quote both, and say which one this document is built
on and why. If there is no gap, say that instead in one line - it is a genuinely good sign.]

## What I left out
[Only if relevant: AHPRA-breaching phrases found in their own copy, supplier copy reposted in their
feed, or agency hashtags that are not their language. One line each, no lecture. If nothing, omit
this section entirely.]

---

## YOUR CLAUDE VOICE BLOCK
[the 250-400 word block below - this is the part that does the work]
```

## The Claude voice block

This is the payoff. Everything above it is evidence for the humans to read once. This block is what
gets pasted into a Claude Project and quietly shapes every output from then on, so it deserves the
most care.

Write it as prose, addressed to Claude, in second person. No headers inside the block, because it
needs to survive being pasted into a custom instructions field.

Structure:

- Open: "You are writing as [Clinic Name], [what they do, for whom, where]."
- Who they are talking to, described as a person rather than a segment.
- How they sound, mechanically: sentence length, opener habit, person, formality, warmth. Include one
  or two real lines of theirs as calibration, marked as theirs.
- The phrase bank, folded in as language to reach for.
- The never-say list, both their taste and the AHPRA hard-bans, stated plainly.
- How to handle treatments: concern-led, never claim-led. Describe what the patient is worried about
  and what the appointment is like, not what the result will be.
- Close with the tell: "If a line could belong to any clinic in Australia, it is wrong. Rewrite it
  with something only this clinic would say."

That last line matters more than it looks. Generic output is the exact failure this whole skill
exists to prevent, so the block should end by naming it.

## Tone of the file itself
Write the document as if the clinic owner will read it, because they will. Warm, specific, and
occasionally complimentary where the compliment is earned - if their review replies are genuinely
lovely, say so. Nobody has ever told them their writing is good, and it makes them far more likely to
actually use the file.
