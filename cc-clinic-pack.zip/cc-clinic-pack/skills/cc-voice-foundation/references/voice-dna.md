# Voice DNA - what to extract from their published writing

The goal is a voice description precise enough that someone could write a new caption and a reader
would not be able to tell it was not the owner. Adjectives cannot do that. Mechanics can.

Work through the checklist below against the real samples you gathered. For every line you write,
you should be able to point at the caption, review reply or web page that proves it. Where you
cannot, leave it out rather than reaching.

## 1. Rhythm and length
- Average sentence length. Short and punchy, or long and flowing?
- Do they use fragments? ("Every single time." "No downtime.")
- Paragraph shape in captions - one block, or lots of line breaks with white space?
- Read three captions aloud in your head. Where does the breath fall?

## 2. Openers
The first line is the most deliberate thing they write, so it carries the most voice.
- Question opener ("Struggling with congestion?")
- Statement opener ("Winter skin is a different beast.")
- Personal opener ("I had a patient in yesterday who ...")
- Announcement opener ("New in clinic ...")
Which do they actually reach for? Give the real examples.

## 3. Closers and calls to action
- How do they ask for the booking? Direct ("Book online"), soft ("We are here when you are ready"),
  or with a question?
- Sign off habits. Do they name themselves? Use the clinic name? Nothing at all?

## 4. Person and distance
- "We" or "I"? A solo nurse writing as "we" sounds like a corporate, and it is usually worth noting
  when someone is hiding behind a plural they do not need.
- Do they address the reader as "you", or talk about patients in the third person? "You" is warmer
  and far more common in clinics that convert.

## 5. How they handle the technical
This is the single most distinguishing trait between clinics.
- Do they name devices and ingredients (Dermapen 4, 15% mandelic, 1927nm), or keep it plain
  English?
- Do they explain the mechanism, or just the outcome?
- Do they teach, or do they reassure? Some clinics educate constantly; others are all warmth.

## 6. Warmth signals
- Humour, and what kind - dry, silly, self-deprecating?
- Do they acknowledge fear and discomfort openly, or move past it?
- Do they talk about their own skin, their own treatments, their own bad days?

## 7. Punctuation and emoji
- Ellipses, exclamation marks, ALL CAPS for emphasis, brackets for asides.
- Emoji: which ones, how many, where in the post. A clinic that uses exactly one emoji at the end of
  every caption has a rule, even if they have never said it out loud.
- Hashtag habit - block at the end, sprinkled inline, or none.

## 8. The phrase bank
Pull 10 to 15 phrases they genuinely repeat. Their words, verbatim, including the imperfect ones.
This is the most reusable section of the entire document, because downstream skills lift it directly.

Look for: how they describe their approach, what they call their patients, the words they use for
results, how they describe the feeling of walking in the door.

## 9. Review replies - read these carefully
Owners write review replies fast, without a content calendar, usually on their phone. That makes
them the least performed writing on the internet and the closest thing to how they actually speak.
If the replies sound different from the captions, the replies are usually the real voice and the
captions are the costume. Note the gap, and say which one you recommend building on.

## 10. What is habit, not voice
Before you write anything up, subtract the accidents:
- A booking link on every post is a content rule, not a voice trait.
- Hashtags carried over from an old agency are not their language.
- Reposted supplier copy (an injectable brand's launch text, a device manufacturer's blurb) is
  someone else's voice sitting in their feed. Exclude it, and it is worth telling them you did.
