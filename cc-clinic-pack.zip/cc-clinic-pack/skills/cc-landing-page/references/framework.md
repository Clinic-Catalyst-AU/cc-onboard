# CC LANDING PAGE - The Full Framework (aesthetics and skin clinics)

The complete method for building or auditing a high-converting, AHPRA-safe clinic landing page. Read this in full before you build or audit. The page draws its headline, audience, language bank and proof angles from the clinic's `Business-Brain/brand-guide.md` (built on `resonance-messaging.md` from `/cc-resonance`). If neither exists, run `/cc-resonance` then `/cc-brand-guide` first - do not build without the foundation.

Throughout: the action you are driving toward is a consult or a concern assessment, never a promised treatment outcome. Every line is screened against the AHPRA guardrails in the SKILL.md file.

---

## HOW TO USE

Build a new landing page:
```
/cc-landing-page [page or offer name] --build
```

Audit an existing page:
```
/cc-landing-page [url or file path] --audit
```

Rebuild the hero section only:
```
/cc-landing-page [url or file path] --hero
```

---

## THE 5 PRINCIPLES

### PRINCIPLE 1: 80% of Your Effort Goes Above the Fold

The hero is where most visitors decide. If a nervous, researching person does not feel "this clinic understands the concern I keep noticing" within five seconds, they are gone.

*The hero MUST contain (in this order):*

1. *Headline* - from the brand guide's key messages. Concern-led emotional entry point. Speaks to the thing THEY see in the mirror, not to the clinic or a treatment.
2. *Sub-headline* - the calm handoff. Bridges from the concern to "there is a simple, no-pressure first step".
3. *One trust signal* - the single strongest AHPRA-safe signal (aggregate rating with count, years established, professional membership, or the clinician's area of special interest). Not a treatment testimonial.
4. *CTA* - one clear action: book a consult, or start the concern assessment. Not two options. Not "learn more". One button.
5. *Reassurance line* - one line that removes pressure or fear. "A consult is a conversation, not a commitment." / "No pressure, no obligation."

*Hero rules:*
- NEVER lead with who the clinic is or what it does. Lead with the concern the patient lives with.
- NEVER use vague copy. "Transform your skin" means nothing and risks a claim. "The lines that only show up in photos" means everything and stays concern-led.
- NEVER have more than one CTA above the fold. Confusion kills conversion.
- The headline should pass the "would a nervous person stop scrolling for this?" test.
- The sub-headline should pass the "does this make me feel understood and safer, not sold to?" test.

*Visual rules (AHPRA-aware):*
- Hero image should show the clinic environment, the clinician, or a calm, trusting moment - NOT a dramatic result. Do not use before/after imagery as the hero or as an implied promise.
- If using a photo of the clinician, they should look warm and approachable, not clinical or corporate.
- Soft overlay on hero images for text readability.
- Minimal elements. White space reads as calm and confident, which is exactly what this audience needs.

### PRINCIPLE 2: People Decide With Emotion, Not Logic

The page must speak to what they are FEELING about the concern, not list what the clinic THINKS they should know. For a regulated clinic, the emotional arc is Concern, Acknowledge, Invite - a gentler, compliant version of problem-agitate-solution that never promises a fix.

1. *Concern* - name their specific concern better than they can, in their own words (pulled from reviews, enquiries, the resonance language bank). When someone reads it and thinks "yes, that is exactly it", you have it. "The under-eye shadows that make you look tired even when you are not."

2. *Acknowledge* - show you understand the full weight of it without judgment, and normalise it. Not manufactured fear - recognition. "You have been quietly researching this for months, editing it out of photos, wondering if anyone else notices. You are not vain for caring about it - most people who book a consult say the same thing."

3. *Invite* - present the consult as the calm next step, framed as understanding rather than a fix. "The first step is simply knowing what is actually going on with your skin. A consult is a conversation, not a commitment - you decide everything after that." Do not present a treatment as the relief or promise an outcome.

*Emotional copy rules:*
- Use "you" far more than "we" or "the clinic".
- Short sentences for impact. Longer sentences for explanation.
- One idea per paragraph. One feeling per section.
- Read it out loud. If it sounds like marketing or a sales push, rewrite it. If it sounds like a calm clinician who gets it, ship it.
- Never promise the outcome. The consult is the product in the copy; the treatment decision happens in the room with the clinician.

### PRINCIPLE 3: Short Attention Spans - Make It Scannable

People do not read landing pages. They scan. The page needs to convert scanners AND readers.

*Scannable elements (use liberally):*
- Headlines that tell the story alone (someone should get the gist from the headlines only).
- Bullet points with short italic lead-ins.
- Highlighted key phrases (the concern words patients use).
- Simple icons as visual anchors.
- Short paragraphs (2-3 lines max on mobile).
- Plenty of white space between sections.

*The "headlines only" test:*
Read ONLY the section headings top to bottom. Do they tell a complete, calm, concern-led story that ends at a consult? If not, rewrite the headings.

*Section length rules:*
- Hero: five seconds to consume.
- Each section below the fold: 10-15 seconds max.
- If a section requires scrolling on mobile, it is too long.
- FAQ should be an accordion, not a wall of text.

### PRINCIPLE 4: Trust That Is Allowed to Sell

Trust signals are what move a cautious clinic visitor. But a regulated aesthetics clinic CANNOT use patient testimonials or endorsements about regulated treatments, and CANNOT use before/after as a promise. So the proof on a clinic page is different from a normal sales page - and done well, it is just as persuasive.

*The AHPRA-safe trust hierarchy (strongest to weakest):*
1. The clinician's qualifications, training, and area of special interest (named, verifiable).
2. Aggregate star rating with review count and a link to the platform (e.g. a Google rating shown as a number, not as quoted treatment reviews).
3. Years established, number of patients cared for, or facility and safety credentials.
4. Professional association memberships and registrations.
5. Genuine media features or community involvement (about the clinic generally, not a treatment outcome).
6. Experience-based comments that name NO treatment and claim NO clinical result - only how it felt to be cared for (use cautiously, see below).

*Placement rules:*
- At least ONE trust signal above the fold (in or immediately after the hero).
- A trust signal every 2-3 sections maximum.
- Each one should quietly answer a SPECIFIC fear this audience holds (looking overdone, being judged, being upsold, pain, wasting money). Map them to the fears in the brand guide.
- Never imply a result. "Our clinician has a special interest in skin health and has cared for the local community for 12 years" builds trust. A quoted treatment result does not - it breaches.

*Experience-based comment placeholders (generic, AHPRA-safe):*
Only ever use comments about the EXPERIENCE of care, never a treatment or an outcome. Examples of safe placeholder framing:
- "The team explained everything clearly and I never felt rushed or pushed into anything." - [First name], [Suburb]
- "I was nervous walking in and left feeling completely at ease. They answered every question." - [First name], [Suburb]
- "Honest, warm, and never once made me feel judged for being there." - [First name], [Suburb]

*What kills trust (and risks a breach):*
- Any testimonial or comment that names a treatment or claims a result ("my wrinkles disappeared", "best results I have ever had").
- Before/after images presented as a promise.
- Superlatives and self-praise (best, leading, #1, expert, specialist, painless, safe).
- Stock photos pretending to be patients.
- Too-polished, too-perfect quotes that read as fabricated.

### PRINCIPLE 5: Visual Hierarchy - Less Is More

Give people too many options and they choose none. Every element earns its place.

*The hierarchy stack:*
1. *One primary CTA* - the consult or assessment. Make it obvious. Repeat it.
2. *One secondary action* - FAQ, scroll, watch a short clinic intro. Never competing with the primary CTA.
3. *Remove everything else* - if it does not name the concern, acknowledge the feeling, build allowed trust, or invite the consult, cut it.

*Layout rules:*
- Maximum 7-9 sections (including hero and footer CTA).
- Each section has ONE job. Name it in three words. If you cannot, it is doing too much.
- CTA appears: in the hero, after the strongest trust section, and at the bottom. Three times max.
- Navigation minimal or hidden. They are here to book a consult, not to browse.
- Mobile-first, always. The majority of this traffic is mobile. Design for thumbs.

*Simplicity rules:*
- One or two font families (a serif for headlines, a sans for body is fine) - match the brand guide.
- Two accent colours max - the clinic's brand colours.
- Consistent spacing, padding and rhythm.
- If a section looks busy, remove elements until it does not.
- Calm beats clever. Conversion and compliance beat decoration.

---

## PAGE FLOW TEMPLATE

The optimal section order for a clinic landing page:

```
1. HERO (Principle 1)
   - Concern-led headline + reassuring sub-headline (from the brand guide)
   - One AHPRA-safe trust signal
   - One CTA (book a consult / start the assessment)
   - Reassurance line ("a conversation, not a commitment")

2. MIRROR (Principle 2 - Concern)
   - "You have probably noticed this..." - name the concern in their words
   - Short. 3-4 sentences max.

3. ACKNOWLEDGE (Principle 2)
   - Show you understand the full weight of it, without judgment
   - Normalise it, then turn gently toward hope (no promise)

4. THE CALM FIRST STEP (Principle 2 - Invite)
   - "There is a simple place to start" - introduce the consult/assessment as understanding, not a fix
   - A consult described as a conversation, not a product description

5. WHAT A CONSULT IS REALLY LIKE (Principle 3 - Scannable)
   - Grid or list: what happens, who they meet, how long, what they will and will not be pushed into
   - Sets expectations and removes fear. Outcomes of CARE and CLARITY, never treatment results.

6. TRUST (Principle 4)
   - Clinician qualifications + area of special interest, aggregate rating, years established, memberships
   - Quietly answers the #1 fear. No treatment testimonials, no before/after promise.

7. WHO THIS IS FOR (Principle 3)
   - "This is for you if..." bullet list - lets them self-select
   - Include one honest "this may not be the right fit if..." to build trust

8. CONSULT CTA (Principle 5)
   - Repeat the CTA. Real scarcity only if true (limited consult times).
   - NO pricing on any Schedule 4 (anti-wrinkle) treatment, and no discount framed as an inducement.
     Consult/assessment pricing or "complimentary consult" is fine if accurate.

9. FAQ (Principle 3 - Scannable)
   - Accordion. Max 6-8 questions.
   - Each answer reduces a fear (pain, downtime, looking overdone, cost transparency, "will I be pushed into anything").

10. FINAL CTA (Principle 5)
    - Calm close - tie back to the concern and the feeling
    - "Whenever you are ready, we are here." CTA button.
    - Reassurance, not manufactured urgency.
```

---

## AUDIT MODE

When auditing an existing page, evaluate against each principle AND the AHPRA guardrails:

```markdown
## CLINIC LANDING PAGE AUDIT: [URL/Page Name]
## Date: [date]
## Brand guide: [reference, or "MISSING - run /cc-brand-guide first"]

### AHPRA Compliance (screen FIRST - a breach outranks any conversion win)
- Superlatives / "expert" / "specialist" / "safe" / "painless": [found? quote them]
- Before/after used as a promise: [yes/no]
- Patient testimonials about regulated treatments: [yes/no - quote any]
- Guaranteed or specific outcomes claimed: [yes/no]
- "Botox" used (should be "anti-wrinkle"): [yes/no]
- Pricing on a Schedule 4 treatment / discount as inducement: [yes/no]
- VERDICT: [compliant / needs fixes - list them as priority 1]

### Principle 1: Above the Fold (80% Rule)
- Headline: [quote it] - [pass/fail] - [concern-led?]
- Sub-headline: [quote it] - [pass/fail]
- Trust signal above fold: [yes/no] - [what, and is it AHPRA-safe?]
- CTA clarity: [pass/fail] - [how many CTAs? is it a consult/assessment?]
- Reassurance line: [yes/no]
- 5-Second Test: [pass/fail]
- SCORE: [1-10]

### Principle 2: Emotional Arc (Concern, Acknowledge, Invite)
- Concern named in their words: [yes/no] - [specific enough?]
- Acknowledged without judgment: [yes/no]
- Consult framed as the calm first step (not a promised fix): [yes/no]
- "You" vs "we" ratio: [ratio]
- SCORE: [1-10]

### Principle 3: Scannable
- Headlines tell the complete story alone: [yes/no]
- Section length on mobile: [pass/fail]
- Bullets / highlights / white space used: [yes/no]
- "Headlines only" test: [pass/fail]
- SCORE: [1-10]

### Principle 4: Allowed Trust
- Trust signal above fold: [yes/no]
- Total trust elements: [count]
- All AHPRA-safe (no treatment testimonials / before-after promise): [yes/no]
- Mapped to patient fears: [yes/no]
- SCORE: [1-10]

### Principle 5: Visual Hierarchy
- Number of sections: [count] - [too many / right / too few]
- CTA count and placement: [details]
- Competing elements: [any?]
- Mobile-first: [yes/no]
- Clutter level: [calm / busy / chaotic]
- SCORE: [1-10]

### OVERALL SCORE: [X/50]   (AHPRA failures are blocking regardless of score)

### TOP 3 FIXES (highest impact, do these first - AHPRA fixes always rank first):
1. [fix]
2. [fix]
3. [fix]

### FULL RECOMMENDATIONS:
[detailed fixes in priority order]
```

---

## RULES

- NEVER build a clinic landing page without the brand guide / resonance foundation. If they are missing, stop and run `/cc-resonance` then `/cc-brand-guide` first.
- ALWAYS read the brand guide's language bank (OPEN and CLOSE words) before writing. One wrong word breaks the trust this audience extends slowly.
- NEVER use emdashes - hyphens with spaces only. Australian English. Italics for emphasis, never bold inline. Never the "it's not X, it's Y" construction.
- NEVER add more than 3 CTAs, and make every CTA a consult or an assessment, never a hard pitch for a named regulated treatment.
- NEVER let a section do more than one job.
- NEVER prioritise design over conversion or over compliance. A pretty page that risks a breach is a liability.
- ALWAYS design mobile-first.
- ALWAYS run the finished page back through the AHPRA guardrails before handing it over. If a line cannot be made compliant, cut it and say why.
- The finished-hero test: does a nervous person feel quietly understood and safer within five seconds, and would the hero survive an AHPRA review? If either answer is no, the hero is not done.
