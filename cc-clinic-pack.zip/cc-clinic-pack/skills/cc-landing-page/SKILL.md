---
name: cc-landing-page
description: High-converting landing page builder and auditor for aesthetics and skin clinics in Australia. Builds new pages or audits existing ones using 5 conversion principles plus the clinic's own emotional resonance, and screens every line against AHPRA and TGA cosmetic advertising rules. Reads the clinic's voice and audience from its brand-guide.md so the page sounds like the clinic, not a template. Use when you say landing page, build a page, audit this page, conversion page, sales page, opt-in page, booking page, consult page, treatment page, or want any clinic landing page created or reviewed. Pairs with /cc-marketing-genius for copy strategy and /cc-resonance for the emotional foundation.
---

# CC LANDING PAGE - High-Converting Page Builder for Aesthetics Clinics

Builds or audits a landing page that turns a cautious, researching visitor into a booked consult. It combines 5 conversion principles with the clinic's own emotional resonance, and screens every line against the cosmetic advertising rules a regulated clinic operates under. A consult or a concern assessment is the action you are driving toward, never a promised treatment outcome.

*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS the clinic's voice, audience, key messages and language boundaries from `Business-Brain/brand-guide.md` (and, when present, `Business-Brain/resonance-messaging.md`, `Business-Brain/concerns.md`, `Business-Brain/offers.md`). When building a new page it WRITES the page to the clinic's site/output folder; it does not write into `Business-Brain/` - with ONE approved exception: after the clinic confirms their published GHL page URL, it records a `Landing page: <url>` line under the offer in `Business-Brain/offers.md`, always with their explicit okay (see the close-the-loop step). All paths are relative to your clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If `brand-guide.md` is missing, say so and offer to run `/cc-brand-guide` first; never fabricate the clinic's voice.

*Prerequisite* - the page draws its headline, audience, language bank and proof angles from the clinic's brand guide (which is itself built on the resonance-messaging.md from `/cc-resonance`). If neither exists yet, stop and run `/cc-resonance` then `/cc-brand-guide` first. Do not build a clinic landing page without the emotional and voice foundation.

---

## HOW TO USE

Build a new landing page:
```
/cc-landing-page [page or offer name] --build
```

Build the GHL offer page for an ad campaign (the workshop fast path - locked template):
```
/cc-landing-page [offer name] --ghl-offer
```

Audit an existing page:
```
/cc-landing-page [url or file path] --audit
```

Rebuild the hero section only:
```
/cc-landing-page [url or file path] --hero
```

---

## GHL OFFER PAGE - THE LOCKED TEMPLATE (fast path, one page per offer)

This is the mode used in the workshop and for every new ad campaign afterwards. The page structure is FIXED so every clinic gets the same proven layout - your only job is filling the slots. Do NOT redesign, add sections, reorder, or touch the CSS. If you think the template needs a structural change, say so and stop - never improvise structure on a live build.

1. Read `references/ghl-offer-template.html` - it is the complete page with `{{SLOT}}` markers.
2. Gather inputs, in this order:
   - The offer: from `Business-Brain/offers.md` or the clinic's Offer Architecture worksheet (offer name, full price, offer price, what's included, urgency/scarcity - urgency must be TRUE, never invented).
   - Voice + audience: `Business-Brain/brand-guide.md` + `resonance-messaging.md` (concern line in the patient's own words, practitioner line, FAQ answers).
   - Accent colour: `Business-Brain/brand-assets/accent.txt` (fallback #0c4a45).
   - The GHL form embed URL - ask the user to copy it from GHL (Sites > Forms > their lead form > embed/link). Never guess it.
   - The hero image as a GHL Media Library CDN URL - they upload the image to GHL Media Library first and paste the URL here. NEVER use a local path or an external host: GHL pages only render GHL CDN media reliably.
3. Fill every `{{SLOT}}`. No slot left unfilled - if information is missing, ask; never pad with invented claims.
4. AHPRA gate every filled line (section below). Trust lines are credentials, years of experience, "special interest in", aggregate Google rating - never treatment testimonials, never before/after language, never guarantees.
5. Save to `Ads/landing-pages/[offer-slug].html` in the clinic workspace. STRICT output contract: exactly ONE file, that path, nothing else - no .md notes, no extra drafts.
6. THE FINALE part 1 - SHOW them the page (always, never ask first). The moment the file exists:
   - `open Ads/landing-pages/[offer-slug].html` - the finished page opens in their browser as a live preview. Because the hero image is a GHL CDN URL and the form is their real GHL embed, what renders locally IS the real page - image and form load live from GHL.
   - Watching their own branded offer page render on screen is the payoff moment. A run that ends with a file path in the terminal is NOT done.
7. THE APPROVAL GATE - nothing ships until they say yes. With the preview open, ask: "Happy with it? Anything to change - wording, image, price line?" Apply edits to the SAME file, refresh the preview, repeat until they approve. The page that goes to GHL is one a human has looked at and okayed - that is the compliance posture too (every output is a draft until a human approves it).
8. ON APPROVAL - hand it over ready to paste:
   - `pbcopy < Ads/landing-pages/[offer-slug].html` - the ENTIRE page code is now on their clipboard; tell them so. Also `open -R` the file in Finder as the backup copy path.
   - Walk them through shipping while the preview is still open: GHL > their funnel > add a step > full-page Custom Code element > Cmd+V paste > preview on phone > publish.
9. CLOSE THE LOOP - get the live URL back. Ask them to paste the published GHL page URL here. Then:
   - Verify it actually loads (curl or open it) - never assume a publish worked.
   - With their okay, record it under the offer in `Business-Brain/offers.md` as a `Landing page: <url>` line (this is the ONE brain write this skill may make, always with explicit approval - it is offer data, and it is where the ad builders look first).
   - Offer the next step out loud: "This URL is what your ads point at - want me to run /cc-googlead-builder or /cc-metaad-builder against it now?"
10. New offer or new ad angle = rerun this mode. One page per offer, always from the same template.

---

## THE 5 PRINCIPLES (OVERVIEW)

The full method, page-flow template and audit scorecard live in `references/framework.md`. Read it in full before you build or audit. In short:

1. *80% of your effort goes above the fold* - the hero is where the visitor decides "this clinic understands my concern" in five seconds.
2. *People decide with emotion, not logic* - mirror the concern they see in the mirror, then open a calm door (Concern, Acknowledge, Invite).
3. *Short attention spans - make it scannable* - headlines should tell the whole story alone; short paragraphs, plenty of white space.
4. *Trust that is allowed to sell* - for a regulated clinic this is credentials, qualifications, aggregate ratings and a calm experience, never treatment testimonials or before/after promises.
5. *Visual hierarchy - less is more* - one clear next step (the consult), repeated, with everything else cut.

---

## AHPRA GUARDRAILS (NON-NEGOTIABLE - SCREEN EVERY LINE)

Aesthetics clinics advertise under AHPRA and TGA cosmetic rules. A landing page is exactly where clinics get fined. Apply this to every headline, body line, button and image caption:

- *Concern-led, never claim-led.* Advertise the concern and the consult, not a promised outcome of a regulated treatment.
- *No superlatives or self-promotion:* best, leading, top, #1, most effective, expert, specialist, expertise, painless, safe, risk-free. Use "has a special interest in" instead of "expert" or "specialist".
- *No before/after as a promise* and no comparative appearance claims. Do not use before/after imagery as the hero or as a guaranteed result.
- *No patient testimonials or endorsements for regulated treatments*, even paraphrased. (See Principle 4 in the framework for what trust signals you CAN use.)
- *No guaranteed or specific outcomes* ("years younger", "wrinkle-free", "clears acne").
- *Never use the word "Botox"* (trademarked and Schedule 4) - use "anti-wrinkle". No pricing on any Schedule 4 (anti-wrinkle) treatment, and no discount framed as an inducement to undergo a regulated procedure.
- *Avoid "anti-ageing";* prefer concern-led framing.
- *Australian English only.* No emdashes - use hyphens with spaces ( - ) or rewrite. Italics for emphasis, never bold. Never the "it's not X, it's Y" construction (an AI tell).

When in doubt, make it gentler and more concern-led. A compliant page that books a consult beats a punchy one that risks a breach. If a line cannot be made compliant, cut it and say why.

---

## RULES

- ALWAYS read `Business-Brain/brand-guide.md` in full before writing a line. The voice, ideal patient, key messages and words-we-avoid all live there. If it is missing, run `/cc-brand-guide` first.
- ALWAYS read the brand guide's language bank (OPEN and CLOSE words) before writing. One wrong word breaks the trust this audience extends slowly.
- NEVER build a clinic landing page without the brand guide / resonance foundation. Generic clinic copy reads as off-voice and risks AHPRA breaches.
- NEVER use emdashes - hyphens with spaces only. Australian English. Italics for emphasis, never bold inline.
- NEVER add more than 3 CTAs on a page, and make every CTA a consult or an assessment, never a hard pitch for a named regulated treatment.
- NEVER let a section do more than one job.
- NEVER prioritise design over conversion or over compliance. A pretty page that risks a breach is a liability.
- ALWAYS design mobile-first. The majority of this traffic is mobile.
- ALWAYS run the final page back through the AHPRA guardrails above before handing it over.
- The test for a finished hero: does a nervous person reading it feel quietly understood and safer within five seconds, and would this hero survive an AHPRA review? If either answer is no, the hero is not done.

For copy strategy, subject lines and nurture sequences that feed people TO this page, pair with `/cc-marketing-genius`. For the deeper emotional foundation behind the headline, see `/cc-resonance`.
