---
name: cc-landing-page
description: High-converting landing page builder and auditor for aesthetics and skin clinics in Australia. Builds new pages or audits existing ones using 5 conversion principles plus the clinic's own emotional resonance, and screens every line against AHPRA and TGA cosmetic advertising rules. Reads the clinic's voice and audience from its brand-guide.md so the page sounds like the clinic, not a template. Use when you say landing page, build a page, audit this page, conversion page, sales page, opt-in page, booking page, consult page, treatment page, or want any clinic landing page created or reviewed. Pairs with /cc-marketing-genius for copy strategy and /cc-resonance for the emotional foundation.
---

# CC LANDING PAGE - High-Converting Page Builder for Aesthetics Clinics

Builds or audits a landing page that turns a cautious, researching visitor into a booked consult. It combines 5 conversion principles with the clinic's own emotional resonance, and screens every line against the cosmetic advertising rules a regulated clinic operates under. A consult or a concern assessment is the action you are driving toward, never a promised treatment outcome.

*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/resonance-messaging.md` (the emotional source of truth - see NEURO-EMOTIVE WIRING below) + the clinic's voice, audience, key messages and language boundaries from `Business-Brain/brand-guide.md` (and, when present, `Business-Brain/concerns.md`, `Business-Brain/offers.md`). When building a new page it WRITES the page to the clinic's site/output folder; it does not write into `Business-Brain/` - with ONE approved exception: after the clinic confirms their published GHL page URL, it records a `Landing page: <url>` line under the offer in `Business-Brain/offers.md`, always with their explicit okay (see the close-the-loop step). All paths are relative to your clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If `brand-guide.md` is missing, say so and offer to run `/cc-brand-guide` first; never fabricate the clinic's voice.

*Prerequisite* - the page draws its headline, audience, language bank and proof angles from the clinic's brand guide (which is itself built on the resonance-messaging.md from `/cc-resonance`). If neither exists yet, stop and run `/cc-resonance` then `/cc-brand-guide` first. Do not build a clinic landing page without the emotional and voice foundation.

---

## NEURO-EMOTIVE WIRING (mandatory - this is what makes the page land, not read like any clinic)

Run the shared engine before writing a line: `cc-resonance/references/neuro-emotive-engine.md` (installed alongside this skill). In short:
1. READ `Business-Brain/resonance-messaging.md` - the emotional stack, the arc, the OPEN/CLOSE language bank, the headline angles, the proof map - as well as `brand-guide.md`. If `resonance-messaging.md` is missing, offer `/cc-resonance`; never generate off the brand-guide alone (that is what makes pages thin).
2. APPLY the 21 neuro-emotive models (`cc-resonance/references/model-library.md`), mapped to the page: hero = Trust Anchor + Desire Dial + Voiceprint Precision; proof = Price Harmony (AHPRA-safe proof only - skin before/afters allowed if genuine and consented and never framed as a guaranteed result; hero placement allowed only under the gated matrix in the AHPRA section; injectable before/afters never on a public page) + Prestige Magnet ("special interest in"); the calm "what happens next" = Trust-Through-Transparency; one clear CTA = Guided Choice Maker.
3. GROUND every line in the clinic's real offer + their OPEN language bank. You should be able to point at any headline or section and name the model firing AND the OPEN word it used. A generic page that ignores the resonance doc is a FAILED run - regenerate. (All model use stays inside the existing AHPRA rules.)

---

## HOW TO USE

Build a new landing page:
```
/cc-landing-page [page or offer name] --build
```

Build the GHL offer page for an ad campaign (the workshop fast path - locked template):
```
/cc-landing-page [offer name] --ghl-offer
```

Audit an existing page:
```
/cc-landing-page [url or file path] --audit
```

Rebuild the hero section only:
```
/cc-landing-page [url or file path] --hero
```

---

## GHL OFFER PAGE - THE LOCKED TEMPLATE (fast path, one page per offer)

This is the mode used in the workshop and for every new ad campaign afterwards. The template (`references/ghl-offer-template.html`, v2) mirrors the copy structure and section placement of a proven high-converting Google Ads offer page. The structure is FIXED so every clinic gets the same converting layout - your only job is filling the slots. Do NOT redesign, add sections, reorder, or touch the CSS layout. If you think the template needs a structural change, say so and stop - never improvise structure on a live build.

*The proven section order (do not change):* sticky offer bar -> hero (eyebrow, two-line headline with the second line in the accent colour, mechanism-rich subhead, offer/price pill, trust chips, DUAL CTA, image with a floating credential badge + reassurance strip) -> mechanism education (why the proper version of the treatment matters, a two-column compare with a cautionary column and an affirmative column, then a bottom-line) -> mid-page CTA band with "can't find a time? contact us" microcopy -> cost anchor (why a cheaper option needs you back more often, compare blocks + a price tally) -> second CTA band -> care/practitioner (feature chips + a practitioner card with a short bio, credentials and a quote) -> before/after proof (allowed for skin/device treatments) -> final booking block (price box, the booking mechanism, filling-fast line, trust badges) -> footer with links and the full compliance disclaimer.

*Colours, fonts and logo come from the brand guide, never hardcoded.* Fill `{{ACCENT_HEX}}`, `{{ACCENT_INK_HEX}}` (a darker shade of the accent for depth), `{{BG_SOFT_HEX}}` (the brand's soft/neutral section tone), and the font slots (`{{FONT_IMPORT}}` = the `<link>`/`@import` line, `{{HEADING_FONT_STACK}}`, `{{BODY_FONT_STACK}}`) from `Business-Brain/brand-guide.md` + `brand-assets/accent.txt`. Never invent a palette or a font the brand does not use.

### STEP 0 - THE PRE-FLIGHT (do this FIRST, before reading the template or writing a word)

The page cannot be built without three things that live inside GHL, not on their computer. Most
clinic owners are not technical and will not know where these are. Do NOT start building and
discover them halfway - ask for all three up front, walk them through getting each one, and WAIT.

Say it plainly: "Before I build this, I need three things out of your GHL. I'll talk you through
each one - it takes about five minutes and you only ever do it once per offer."

*1. The booking link* - where every button on the page sends them.
   Their real, public booking calendar URL (GHL calendar, Timely, Cliniko, Fresha).
   Ask them to open their booking page as a patient would, and copy the URL from the address bar.
   Never guess or construct this.

*2. The form embed code* - the actual booking form on the page.
   Click path, read it to them one step at a time:
   GHL > *Sites* > *Forms* > click their lead form > *Integrate* (or *Embed*) > copy the WHOLE snippet.
   It must be the full `<iframe ...></iframe>` PLUS the `<script src=".../form_embed.js">` line.
   A bare URL is not enough and the form will not render. If they paste only a URL, ask again and
   tell them what is missing. If they have no lead form and run direct-booking only, say so - the
   page falls back to a button pointing at the booking link.

*3. The images, uploaded to GHL, as GHL CDN links* - this is the one that breaks pages.
   A local file path or a link from their website WILL NOT RENDER on a published GHL page.
   Every image has to be uploaded into GHL first and referenced by its GHL CDN URL.
   Click path: GHL > *Media Library* (Marketing > Media) > *Upload* > drag the images in > click
   the uploaded image > *Copy link*. The link must start with `https://assets.cdn.filesafe.space/`.
   Collect: the hero image, and any before/after pairs they want to show (skin/device only - see
   the AHPRA matrix; injectables never on a public page).
   If they paste a path like `/Users/...` or a link to their existing website, stop and explain
   why it will break, then send them back to Media Library.

Only when all three are in hand do you move on. If something is missing, hold - a page built
without them looks finished on their screen and is broken the moment it is published.

1. Read `references/ghl-offer-template.html` in full - it is the complete page with `{{SLOT}}` markers and inline guidance.
2. Gather the rest of the inputs, in this order (the three pre-flight items above are already in hand):
   - The offer: from `Business-Brain/offers.md` or the clinic's Offer Architecture worksheet (offer name, full price, offer price, what's included, urgency/scarcity - urgency must be TRUE, never invented).
   - Voice + audience + proof angles: `Business-Brain/brand-guide.md` + `resonance-messaging.md` (concern line in the patient's own words, the mechanism/education angle, practitioner bio + credentials, the honest "why cheaper costs more" framing).
   - Brand tokens: accent + soft background + font pairing from the brand guide (see above). `brand-assets/accent.txt` is the accent fallback source.
   - *THE TWO BOOKING INPUTS - always ask the clinic for BOTH before building (this is non-negotiable, the page cannot be built without them):*
     - `{{DIRECT_BOOKING_LINK}}` - the clinic's real, public booking calendar URL (Timely, Cliniko, Fresha, or a GHL calendar). EVERY CTA button on the page points here. Ask them to paste it; never guess or construct it.
     - `{{GHL_FORM_EMBED_CODE}}` - the FULL form embed snippet the clinic copies out of GHL (the whole `<iframe>...</iframe>` plus the `<script src=".../form_embed.js">` line), NOT just a URL. It is pasted verbatim into the final booking block. Ask them to copy it from GHL (Sites > Forms > their lead form > Integrate/Embed). If the clinic runs a direct-booking-only model with no lead form, say so and leave the form block's fallback button (which points at `{{DIRECT_BOOKING_LINK}}`).
   - The hero image as a GHL Media Library CDN URL - they upload to GHL Media Library first and paste the URL here. NEVER a local path or an external host: GHL pages only render GHL CDN media reliably.
   - *Before/after images (skin/device treatments only)* - ask the clinic to point Claude at their before/after photos, either a folder they name in the prompt or the conventional `Business-Brain/brand-assets/before-after/`. Read that folder, pick the genuine, consented, matched pairs (same lighting, realistic - see the AHPRA matrix), and pair each before with its after. These images follow the SAME rule as the hero: for the live GHL page they must be uploaded to GHL Media Library and referenced by their CDN URL in the `{{BA_n_BEFORE_URL}}` / `{{BA_n_AFTER_URL}}` slots - a local path renders in the on-screen preview but breaks on the published GHL page. If the clinic has no before/after folder, or the treatment is an injectable (Schedule 4), remove the whole before/after section rather than inventing or borrowing images.
3. Fill every `{{SLOT}}`. No slot left unfilled - if information is missing, ask; never pad with invented claims. Genuinely optional-per-clinic slots (extra before/after cards, some credential chips) can be trimmed, but never faked.
4. AHPRA gate every filled line (section below). For SKIN / DEVICE treatments (HIFU, IPL, skin needling, LED, peels, facials) the full structure is allowed - before/after images, pricing and the compare blocks are all fine when genuine and consented; keep them. Only INJECTABLES (Schedule 4) lose the before/after and pricing. Separately, keep the COPY clean of advertising-conduct breaches regardless of treatment: no superlatives (best/leading/expert/specialist - use "has a special interest in"), no health-outcome guarantees, no success-rate stats. Trust lines are credentials, years of experience, aggregate Google rating - never treatment testimonials.
5. Save to `Ads/landing-pages/[offer-slug].html` in the clinic workspace. STRICT output contract: exactly ONE file, that path, nothing else - no .md notes, no extra drafts.
6. THE FINALE part 1 - SHOW them the page (always, never ask first). The moment the file exists:
   - `open Ads/landing-pages/[offer-slug].html` - the finished page opens in their browser as a live preview. Because the hero image is a GHL CDN URL and the form is their real GHL embed, what renders locally IS the real page - image and form load live from GHL.
   - Watching their own branded offer page render on screen is the payoff moment. A run that ends with a file path in the terminal is NOT done.
7. THE APPROVAL GATE - nothing ships until they say yes. With the preview open, ask: "Happy with it? Anything to change - wording, image, price line?" Apply edits to the SAME file, refresh the preview, repeat until they approve. The page that goes to GHL is one a human has looked at and okayed - that is the compliance posture too (every output is a draft until a human approves it).
8. ON APPROVAL - hand it over ready to paste:
   - `pbcopy < Ads/landing-pages/[offer-slug].html` - the ENTIRE page code is now on their clipboard; tell them so out loud ("the whole page is copied - you don't need to open the file or select anything").
   - Walk them through shipping ONE STEP AT A TIME, waiting after each, with the preview still open.
     They are not technical - do not read this as a single sentence:
     1. In GHL, go to *Sites* > *Funnels* > their funnel (or *+ New Funnel* if this offer has none).
     2. *+ Add Step*, name it after the offer, open the new step in the builder.
     3. Delete any default section GHL put there - the page is complete on its own.
     4. Add a *Custom Code / HTML* element and set it to full width.
     5. Click into it and paste (Cmd+V on Mac, Ctrl+V on Windows). The whole page goes in.
     6. Save, then *Preview* - and check it on a phone, not just the desktop preview.
     7. *Publish*, and copy the live URL.
   - If the page looks broken after pasting, the cause is almost always an image that is not a GHL
     CDN link, or a form embed that was pasted as a URL instead of the full snippet. Say that.
9. CLOSE THE LOOP - get the live URL back. Ask them to paste the published GHL page URL here. Then:
   - Verify it actually loads (curl or open it) - never assume a publish worked.
   - With their okay, record it under the offer in `Business-Brain/offers.md` as a `Landing page: <url>` line (this is the ONE brain write this skill may make, always with explicit approval - it is offer data, and it is where the ad builders look first).
   - Offer the next step out loud: "This URL is what your ads point at - want me to run /cc-googlead-builder or /cc-metaad-builder against it now?"
10. New offer or new ad angle = rerun this mode. One page per offer, always from the same template.

---

## THE 5 PRINCIPLES (OVERVIEW)

The full method, page-flow template and audit scorecard live in `references/framework.md`. Read it in full before you build or audit. In short:

1. *80% of your effort goes above the fold* - the hero is where the visitor decides "this clinic understands my concern" in five seconds.
2. *People decide with emotion, not logic* - mirror the concern they see in the mirror, then open a calm door (Concern, Acknowledge, Invite).
3. *Short attention spans - make it scannable* - headlines should tell the whole story alone; short paragraphs, plenty of white space.
4. *Trust that is allowed to sell* - for a regulated clinic this is credentials, qualifications, aggregate ratings and a calm experience, never treatment testimonials or before/after promises.
5. *Visual hierarchy - less is more* - one clear next step (the consult), repeated, with everything else cut.

---

## AHPRA GUARDRAILS (NON-NEGOTIABLE - SCREEN EVERY LINE)

Aesthetics clinics advertise under AHPRA and TGA cosmetic rules. A landing page is exactly where clinics get fined. Apply this to every headline, body line, button and image caption:

- *Concern-led, never claim-led.* Advertise the concern and the consult, not a promised outcome of a regulated treatment.
- *Superlatives - two tiers (do not blanket-ban all of them):*
  - HARD-BANNED, these are the actual breach: *safe, painless, risk-free, best, #1, most effective* (safety and comparative claims that cannot be substantiated), and *specialist* / *expert* unless the practitioner actually holds that registration (protected title). Keep using "has a special interest in".
  - DISCRETIONARY, the clinic's call, not a breach: *leading, top, expertise, premium, trusted, boutique* - this is puffery, low risk; use it if the brand wants it. Default to warmer concern-led language, but do not strip these out as if they were illegal.
- *Before/after images (the legal matrix, not a blanket ban):* skin-treatment before/afters (non-Schedule-4 - IPL, skin needling, LED, HIFU, facials, peels) are allowed on the page, provided they are genuine, consented, realistic (same lighting, not misleading), matched, and never framed as a guaranteed result. AHPRA regulates the IMAGE (genuine / consented / realistic / not-misleading, plus a visible "individual results vary" disclaimer), not its POSITION on the page - so a skin/non-S4 before/after MAY be used as the hero image, on a private or public page, when ALL of these hold: non-Schedule-4 (skin/device), genuine and consented, realistic and matched, NOT captioned or framed as a promised or typical result, and paired with a visible "individual results vary" disclaimer. Default to a non-result hero (clinic, clinician, calm moment) unless the clinic has explicitly chosen the before/after there - that gate is what keeps hero placement compliant. Injectable (Schedule 4) before/afters must NEVER appear on a public page - they are permitted only in direct channels (email, or after a consult), and never as a hero anywhere. Always defer to the clinic's own resonance-messaging.md / brand-guide.md boundaries (some brands use none at all). No comparative appearance claims, and never a patient testimonial that claims a treatment result.
- *No patient testimonials or endorsements for regulated treatments*, even paraphrased. (See Principle 4 in the framework for what trust signals you CAN use.)
- *No guaranteed or specific outcomes* ("years younger", "wrinkle-free", "clears acne").
- *Never use the word "Botox"* (trademarked and Schedule 4) - use "anti-wrinkle". No pricing on any Schedule 4 (anti-wrinkle) treatment, and no discount framed as an inducement to undergo a regulated procedure.
- *"Anti-ageing" is allowed - use with care, not banned.* AHPRA does not prohibit the term; concern-led framing usually converts better and is the default, but whether to use "anti-ageing" is the clinic's choice, not a hard rule.
- *Australian English only.* No emdashes - use hyphens with spaces ( - ) or rewrite. Italics for emphasis, never bold. Never the "it's not X, it's Y" construction (an AI tell).

When in doubt, make it gentler and more concern-led. A compliant page that books a consult beats a punchy one that risks a breach. If a line cannot be made compliant, cut it and say why.

---

## RULES

- ALWAYS read `Business-Brain/brand-guide.md` in full before writing a line. The voice, ideal patient, key messages and words-we-avoid all live there. If it is missing, run `/cc-brand-guide` first.
- ALWAYS read the brand guide's language bank (OPEN and CLOSE words) before writing. One wrong word breaks the trust this audience extends slowly.
- NEVER build a clinic landing page without the brand guide / resonance foundation. Generic clinic copy reads as off-voice and risks AHPRA breaches.
- NEVER use emdashes - hyphens with spaces only. Australian English. Italics for emphasis, never bold inline.
- NEVER add more than 3 CTAs on a page, and make every CTA a consult or an assessment, never a hard pitch for a named regulated treatment.
- NEVER let a section do more than one job.
- NEVER prioritise design over conversion or over compliance. A pretty page that risks a breach is a liability.
- ALWAYS design mobile-first. The majority of this traffic is mobile.
- ALWAYS run the final page back through the AHPRA guardrails above before handing it over.
- The test for a finished hero: does a nervous person reading it feel quietly understood and safer within five seconds, and would this hero survive an AHPRA review? If either answer is no, the hero is not done.

For copy strategy, subject lines and nurture sequences that feed people TO this page, pair with `/cc-marketing-genius`. For the deeper emotional foundation behind the headline, see `/cc-resonance`.
