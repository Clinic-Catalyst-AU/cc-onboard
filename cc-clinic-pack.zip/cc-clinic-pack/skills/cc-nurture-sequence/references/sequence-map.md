# CC Nurture Sequence - The Locked 7-Day Ad-Enquiry Map

A high-converting lead nurture framework, made AHPRA-safe for regulated clinics. This is the reference the skill fills in the clinic's voice. Read it in full before generating.

The sequence catches a lead the moment they enquire from a paid ad (the person who filled the `/cc-landing-page` form but has NOT booked) and walks them to a consult over 7 days. If no booking by day 7, they exit into long-term nurture (`/cc-follow-up-agent`).

---

## THE CORE PRINCIPLE

People rarely buy aesthetic treatments because they need more information. They buy when they feel understood, safe and confident they are making the right decision. Every touchpoint moves the lead through ONE emotional stage:

*Curiosity → Connection → Trust → Belief → Action*

The formula the whole sequence obeys: *Conversation → Education → Social Proof → Consultation → Booking.* Never ask for the booking in every message. Build trust first.

---

## THE SPINE - RESONANCE FIRST, ALWAYS

This sequence is NOT generated from this map alone. It is generated from the clinic's `Business-Brain/resonance-messaging.md` (the output of `/cc-resonance`), which is where the clinic's specific felt-experience, language bank, proof and the 21 neuro-emotive models have already been applied to THIS clinic. This map is the structure; the resonance doc is the voice and the psychology. If `resonance-messaging.md` is missing, run `/cc-resonance` first - never write nurture off the brand-guide summary alone.

## THE NEURO-EMOTIVE LAYER - all 21 models, not 5

The one-page framework names 5 surface drivers (Recognition, Trust, Certainty, Safety, Momentum). Those are a summary. The real system is the *21-model library* in `cc-resonance/references/model-library.md` across 3 families - Structural (7), Embedded Emotional (9), Language Precision (5). This sequence maps them properly: a few carry across the whole sequence, most fire at a specific touch point. Every message is labelled with the models firing in it.

*Sequence-wide (set at the resonance layer, carried through every message):*
- *Trust Anchor, Prestige Magnet, Possibility Lens* - the clinic's positioning and likeability, from resonance-messaging.md.
- *Voiceprint Precision* - the calm, premium, no-hype voice on every single line.
- *Urgency with Integrity* and *Binge-Worthy Flow / Relevance Lock* - carried in the CADENCE (the 7-day rhythm itself), never as a claim. AHPRA caps how hard urgency can be pushed - it lives in the pacing, not the words.

*Per touch point (see the map below for which fire where):* Empathy Echo, Belonging Trigger, Curiosity Spark, Pain Diffuser, Emotional Proof, Desire Dial, Retention Resonator, Ownership Shift, Clarity Charge, Trust-Through-Transparency, Price Harmony, Believability Bridge, Social Mirror, Guided Choice Maker.

The 5-step Neuro-Emotive Method (`cc-resonance/references/neuro-emotive-method.md`) governs HOW they layer: *layered but soft, psychological but ethical, never hypey.* Step 04 (Alignment) is the ethical gate and it doubles as the AHPRA gate - every message must create clarity, reduce fear, encourage autonomy, maintain integrity. Power stays with the lead.

## THE HOOK LAYER - draw from the bank, do not hand-write

Every SMS opener and email subject line pulls from the hook bank (`cc-hook/references/hook-templates.md`), filled with the clinic's concept and real proof from resonance-messaging.md. Do NOT invent hooks from scratch. The bank is weighted by stopping power: Curiosity (56%), Concern/Pain (39%), List (28%), Seasonal (20%), Authority (17%, real proof only), Deep Desire (14%), Question Open (strongest concern-led). Best hooks combine 2-4 templates. Which hook family suits which touch point is in the map below. *One exception: Touch Point 1's EMAIL subject is NOT a hook-bank pull - it is the possessive, treatment-specific ownership frame ("Your [treatment]"), because the lead already named the treatment they enquired about (see TP1).*

---

## BEFORE/AFTERS AND PROOF (email is the allowed surface)

This is a NURTURE EMAIL + SMS sequence, and email is a direct, opted-in channel - so the before & after beats at Touch Points 1 and 4 run in the emails. Because it is email (not public advertising), before/afters are fine here for BOTH skin treatments AND injectables - the public-marketing ban on injectable before/afters does not apply to direct email or to one-to-one after a consult. Conditions on all of them: patient consent, realistic and same-lighting, and never framed as a guaranteed result. The SMS carries no image; it points to the email ("I have sent through some before & after photos").

*Two hard limits:*
- Defer to the clinic's own `resonance-messaging.md` / `brand-guide.md` - some concern-led brands (e.g. Bonnie Lass) choose NO before/afters at all, and their boundary wins. Check the CLOSE-words list before using any.
- No patient testimonial that claims a treatment result (that is separate from a before/after image and stays out regardless).

Where a clinic opts out of before/afters, keep the emotional job of those beats (build Certainty through proof) with the AHPRA-safe stack instead: plain-language education, the clinician's area of special interest, an aggregate Google rating, a short clinic/process video, experience-of-care comments (name no treatment, claim no result), and the written personalised plan they leave with. Session counts framed generally ("your practitioner will explain what may suit you"), never as a guaranteed outcome.

---

## THE 5 TOUCH POINTS (fill each in the clinic voice)

Merge fields stay literal for GHL: `{{contact.first_name}}`, the clinic name, `{{booking_link}}`.
SMS keeps a warm, human, un-automated tone. A friendly emoji (e.g. 😊) is optional per the clinic's brand voice - keep if it fits them, drop if not.

### TOUCH POINT 1 - Immediately - SMS + Email
Stage: *Curiosity → Connection*.
Models: *Ownership Shift* + *Relevance Lock* (the subject line - the treatment is already theirs), *Empathy Echo* (reflect the felt experience), *Belonging Trigger* (one of them), *Curiosity Spark* (open loop), *Pain Diffuser* (foot-in-the-door = the reply), *Emotional Proof* (why it matters).
Hooks: *Question Open* + *Concern/Pain* (e.g. "What actually causes ___?", "If your skin feels ___, you are not imagining it").

*SMS - Purpose: start a conversation, never ask for the booking. Goes out WITH the email above.*
Name the specific treatment they enquired about, ask about their concerns (3-4 real options from `concerns.md`), then point them to the email you just sent (with the before/afters) - which doubles as a deliverability check. Sign off with the practitioner's real name, not the clinic.
Shape: "Hey {{contact.first_name}}, thanks for reaching out about our [treatment they enquired on]! Can you tell me more about your main concerns - for example, [3-4 real concern options]? Also, let me know if you have any trouble receiving the email I just sent with some before & afters. [Practitioner first name] xx, [clinic]"

*Email - the LOCKED first-email template.* This exact shape converts across every one of the examples (Confiderm/HIFU, Sculpted/EMSCULPT, Snatched/EvolveX). Purpose: make the treatment feel already theirs, then educate and reassure. Fill each beat in the clinic's voice, in this order:

1. *Subject - the signature move, and it is an OPEN-RATE DEVICE:* "Your [treatment] appointment" / "Your [treatment] session" - it reads as if they already have one, and that flicker of "wait, do I have an appointment?" is exactly what earns the open. It does NOT claim they have booked or secured anything - its ONLY job is to get the email opened. Name the exact treatment they enquired about ("Your skin-tightening appointment", "Your Pigmentation Restoration", "Your EMSCULPT session"), from `offers.md`, never generic. Fires *Ownership Shift* + *Relevance Lock*.
2. *Personal greeting* - "Hey {{contact.first_name}},".
3. *Warm acknowledgment of their ENQUIRY* (NOT a claim they booked): thank them for reaching out about this specific treatment - "Thanks for reaching out about our [treatment]", "Thank you for your interest in our [offer]", "I've received your request to try our [offer]". Honour the step they took. Never imply they have secured, won or booked anything - they have not; the subject line got the open, the body just meets them warmly where they actually are (an enquiry).
4. *The offer + its value* - what they get and what it is normally worth. AHPRA guardrail: state the offer, but do NOT stack a discounted price + code + countdown as an inducement to book fast ("only $199, save $101, code QUICK101, 20 vouchers, held 24 hours, once they're gone they're gone") - that is precisely the inducement AHPRA polices. Keep the value, drop the pressure-discount.
5. *Gentle, real scarcity* - a genuine limited number of consult spots is fine as pacing. Never a discount countdown.
6. *Clear CTA, early* - book / claim the appointment (prominent, button-style line), plus reply or call as the low-friction option.
7. *Before & afters* - 2-4 images are fine HERE (email, skin or injectables, consent, realistic) unless the clinic opts out. Frame them as *examples of what is possible*, never "the results you can expect" or "REAL results you'll get" (guaranteed-outcome framing - AHPRA).
8. *Education* - What is [treatment]? How does it work? What does it feel like? Answer the value/price objection head-on (why medical-grade differs, how it works). Concern-led, no outcome promises, no calorie/measurement claims as promises ("burn 500 calories", "20,000 sit-ups" = outcome claims - soften to what it may help with).
9. *Benefits* - the concern-led wins (a checklist works), framed as what it *may help with*, never guaranteed.
10. *Social proof, AHPRA-safe* - an experience-of-care comment ("clients say the space feels calm and unhurried") is fine; a patient testimonial that claims a treatment RESULT ("after 5 weeks I saw visible definition, it actually works") is NOT (AHPRA bans testimonials about regulated treatments). Swap for the safe proof stack where the clinic opts out.
11. *Warm, personal sign-off* - the practitioner's real name(s) ("Warmly, Ruby & Nicola"), clinic, phone. Signed by a person, never "the team".

### TOUCH POINT 2 - 24 hours later - SMS
Stage: *Connection → Trust*.
Models: *Desire Dial* (risk-reversal - "before recommending anything"), *Retention Resonator* (reduce choice fatigue - one clear action), *Clarity Charge* (make booking effortless), *Ownership Shift* (soft, no false urgency).
Hook: light - this one is friction-removal, lead with the ease not a hook.

*Purpose: remove friction.* People intend to book then get distracted. Make it effortless.
Shape: "Hi {{contact.first_name}} 😊 Just in case it is easier, here is the link to book your complimentary consult. {{booking_link}} We will assess your skin, explain your options and answer all your questions before recommending anything."

### TOUCH POINT 3 - 2 to 3 days later - Email (the "meet the team" connection email)
Stage: *Connection → Trust*.
Models: *Empathy Echo* + *Social Mirror* (the practitioners have lived what she is living), *Belonging Trigger* ("women just like you"), *Trust Anchor* + *Prestige Magnet* (real faces + TGA-approved machines), *Believability Bridge* (proof via Instagram, never a claim).
Hook: warm + relatable - "the faces behind your treatment", not a pain hook.

*Purpose: build connection and trust by introducing the humans.* This is the real second email. Shape:
- *Introduce the practitioners by name, with a real photo of them* - "meet [names], the faces behind your treatment". The team photo lives in this email.
- *Their relatable WHY (Empathy Echo)* - what they have personally lived that makes them care ("mums who get it - the sleepless nights, the body changes, not feeling like yourself"). Pull the clinic's REAL story from `resonance-messaging.md` / `team.md`; never invent a personal history.
- *The clinic's approach + the popular treatment* - what they specialise in, tailored "for women just like you", and a plain-language line on the treatment.
- *Benefits* - concern-led checklist (what it may help with), never guaranteed. Soften device claims (big contraction counts, "no pain", "safe for all skin types", "real results" are amber - reframe as what it may help with).
- *A real trust signal* - "TGA-approved machines" is a good, AHPRA-safe one; use it where true.
- *Social proof* - invite them to follow the clinic's Instagram to see transformations (points to proof; does not claim a result in the email).
- *Warm the next touch* - "[names] will give you a quick call today to chat about your goals" (sets up the phone call), or the book CTA if the clinic does not phone.
- Warm team or personal sign-off.

### TOUCH POINT 4 - 4 to 5 days later - SMS + Email
Stage: *Trust → Belief*.
Models: *Price Harmony* (claim then proof - before/afters in-email if the clinic uses them, else the AHPRA-safe stack: clinic video / rating / experience-of-care), *Believability Bridge* (the clinic's approach vs the burned-before experience, no character smear), *Social Mirror* (reflect her lived experience), *Emotional Proof* (paint the journey), *Clarity Charge* (help her picture herself in it).
Hooks: *Authority* (real proof only) + *List* ("3 things to know before your consult").

*SMS - Purpose: increase belief through PROOF.*
Point to the proof in the email - the original before & after photos (non-S4, consent, realistic), or the AHPRA-safe proof (clinic/process video, the practitioner's approach, experience-of-care comments) if the clinic opts out of before/afters.
Shape: "Hi {{contact.first_name}} 😊 I have just sent through some before & after photos so you can see what is possible. Everyone's skin is different, but hopefully it gives you a clearer picture. Any questions, just reply." (Swap the first line to "a few things about the consult and the experience" if the clinic does not use before/afters.)

*Email - the social-proof email (the real third email). Purpose: build belief through PROOF - the people, the place, the experience.*
- *Client voices - AHPRA-CRITICAL swap.* The real email leads with client testimonials. Patient testimonials that claim a treatment RESULT are BANNED for regulated clinics under National Law s133 - even in a direct email this is the most-enforced rule ("bladder leaks... I feel stronger", "such a big difference", "the treatments work"). So KEEP the human warmth, SWAP the result claims: use *experience-of-care* comments only - how welcome, comfortable and at-ease they felt, the people, the space ("Nicola and Ruby made me feel completely comfortable", "the clinic is beautiful", "so welcoming and knowledgeable"). Drop every line that claims the treatment worked or names a clinical result. If a clinic insists on full result-testimonials, that is THEIR documented decision against the rule - flag it, never auto-produce it.
- *The space* - the clinic environment, location, parking, the serene/beachfront setting, a Google Maps link, a real photo of the clinic.
- *A real trust signal* - "TGA-approved machines", the named treatments offered.
- *Warm the next touch* - "[names] will reach out today to discuss how we can support you", or the book CTA if the clinic does not phone.
- Warm team or personal sign-off.

### TOUCH POINT 5 - 7 days later - SMS
Stage: *Belief → Action*.
Models: *Guided Choice Maker* (give her the clear, low-pressure choice), *Empathy Echo* ("I don't want to keep bothering you"), *Trust-Through-Transparency* (honest "if now isn't the right time"), *Voiceprint Precision* (calm, no push).
Hook: *Beginner Friendly / soft* - no hook, just the human check-in.

*Purpose: permission to say no + a clean opt-out.* Removing pressure ironically increases replies. (The real final SMS.)
Shape: "Hi {{contact.first_name}}, we understand life gets busy and we don't want to intrude. If you're no longer interested, just let us know and we'll update our records. But if you're still considering our TGA-approved treatments ([the clinic's named treatments]), we're here - reply with any questions, or a day and time that suits for a consult. Warm regards, [Practitioner names], [clinic]."

---

## AFTER DAY 7 - HANDOFF

No booking by day 7 → move the lead into long-term monthly nurture. Do NOT rebuild that here - it is `/cc-follow-up-agent`'s job (educational value, client stories told AHPRA-safe, team intros, treatment FAQs, seasonal news). This sequence's job ends at the handoff. State the handoff in the delivery so the GHL workflow exits cleanly into the long-term campaign.

*Booked exit (critical):* the instant a lead books at ANY touch point, they must exit this sequence immediately (no "book now" texts after they have booked). The GHL workflow needs a booked/appointment trigger that removes them from the remaining steps.

---

## AHPRA GATE (screen every SMS and email before delivery)

- Concern-led, never claim-led. No promised outcomes ("years younger", "tighter skin guaranteed").
- Before/afters are fine in the EMAILS (skin or injectables - email is a direct channel; consent, realistic, never framed as a guaranteed result) unless the clinic opts out; never in the SMS body itself (it points to the email). No patient testimonial that claims a treatment result; no guaranteed outcomes.
- Superlatives - two tiers. HARD-BANNED: best, #1, most effective, painless, safe, risk-free, and expert/specialist unless the practitioner holds that registration (use "special interest in"). DISCRETIONARY, the clinic's call, not a breach: leading, top, expertise, premium, trusted, boutique - and "anti-ageing".
- Never the word "Botox" (use "anti-wrinkle"); no pricing on Schedule 4 treatments; no discount framed as an inducement.
- Complimentary consult is fine to name. Experience-of-care comments only (never treatment results).
- Australian English, no emdashes, italics not bold, never "it's not X, it's Y".

---

## OUTPUT SHAPE

A single review doc (`Ads/nurture/[offer-slug]-nurture.md`) containing, per touch point: the timing, channel, emotional stage, neuro-emotive driver(s), the finished copy (SMS and/or email, in the clinic voice with live merge fields), and a one-line AHPRA note. End the doc with the GHL build guide: the trigger (ad-enquiry tag from the landing-page form), the exact delays (0h, 24h, 2-3d, 4-5d, 7d), the booked-exit trigger, and the day-7 handoff into `/cc-follow-up-agent`.
