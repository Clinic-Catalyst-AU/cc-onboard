---
name: cc-nurture-sequence
description: Generate the high-converting 7-day ad-enquiry nurture sequence for an aesthetics clinic - the Curiosity-Connection-Trust-Belief-Action framework made AHPRA-safe. Five SMS + email touch points that catch a paid-ad lead the moment they enquire on the /cc-landing-page form but do not book, and walk them to a consult through conversation not pressure. Reads the clinic's voice from brand-guide.md, maps every message to its emotional stage and the neuro-emotive models, keeps before/afters in-email where the clinic uses them (AHPRA-safe proof otherwise) with clearly-marked photo placeholders, hands each finished message over ONE AT A TIME as clean copy-paste blocks the clinic pastes straight into their GHL paid-ad nurture, and hands off to /cc-follow-up-agent at day 7. Use when you say nurture sequence, ad nurture, lead nurture sequence, follow-up sequence for ads, after-ads nurture, enquiry sequence, SMS nurture, 7-day nurture, or the sequence that runs after the ad. Companion to /cc-landing-page and /cc-thankyou-page.
---

# CC NURTURE SEQUENCE - The 7-Day Ad-Enquiry Rescue

Generates the SMS + email nurture that turns a paid-ad enquiry into a booked consult. This is the fourth piece of the paid-ad flow: *ad → `/cc-landing-page` (offer page) → `/cc-thankyou-page` (confirmation) → THIS (nurture the ones who enquired but did not book)*. It is built on a high-converting nurture framework, made AHPRA-safe for a regulated clinic.

The whole thing runs on one principle: people do not buy aesthetic treatments because they need more information - they buy when they feel understood, safe and confident. So the sequence is *Conversation → Education → Social Proof → Consultation → Booking*, never "book now" in every message.

*Boundary vs `/cc-follow-up-agent`* - that skill is the always-on engine (7-email ladder, newsletter, win-back) for the whole database. THIS skill is the tight, SMS-led, 7-day rescue for a fresh paid-ad enquiry, and it HANDS OFF to `/cc-follow-up-agent` at day 7. Do not rebuild the long-term nurture here.

*File contract* - follows the Business Brain File Contract (your workspace `CLAUDE.md`). READS the clinic's voice, concerns, offer and proof from `Business-Brain/brand-guide.md`, `resonance-messaging.md`, `concerns.md`, `offers.md`. WRITES the sequence to `Ads/nurture/[offer-slug]-nurture.md` in the clinic workspace. Does NOT write into `Business-Brain/`. All paths relative to `~/Clinic/` - never hardcode absolute paths. If `brand-guide.md` is missing, stop and offer `/cc-brand-guide`; never fabricate the clinic's voice.

*Prerequisite* - pairs with a live `/cc-landing-page` offer page (the sequence assumes the ad-enquiry tag and the `{{booking_link}}` come from that page's form). If there is no brand guide, run `/cc-resonance` then `/cc-brand-guide` first.

---


*GHL access* - BEFORE any GHL call, read the clinic's Private Integration token + Location ID from `Credentials/credentials-reference.txt`. They are already in there - the clinic created that file during setup and their CLAUDE.md points at it. Use them and push. Only if a value is genuinely blank, ask for it and save it. Full contract, scope list and failure handling: `../cc-reeltalkinghead/references/ghl-credentials.md`.

## HOW TO USE

```
/cc-nurture-sequence [offer name]
```

---

## NEURO-EMOTIVE WIRING (mandatory - this is what makes the sequence land, not read like any clinic)

Run the shared engine before writing a line: `cc-resonance/references/neuro-emotive-engine.md` (installed alongside this skill). In short:
1. READ `Business-Brain/resonance-messaging.md` - the emotional stack, the arc, the OPEN/CLOSE language bank, the headline angles, the proof map - as well as `brand-guide.md`. This IS the spine of the sequence; never generate off the brand-guide alone.
2. APPLY the 21 neuro-emotive models (`cc-resonance/references/model-library.md`) along the arc: TP1 Ownership Shift + Relevance Lock (the "Your [treatment]" open-device subject) + Empathy Echo + Belonging Trigger + Curiosity Spark; TP2 Desire Dial + Retention Resonator + Ownership Shift (soft); TP3 Empathy Echo + Social Mirror + Belonging Trigger + Trust Anchor (meet-the-team connection); TP4 Believability Bridge + Social Mirror + Emotional Proof (experience-of-care proof, never result-testimonials); TP5 Guided Choice Maker + Empathy Echo + Trust-Through-Transparency. Voiceprint Precision on every message. Full per-touchpoint map in `references/sequence-map.md`.
3. GROUND every message in the clinic's real offer + their OPEN language bank. You should be able to point at any SMS or email and name the model firing AND the OPEN word it used. A generic sequence that ignores the resonance doc is a FAILED run - regenerate.

## BEFORE/AFTERS - READ THIS FIRST

The framework sends *before & after images* at Touch Points 1 and 4, and they run in the emails. Because this is a NURTURE EMAIL sequence (direct, opted-in - not public ad creative), before/afters are fine here for BOTH skin treatments AND injectables: the public-marketing ban on injectable before/afters does not apply to direct email or to one-to-one after a consult. Conditions on all of them: patient consent, realistic and same-lighting, never framed as a guaranteed result. The image lives in the email, never in the SMS body (the SMS points to it). The skill NEVER inserts a real image - it drops a clearly-marked placeholder slot the clinic fills with their own consented photo in GHL (see build step 5).

Two limits that always hold: (1) the clinic's own `resonance-messaging.md` / `brand-guide.md` boundary wins - some concern-led brands (e.g. Bonnie Lass, whose CLOSE list bans them) use NO before/afters at all, and you must respect that; (2) never a patient testimonial that claims a treatment result. Where a clinic opts out, keep the emotional job of those beats with the AHPRA-safe proof stack (education, area of special interest, aggregate rating, clinic/process video, experience-of-care comments, the written plan). Full before/after rule (by treatment type and surface) is in `cc-resonance/references/neuro-emotive-engine.md`; touch-point spec in `references/sequence-map.md`.

---

## BUILD STEPS

1. Read `references/sequence-map.md` in full - the locked 7-day map, the neuro-emotive layer, the before/afters-and-proof guidance, and the per-touch-point copy spec.
2. Read the clinic's `brand-guide.md` (+ `resonance-messaging.md`, `concerns.md`, `offers.md`). Pull: the voice, the real concern words for the Touch Point 1 options, the offer/consult framing, and which AHPRA-safe proof the clinic actually has (rating + count, years, special interest, clinic video, experience-of-care comments). If the clinic has none of the proof elements, say so and use education + reassurance only - never invent a rating, a review count or a comment.
3. Confirm the two inputs the sequence needs to be live: the *ad-enquiry trigger tag* (from the landing-page form) and the *{{booking_link}}* (their GHL consult calendar/booking link). Ask if not known; never guess a link.
4. Generate every touch point in the clinic's voice, filling the map (the real, proven templates - the full copy spec is in `references/sequence-map.md`):
   - *TP1 immediate:* EMAIL (the LOCKED first-email template - "Your [treatment]" open-device subject, warm acknowledgment of the ENQUIRY, offer + value, before/after placeholder, education, benefits, AHPRA-safe proof, personal sign-off) + SMS (concerns question with 3-4 real options, points to the email).
   - *TP2 24h:* SMS (remove friction, the booking link) - keep only if the clinic's sequence uses it.
   - *TP3 2-3 days:* EMAIL - the "meet the team" connection email (practitioners introduced + team-photo placeholder, their relatable why, the treatment, TGA-approved trust signal, Instagram, warms the call).
   - *TP4 4-5 days:* EMAIL - the social-proof email (experience-of-care comments, NEVER result-testimonials; clinic-photo placeholder, location/Maps, TGA-approved) + SMS (points to the proof).
   - *TP5 7 days:* SMS (permission to say no + a clean opt-out).
   Keep merge fields literal: `{{contact.first_name}}`, clinic name, `{{booking_link}}`. Emoji in SMS only if it suits the clinic.
5. *Insert image PLACEHOLDERS where a photo goes* - never a real image, always a clearly-marked slot the clinic drops their own photo into, on its own line, in this exact unmissable form:
   `[ INSERT BEFORE & AFTER PHOTOS HERE - 2 to 4, patient consent, realistic, same lighting ]` (TP1 email),
   `[ INSERT YOUR TEAM PHOTO HERE ]` (TP3 email), `[ INSERT YOUR CLINIC PHOTO HERE ]` (TP4 email).
   If the clinic opts out of before/afters, drop that slot and use the AHPRA-safe proof stack instead.
6. Chain every draft through `/cc-marketing-genius` (sharpen copy + CTA) and `/stoptheslop` (strip AI tells), then run the hard AHPRA gate on every message. Default AHPRA swaps - keep these unless the clinic documents a decision otherwise: result-testimonials → experience-of-care comments; a discount + countdown inducement → the offer stated plainly + genuine spot-based scarcity; guaranteed-result framing → "examples of what is possible". Fix or cut any line that cannot be made compliant, and say why.
7. Save the full record to `Ads/nurture/[offer-slug]-nurture.md` - every message with its stage, driver(s), a one-line AHPRA note, and its image slot(s). This is the archive; the one-at-a-time delivery below is how the clinic actually loads it.
8. End the file with the GHL BUILD GUIDE: *Trigger* (ad-enquiry tag from the landing-page form); *Delays* 0h → 24h → 2-3d → 4-5d → 7d; *Booked exit* (appointment-booked trigger that removes the lead from all remaining steps the instant they book); *Day-7 handoff* into `/cc-follow-up-agent`.

---

## DELIVERY - ONE MESSAGE AT A TIME (this is the point of the skill)

The clinic pastes each message straight into their GHL paid-ad nurture workflow. Do NOT dump all the messages at once. Once the file is saved, hand them over ONE AT A TIME, each as a clean, paste-ready block:

- Show ONE message. Header line, in plain text ABOVE the copy: `MESSAGE [n] of [total] - [Touch Point, timing] - [EMAIL or SMS]`.
- EMAIL: a `SUBJECT:` line, then a blank line, then the body copy exactly as it should paste - merge fields literal, image placeholder on its own line, personal sign-off. Nothing else inside the block (no commentary in the copy).
- SMS: just the message text, paste-clean.
- Under the block, in plain text OUTSIDE the copy, one line: where it goes in GHL (which step, the delay, email vs SMS).
- Then STOP and say: "Copy this into GHL, then tell me *next* when you're ready for the following message." WAIT for the user.
- On *next* (or *done* / *go*), show the next message the same way. Continue until all are delivered.
- After the last message, show the GHL BUILD GUIDE (trigger, delays, booked-exit, day-7 handoff) so they wire the timing.

Each block must be genuinely paste-ready: the clinic selects it, copies, and pastes into the GHL email/SMS body with zero cleanup. Keep the image placeholder IN the pasted copy so they see exactly where to attach their photo in GHL. Before delivering message 1, offer the quick approval: "I'll hand these over one at a time so you can paste each into GHL. Want to skim the whole sequence in the file first, or go straight into pasting?"

---

## RULES

- ALWAYS read `brand-guide.md` before writing. If missing, run `/cc-brand-guide` first. Never fabricate the clinic's voice, rating, review count or comments.
- NEVER reintroduce treatment testimonials or guaranteed outcomes - use the AHPRA-safe proof swap, always. Before/afters go in the EMAILS as a placeholder slot (never a real image the skill inserts), unless the clinic opts out.
- ALWAYS deliver the messages ONE AT A TIME as paste-ready blocks (see DELIVERY) - never dump the whole sequence into the chat at once. The clinic pastes each straight into GHL, then says *next*.
- NEVER ask for the booking in every message. Conversation and education come before the CTA. One simple action per message - never multiple CTAs.
- ALWAYS include the booked-exit trigger in the GHL guide - a lead who books must leave the sequence immediately.
- ALWAYS hand off to `/cc-follow-up-agent` at day 7 - do not rebuild long-term nurture here.
- NEVER use emdashes; Australian English; italics not bold; never "it's not X, it's Y". Run every message back through the AHPRA gate before handing over.
- Keep merge fields literal for GHL. Emoji in SMS only, and only if it suits the clinic's voice.
- The finished-sequence test: does each message make the lead feel understood and safe rather than chased, does it move them exactly one emotional stage, and would every line survive an AHPRA review? If any answer is no, it is not done.

Pairs with `/cc-landing-page` and `/cc-thankyou-page` (the pages that feed it), `/cc-marketing-genius` and `/stoptheslop` (the copy passes), and hands off to `/cc-follow-up-agent` (long-term nurture).
