---
name: cc-fb-leadform
description: Build the copy for a Facebook / Instagram Lead Form (Instant Form) for an aesthetics clinic - the form headline, intro description, qualifying questions, privacy line and completion screen - written in a high-converting style (the headline calls out the PROBLEM together WITH the OFFER, value-stacked, AHPRA-safe). Reads the clinic's Business Brain + the 21 neuro-emotive models. The lead-form counterpart to /cc-metaad-builder (feed ads), and its submissions feed /cc-nurture-sequence. Use when you say lead form, facebook lead form, fb lead form, instant form, meta lead form, lead gen form, on-facebook form, in-app form, or the form the ad opens.
---

# CC Facebook Lead Form Builder

Writes the copy for a Meta Instant (Lead) Form - the in-app form that opens when someone taps a lead-gen ad, capturing the lead WITHOUT a landing page. These are written a specific way: the headline calls out the problem together with the offer, the body is value-stacked, and every line is AHPRA-safe. This is the lead-form counterpart to `/cc-metaad-builder` (which writes the feed ad that opens the form).

*Where it sits in the paid pipeline:* ad (`/cc-metaad-builder`) -> THIS lead form (captures the enquiry) -> `/cc-nurture-sequence` (the 5-point ad-enquiry nurture fires on submit) -> booking. A lead form is the alternative to a landing page (`/cc-landing-page`) when the clinic wants the capture to happen inside Facebook/Instagram.

*File contract* - follows the Business Brain File Contract (your workspace `CLAUDE.md`). READS `Business-Brain/resonance-messaging.md` (the emotional source of truth) + `Business-Brain/brand-guide.md` (voice) + `Business-Brain/offers.md` (the offer + value stack) + `Business-Brain/services-machines.md` (treatments, and which are Schedule 4). WRITES to `Ads/lead-forms/[offer-slug]-leadform.md`. All paths relative to `~/Clinic/`. If `brand-guide.md` is missing, offer `/cc-brand-guide`; never fabricate.


*GHL access* - BEFORE any GHL call, read the clinic's Private Integration token + Location ID from `Credentials/credentials-reference.txt`. They are already in there - the clinic created that file during setup and their CLAUDE.md points at it. Use them and push. Only if a value is genuinely blank, ask for it and save it. Full contract, scope list and failure handling: `../cc-reeltalkinghead/references/ghl-credentials.md`.

## NEURO-EMOTIVE WIRING (mandatory - this is what makes the form land, not read like any clinic)

Run the shared engine before writing a line: `cc-resonance/references/neuro-emotive-engine.md` (installed alongside this skill). In short:
1. READ `Business-Brain/resonance-messaging.md` - the emotional stack, the arc, the OPEN/CLOSE language bank, the headline angles, the proof map - as well as `brand-guide.md`. If `resonance-messaging.md` is missing, offer `/cc-resonance`; never generate off the brand-guide alone.
2. APPLY the 21 neuro-emotive models (`cc-resonance/references/model-library.md`): headline = Desire Dial + Ownership Shift (the offer); intro = Empathy Echo + Emotional Proof + Pain Diffuser; value stack = Price Harmony (stacked value makes the price believable); completion = Guided Choice Maker + Voiceprint Precision.
3. GROUND every line in the clinic's real offer + their OPEN language bank. Generic form copy that ignores the resonance doc is a FAILED run - regenerate.

## STYLE - read the ad exemplars first

Read `cc-metaad-builder/references/perfect-ad-examples.md` (installed alongside) BEFORE writing. It carries the AD ANATOMY, top-performing exemplars, the HEADLINE FORMULA and VALUE STACKING - the lead form uses the same two techniques:
- *Headline formula:* call out the PROBLEM together WITH the OFFER. E.g. "Claim Your Non-Surgical Face Lift (Save 50%!)", "Say Goodbye to Sagging Skin - $150 (normally $300)".
- *Value stacking:* list the offer's REAL inclusions as a 🔥/✔ stack so the price feels like a bargain, then the price with a true anchor ("Normally $300, now $150").

## THE LEAD FORM ANATOMY (fill each field - this is what Meta's Instant Form gives you)

1. *Form headline* (short, the top of the form) - the formula: the concern/outcome + the offer. This is the single most important line.
2. *Intro description* (the paragraph under the headline) - the offer in the clinic's voice: a one-line mechanism in plain language, then the VALUE STACK (🔥 inclusions), then the price + anchor. Keep it scannable.
3. *Questions* - keep it MINIMAL for volume: Meta pre-fills name, email, phone; add at most 1-2 qualifying questions drawn from the clinic (e.g. "Which concern brings you in?" with 3-4 real options from `concerns.md`; or "Preferred time?"). More questions = fewer, higher-intent leads; fewer = more volume. Recommend based on the offer, and say which you chose and why.
4. *Privacy line* - a short consent sentence pointing to the clinic's privacy policy (they paste their URL). Do not invent a URL.
5. *Completion screen* - the "thank you" the lead sees after submitting: a warm headline ("You're in - we'll be in touch"), one line on what happens next and when (must be TRUE - matches the nurture's TP1), and the CTA button + link (usually "Book now" -> the GHL booking link, or "Call us").

## AHPRA gate (screen EVERY line)

- Concern-led, never claim-led. No guaranteed outcomes. Frame results as what the treatment is designed to help with, never a promise.
- *Banned safety claims:* "No Risk", "safe", "painless", "risk-free", "No Scars" as a promise. Swap for "non-invasive", "minimal downtime", "comfortable". (The raw exemplars use "No Risk / No Scars" - do NOT carry those across; that is the compliance line.)
- Superlatives - two tiers. HARD-BANNED: best, #1, most effective, safe, painless, risk-free, and expert/specialist unless the practitioner holds that registration ("has a special interest in"). DISCRETIONARY, the clinic's call, not a breach: leading, top, expertise, premium, trusted, boutique - and "anti-ageing". No "Botox" / Schedule 4 product names. No pricing on Schedule 4 treatments - the value-stacked price is for non-S4 offers only. No before/after promise in the copy; no patient testimonial claiming a result.
- Australian English, no emdashes, italics not bold, never "it's not X, it's Y".

## Output + workflow

1. Read the Business Brain + the ad exemplars + the engine.
2. Confirm the offer (from `offers.md`) and the booking link (the completion CTA target). Ask if unknown; never guess a link.
3. Write all five fields (headline, intro + value stack, questions, privacy line, completion screen), grounded in the offer + language bank + models, value-stacked, AHPRA-screened.
4. Save ONE file: `Ads/lead-forms/[offer-slug]-leadform.md`.
5. SHOW it (never just a path) and run the APPROVAL GATE - edit the same file until they approve.
6. On approval, walk them through building it in Meta: Ads Manager > Instant Forms > create > paste each field. Tell them to point the lead-form ad at THIS form, and to wire the form's submissions to the ad-enquiry tag that triggers `/cc-nurture-sequence`.

## RULES

- ALWAYS read `brand-guide.md` + `resonance-messaging.md` first. Never fabricate the voice, the offer, inclusions, a rating, or a URL.
- ALWAYS use the headline formula (problem + offer) and value stacking (real inclusions only).
- NEVER carry across "No Risk / No Scars / painless / safe" - swap for compliant framing. Run every field through the AHPRA gate.
- ALWAYS keep the completion-screen "what happens next" TRUE and matched to the nurture's first touch.
- Pairs with `/cc-metaad-builder` (the ad that opens the form), `/cc-nurture-sequence` (fires on submit) and `/cc-resonance` (the emotional foundation).
