#!/usr/bin/env python3
"""
Clinic carousel renderer - renders the slides cc-carousel writes, in the
CLINIC's OWN branding. Dumb renderer: the skill supplies copy + brand params.

Usage:  python3 render_carousel.py < spec.json
Spec:
{
  "slug": "menopause-skin",
  "out_dir": "~/Clinic/Content/carousels/menopause-skin",
  "accent_hex": "#C5A445",              (or omit -> brand-assets/accent.txt -> neutral)
  "brand_dir": "~/Clinic/Business-Brain",
  "slides": [
    {"type": "hook",  "eyebrow": "MENOPAUSE SKIN", "headline": "Your skin changed.|Nobody warned you.", "body": ""},
    {"type": "teach", "eyebrow": "WHY", "headline": "Oestrogen drops,|collagen follows", "body": "Up to 30% of collagen goes in the first five years."},
    {"type": "photo", "photo": "/path/clinic-photo.jpg", "headline": "Looked at properly", "body": "45 minutes with our nurse. A plan, not a product push."},
    {"type": "cta",   "headline": "Ready to understand|your skin?", "body": "Book your skin assessment", "sub": "link in bio"}
  ]
}
Design rules honoured: photo zone and text zone NEVER share space; headline font
from brand-assets/headline-font.ttf; accent from the brain; no agency branding.
"""
import json
import os
import sys

from PIL import Image, ImageDraw, ImageFont, ImageOps

W, H = 1080, 1350
WHITE = (255, 255, 255)

BOLD_CANDIDATES = [
    os.path.expanduser("~/Library/Fonts/Montserrat-ExtraBold.ttf"),
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/System/Library/Fonts/HelveticaNeue.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
]
REG_CANDIDATES = [
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "/System/Library/Fonts/HelveticaNeue.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]


def hex_rgb(h, fallback=(61, 189, 179)):
    h = (h or "").strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    except ValueError:
        return fallback


def tint(rgb, factor):
    return tuple(int(round(c + (255 - c) * factor)) for c in rgb)


def shade(rgb, factor):
    return tuple(int(round(c * (1 - factor))) for c in rgb)


def load_font(pref, size, candidates):
    for p in ([pref] if pref else []) + candidates:
        if p and os.path.isfile(p):
            try:
                return ImageFont.truetype(p, size)
            except (IOError, OSError):
                continue
    return ImageFont.load_default()


def wrap(draw, text, f, max_w):
    words, lines, buf = text.split(), [], []
    for w in words:
        if draw.textbbox((0, 0), " ".join(buf + [w]), font=f)[2] > max_w and buf:
            lines.append(" ".join(buf)); buf = [w]
        else:
            buf.append(w)
    if buf:
        lines.append(" ".join(buf))
    return lines


def headline_lines(text):
    return [l.strip() for l in text.split("|") if l.strip()]


def fit_headline(draw, lines, font_path, start_size, max_w):
    size = start_size
    f = load_font(font_path, size, BOLD_CANDIDATES)
    longest = max(draw.textbbox((0, 0), l, font=f)[2] for l in lines)
    if longest > max_w:
        size = max(40, int(size * max_w / longest))
        f = load_font(font_path, size, BOLD_CANDIDATES)
    return f, size


def crop_to(img, w, h):
    img = ImageOps.exif_transpose(img.convert("RGB"))
    ratio, ir = w / h, img.width / img.height
    if ir > ratio:
        nw = int(img.height * ratio); left = (img.width - nw) // 2
        img = img.crop((left, 0, left + nw, img.height))
    else:
        nh = int(img.width / ratio)
        img = img.crop((0, 0, img.width, nh))  # centre-top bias per design rules
    return img.resize((w, h), Image.LANCZOS)


def draw_dots(draw, idx, total, accent, y):
    r, gap = 7, 26
    x0 = (W - (total - 1) * gap) // 2
    for i in range(total):
        c = accent if i == idx else tint(accent, 0.75)
        x = x0 + i * gap
        draw.ellipse((x - r, y - r, x + r, y + r), fill=c)


def render_slide(s, idx, total, accent, ink, fonts, logo, out_path):
    hp, bp = fonts
    is_cta = s.get("type") == "cta"
    photo = s.get("photo")

    if is_cta:
        canvas = Image.new("RGB", (W, H), accent)
        draw = ImageDraw.Draw(canvas)
        text_col, acc_col = WHITE, WHITE
        text_top = int(H * 0.30)
    elif photo and os.path.isfile(os.path.expanduser(photo)):
        canvas = Image.new("RGB", (W, H), tint(accent, 0.92))
        ph = int(H * 0.55)
        canvas.paste(crop_to(Image.open(os.path.expanduser(photo)), W, ph), (0, 0))
        draw = ImageDraw.Draw(canvas)
        draw.rectangle((0, ph, W, ph + 10), fill=accent)
        text_col, acc_col = ink, shade(accent, 0.15)
        text_top = ph + 60
    else:
        canvas = Image.new("RGB", (W, H), tint(accent, 0.92))
        draw = ImageDraw.Draw(canvas)
        draw.rectangle((0, 0, 26, H), fill=accent)
        text_col, acc_col = ink, shade(accent, 0.15)
        text_top = int(H * 0.24)

    pad = 90
    max_w = W - pad * 2
    y = text_top

    if s.get("eyebrow") and not is_cta:
        f_eye = load_font(bp, 34, REG_CANDIDATES)
        draw.text((pad, y), s["eyebrow"].upper(), fill=acc_col, font=f_eye)
        y += 70

    lines = headline_lines(s.get("headline", ""))
    if lines:
        fh, size = fit_headline(draw, lines, hp, 92 if not photo else 72, max_w)
        for line in lines:
            draw.text((pad, y), line, fill=text_col, font=fh)
            bb = draw.textbbox((0, 0), line, font=fh)
            y += (bb[3] - bb[1]) + 26

    if s.get("body"):
        y += 26
        f_body = load_font(bp, 44 if is_cta else 40, REG_CANDIDATES)
        for line in wrap(draw, s["body"], f_body, max_w):
            draw.text((pad, y), line, fill=text_col, font=f_body)
            bb = draw.textbbox((0, 0), line, font=f_body)
            y += (bb[3] - bb[1]) + 16

    if is_cta and s.get("sub"):
        y += 30
        f_sub = load_font(bp, 34, REG_CANDIDATES)
        draw.text((pad, y), s["sub"], fill=tint(accent, 0.7), font=f_sub)

    if is_cta and logo and os.path.isfile(logo):
        try:
            lg = Image.open(logo).convert("RGBA")
            tw = 220
            lg = lg.resize((tw, int(lg.height * tw / lg.width)), Image.LANCZOS)
            canvas.paste(lg, ((W - tw) // 2, H - lg.height - 90), lg)
        except Exception as e:
            print(f"  (logo skipped: {e})")

    draw_dots(ImageDraw.Draw(canvas), idx, total, WHITE if is_cta else accent, H - 48)
    canvas.save(out_path, "PNG", quality=95)
    print(f"slide {idx + 1}/{total}: {out_path}")


def main():
    spec = json.load(sys.stdin)
    brand = os.path.expanduser(spec.get("brand_dir", "~/Clinic/Business-Brain"))
    assets = os.path.join(brand, "brand-assets")
    accent_hex = spec.get("accent_hex")
    if not accent_hex:
        ac = os.path.join(assets, "accent.txt")
        accent_hex = open(ac).read().strip() if os.path.isfile(ac) else ""
    accent = hex_rgb(accent_hex)
    ink = hex_rgb(spec.get("ink_hex"), fallback=(35, 42, 40))
    hp = os.path.join(assets, "headline-font.ttf")
    bp = os.path.join(assets, "body-font.ttf")
    fonts = (hp if os.path.isfile(hp) else "", bp if os.path.isfile(bp) else "")
    logo = os.path.join(assets, "logo.png")
    logo = logo if os.path.isfile(logo) else ""

    out_dir = os.path.expanduser(spec["out_dir"])
    os.makedirs(out_dir, exist_ok=True)
    slides = spec["slides"]
    for i, s in enumerate(slides):
        render_slide(s, i, len(slides), accent, ink, fonts, logo,
                     os.path.join(out_dir, f"{spec.get('slug','carousel')}-{i+1:02d}.png"))
    print(f"done: {len(slides)} slides -> {out_dir}")


if __name__ == "__main__":
    main()
