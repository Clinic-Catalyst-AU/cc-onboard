# Carousel design rules - clinic-clean

This skill produces the slide copy and the per-slide design direction. It does not render the final images - that is a separate generation step. These rules are what the design direction must honour so the carousel is phone-readable and unmistakably the clinic's brand.

The brand itself - colours, fonts, voice - is never hardcoded here. It is read from the clinic's `Business-Brain/brand-guide.md` every time. Read that guide literally: if it names a number of colours, use that many; if it says avoid a colour, avoid it; use exactly the two fonts it specifies.

---

## Read the brand from the guide (not from this file)

Before writing any design direction, pull from `brand-guide.md`:
- *Palette* - the clinic's colours. Use only these. Pick one as the dark/background lead, one as the accent, one as the light/text where the guide allows.
- *Fonts* - exactly the two fonts named (one heading, one body). Two sizes only (one big, one medium). No third font for "accents" or "badges".
- *Voice* - words-we-use, words-we-avoid, tone. The copy on every slide inherits this.

If the clinic has a live website, a quick look confirms the fonts and colours render as the guide says. The carousel should look like it came off the clinic's own feed.

---

## Text size and readability

The carousel lives on a phone in a moving feed. If it cannot be read at a glance while scrolling, it is too small. These are minimums on a 1080px-wide canvas - scale up proportionally for taller formats (a 1080x1350 portrait or a 1080x1920 story needs larger text than a 1080x1080 square).

| Element | Minimum | Why |
|---------|---------|-----|
| Headline | 64px | Must stop the scroll, readable with a thumb over half the screen. |
| Body / list item | 38px | Readable at speed. Many clinic clients are 35-60+ - design for reduced vision. Prefer 42px+. |
| Subtext / fine print | 30px | The smallest text allowed anywhere. |
| Eyebrow / badge | 16px | Allowed smaller only inside a pill - the container draws the eye. |
| Brand mark | 15px | Recognised, not read. |

The test: view the slide at 40% zoom. If you cannot read every word, bump the size.

*Two fonts, two sizes.* One heading font, one body font (both from the brand guide). One big size, one medium. No third font, no third size.

*Contrast.* Body text is always the brand's light colour on a dark background, or its dark colour on a light background - whichever the guide specifies. Accent colours are for headlines and single emphasis words only, never for paragraph or list text. If text does not separate from the background at a glance, the contrast is too low.

---

## Padding and spacing

- *Edge padding* - 80px minimum from every edge. Text near the edge looks amateur and gets cropped on some platforms.
- *Between sections* - clear separation between the headline zone, the body zone, and any CTA zone.
- *List items* - each item gets its own row with real space between. Cramped lists are unreadable. If a list is getting tight, split the slide.

Less is more. Fewer words per slide, generous white space. White space is a feature, not wasted room. If a slide feels crowded, add a slide rather than shrink the text.

---

## Separate zones (photo vs text)

The photo zone and the text zone never compete. Two valid approaches:
- *Split* - photo on one side, text on the other, with a clean fade between.
- *Full bleed with a readable panel* - photo fills the slide and a brand-coloured semi-transparent panel sits behind the text so it stays readable.

Never put text directly over a busy photo without a panel. Even a subtle overlay is not enough.

---

## Photos

- *Use the clinic's own photography only* - the room, the team, on-brand textures the clinic supplied. Never random stock, never another clinic's images, never invented imagery. If no photo is supplied, the design direction calls for a brand-coloured textured background instead of a photo.
- *Never before/after imagery* - it is an AHPRA hard fail. No before/after, ever (see `ahpra-gate.md`).
- *Faces stay fully visible* - if a photo has a person, anchor the crop to the top so the face is not cut, and keep text away from the face.
- *No flat colour blocks as backgrounds* - a subtle brand-coloured texture reads premium; a flat fill reads like a quick template.

---

## Backgrounds when there is no photo

When a slide has no clinic photo, the design direction specifies a brand-coloured textured background (the clinic's dark colour with a soft, subtle texture - not a flat fill). Keep it subtle so the text leads. The image generation step builds it; this skill only describes it. Always describe the *effect* wanted (e.g. "soft warm texture in the clinic's deep [colour], no busy detail behind the text"), not hardcoded prompts.

---

## What the per-slide design direction must include

For each slide, the direction names: the slide type, the exact copy (eyebrow / headline / body / CTA), the layout intent (text placement, photo zone vs text zone), which brand colour leads, and the image brief (a supplied clinic photo, or a brand-coloured texture - never stock, never before/after). Keep it short - enough for the image step or a designer to build cleanly.
