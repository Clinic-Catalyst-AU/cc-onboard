# Slide templates - the carousel building blocks

A carousel is a small story told across slides. Pick the pillar first (the SKILL maps the pillars), then choose a flow below, then fill the slide types. Each slide type has a layout intent and a copy schema. This skill writes the copy and the design direction - it does not render the image.

Australian English throughout. No emdashes (hyphens with spaces). Italics not bold. Everything concern-led, never claim-led. Screen every slide against `ahpra-gate.md`.

---

## Recommended flows per pillar

*Educate (the most common carousel)* - 6 slides
1. Hook - 2. The concern - 3. Why it happens - 4. What helps (plain language) - 5. What to expect - 6. Soft CTA

*Educate - tips variant* - 6 slides
1. Hook - 2. Tip 1 - 3. Tip 2 - 4. Tip 3 - 5. The why behind them - 6. Soft CTA

*Connect (meet the team / values)* - 6 slides
1. Hook - 2. Who we are - 3. Our standards - 4. Why we do this - 5. A real, verifiable credential (fact, not a boast) - 6. Soft CTA

*Proof (what-to-expect only - never before/after)* - 5-6 slides
1. Hook - 2-4. The honest steps (consult, appointment, recovery, realistic timeline) - 5. Our experience as fact - 6. Soft CTA

*Offer (rare - earn it with value first)* - 5 slides
1. Hook (useful, concern-led) - 2. The concern it answers - 3. What the offer includes - 4. What to expect - 5. CTA (clear booking invite)

Adapt slide count to the content. If a slide gets crowded, split it rather than shrink the text.

---

## Slide types

### HOOK (slide 1 of every carousel)
The scroll-stopper. One concern-led line that promises what they will learn. Highest creative effort. Never a claim or a promise of a result - a promise of *useful information*.

Layout intent:
- Clinic brand mark, small, top.
- Optional eyebrow (small uppercase) - the topic or pillar cue.
- 2-3 line headline, large, the clinic's heading font - the concern, in their voice.
- One short emphasis line (italic, the brand's accent colour) - optional.
- Optional one-line subtext promising the swipe payoff ("here is what actually helps").

Copy schema:
```
type: hook
eyebrow: "WINTER SKIN"            (optional)
headline: ["Why your skin feels", "tight every winter"]
accent_line: "and what actually helps."   (optional, italic)
subtext: "Swipe for the simple fix."       (optional)
```

### CONCERN (the honest mirror)
Name what the client is experiencing, in their language, without alarm. Builds the "they get me" trust.

Layout intent: heading + a short list of felt symptoms (3-4), or a single empathetic paragraph. List set flush-left within a centred block.

```
type: concern
heading: "Sound familiar?"
items: ["Tight after cleansing", "Flaky patches by midday", "Make-up not sitting right"]
```

### EXPLAIN (why it happens)
The plain-language reason. This is where credibility is built - clear, calm, true. No jargon dumps.

```
type: explain
heading: "What's going on"
body: "Cold air and indoor heating pull moisture from the skin barrier faster than it rebuilds."
```

### WHAT-HELPS (the approach or treatment, plain language)
Describe the approach or treatment in plain language. What it does, who it suits, in the clinic's words. NO outcome promise. NO Schedule 4 pricing or dosing. If it is a regulated treatment, describe the process, not the result.

```
type: what_helps
heading: "What helps"
items: ["A barrier-supporting routine", "An in-clinic hydration focus", "A consult to match it to your skin"]
note: "No outcome claims. Describe the approach, not a guaranteed result."
```

### TIP (for the tips-variant Educate carousel)
One useful, self-contained tip per slide. Numbered. Practical and true.

```
type: tip
number: 1
heading: "Switch to a cream cleanser"
body: "Foaming cleansers can strip an already-dry barrier in winter."
```

### STEPS / WHAT-TO-EXPECT (the Proof-safe pillar)
The honest, step-by-step of a treatment or process. Setting real expectations reads as confidence and is AHPRA-safe. This is how Proof carousels prove competence WITHOUT before/after or testimonials.

```
type: steps
heading: "What to expect from a peel"
steps: ["A consult to check your skin suits it", "The treatment - around 30 minutes", "Some redness for a day or two", "A realistic timeline we talk through honestly"]
```

### CONNECT / TEAM (Connect pillar)
The people, the standards, the why. Real names and credentials ONLY if true and verifiable. Never "expert" or "specialist" - use "has a special interest in [area]".

```
type: team
heading: "Meet the team"
body: "Sophie, our Clinic Director, has a special interest in barrier health and 14 years in skin."
note: "State credentials only if true and verifiable. No 'expert' / 'specialist'."
```

### QUOTE (use with care)
A clinic value or a general sentiment in the clinic's voice. NOT a patient testimonial for a regulated treatment (that is a hard fail). A general "people leave feeling looked after" sentiment can be fine; a quote about a treatment outcome is not.

```
type: quote
quote: "Honest advice first. The right treatment second."
attribution: "Our consult-first promise"
note: "Never a patient testimonial for a regulated treatment."
```

### CTA (last slide of every carousel)
The close. A low-friction, concern-led invite. Book a consult, send a DM, save the post. For an Offer carousel, the clear booking line and destination. No guaranteed outcome, no S4 pricing, no urgency unless it is real.

```
type: cta
headline: ["Not sure what your", "skin needs this winter?"]
accent_line: "Start with a consult."     (optional, italic)
button_text: "BOOK A CONSULT"
link: "(the clinic's booking destination)"
```

---

## Slide furniture (every slide)

- *Brand mark* - the clinic's name or logo, small, top. Recognised not read.
- *Swipe cue* - on Instagram, simple swipe dots or a "swipe" hint on the hook (do not put dots at the bottom of Stories - the UI covers them).
- *Consistent padding* from every edge.
- The clinic's two fonts, two sizes, and palette only - read from `brand-guide.md`. Nothing hardcoded here.
