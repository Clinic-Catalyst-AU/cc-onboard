# AHPRA gate - read before building any carousel (and especially any Proof carousel)

A carousel is public advertising. AHPRA and the TGA regulate how a clinic may advertise regulated treatments (anything Schedule 4 - anti-wrinkle and similar - and cosmetic medical procedures generally). The instinct to "show results" is exactly what gets a clinic reported, fined, or named publicly. This file is the guardrail for every slide and the caption. When in doubt, downgrade the slide to Educate (what-to-expect).

This mirrors the content-engine's `proof-pillar-ahpra.md` - the same rules, applied to carousel slides and captions.

## NEVER (hard fail - fix before delivering)

- *Before/after images.* Skin-treatment before/afters (non-Schedule-4 - IPL, skin needling, LED, HIFU, facials, peels) are allowed on a carousel, provided they are genuine, consented, realistic (same lighting, not misleading) and never framed as a guaranteed result. Injectable (Schedule 4) before/afters must NEVER appear in public advertising or social, including a carousel - they are permitted only in direct channels (email, or after a consult). Always defer to the clinic's own resonance-messaging.md / brand-guide.md boundaries (some brands use none at all). Never a patient testimonial that claims a treatment result.
- *Patient testimonials / endorsements for regulated treatments.* No "my skin has never looked better", no paraphrased patient quotes, no review screenshots about a regulated-treatment outcome. This holds even for genuine testimonials the clinic received.
- *Guaranteed or specific outcomes.* No "wrinkle-free", "years younger", "clears your acne", "removes pigmentation", "permanent". No shades-lighter or percentage-improvement claims.
- *Superlatives - two tiers, do not blanket-ban.* HARD-BANNED (the actual breach): best, #1, most effective, safe, painless, risk-free, miracle, transformation (as a promise), and expert/specialist unless the practitioner holds that registration. DISCRETIONARY (puffery, the clinic's call, not a breach): leading, top, expertise, premium, trusted, boutique.
- *Safety claims.* "safe", "painless", "no risk", "no downtime" (as an absolute).
- *Schedule 4 specifics.* No "Botox" (use "anti-wrinkle"), no pricing on Schedule 4 treatments, no dosing.
- *"Anti-ageing" is ALLOWED* - use with care, not banned. Australian English. No emdashes (hyphens with spaces). Italics not bold for emphasis. Never the "it's not X, it's Y" pattern.

## INSTEAD - compliant ways to be persuasive on a slide

- *What to expect, step by step.* Walk a treatment honestly - the consult, the appointment, the recovery, the realistic timeline. Honesty reads as confidence and quietly proves competence.
- *Process transparency.* How the clinic assesses skin, how it decides what suits someone, why it might say "not yet" or "not this".
- *Realistic-outcome education.* What a treatment can and cannot do, said plainly. This builds more trust than any hype.
- *Experience as fact, not superiority.* "14 years in skin", "thousands of consults", a named device - stated, never ranked against others.
- *Qualifications and standards.* The training, the registration, the protocols, the aftercare - facts that must be true and verifiable. Use "has a special interest in [area]", never "expert" or "specialist".
- *General sentiment, carefully.* A general "people leave feeling looked after" can be fine; a quote describing a regulated-treatment outcome is not. If unsure, leave it out.
- *Myth-busting and straight talk.* Being the calm, honest voice on a concern is itself proof of competence - without the word "expert".

## The downgrade rule

If a slide cannot be written without edging toward a claim, rewrite it as an Educate (what-to-expect) slide. A safe, useful slide beats a breach every time.

## One-line test for any slide

"Does this state a fact about our process or experience (safe), or does it promise the reader a result (breach)?" Facts pass. Promises do not. Apply it to the caption too.
