# AHPRA gate - read before building any carousel (and especially any Proof carousel)

A carousel is public advertising. AHPRA and the TGA regulate how a clinic may advertise regulated treatments (anything Schedule 4 - anti-wrinkle and similar - and cosmetic medical procedures generally). The instinct to "show results" is exactly what gets a clinic reported, fined, or named publicly. This file is the guardrail for every slide and the caption. When in doubt, downgrade the slide to Educate (what-to-expect).

This mirrors the content-engine's `proof-pillar-ahpra.md` - the same rules, applied to carousel slides and captions.

## NEVER (hard fail - fix before delivering)

- *Before/after as a promise.* No before/after images, no before/after wording, no "this is what you'll get". Show process, not promise. The carousel never produces before/after imagery, even where consent and disclaimers might technically allow it elsewhere - the risk is not worth it.
- *Patient testimonials / endorsements for regulated treatments.* No "my skin has never looked better", no paraphrased patient quotes, no review screenshots about a regulated-treatment outcome. This holds even for genuine testimonials the clinic received.
- *Guaranteed or specific outcomes.* No "wrinkle-free", "years younger", "clears your acne", "removes pigmentation", "permanent". No shades-lighter or percentage-improvement claims.
- *Superlatives and therapeutic claims.* best, leading, top, #1, most effective, expert, specialist, miracle, transformation (as a promise).
- *Safety claims.* "safe", "painless", "no risk", "no downtime" (as an absolute).
- *Schedule 4 specifics.* No "Botox" (use "anti-wrinkle"), no pricing on Schedule 4 treatments, no dosing.
- *"Anti-ageing".* Australian English. No emdashes (hyphens with spaces). Italics not bold for emphasis. Never the "it's not X, it's Y" pattern.

## INSTEAD - compliant ways to be persuasive on a slide

- *What to expect, step by step.* Walk a treatment honestly - the consult, the appointment, the recovery, the realistic timeline. Honesty reads as confidence and quietly proves competence.
- *Process transparency.* How the clinic assesses skin, how it decides what suits someone, why it might say "not yet" or "not this".
- *Realistic-outcome education.* What a treatment can and cannot do, said plainly. This builds more trust than any hype.
- *Experience as fact, not superiority.* "14 years in skin", "thousands of consults", a named device - stated, never ranked against others.
- *Qualifications and standards.* The training, the registration, the protocols, the aftercare - facts that must be true and verifiable. Use "has a special interest in [area]", never "expert" or "specialist".
- *General sentiment, carefully.* A general "people leave feeling looked after" can be fine; a quote describing a regulated-treatment outcome is not. If unsure, leave it out.
- *Myth-busting and straight talk.* Being the calm, honest voice on a concern is itself proof of competence - without the word "expert".

## The downgrade rule

If a slide cannot be written without edging toward a claim, rewrite it as an Educate (what-to-expect) slide. A safe, useful slide beats a breach every time.

## One-line test for any slide

"Does this state a fact about our process or experience (safe), or does it promise the reader a result (breach)?" Facts pass. Promises do not. Apply it to the caption too.
