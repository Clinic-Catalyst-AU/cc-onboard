---
name: cc-carousel
description: Build a branded, AHPRA-safe Instagram or Facebook carousel for an aesthetics clinic - a concern-led, swipeable multi-slide post that teaches first and invites the booking last. Reads the clinic's own brand-guide.md (colours, fonts, voice) so every slide looks and sounds like their brand, not a template. Maps the slides to the four content pillars (Educate, Connect, Proof, Offer). RENDERS the finished slide images (bundled render_carousel.py - pure Pillow, their photos + brand assets, no generation key needed) and finishes by opening the slides on screen. Use when you say carousel, build a carousel, make me a carousel about [concern], carousel post, swipe post, multi-slide, slides for instagram, or want a multi-image teaching post for the clinic.
---

# CC Carousel - the clinic's concern-led swipe post

Turns one concern (and the clinic's brand) into a phone-readable, swipeable carousel that earns the swipe, teaches something true, and ends on a low-friction booking invite. It reads the clinic's `brand-guide.md` for colours, fonts and voice so the slides look like they belong on the clinic's own feed. Everything is concern-led and AHPRA-safe by construction.

This is a SINGLE-post tool (one carousel at a time). The monthly plan that decides *which* carousels to post and when is `/cc-content-engine` - this skill is what builds an individual carousel slide-by-slide when you want one. Same brand spine (`brand-guide.md`), same four pillars, same AHPRA gate.

This skill produces the words AND the finished slides. Copy first (concern-led, in their voice), then `render_carousel.py` renders every slide in the clinic's branding - pure Pillow from their brand assets and their own photos, no generation API, no key, no cost. The payoff is a swipeable, postable carousel opened on screen.


*Folders + the shared ending* - read `../cc-reeltalkinghead/references/workspace-folders.md`. EVERY media folder lives under `Content/`. They drop files into Talking Head / Long Videos / Raw Clips / Photos; the system writes into Clips and Ready to Post. Never make the clinic type a file path. Every video skill ends the same way: save to Ready to Post, open it on screen, ASK before pushing to GHL, and if they say no, tell them the file is there to post natively (that is how they add a trending sound).


*GHL access* - BEFORE any GHL call, read the clinic's Private Integration token + Location ID from `Credentials/credentials-reference.txt`. They are already in there - the clinic created that file during setup and their CLAUDE.md points at it. Use them and push. Only if a value is genuinely blank, ask for it and save it. Full contract, scope list and failure handling: `../cc-reeltalkinghead/references/ghl-credentials.md`.

## When to use

- You say "carousel", "build a carousel", "make me a carousel about [concern]", "swipe post", "multi-slide", "slides for instagram".
- A concern would teach well in steps (a skin concern explained, a myth busted, what-to-expect for a treatment, a 3-tip post, a meet-the-team intro).
- You want one polished, compliant carousel for the clinic's feed rather than a whole month of content (that is `/cc-content-engine`).

## Inputs

*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/resonance-messaging.md` (the emotional source of truth - see NEURO-EMOTIVE WIRING below) + `Business-Brain/brand-guide.md` (and `Business-Brain/concerns.md` + `Business-Brain/offers.md` when they exist, for the concern detail and the current offer) and WRITES to `Content/`. Never write into `Business-Brain/`. All paths are relative to the active clinic workspace (root `~/Clinic/`) - never hardcode an absolute path. If `brand-guide.md` is missing, say so and offer to run `/cc-brand-guide` first; never fabricate the brand.

1. *The spine* - the clinic's `Business-Brain/brand-guide.md` (output of `/cc-brand-guide`). Read it in full and pull, in the clinic's own values:
   - *Colours* - the clinic's palette. Use only these. If the guide names a number of colours, use that many - no extras.
   - *Fonts* - exactly the fonts the guide specifies. Two fonts only (one heading, one body), two sizes only (one big, one medium). Do not add a third font for "accents" or "badges".
   - *Voice* - tone of voice, words-we-use, words-we-avoid, key messages, the Claude Context Block at the bottom. Every line of copy inherits this. Nothing about the brand is hardcoded in this skill.
   If there is no `brand-guide.md`, run `/cc-brand-guide` first - do not build a carousel without the spine.
2. *The brief* - what this carousel is about. Ask only what the files do not already give you:
   - The single concern or topic (e.g. winter dryness, congestion, pigmentation, what-to-expect for a peel, meet-the-team).
   - The pillar it serves (Educate / Connect / Proof / Offer - see below). Default to Educate if unsure; a single carousel is usually one pillar.
   - The CTA / booking destination (only needed if the carousel ends on an Offer or soft ask).
   - Format: Instagram (default) or Facebook. Slide count (default 6).
3. *Photos (optional)* - if the clinic has supplied their own on-brand photography (the room, the team, textures), note the path. Never substitute random stock or invent imagery; if no photo, the design direction calls for a brand-coloured textured background instead. On before/after: skin-treatment before/afters (non-Schedule-4 - IPL, skin needling, LED, HIFU, facials, peels) are allowed if genuine, consented and realistic; injectable (Schedule 4) before/afters must never appear on a carousel (direct channels only). Always defer to the clinic's resonance-messaging.md / brand-guide.md boundaries (see the AHPRA gate).

If any input is missing, ask the few questions one at a time. Never invent clinic facts, treatments, team names, credentials, or results - verify against the brand-guide or ask.

## NEURO-EMOTIVE WIRING (mandatory - this is what makes the carousel land, not read like any clinic)

Run the shared engine before writing a line: `cc-resonance/references/neuro-emotive-engine.md` (installed alongside this skill). In short:
1. READ `Business-Brain/resonance-messaging.md` - the emotional stack, the arc, the OPEN/CLOSE language bank, the headline angles, the proof map - as well as `brand-guide.md`. If `resonance-messaging.md` is missing, offer `/cc-resonance`; never generate off the brand-guide alone (that is what makes carousels thin).
2. APPLY the 21 neuro-emotive models (`cc-resonance/references/model-library.md`), mapped to the slides: slide 1 hook = Curiosity Spark + Empathy Echo; middle slides = Emotional Proof + Clarity Charge + Belonging Trigger; final CTA slide = Desire Dial + Guided Choice Maker.
3. GROUND every slide in the clinic's real offer + their OPEN language bank. You should be able to point at any slide and name the model firing AND the OPEN word it used. A generic carousel that ignores the resonance doc is a FAILED run - regenerate.

## The four pillars (which carousel is this?)

A carousel almost always serves one pillar. Pick the pillar first; it shapes the whole flow. These are the same four pillars as `/cc-content-engine` (see that skill's `references/content-pillars.md` for the full logic).

| Pillar | Stage | A carousel in this pillar |
|--------|-------|---------------------------|
| Educate | Know | Explain a concern, explain a treatment in plain language, bust a myth, answer the shy question. The most common carousel. |
| Connect | Like + Trust | Meet the team, the clinic's values and standards, behind the scenes, why we do this. |
| Proof | Trust | What-to-expect step by step, process transparency, experience-and-qualifications as fact. NEVER injectable (Schedule 4) before/afters or a patient testimonial claiming a treatment result; skin-treatment before/afters only if genuine, consented and realistic. |
| Offer | Convert | The current offer tied to the concern it answers, a clean booking invite. Smallest and rarest - earn it with value first. |

Value before the ask. An Educate or Connect carousel can end on a soft invite; an Offer carousel still opens with a useful slide before it asks.

## The AHPRA gate (screen EVERY slide - non-negotiable)

CC clinics advertise under AHPRA + TGA cosmetic rules. The carousel is public advertising, so every slide is screened. The hard line, applied to every slide and the caption:

NEVER produce:
- Superlatives - two tiers, do not blanket-ban. HARD-BANNED (the actual breach): best, #1, most effective, safe, painless, risk-free, miracle, transformation as a promise, and expert/specialist unless the practitioner holds that registration (use "has a special interest in"). DISCRETIONARY (puffery, the clinic's call, not a breach): leading, top, expertise, premium, trusted, boutique.
- Before/after framed as a promise or guaranteed result, injectable (Schedule 4) before/afters, or comparative appearance claims (skin-treatment before/afters are allowed only if genuine, consented and realistic - see the gate).
- Patient testimonials or endorsements for regulated treatments (even paraphrased, even real).
- Guaranteed or specific outcomes ("years younger", "wrinkle-free", "clears acne", "removes pigmentation", "permanent").
- Safety claims ("safe", "painless", "no risk", "no downtime" as an absolute).
- The word "Botox" (trademarked + Schedule 4) - use "anti-wrinkle". No pricing on Schedule 4 treatments. No dosing.
- "Anti-ageing" is ALLOWED - use with care, not banned; concern-led framing is the default but the term is the clinic's choice. Australian English only. No emdashes (use hyphens with spaces). Italics not bold for emphasis. Never the "it's not X, it's Y" pattern.

When a Proof idea cannot be said without edging toward a claim, downgrade the slide to Educate (what-to-expect). A safe, useful slide beats a breach every time. Full detail in `references/ahpra-gate.md` - read it before building any Proof carousel.

## How to build

### Step 1: Read the brand guide
Read `Business-Brain/brand-guide.md` in full. Lock in the colours, the two fonts, the two sizes, and the voice (words-we-use / words-we-avoid / tone). If the clinic has a live website, a quick look confirms the fonts and colours render the way the guide says. The carousel must look like it came from the clinic's brand, not a generic template. Read the guide literally - if it says four colours, use four; if it says "no [colour]", do not use it.

### Step 2: Pick the pillar and plan the slide flow
Choose the pillar (above). Then plan the flow. Every carousel tells one small story across the slides. The first slide earns the swipe; the last slide closes it. See `references/slide-templates.md` for the slide-type library and the recommended flows per pillar.

Standard 6-slide Educate flow:
1. *Hook* - stop the scroll. One concern-led promise of what they will learn. Biggest creative effort here. Concern-led, never claim-led.
2. *The concern* - name what is going on / what it feels like. The honest mirror.
3. *Why it happens* - the plain-language explanation. This is where trust is built.
4. *What helps* - the approach or treatment in plain language (no outcome promise, no S4 pricing).
5. *What to expect* - set honest expectations (this reads as confidence and is AHPRA-safe).
6. *Soft CTA* - a low-friction invite (book a consult / send a DM / save this post). Concern-led.

Adapt to the pillar: a Connect (meet-the-team) carousel is hook, who-we-are, our-standards, why-we-do-this, a real (verifiable) credential, invite. A Proof carousel is hook, the honest what-to-expect steps, then invite - injectable before/afters never, skin-treatment before/afters only if genuine, consented and realistic. A 3-tip carousel is hook, tip 1, tip 2, tip 3, invite.

### Step 3: Write the copy in the clinic's voice
Draft each slide using the brand-guide voice: words-we-use, the clinic's phrasing, their tone. Less is more - fewer words per slide, lots of breathing room. If a slide is getting crowded, split it into two slides rather than shrinking the text. Australian English, no emdashes, italics not bold.

Sharpen as you go:
- The *hook* (slide 1) is the highest-leverage line - make it concern-led and specific, the thing their ideal client is actually wondering. Run it past `/cc-resonance`'s language bank if one exists.
- Run the full draft through `/stoptheslop` to strip AI tells and enforce Australian English + no emdashes.
- Screen every slide against the AHPRA gate (above / `references/ahpra-gate.md`). Fix anything flagged before moving on.

### Step 4: Write the design direction (per slide)
For each slide, write a short design brief the image step (or a designer) can build from. This skill does not render the images. For each slide note: slide type, the exact copy (eyebrow / headline / body / CTA), the layout intent (where the text sits, photo zone vs text zone), which brand colour leads, and the image brief (a brand-coloured texture, or a supplied clinic photo - never stock; no injectable before/afters, skin-treatment before/afters only if genuine, consented and realistic). The design principles to honour are in `references/design-rules.md`:
- Text is large and phone-readable. Generous edge padding. Separate photo and text zones - never text crammed over a busy photo without a readable panel. Two fonts, two sizes. Brand colours only.

### Step 5: RENDER (deterministic - never improvise the design in-session)
Build the spec JSON (slug, out_dir `Content/Ready to Post/<slug>/`, accent from the brand guide,
slides with type hook/teach/proof/photo/cta + eyebrow/headline/body, photo paths ONLY from the
clinic's own supplied photos) and run the bundled renderer:
```bash
python3 <this-skill-folder>/render_carousel.py < spec.json
```
Design rules are baked into the renderer: photo zone and text zone never share space, headline
font + logo + accent come from brand-assets, slide dots, 1080x1350. Do not restyle ad hoc - if
the layout needs a structural change, change render_carousel.py deliberately.

### Step 6: THE FINALE - show it (always, never ask)
`open Content/Ready to Post/<slug>/` so the slide set opens in Finder, and `open` slide 01 so it
renders full size. Seeing their branded slides IS the payoff. A run that ends with file paths in
the terminal is NOT done. Then offer the next step out loud: post copy + hashtags, and the GHL
Social Planner draft (multi-image post) via `../cc-reeltalkinghead/references/ghl-social-push.md` -
draft only, never scheduled, and never push a post without its media attached.

### Step 7: Deliver
Write the carousel to `Content/` in the active clinic workspace (never into `Business-Brain/`):
- *Carousel doc* (`Content/<clinic>-carousel-<topic-slug>.md`) - each slide as: `slide # / type / pillar / eyebrow / headline / body / CTA` plus a one-line `image direction`. Then the suggested feed caption (also AHPRA-screened) and hashtags.
- If the clinic is GHL-social-connected and you have explicit go-ahead, the carousel can be queued to their GHL Social Planner as a draft (never auto-publish). Confirm the location and connected accounts first.

## Process

1. Read `brand-guide.md` (and `concerns.md` / `offers.md` if present). If missing, offer `/cc-brand-guide`.
2. Gather the brief: concern, pillar, format, slide count, CTA - ask only what is missing.
3. Plan the slide flow for that pillar.
4. Draft each slide in the clinic's voice.
5. Run the draft through `/stoptheslop`; screen every slide against the AHPRA gate; fix and re-check.
6. Write the per-slide design direction.
7. Deliver the carousel doc to `Content/` (and optionally queue as a GHL draft with go-ahead).

## Notes

- Pairs with `/cc-content-engine` (the monthly organic plan) and `/cc-metaad-builder` (paid). Same concern feeds all three. This skill builds one carousel; the engine decides the month.
- The Proof pillar is the legal risk. When in doubt on a Proof slide, downgrade it to Educate (what-to-expect) rather than risk a claim.
- Never reuse another clinic's brand, colours, or photos. Every carousel reads from the active clinic's own `brand-guide.md`.
- Image generation is deliberately out of scope - this skill is the copy and the direction. Keep that line clean.
