---
name: cc-carousel
description: Build a branded, AHPRA-safe Instagram or Facebook carousel for an aesthetics clinic - a concern-led, swipeable multi-slide post that teaches first and invites the booking last. Reads the clinic's own brand-guide.md (colours, fonts, voice) so every slide looks and sounds like their brand, not a template. Maps the slides to the four content pillars (Educate, Connect, Proof, Offer). Produces the slide copy plus a per-slide design direction; image generation is a separate concern. Use when you say carousel, build a carousel, make me a carousel about [concern], carousel post, swipe post, multi-slide, slides for instagram, or want a multi-image teaching post for the clinic.
---

# CC Carousel - the clinic's concern-led swipe post

Turns one concern (and the clinic's brand) into a phone-readable, swipeable carousel that earns the swipe, teaches something true, and ends on a low-friction booking invite. It reads the clinic's `brand-guide.md` for colours, fonts and voice so the slides look like they belong on the clinic's own feed. Everything is concern-led and AHPRA-safe by construction.

This is a SINGLE-post tool (one carousel at a time). The monthly plan that decides *which* carousels to post and when is `/cc-content-engine` - this skill is what builds an individual carousel slide-by-slide when you want one. Same brand spine (`brand-guide.md`), same four pillars, same AHPRA gate.

This skill produces the *words and the design direction* - the slide copy, layout intent, and a per-slide image brief. It does not render the final images; that is a separate generation step. The payoff here is on-brand, compliant, scroll-stopping carousel content ready to hand to a designer or an image step.

## When to use

- You say "carousel", "build a carousel", "make me a carousel about [concern]", "swipe post", "multi-slide", "slides for instagram".
- A concern would teach well in steps (a skin concern explained, a myth busted, what-to-expect for a treatment, a 3-tip post, a meet-the-team intro).
- You want one polished, compliant carousel for the clinic's feed rather than a whole month of content (that is `/cc-content-engine`).

## Inputs

*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/brand-guide.md` (and `Business-Brain/concerns.md` + `Business-Brain/offers.md` when they exist, for the concern detail and the current offer) and WRITES to `Content/`. Never write into `Business-Brain/`. All paths are relative to the active clinic workspace (root `~/Clinic/`) - never hardcode an absolute path. If `brand-guide.md` is missing, say so and offer to run `/cc-brand-guide` first; never fabricate the brand.

1. *The spine* - the clinic's `Business-Brain/brand-guide.md` (output of `/cc-brand-guide`). Read it in full and pull, in the clinic's own values:
   - *Colours* - the clinic's palette. Use only these. If the guide names a number of colours, use that many - no extras.
   - *Fonts* - exactly the fonts the guide specifies. Two fonts only (one heading, one body), two sizes only (one big, one medium). Do not add a third font for "accents" or "badges".
   - *Voice* - tone of voice, words-we-use, words-we-avoid, key messages, the Claude Context Block at the bottom. Every line of copy inherits this. Nothing about the brand is hardcoded in this skill.
   If there is no `brand-guide.md`, run `/cc-brand-guide` first - do not build a carousel without the spine.
2. *The brief* - what this carousel is about. Ask only what the files do not already give you:
   - The single concern or topic (e.g. winter dryness, congestion, pigmentation, what-to-expect for a peel, meet-the-team).
   - The pillar it serves (Educate / Connect / Proof / Offer - see below). Default to Educate if unsure; a single carousel is usually one pillar.
   - The CTA / booking destination (only needed if the carousel ends on an Offer or soft ask).
   - Format: Instagram (default) or Facebook. Slide count (default 6).
3. *Photos (optional)* - if the clinic has supplied their own on-brand photography (the room, the team, textures), note the path. Never substitute random stock or invent imagery; if no photo, the design direction calls for a brand-coloured textured background instead. No before/after imagery, ever (see the AHPRA gate).

If any input is missing, ask the few questions one at a time. Never invent clinic facts, treatments, team names, credentials, or results - verify against the brand-guide or ask.

## The four pillars (which carousel is this?)

A carousel almost always serves one pillar. Pick the pillar first; it shapes the whole flow. These are the same four pillars as `/cc-content-engine` (see that skill's `references/content-pillars.md` for the full logic).

| Pillar | Stage | A carousel in this pillar |
|--------|-------|---------------------------|
| Educate | Know | Explain a concern, explain a treatment in plain language, bust a myth, answer the shy question. The most common carousel. |
| Connect | Like + Trust | Meet the team, the clinic's values and standards, behind the scenes, why we do this. |
| Proof | Trust | What-to-expect step by step, process transparency, experience-and-qualifications as fact. NEVER before/after or testimonials for regulated treatments. |
| Offer | Convert | The current offer tied to the concern it answers, a clean booking invite. Smallest and rarest - earn it with value first. |

Value before the ask. An Educate or Connect carousel can end on a soft invite; an Offer carousel still opens with a useful slide before it asks.

## The AHPRA gate (screen EVERY slide - non-negotiable)

CC clinics advertise under AHPRA + TGA cosmetic rules. The carousel is public advertising, so every slide is screened. The hard line, applied to every slide and the caption:

NEVER produce:
- Superlatives / therapeutic claims: best, leading, top, #1, most effective, expert, specialist (use "has a special interest in"), miracle, transformation as a promise.
- Before/after as a promise, before/after images, or comparative appearance claims.
- Patient testimonials or endorsements for regulated treatments (even paraphrased, even real).
- Guaranteed or specific outcomes ("years younger", "wrinkle-free", "clears acne", "removes pigmentation", "permanent").
- Safety claims ("safe", "painless", "no risk", "no downtime" as an absolute).
- The word "Botox" (trademarked + Schedule 4) - use "anti-wrinkle". No pricing on Schedule 4 treatments. No dosing.
- "Anti-ageing". Australian English only. No emdashes (use hyphens with spaces). Italics not bold for emphasis. Never the "it's not X, it's Y" pattern.

When a Proof idea cannot be said without edging toward a claim, downgrade the slide to Educate (what-to-expect). A safe, useful slide beats a breach every time. Full detail in `references/ahpra-gate.md` - read it before building any Proof carousel.

## How to build

### Step 1: Read the brand guide
Read `Business-Brain/brand-guide.md` in full. Lock in the colours, the two fonts, the two sizes, and the voice (words-we-use / words-we-avoid / tone). If the clinic has a live website, a quick look confirms the fonts and colours render the way the guide says. The carousel must look like it came from the clinic's brand, not a generic template. Read the guide literally - if it says four colours, use four; if it says "no [colour]", do not use it.

### Step 2: Pick the pillar and plan the slide flow
Choose the pillar (above). Then plan the flow. Every carousel tells one small story across the slides. The first slide earns the swipe; the last slide closes it. See `references/slide-templates.md` for the slide-type library and the recommended flows per pillar.

Standard 6-slide Educate flow:
1. *Hook* - stop the scroll. One concern-led promise of what they will learn. Biggest creative effort here. Concern-led, never claim-led.
2. *The concern* - name what is going on / what it feels like. The honest mirror.
3. *Why it happens* - the plain-language explanation. This is where trust is built.
4. *What helps* - the approach or treatment in plain language (no outcome promise, no S4 pricing).
5. *What to expect* - set honest expectations (this reads as confidence and is AHPRA-safe).
6. *Soft CTA* - a low-friction invite (book a consult / send a DM / save this post). Concern-led.

Adapt to the pillar: a Connect (meet-the-team) carousel is hook, who-we-are, our-standards, why-we-do-this, a real (verifiable) credential, invite. A Proof carousel is hook, the honest what-to-expect steps, then invite - never before/after. A 3-tip carousel is hook, tip 1, tip 2, tip 3, invite.

### Step 3: Write the copy in the clinic's voice
Draft each slide using the brand-guide voice: words-we-use, the clinic's phrasing, their tone. Less is more - fewer words per slide, lots of breathing room. If a slide is getting crowded, split it into two slides rather than shrinking the text. Australian English, no emdashes, italics not bold.

Sharpen as you go:
- The *hook* (slide 1) is the highest-leverage line - make it concern-led and specific, the thing their ideal client is actually wondering. Run it past `/cc-resonance`'s language bank if one exists.
- Run the full draft through `/stoptheslop` to strip AI tells and enforce Australian English + no emdashes.
- Screen every slide against the AHPRA gate (above / `references/ahpra-gate.md`). Fix anything flagged before moving on.

### Step 4: Write the design direction (per slide)
For each slide, write a short design brief the image step (or a designer) can build from. This skill does not render the images. For each slide note: slide type, the exact copy (eyebrow / headline / body / CTA), the layout intent (where the text sits, photo zone vs text zone), which brand colour leads, and the image brief (a brand-coloured texture, or a supplied clinic photo - never stock, never before/after). The design principles to honour are in `references/design-rules.md`:
- Text is large and phone-readable. Generous edge padding. Separate photo and text zones - never text crammed over a busy photo without a readable panel. Two fonts, two sizes. Brand colours only.

### Step 5: Deliver
Write the carousel to `Content/` in the active clinic workspace (never into `Business-Brain/`):
- *Carousel doc* (`Content/<clinic>-carousel-<topic-slug>.md`) - each slide as: `slide # / type / pillar / eyebrow / headline / body / CTA` plus a one-line `image direction`. Then the suggested feed caption (also AHPRA-screened) and hashtags.
- If the clinic is GHL-social-connected and you have explicit go-ahead, the carousel can be queued to their GHL Social Planner as a draft (never auto-publish). Confirm the location and connected accounts first.

## Process

1. Read `brand-guide.md` (and `concerns.md` / `offers.md` if present). If missing, offer `/cc-brand-guide`.
2. Gather the brief: concern, pillar, format, slide count, CTA - ask only what is missing.
3. Plan the slide flow for that pillar.
4. Draft each slide in the clinic's voice.
5. Run the draft through `/stoptheslop`; screen every slide against the AHPRA gate; fix and re-check.
6. Write the per-slide design direction.
7. Deliver the carousel doc to `Content/` (and optionally queue as a GHL draft with go-ahead).

## Notes

- Pairs with `/cc-content-engine` (the monthly organic plan) and `/cc-ad-builder` (paid). Same concern feeds all three. This skill builds one carousel; the engine decides the month.
- The Proof pillar is the legal risk. When in doubt on a Proof slide, downgrade it to Educate (what-to-expect) rather than risk a claim.
- Never reuse another clinic's brand, colours, or photos. Every carousel reads from the active clinic's own `brand-guide.md`.
- Image generation is deliberately out of scope - this skill is the copy and the direction. Keep that line clean.
