---
name: cc-thankyou-page
description: Builds the matching thank-you / confirmation page a lead lands on straight after submitting the booking form on a /cc-landing-page offer page. Reuses the exact same visual system (accent, fonts, sections) so it feels continuous, confirms the booking, sets expectations, and quietly reduces no-shows. Supports CONFIRM mode (time already booked) or PICK-A-TIME mode (lead chooses a consult time from an embedded GHL calendar). AHPRA-screened, reads the clinic's voice from its brand-guide.md. Use when you say thank you page, thankyou page, confirmation page, booking confirmation, post-submit page, redirect page, next-step page, or want the page that shows AFTER a clinic lead books. Pairs with /cc-landing-page (the offer page that feeds it).
---

# CC THANK-YOU PAGE - The Matching Confirmation Page

Builds the page a lead sees the moment they submit the booking form on a `/cc-landing-page` offer page. It is not a second sales pitch. Its job is to *confirm* (they did the right thing), *set expectations* (what happens next and when), and *quietly reduce no-shows* (reassurance, what to expect, an easy way to lock a time). It reuses the offer page's exact visual system so the lead never feels like they left the clinic's world.

The action is already done - a consult is booked or about to be. So the tone is warm, calm and certain, never selling. Never promise a treatment outcome here either; the AHPRA rules still apply.

*File contract* - follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/resonance-messaging.md` (the emotional source of truth - see NEURO-EMOTIVE WIRING below) + the clinic's voice and offer from `Business-Brain/brand-guide.md` and `Business-Brain/offers.md` (and `resonance-messaging.md` when present). It WRITES the page to the clinic's `Ads/landing-pages/` folder, alongside the offer page it matches. It does not write into `Business-Brain/` - with ONE approved exception: after the clinic confirms the published GHL URL, it records a `Thank-you page: <url>` line under the offer in `Business-Brain/offers.md`, always with their explicit okay (see close-the-loop). All paths are relative to the clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If `brand-guide.md` is missing, say so and offer to run `/cc-brand-guide` first; never fabricate the clinic's voice.

*Prerequisite* - this is the companion to `/cc-landing-page`. Build the offer page first (or have it), so this page matches its accent, clinic name, offer name and voice. If there is no brand guide, stop and run `/cc-resonance` then `/cc-brand-guide` first.

---

## NEURO-EMOTIVE WIRING (mandatory - this is what makes the page land, not read like any clinic)

Run the shared engine before writing a line: `cc-resonance/references/neuro-emotive-engine.md` (installed alongside this skill). In short:
1. READ `Business-Brain/resonance-messaging.md` - the emotional stack, the arc, the OPEN/CLOSE language bank, the headline angles, the proof map - as well as `brand-guide.md`. If `resonance-messaging.md` is missing, offer `/cc-resonance`; never generate off the brand-guide alone.
2. APPLY the 21 neuro-emotive models (`cc-resonance/references/model-library.md`), mapped to the confirmation page: Trust Anchor + Voiceprint Precision (calm certainty), Guided Choice Maker (one clear next step), Desire Dial (how she wants to feel), Retention Resonator (post-action reassurance). Urgency stays soft and true only.
3. GROUND every line in the clinic's real offer + their OPEN language bank. A generic confirmation page that ignores the resonance doc is a FAILED run - regenerate. (All model use stays inside the existing AHPRA rules.)

---

## HOW TO USE

```
/cc-thankyou-page [offer name]
```

The page has TWO modes - pick ONE at build time based on how the clinic's GHL funnel is wired. Ask which if it is not obvious:

- *CONFIRM mode* - the booking form already captured a time (or the clinic books it manually). This page just confirms and sets expectations. No calendar.
- *PICK-A-TIME mode* - the form only captured the lead's details; they now choose their consult time from a GHL Calendar embedded on this page. This is the common two-step GHL pattern (capture, then book). You will need the clinic's GHL Calendar embed URL.

---

## BUILD STEPS (locked template - fill the slots, never restructure)

1. Read `references/thankyou-template.html` - the complete page with `{{SLOT}}` markers. Do NOT redesign, add sections, reorder, or touch the CSS. If you think the template needs a structural change, say so and stop.
2. Gather inputs, in this order:
   - Match the offer page - this template is the SIBLING of the `/cc-landing-page` v2 offer template and shares its `.cc` theme engine. Pull the SAME brand tokens the offer page used: `{{ACCENT_HEX}}`, `{{ACCENT_INK_HEX}}`, `{{BG_SOFT_HEX}}` and the two font stacks `{{FONT_IMPORT}}` / `{{HEADING_FONT_STACK}}` / `{{BODY_FONT_STACK}}` from `brand-guide.md` (+ `Business-Brain/brand-assets/accent.txt`, accent fallback `#0c4a45`). These MUST equal the offer page's values - fonts, palette and section tones carried across is the whole point. If the offer page (`Ads/landing-pages/[offer-slug].html`) already exists, copy its exact `--accent`, `--accent-ink`, `--bg-soft`, `--head`, `--body` and `{{FONT_IMPORT}}` straight out of its `<head>` rather than re-deriving them.
   - Also pull `{{CLINIC_NAME}}`, `{{SUBURB_STATE}}`, `{{OFFER_NAME}}`, and optionally a `{{HERO_IMAGE_GHL_URL}}` (+ `{{HERO_BADGE_TITLE}}` / `{{HERO_BADGE_SUB}}`) - reuse a GHL Media Library image from the offer page for continuity, or DELETE the `.cc-ty-media` block if none.
   - Voice: `brand-guide.md` + `resonance-messaging.md` for the confirmation copy, next steps and reassurance lines.
   - Mode: CONFIRM or PICK-A-TIME. For PICK-A-TIME, ask the user for the GHL Calendar embed URL (GHL > Calendars > their consult calendar > embed/permalink). Never guess it. For CONFIRM, leave `{{CALENDAR_EMBED_URL}}` empty and DELETE the calendar section from the file.
   - The `{{CONTACT_LINE}}` must be TRUE - how and when the clinic actually follows up ("We will text you within one business day to confirm"). Never invent a timeframe.
3. Fill every `{{SLOT}}`. No slot left unfilled - if information is missing, ask; never pad with invented claims. Delete any optional section the clinic does not want (the secondary-action section, or the calendar section in CONFIRM mode) rather than leaving an empty slot.
4. AHPRA gate every filled line (see below). A thank-you page is still an ad surface.
5. Save to `Ads/landing-pages/[offer-slug]-thankyou.html` in the clinic workspace, next to `[offer-slug].html`. STRICT output contract: exactly ONE file, that path, nothing else - no .md notes, no extra drafts.
6. THE FINALE part 1 - SHOW them the page (always, never ask first). The moment the file exists:
   - Screenshot it with headless Chrome and show it inline, or open it - so the clinic actually sees the confirmation render, not a file path in the terminal. In PICK-A-TIME mode the calendar iframe loads live from GHL; in CONFIRM mode the whole page renders standalone.
7. THE APPROVAL GATE - nothing ships until they say yes. With the preview visible, ask: "Happy with it? Anything to change - wording, the follow-up timeframe, the secondary link?" Apply edits to the SAME file, refresh, repeat until they approve.
8. ON APPROVAL - hand it over ready to paste:
   - `pbcopy < Ads/landing-pages/[offer-slug]-thankyou.html` - the entire page is now on their clipboard; tell them so. Also `open -R` the file in Finder as the backup path.
   - Walk them through shipping: GHL > their funnel > the step set as the form's "On submit / redirect" page > full-page Custom Code element > Cmd+V paste > set the offer form's redirect to this step > preview on phone > publish. (If PICK-A-TIME, confirm the form redirects here and the calendar shows.)
9. CLOSE THE LOOP - get the live URL back. Ask them to paste the published GHL thank-you URL. Then:
   - Verify it actually loads (curl or open it) - never assume a publish worked.
   - Confirm the offer form's redirect points at it (in PICK-A-TIME, confirm the calendar books into the right consult calendar).
   - With their okay, record it under the offer in `Business-Brain/offers.md` as a `Thank-you page: <url>` line (the ONE brain write this skill may make, always with explicit approval).

---

## WHAT A GOOD THANK-YOU PAGE DOES (the 3 jobs)

1. *Confirm* - a clear, warm "you're booked / we've got you" with a visual tick. The lead's first feeling should be relief, not "did that go through?". Personalise with a GHL merge field only if the clinic's GHL reliably has the name; otherwise keep it warmly generic.
2. *Set expectations* - the numbered "what happens next": who contacts them, how (SMS/call/email), and by when. This single section prevents most "did they forget me?" anxiety. The timeframe must be real.
3. *Reduce no-shows* - "what to expect on the day" as calm, pressure-free reassurance (how long, who they meet, that nothing is pushed on them, what to bring if anything). In PICK-A-TIME mode, the embedded calendar is the no-show reducer - they lock a time while intent is highest.

*One* optional secondary action only (follow on Instagram, read a short skin-health guide, save the clinic's number). It must never compete with the confirmation - no new offer, no upsell, no second CTA to book something else. If in doubt, delete it.

---

## AHPRA GUARDRAILS (still apply - screen every line)

A thank-you page is an advertising surface. Everything from the offer page holds:

- *Concern-led, never claim-led.* Reassure about the consult and the care, never promise a treatment outcome ("you'll love your results", "years younger" - banned).
- *Superlatives - two tiers, do not blanket-ban.* HARD-BANNED (the actual breach): best, #1, most effective, painless, safe, risk-free, and expert/specialist unless the practitioner holds that registration (use "has a special interest in"). DISCRETIONARY (puffery, the clinic's call, not a breach): leading, top, expertise, premium, trusted, boutique. "Anti-ageing" is allowed - use with care.
- *No before/after as a promise, no patient testimonials about regulated treatments, no guaranteed outcomes.*
- *Never the word "Botox"* (use "anti-wrinkle"); no pricing on Schedule 4 treatments; no discount framed as an inducement to undergo a procedure.
- *Australian English only.* No emdashes - hyphens with spaces ( - ) or rewrite. Italics for emphasis, never bold. Never the "it's not X, it's Y" construction.

When in doubt, make it gentler and more about the experience of care. A compliant page that reassures beats a clever one that risks a breach.

---

## RULES

- ALWAYS match the offer page: same clinic name, same offer name, same accent, same voice. This page is a continuation, not a new design.
- ALWAYS read `brand-guide.md` before writing a line. If it is missing, run `/cc-brand-guide` first. Never fabricate the clinic's voice.
- NEVER turn the thank-you page into a second sales pitch. No new offer, no upsell, at most ONE calm secondary action.
- NEVER invent a follow-up timeframe or contact method - the `{{CONTACT_LINE}}` must be what the clinic actually does.
- NEVER restructure the locked template, add sections, or touch the CSS. Delete optional sections cleanly; never leave an empty slot.
- NEVER use emdashes; Australian English; italics not bold; run the finished page back through the AHPRA guardrails before handing it over.
- ALWAYS design mobile-first - the majority of this traffic is mobile, and they are reading it seconds after booking on their phone.
- The finished-page test: does a lead who just booked feel relieved, certain about what happens next, and calmer about showing up - and would the page survive an AHPRA review? If any answer is no, it is not done.

Pairs with `/cc-landing-page` (the offer page that redirects here) and `/cc-brand-guide` / `/cc-resonance` (the voice and emotional foundation).
