---
name: cc-reel
description: Turn a clinic video clip into a captioned, social-ready reel (animated word-by-word captions, Clinic Catalyst styling, vertical/square/landscape). Transcribes with mlx-whisper (OpenAI Whisper API fallback), renders with the cc-reel-render Remotion engine, AHPRA-screens the on-screen words, and saves to the clinic workspace. Use when the user says reel, caption this, add captions, captioned reel, burn captions, subtitle this clip, make a reel, turn this into a reel, or video for social.
---

# CC REEL - Captioned Reel Renderer

Takes a short clinic video clip (ideally the output of `/cc-find-clip`) and produces a polished, captioned reel with animated word-by-word captions, ready to post. The output is the CLINIC's own social content - it carries NO agency branding (no "Clinic Catalyst" stamped on the video). The teal styling is the caption look only.

## ENGINE

This skill drives a Remotion project (compositions: `CaptionedReel` 1080x1920, `CaptionedSquare` 1080x1080, `CaptionedLandscape` 1920x1080). The engine's location depends on install type - clinics get it at `~/Clinic/.reel-render` (via the clinic pack's INSTALL.sh), operator installs get it at `~/Systems/cc-aios/reel-render` (via bootstrap.sh). Detect which one exists before running any command below:
```bash
REEL_ENGINE=~/Clinic/.reel-render
[ -d "$REEL_ENGINE" ] || REEL_ENGINE=~/Systems/cc-aios/reel-render
```
The CC bootstrap/installer runs `npm install` there already. If `$REEL_ENGINE/node_modules` is missing, run `cd "$REEL_ENGINE" && npm install` once before rendering.

## HOW TO USE

```
/cc-reel ~/Downloads/clip.mp4                 # vertical 9:16 reel (default)
/cc-reel ~/Downloads/clip.mp4 --square        # 1:1 feed
/cc-reel ~/Downloads/clip.mp4 --landscape     # 16:9
/cc-reel ~/Downloads/clip.mp4 --name skin-consult
/cc-reel ~/Downloads/clip.mp4 --model small   # mlx-whisper model size (default: small)
```

## PROCEDURE

### STEP 0: VALIDATE
1. Input file exists and is video (`.mp4`, `.mov`, `.webm`, `.mkv`).
2. Dependencies:
   ```bash
   which ffmpeg ffprobe
   which mlx_whisper   # Apple Silicon only. If missing (Windows / Intel Mac), use faster-whisper instead (python -c "import faster_whisper" to check; CC bootstrap installs it). Last resort: OpenAI Whisper API (/transcribe). Do NOT install local openai-whisper.
   REEL_ENGINE=~/Clinic/.reel-render; [ -d "$REEL_ENGINE" ] || REEL_ENGINE=~/Systems/cc-aios/reel-render
   [ -d "$REEL_ENGINE/node_modules" ] || (cd "$REEL_ENGINE" && npm install)
   ```
3. Parse flags: `--square` / `--landscape` (default reel), `--name SLUG` (default from filename), `--model [tiny|base|small|medium]` (default small).
   - Composition: `CaptionedReel` (default), `CaptionedSquare`, or `CaptionedLandscape`.

### STEP 1: TRANSCRIBE (word-level timestamps)
```bash
mkdir -p /tmp/cc-reel
mlx_whisper "[input]" --model mlx-community/whisper-small-mlx \
  --output-format json --word-timestamps True --output-dir /tmp/cc-reel/
```
If mlx_whisper is unavailable (Windows / Intel Mac), use faster-whisper - keyless, on-device, same output shape (use `python` on Windows, `python3` on Mac):
```bash
python3 - "[input]" /tmp/cc-reel/[input-basename].json <<'PY'
import json, sys
from faster_whisper import WhisperModel
segs, _ = WhisperModel("small", compute_type="int8").transcribe(sys.argv[1], word_timestamps=True)
out = {"segments": [{"start": s.start, "end": s.end, "text": s.text,
       "words": [{"word": w.word, "start": w.start, "end": w.end} for w in (s.words or [])]} for s in segs]}
json.dump(out, open(sys.argv[2], "w"))
PY
```
If faster-whisper is also missing, `pip install faster-whisper` (add `--user` if needed). Last resort with an OpenAI key: the /transcribe API method, producing the same JSON shape (`segments[].words[]` with `word/start/end`).

### STEP 2: BUILD CAPTIONS
Convert the whisper JSON into the @remotion/captions format:
```bash
python3 "$REEL_ENGINE"/src/scripts/captions_from_mlx.py \
  /tmp/cc-reel/[input-basename].json /tmp/cc-reel/captions.json
```

### STEP 3: AHPRA SCREEN (mandatory)
Read `/tmp/cc-reel/captions.json` (these are the SPOKEN words that will appear on screen). Scan for AHPRA breaches: therapeutic/outcome claims, guarantees, "best/expert/specialist", or named prescription products (e.g. injectable brand names).
- If anything is flagged: STOP and tell the user exactly which words are a problem. These are the speaker's own words, so you cannot silently rewrite them - the user must decide to re-record, trim, or not post. Do NOT render a non-compliant reel and call it done.
- If clean: continue.

### STEP 4: STAGE ASSETS
```bash
PUB="$REEL_ENGINE"/public
cp "[input]" "$PUB/clip.mp4"
cp /tmp/cc-reel/captions.json "$PUB/captions.json"
```

### STEP 5: COMPUTE DURATION + PROPS
```bash
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "[input]")
FRAMES=$(python3 -c "import sys;print(max(1,round(float(sys.argv[1])*30)))" "$DUR")
cat > /tmp/cc-reel/props.json <<JSON
{"videoSrc":"clip.mp4","captionsFile":"captions.json","brandKey":"cc","showLogo":false,"durationInFrames":$FRAMES}
JSON
```

### STEP 6: RENDER
```bash
OUT=~/Clinic/Content/reels
mkdir -p "$OUT"
cd "$REEL_ENGINE"
npx remotion render src/index.ts [CompId] "$OUT/[slug]-[platform]-$(date +%Y-%m-%d).mp4" \
  --props=/tmp/cc-reel/props.json
```
- `[CompId]` = CaptionedReel | CaptionedSquare | CaptionedLandscape
- `[platform]` = reel | square | landscape

### STEP 7: REPORT + CLEAN UP
1. Tell the user the output path and duration.
2. Remind: this is their clinic's content (no agency branding on it).
3. Clean staging:
   ```bash
   rm -f "$REEL_ENGINE"/public/clip.mp4 "$REEL_ENGINE"/public/captions.json
   rm -rf /tmp/cc-reel
   ```

## NOTES
- Source aspect doesn't matter - the video is `objectFit: cover` (centre-crop) into the chosen platform frame.
- The caption look (teal active-word highlight, white words, dark stroke) lives in `$REEL_ENGINE/src/theme.ts` (`~/Clinic/.reel-render/src/theme.ts` for clinics, `~/Systems/cc-aios/reel-render/src/theme.ts` for operators). Edit there to adjust styling for ALL reels.
- Pairs with `/cc-find-clip` (find the best 2-min moment) and `/cc-content-pipeline` (write the post copy + hashtags for the reel).

## IMPORTANT RULES
- NEVER stamp "Clinic Catalyst" or any agency name on the clinic's video (showLogo stays false).
- NEVER render a reel whose on-screen words breach AHPRA - flag and stop.
- NEVER use emdashes in any output.
- Output lands in `~/Clinic/Content/reels/`, never in the operator's personal folders.
