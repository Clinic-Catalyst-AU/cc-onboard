#!/usr/bin/env python3
"""
make_sheet.py - build the STYLED Clinic Catalyst RSA Ad Builder workbook.

Usage:  python3 make_sheet.py <output.xlsx>  < spec.json (stdin)

Spec JSON (all keys required unless noted):
{
  "clinic": "Harbourlight Skin Clinic",
  "suburb": "Williamstown VIC",                (optional)
  "campaign": "Winter Skin Reset",             (optional)
  "accent_hex": "#2E6E6A",                     (from brand-guide.md; falls back to CC teal)
  "final_url": "https://...",
  "headlines": [{"text": "...", "angle": "Intent Match"}, ...],   (15)
  "descriptions": [{"text": "...", "focus": "Core Value"}, ...],  (4)
  "paths": ["skin-clinic", "williamstown"],
  "ad_groups": [{"name": "concern-laxity", "keywords": [{"kw": "...", "match": "Phrase"}]}],
  "negatives": ["DIY", "at home", ...]
}

Deterministic on purpose: every clinic gets the same lovely sheet, only the
brand accent and content change. Do not restyle ad hoc in the session.
"""
import json
import sys

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

CC_TEAL = "0F6B5C"  # fallback accent
INK = "23302E"
WHITE = "FFFFFF"
RED = "B03A2E"


def norm_hex(h, fallback=CC_TEAL):
    h = (h or "").strip().lstrip("#")
    return h.upper() if len(h) == 6 else fallback


def tint(hex6, factor=0.88):
    """Blend a colour toward white. factor = how much white (0..1)."""
    r, g, b = (int(hex6[i:i + 2], 16) for i in (0, 2, 4))
    mix = lambda c: int(round(c + (255 - c) * factor))
    return f"{mix(r):02X}{mix(g):02X}{mix(b):02X}"


def main():
    if len(sys.argv) != 2:
        sys.exit("usage: make_sheet.py <output.xlsx> < spec.json")
    spec = json.load(sys.stdin)
    accent = norm_hex(spec.get("accent_hex"))
    band = tint(accent, 0.90)      # zebra row tint
    section = tint(accent, 0.72)   # section sub-header tint

    accent_fill = PatternFill("solid", fgColor=accent)
    band_fill = PatternFill("solid", fgColor=band)
    section_fill = PatternFill("solid", fgColor=section)
    thin = Side(style="thin", color=tint(accent, 0.55))
    box = Border(left=thin, right=thin, top=thin, bottom=thin)

    f_title = Font(bold=True, size=16, color=WHITE)
    f_sub = Font(size=10, color=WHITE)
    f_section = Font(bold=True, size=11, color=INK)
    f_head = Font(bold=True, size=10, color=INK)
    f_body = Font(size=11, color=INK)
    f_small = Font(size=9, italic=True, color=INK)
    f_over = Font(size=11, bold=True, color=RED)

    wb = Workbook()
    ws = wb.active
    ws.title = "RSA Ad Builder"
    ws.sheet_view.showGridLines = False
    widths = {"A": 6, "B": 24, "C": 66, "D": 9, "E": 16}
    for col, w in widths.items():
        ws.column_dimensions[col].width = w

    row = 1

    def merged(text, font, fill=None, height=None, r=None):
        nonlocal row
        r = r or row
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
        c = ws.cell(row=r, column=1, value=text)
        c.font = font
        if fill:
            for col in range(1, 6):
                ws.cell(row=r, column=col).fill = fill
        c.alignment = Alignment(vertical="center", horizontal="left", indent=1)
        if height:
            ws.row_dimensions[r].height = height
        row = r + 1

    clinic = spec["clinic"]
    subtitle_bits = [b for b in [spec.get("suburb"), spec.get("campaign"),
                                 spec.get("final_url")] if b]
    merged(f"{clinic} - Google RSA Ad Builder", f_title, accent_fill, 30)
    merged(" | ".join(subtitle_bits) + "   |   Built by Clinic Catalyst",
           f_sub, accent_fill, 16)
    row += 1

    def section_header(label):
        nonlocal row
        merged(label, f_section, section_fill, 20)

    def table_header(cells):
        nonlocal row
        for i, text in enumerate(cells, start=1):
            c = ws.cell(row=row, column=i, value=text)
            c.font = f_head
            c.fill = band_fill
            c.border = box
        row += 1

    def body_row(cells, zebra_on, char_limit=None, char_col=None):
        nonlocal row
        for i, val in enumerate(cells, start=1):
            c = ws.cell(row=row, column=i, value=val)
            c.font = f_body
            c.border = box
            c.alignment = Alignment(vertical="center", wrap_text=(i == 3))
            if zebra_on:
                c.fill = band_fill
            if char_limit and i == char_col and isinstance(val, int) and val > char_limit:
                c.font = f_over
        row += 1

    # HEADLINES
    section_header("HEADLINES - 15, max 30 characters")
    table_header(["#", "Angle", "Headline", "Chars", ""])
    for i, h in enumerate(spec["headlines"], start=1):
        body_row([i, h.get("angle", ""), h["text"], len(h["text"]), ""],
                 zebra_on=(i % 2 == 0), char_limit=30, char_col=4)
    row += 1

    # DESCRIPTIONS
    section_header("DESCRIPTIONS - 4, max 90 characters")
    table_header(["#", "Focus", "Description", "Chars", ""])
    for i, d in enumerate(spec["descriptions"], start=1):
        body_row([i, d.get("focus", ""), d["text"], len(d["text"]), ""],
                 zebra_on=(i % 2 == 0), char_limit=90, char_col=4)
    row += 1

    # PATHS
    section_header("DISPLAY PATHS - 2, max 15 characters each")
    table_header(["#", "", "Path", "Chars", ""])
    for i, p in enumerate(spec["paths"], start=1):
        body_row([i, "", p, len(p), ""], zebra_on=(i % 2 == 0),
                 char_limit=15, char_col=4)
    row += 1

    # KEYWORDS
    section_header("KEYWORD PLAN - Exact + Phrase only, grouped by concern")
    table_header(["", "Ad group", "Keyword", "", "Match type"])
    z = 0
    for g in spec["ad_groups"]:
        for k in g["keywords"]:
            body_row(["", g["name"], k["kw"], "", k["match"]], zebra_on=(z % 2 == 1))
            z += 1
    row += 1

    # NEGATIVES
    section_header("NEGATIVE KEYWORDS - campaign level")
    table_header(["", "", "Keyword", "", "Match type"])
    for i, n in enumerate(spec["negatives"]):
        body_row(["", "", n, "", "Negative"], zebra_on=(i % 2 == 1))
    row += 1

    merged("AHPRA screen: PASS - concern-led, no superlatives, no before/after, "
           "no testimonials, no S4 names or S4 pricing. Draft for human approval.",
           f_small)

    out = sys.argv[1]
    wb.save(out)
    print(f"styled sheet written: {out}")


if __name__ == "__main__":
    main()
