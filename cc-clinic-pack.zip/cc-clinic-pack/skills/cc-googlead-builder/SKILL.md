---
name: cc-googlead-builder
description: Generate AHPRA-compliant GOOGLE Search ads for aesthetic and medical clinics - 15 RSA headlines (<=30 chars), 4 descriptions (<=90), paths, Exact/Phrase keyword plans, negatives - all char-checked and compliance-screened, mirroring the workshop RSA Ad Builder sheet exactly. Outputs the fixed file set (3 Google Ads Editor CSVs + builder CSV + styled sheet) and ALWAYS finishes by opening the filled RSA sheet on screen (native Google Sheet via the Drive connector, or the local .xlsx). Use when you say cc googlead builder, google ad builder, build google ads, RSA copy, google ads for [clinic], fill the ad sheet. For Meta/Facebook ads use /cc-metaad-builder.
---

# CC Ad Builder - Google RSA + Keyword Generator

Turns a clinic's details into a complete, AHPRA-compliant Google Ads package in ~2 minutes instead of an hour by hand. Built for the Clinic Catalyst workshop. Exact + Phrase match only (no Broad except negatives).

## When to use

- you say "ad builder", "build google ads for [clinic]", "RSA copy", "fill the ad sheet".
- A workshop attendee needs their Google Ads copy generated from their Business Brain.
- Anytime you would otherwise hand-write RSA headlines/descriptions + keywords.

## Inputs (pull from the clinic Business Brain / intake, or ask)

*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/brand-guide.md` (voice spine) + `Business-Brain/offers.md` (the offer) + `Business-Brain/services-machines.md` (treatments and the actual devices/machines) and WRITES to `Ads/` - never into `Business-Brain/`. All paths are relative to your clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If a required file is missing, say which one and offer to run the skill that creates it (no `brand-guide.md` -> run `/cc-brand-guide` first); never fabricate.

- Clinic name, suburb, city - from `Business-Brain/brand-guide.md`.
- Service list - from `Business-Brain/services-machines.md`; flag which are Schedule 4 (anti-wrinkle / botulinum toxin) so pricing is blocked on those.
- USPs / credentials that are TRUE and verifiable (registered nurse, female-led, years open, AHPRA registration) - from the brand guide. Never invent these.
- The offer (e.g. free skin consult) - from `Business-Brain/offers.md`.
- Final URL - this is the offer's landing page, live in GHL, and it must exist BEFORE the ads. If the clinic has no landing page for this offer yet, PAUSE and ask the user: "This offer has no landing page yet - the ads need one to point at. Want me to build it now with /cc-landing-page [offer] --ghl-offer, or do you have a URL?" Do not silently chain into the landing-page build - the user decides. Never launch ads at a homepage and never invent a URL - a placeholder "TBC" line in the sheet is the honest fallback when the page is still being wired.
- Brand voice notes (from `Business-Brain/brand-guide.md`); any genuine, named, verifiable awards.

## The AHPRA hard rules (screen EVERY line - non-negotiable)

NEVER produce:
- Superlatives: `#1`, `best`, `leading`, `top`, `most effective`, `expert` (therapeutic claims).
- Before/after wording or comparative appearance claims.
- Testimonials / patient endorsements (even paraphrased or invented).
- Guaranteed results / specific outcomes ("look 10 years younger", "wrinkle-free").
- Pricing on Schedule 4 treatments (anti-wrinkle injections). Pricing is fine for non-S4: HIFU, LED, skin needling, facials.
- Safety claims ("safe", "no risk").
- The word "Botox" in copy (trademarked + S4) - use "anti-wrinkle".

USE SPARINGLY (medium risk): "natural-looking results", "experienced injector" (never "expert").

ALWAYS: mirror the search intent in headlines; lead the offer with a low-friction action; only state a credential/USP if true for THAT clinic.

Full traffic-light reference (green / amber / red, with examples) - screen every line against it: `references/ahpra-risk-tiers.md`.

## Generation spec

Headlines - 15, each <=30 chars, spread across the Angle taxonomy in this row order (matches the RSA Ad Builder sheet):
1-2 Intent Match, 3 Keyword, 4-5 USP, 6-7 Differentiation, 8-9 Offer, 10-11 Trust, 12-13 CTA, 14-15 Theme Test.

Descriptions - 4, each <=90 chars, across Focus: Core Value, Offer, Differentiation, CTA.

Paths - 2, each <=15 chars (service category + suburb).

Keywords - Exact + Phrase only, grouped into ad groups by service, tagged intent (Transactional / Local / Informational). Map "botox near me" demand to anti-wrinkle keywords; never use Botox in copy.

Negatives - DIY, at home, cheap, jobs, salary, training, course, certification, "how to inject", "side effects". CRITICAL: do NOT add `free` as a negative if the clinic runs a free-consult offer - it blocks their own searchers.

## Process

Run steps 1-5 as ONE unbroken sequence - the run is finished when the branded sheet is open on screen, not before. This is the workshop moment: the clinic watches their ads appear in a sheet that looks like theirs. Stopping at step 4 hands them file paths instead of the payoff.

1. Gather inputs (Business Brain or ask the few missing).
2. Generate headlines, descriptions, paths, keywords, negatives per the spec.
3. Run `validate.py` on the output - it checks every char limit AND scans for banned AHPRA terms. Fix anything it flags and re-run until clean. Never present un-validated copy.
4. Produce outputs (below) - the EXACT file set, no more, no less.
5. THE FINALE - open the filled sheet on screen. ALWAYS do this, NEVER ask first:
   - Build `Ads/<clinic>-rsa-sheet.xlsx` with `make_sheet.py` (it lives in this skill's folder, next to `validate.py`) - do not improvise the styling in-session and do not upload a bare CSV as the sheet: CSV conversion strips all branding and lands as generic mush, which reads as broken to the clinic. Write the spec JSON to `Ads/.rsa-spec.json` then: `python3 <this-skill-folder>/make_sheet.py Ads/<clinic>-rsa-sheet.xlsx < Ads/.rsa-spec.json` (spec schema is documented at the top of the script; `accent_hex` comes from the `## Brand colours` section of `brand-guide.md`; delete the spec file after).
   - Immediately run `open Ads/<clinic>-rsa-sheet.xlsx` so the branded sheet opens on screen (Numbers/Excel). This is the payoff moment and it must not wait on anything - do it the second the file exists. If openpyxl is missing, say so and offer `pip3 install openpyxl --break-system-packages`.
   - THEN, with the sheet already open, offer the optional after-step: push it to Google Drive as a native Google Sheet (upload the .xlsx as base64 via the Drive connector, converting, named `<Clinic> - Google RSA Ad Builder`) when they want a shareable link. Do this AFTER the local open, never before - the base64 hand-off is the slowest step in the whole run and must never sit between the clinic and seeing their sheet. Skip the offer entirely if no Drive connector is available.
   - The branded sheet opening IS the payoff. A run that ends with file paths in the terminal is NOT done.

## Outputs - the STRICT contract (exactly these, nothing else)

All file outputs are written to `Ads/` in the active clinic workspace (never into `Business-Brain/`). The output set is EXACTLY the five files below plus the opened sheet. Do NOT produce .md files, notes files, JSON dumps, or any other format - a run that emits anything outside this list is wrong.

1. `Ads/<clinic>-rsa-ads.csv` - Google Ads Editor ad import. Columns: `Campaign,Ad Group,Headline 1,...,Headline 15,Description 1,...,Description 4,Path 1,Path 2,Final URL`
2. `Ads/<clinic>-keywords.csv` - Editor keyword import. Columns: `Campaign,Ad Group,Keyword,Match Type`
3. `Ads/<clinic>-negatives.csv` - Editor negatives import. Columns: `Campaign,Keyword,Match Type` (Negative)
4. `Ads/<clinic>-rsa.csv` - the filled builder sheet, plain-data twin of the styled sheet.
5. `Ads/<clinic>-rsa-sheet.xlsx` - THE styled workshop sheet -> uploaded as a native Google Sheet and OPENED on screen (Process step 5). This is the run's closing beat.

In the chat itself: the paste-ready Headline column (15 lines) and Description column (4 lines), in sheet row order.

## Notes

- KEYWORD RESEARCH IS ALREADY DONE. The map ships in the pack - do NOT run /cc-keyword-research first, it is not a prerequisite. Brain in, finished ads out, one step.
- Keyword plans SEED FROM REAL DATA: read `../cc-keyword-research/references/master-keyword-map-au.md` (ships with the pack) - real Semrush AU volumes/KD/CPC per cluster. Pick the clusters matching the clinic's services, use the head terms + intent tags for ad groups, apply the clinic's suburbs to the `near me`/`[city]` patterns. Keywords not on the map are Claude-judgment - never quote a volume for them.

- The connected Google tools can read sheets and CREATE new ones, but cannot write into the cells of an existing sheet. To "fill" a sheet, either create a new filled Sheet or hand the user paste-ready columns.
- Pairs with the Get Found SEO/GEO subsystem - the same keyword research feeds both the ads and the organic concern/treatment pages.
- This skill's output mirrors the Clinic Catalyst "Google RSA Ad Builder" workshop sheet EXACTLY - same 15-headline angle taxonomy, the 4 description focuses (Core Value / Offer / Differentiation / CTA), paths, and keyword intent tiers (Transactional / Local / Informational + negatives). So the generated package drops straight into the format clinics learn in the workshop - the system fills the sheet they would otherwise fill by hand. Keep it aligned if the workshop sheet is revised.
- Gold-standard reference + worked example: `~/Projects/clinic-catalyst/workshop-build/06-advertising-ai.md`.
