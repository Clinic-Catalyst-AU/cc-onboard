---
name: cc-reelassembly
description: The STORY reel for an aesthetics clinic - clips edited in a told order (walking into the clinic, meeting your practitioner, them talking and explaining the process, closing on a branded text card with the call to action), word-by-word captions burned on the talking parts, AHPRA-screened, then the full GHL kit: post copy + hook + hashtags from the Business Brain, video uploaded to their GHL Media Library, Social Planner DRAFT created for approval. Finishes by opening the finished reel on screen. Use when the user says story reel, journey reel, clinic tour reel, edit these in order, welcome video, meet the team reel, new patient journey, or has clips that must play in a narrative order ending in a call to action. Simple montage = /cc-reelclips or /cc-reelvoiceover.
---

# CC REEL - ASSEMBLY (the story edit: ordered clips -> captions -> CTA card -> GHL draft)

The "what it feels like to come here" reel: door, face, voice, invitation. Clips play in a TOLD
order, the talking parts get captions, and it closes on a branded text card carrying the call to
action. Then the whole GHL kit so it lands as a draft waiting for approval.

*File contract* - READS `Business-Brain/brand-guide.md` (voice, colours, hashtags) +
`brand-assets/` (fonts, logo) + `offers.md` (CTA). WRITES to `Content/reels/`. Paths relative
to the clinic workspace (`~/Clinic/`).

## HOW TO USE

```
/cc-reelassembly --clips door.mp4 greeting.mp4 talking.mp4 --cta "Book your skin consult"
/cc-reelassembly --folder Content/video/journey --cta-from-offer     # CTA from offers.md
/cc-reelassembly [...] --no-push                                     # stop before GHL
```
ALWAYS confirm the clip order with the user before building - order IS the story. Show the
planned sequence ("1 door.mp4 (4s) -> 2 greeting.mp4 (3s) -> 3 talking.mp4 (22s) -> CTA card")
and get a yes.

## PROCEDURE

### STEP 1: VALIDATE + STORY PLAN
1. `which ffmpeg ffprobe` + the reel engine (same detection as /cc-reeltalkinghead: 
   `REEL_ENGINE=~/Clinic/.reel-render; [ -d "$REEL_ENGINE" ] || REEL_ENGINE=~/Systems/cc-aios/reel-render`).
2. Probe every clip. Present the sequence + runtimes, confirm the order. Scene-setting clips
   longer than 4s: offer to trim (keep the talking clips whole - never cut speech).

### STEP 2: THE CTA END-CARD (branded, deterministic)
Build a 1080x1920 (or square/landscape to match) title card with Pillow - the same brand rules
as /cc-cover: background = the clinic's accent colour from `brand-guide.md` Brand colours (or a
brand-assets photo, dimmed), headline font from `brand-assets/headline-font.ttf` (clean fallback
if absent), the CTA line large + centred, booking link or phone beneath it, logo bottom-centre if
`brand-assets/logo.png` exists. CTA text comes from --cta or the offer in `offers.md` - never
invented. AHPRA: the CTA invites (book/call/ask), it never promises outcomes.
Then make it a 3-second clip:
```bash
ffmpeg -y -loop 1 -i /tmp/cc-assembly/cta.png -t 3 -r 30 -pix_fmt yuv420p \
  -vf scale=1080:1920 /tmp/cc-assembly/cta.mp4
```

### STEP 3: ASSEMBLE IN ORDER (audio kept - the talking is the story)
```bash
python3 ~/.claude/skills/cc-assemble/assemble.py \
  --clips [confirmed order] /tmp/cc-assembly/cta.mp4 --aspect reel --out /tmp/cc-assembly/story.mp4
```

### STEP 4: CAPTION THE TALKING (the /cc-reeltalkinghead pipeline, steps 2-5)
Run the assembled video through the caption pipeline: transcribe (mlx-whisper / faster-whisper,
word timestamps) -> captions.json -> AHPRA + language screen the spoken words (STOP on breaches,
flag swearing with timestamps) -> render through the Remotion engine (CaptionedReel/Square/
Landscape, showLogo false). Captions appear only where speech exists - the door and greeting
shots stay clean, the talking section gets the word-by-word treatment, the CTA card carries its
own text. Output: `Content/reels/<slug>-story-<date>.mp4`.

### STEP 5: THE FINALE part 1 - show it (always, never ask)
`open` the finished story reel + `open -R` in Finder. Watching their clinic's story play IS the
payoff. A run that ends with a file path is not done.

### STEP 6: THE GHL KIT (skip only with --no-push)
Follow `../cc-reeltalkinghead/references/ghl-social-push.md` exactly: copy package (hook +
caption + their hashtags + the same CTA) shown in chat, upload to their GHL Media Library,
Social Planner DRAFT, verify via posts/list, closing line: "Draft waiting in your Social
Planner - review and hit post." Missing token/socials: deliver the reel + copy anyway, say
exactly what to set up.

### STEP 7: CLEAN UP
Remove /tmp/cc-assembly and the engine's staged public/ files.

## Outputs - the STRICT contract (exactly these, nothing else)
1. `Content/reels/<slug>-story-<date>.mp4` - the story reel with CTA card (opened on screen).
2. The copy package in chat.
3. The GHL Social Planner DRAFT (verified id) - unless --no-push or blocked (say why).
No .md files, no leftover card PNGs, no extra drafts.

## IMPORTANT RULES
- Order is confirmed by the human BEFORE building - never guess the story.
- Never cut inside a talking clip. Never render AHPRA-breaching spoken words - flag and stop.
- CTA card = brand assets + true offer only. The card invites, never promises.
- GHL push is DRAFT-only, human approves in GHL. No agency branding. No emdashes.
- Pairs with /cc-cover (post cover) and /cc-reelclips (trend edits).
