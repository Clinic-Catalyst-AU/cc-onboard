# Perfect Ad Examples - the "Ad Copy That Works" gold standards

Lifted from the Clinic Catalyst Day 1 deck + top-performing clinic ads. These are THE reference for
what good Meta ad copy looks like. When generating Meta ads, match the ENERGY, STRUCTURE, value stack
and headline formula of these - never copy them word-for-word for a client, and always run every line
through the AHPRA gate (concern-led, genuine + non-guaranteed benefits, pricing on non-S4 only).

## The core swap - lead with the outcome, not the machine

| DON'T SAY (device-led) | DO SAY (outcome-led) |
|---|---|
| "RF Microneedling Treatment" | "Tighter, brighter skin - no downtime" |
| "Venus Viva Diamond Polar" | "Collagen Lift Facial" |
| "Opus RF + CO2 Full Face $499" | "Firming & texture pathway, Full Face $499" |

Patients think: "I look tired even when I'm not... my skin feels dull... I've lost that glow." Speak to
that reality. *Exception (see the picks below):* you CAN name the device when its medical GRADE is the
actual differentiator against "cheap" competitors - but bring it in as the quality/mechanism REASON,
never as the headline.

## THE AD ANATOMY (the repeatable structure across every top performer)

1. *Headline* = the PROBLEM together WITH the OFFER (see Headline Formula below).
2. *Hook* (first line of primary text) = a curiosity gap / myth-bust / desire line that stops the scroll.
3. *Mechanism* = plain-language "how it works / why cheap versions don't" (reframes price as quality).
4. *Concern checklist* = "Ideal for addressing: ✔ ..." mirroring what she'd type into Google.
5. *Value stack* = "Includes: 🔥 ..." - every real inclusion listed so the price feels like a bargain.
6. *Offer + anchor* = the price with a true "normally $X" / "valued at $X" anchor.
7. *Close* = a calm reason to act ("without surgery or harsh lasers", limited time, local social proof).

Not every ad needs all 7, but the strongest stack most of them. The value stack (5) and the
problem+offer headline (1) are the two most worth bringing in.

## HEADLINE FORMULA (how Meta + lead-form headlines are written)

The headline calls out the PROBLEM together WITH the OFFER - not a pure curiosity line, not a bare price.
Name the concern AND the offer in the one headline:
- "Say Goodbye to Sagging Skin! Save 50% Off" (problem + offer)
- "Jawline & Neck Lift for just $399 (normally $799)" (concern area + offer + anchor)
- "Reverse Time with NanoFractional RF (Save $399)" (desired outcome + offer)
- "The $399 Jaw & Neck Lift Everyone's Talking About" (offer + concern + social proof)

Formula: *[the concern / desired outcome, in their words] + [the offer / intro price / "save X"]*
(+ optional anchor "normally $X" or a line of social proof). AHPRA: name the concern, never promise a
result; pricing on non-S4 only.

## VALUE STACKING (from the workshop - bring this into every offer ad)

Value stacking = list everything the client GETS for the one price, as a stack (🔥 / • / ✔ bullets),
so the offer feels worth far more than they pay. It turns a discount into a bargain, not a cheapening.
Build the stack from the clinic's REAL offer (`offers.md`): the consult, the assessment, each step of
the treatment, any bonus/upgrade, the plan they leave with, time saved ("one treatment instead of
multiple"). Show the stacked value, THEN the price (with "normally $X" / "valued at $X" only if true).
Never invent an inclusion the clinic does not actually provide. Stack INCLUSIONS and genuine concern-led
benefits - keep benefit lines honest and non-guaranteed.

---

## Example 1 - short-form (the mirror moment)
> You'll notice it in the mirror first. Smoother. Firmer. Brighter.
> That subtle shift where your skin just... looks better.
> This is what our Collagen Lift Facial is known for. ✨ Intro Offer $199. Spots are limited.

Why it works: outcome imagery, sensory rhythm (three single words), treatment named as a BENEFIT not a
device, price + scarcity in two clean lines.

## Example 2 - long-form (problem-led with concern checklist)
> Loose skin? Fine lines creeping in? Skin not bouncing back like it used to?
> This is where most people start looking at injectables... but there's another option.
> Our Skin Tightening Facial works beneath the surface to stimulate your body's natural collagen.
> No needles. No harsh lasers. No downtime.
> Perfect for: ✔ Loose or sagging skin ✔ Fine lines + wrinkles ✔ Acne scarring ✔ Pigmentation ✔ Enlarged pores
> Full Face + Neck Skin Tightening Facial $499 (Neck upgrade included - valued at $399)

Why it works: opens with THEIR questions (pain hook), acknowledges the injectables thought then pivots
(pattern interrupt), objection kill, concern checklist, offer with value anchoring.

## Example 3 - proven pick: curiosity-gap mechanism hook (HIFU)
> *HEADLINE:* Jawline & Neck Lift for just $399 (normally $799).
> Why are some HIFU results incredible... and others barely noticeable? Because not all HIFU devices reach the layers where lifting actually happens.
> While many clinics offer cheaper treatments using basic devices, Ultraformer III targets multiple depths to create genuine lifting and tightening.
> The difference? ✔ More defined jawline ✔ Firmer neck ✔ Longer-lasting results ✔ One treatment instead of multiple appointments
> For a limited time: Jawline & Neck Lift $399 (Normally $799). See why more Ipswich women are choosing medical-grade HIFU over cheap alternatives. Limited appointments available.

Why it works: hook is a curiosity gap that is ALSO the objection; mechanism reframes cheap = basic
device; tight benefit stack; price anchoring; local social proof; soft scarcity.

## Example 4 - proven pick: pattern-interrupt + authority + "save yourself" close (HIFU)
> *HEADLINE:* The $399 Jawline & Neck Lift Everyone's Talking About
> 🚨 Not all HIFU treatments reach the layer where lifting actually happens. That's why some clinics need you back 3 times.
> Our TGA-approved Ultraformer III treats FOUR depths in a single session, including the SMAS layer responsible for genuine lifting and tightening.
> For a limited time: Jaw & Neck Lift $399. See why so many people are disappointed with cheap HIFU before you spend a cent. 👇

Why it works: alarm hook + myth-bust; quantified pain ("back 3 times"); authority (TGA-approved, FOUR
depths, SMAS named); the "protect yourself before you spend" close flips scepticism into a reason to book.

## Example 5 - proven pick: VALUE STACKING (Diamond Polar)
> *HEADLINE:* Say Goodbye to Sagging Skin! Save 50% Off [Introductory Special]
> Want to Hydrate, Tighten and Lift your skin? Then grab our 🚨 Limited Time Offer 🚨 - save over 50% on our Face Tightening Treatment.
> Our treatment includes:
> 🔥 Tailored skincare consultation
> 🔥 Double Cleanse
> 🔥 Diamond Polar Treatment (brighten, tighten & hydrate)
> 🔥 Customised serum (mineral, amino acid, multivitamin infusion)
> 🔥 Application of protective SPF 50+ cream
> To Claim Your Voucher Hit 'Get Offer'. Limited Time Offer ends soon.

Why it works: THIS is value stacking. Headline pairs the PROBLEM (sagging skin) with the OFFER (50% off);
the body lists everything INCLUDED as a 🔥 stack so the treatment feels worth far more than the price.

## Example 6 - proven pick: full anatomy (NanoFractional RF)
> *HEADLINE:* Reverse Time with NanoFractional RF (Save $399)
> Refine. Restore. Rejuvenate with our Nano-Facial. An advanced skin rejuvenation technology designed to visibly lift, smooth and tighten the skin with minimal downtime.
> This intelligent treatment delivers precision energy deep into the dermis, stimulating new, healthy collagen and improving skin tone, texture and elasticity from within.
> Ideal for addressing: ✔ Lifting & tightening of face, eyelids & neck ✔ Fine lines, wrinkles & laxity ✔ Acne scarring & stretch marks ✔ Rosacea, brown spots & pigmentation ✔ Uneven texture & enlarged pores
> Your RF Skin Rejuvenation Experience Includes: • Bespoke double cleanse (medical-grade skincare) • NanoFractional RF treatment • Post-treatment serum to soothe & replenish
> For a limited time, a Full Face & Neck RF Skin Tightening Package for $499, with a complimentary neck upgrade valued at $399. Firmer, more luminous skin - without surgery or harsh lasers.

Why it works: the complete anatomy - desire hook (Refine/Restore/Rejuvenate), mechanism (precision energy
into the dermis), concern checklist, VALUE STACK of inclusions, offer with a real anchor ("valued at
$399"), calm close. This is the template to mirror.

*AHPRA note on these picks:* they contain some result-forward language ("genuine lifting", "reverse time",
"No Risk"). When you mirror the STYLE, keep the claims compliant: "No Risk / safe / painless" are banned
(swap for "minimal downtime", "non-invasive"); frame results as what the treatment is designed to help
with, not a guarantee; name the concern; pricing on non-S4 only.

## Example 7 - proven pick: IPL for redness / pigmentation (Photo Rejuvenation)
> *HEADLINE:* 50% Off - Redness, Pigmentation & Veins. Only $199.
> Reveal Radiance. Restore Clarity. Photo Rejuvenation refines tone, reduces redness and restores a luminous complexion.
> Powered by IPL technology, it targets pigmentation, vascular irregularities and visible signs of ageing with precision.
> What this treatment addresses: ✔ Fine lines & wrinkles ✔ Rosacea, redness & sun damage ✔ Freckles, pigmentation & brown spots ✔ Uneven tone & texture
> What to expect: ✨ Visibly brighter, more even skin ✨ Enhanced collagen for smoother skin ✨ Real-time cooling for a comfortable experience
> Full face Photo Rejuvenation session $199, limited time. Step into our calm, professional space and leave with refreshed skin.

Why it works: the anatomy applied to a redness/pigmentation concern - headline pairs the concern with the
offer; desire hook (Reveal Radiance); mechanism (IPL targets pigment + vascular); concern checklist; a
"what to expect" benefit stack; calm close. AHPRA: the original "No More Redness" is a guaranteed-result
promise (soften to the concern named), and "pain-free" becomes "comfortable" (never "painless").

## The four tests (every ad must pass all four)

1. It speaks to the problem. 2. It shows the outcome. 3. It removes confusion. 4. It makes it easy to say yes.

Sell the outcome, not the device. When your messaging reflects the patient's thoughts, not your treatment
menu, conversion increases.
