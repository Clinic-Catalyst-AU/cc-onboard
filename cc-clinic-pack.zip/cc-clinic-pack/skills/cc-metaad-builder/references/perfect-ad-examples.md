# Perfect Ad Examples - the "Ad Copy That Works" gold standards

Lifted verbatim from the Clinic Catalyst Day 1 deck. These are THE reference for what good Meta ad
copy looks like: outcome-led, problem-first, device-free, AHPRA-safe. When generating Meta ads,
match the ENERGY and STRUCTURE of these - never copy them word-for-word for a client.

## The core swap - never sell the machine

| DON'T SAY (device-led) | DO SAY (outcome-led) |
|---|---|
| "RF Microneedling Treatment" | "Tighter, brighter skin - no downtime" |
| "Venus Viva Diamond Polar" | "Collagen Lift Facial" |
| "Venus Viva RF" | "Fix fine lines & loose skin" |
| "Opus RF + CO2 Full Face $499" | "Firming & texture pathway, Full Face $499" |

Patients aren't searching for RF, IPL or brand names. They're thinking: "I look tired even when
I'm not... my skin feels dull... I've lost that glow." Speak to that reality and everything
shifts: more attention, more trust, more bookings.

## Example 1 - short-form (the mirror moment)

> You'll notice it in the mirror first.
> Smoother. Firmer. Brighter.
> That subtle shift where your skin just... looks better.
> This is what our Collagen Lift Facial is known for.
> ✨ Intro Offer $199
> Spots are limited

Why it works: outcome imagery ("in the mirror"), sensory rhythm (three single words), names the
treatment as a BENEFIT not a device, price + scarcity in two clean lines.

## Example 2 - long-form (problem-led with checklist)

> Loose skin? Fine lines creeping in? Skin not bouncing back like it used to?
> This is where most people start looking at injectables...
> But there's another option.
> Our Skin Tightening Facial works beneath the surface to stimulate your body's natural
> collagen - helping to ✨ firm ✨ smooth ✨ restore glow
> No needles. No harsh lasers. No downtime.
> Just skin that looks fresher, tighter, and more lifted.
> Perfect for:
> ✔ Loose or sagging skin (face, eyes & neck)
> ✔ Fine lines + deeper wrinkles
> ✔ Acne scarring + uneven texture
> ✔ Pigmentation + dull skin
> ✔ Enlarged pores
> Limited Time Offer
> Full Face + Neck Skin Tightening Facial
> $499 (Neck upgrade included - valued at $399)

Why it works: opens with THEIR questions (pain-based hook), acknowledges the injectables thought
then pivots (pattern interrupt), objection kill ("no needles, no harsh lasers, no downtime"),
concern checklist mirrors what they'd type into Google, offer with value anchoring.

## The four tests (every ad must pass all four)

1. It speaks to the problem.
2. It shows the outcome.
3. It removes confusion.
4. It makes it easy to say yes.

They don't sell the treatment. They sell the outcome. Most clinics talk about devices, technology
and features - high-converting ads speak to what the patient actually wants. When your messaging
reflects their thoughts, not your treatment menu, conversion increases.
