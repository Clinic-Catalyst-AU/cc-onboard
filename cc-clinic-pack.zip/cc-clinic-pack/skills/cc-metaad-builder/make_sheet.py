#!/usr/bin/env python3
"""
make_sheet.py - build the STYLED Clinic Catalyst Meta Campaign Details workbook.

Usage:  python3 make_sheet.py <output.xlsx>  < spec.json (stdin)

Spec JSON:
{
  "clinic": "Harbourlight Skin Clinic",
  "suburb": "Williamstown VIC",                 (optional)
  "campaign": "Skin Clarity Consult",           (optional)
  "accent_hex": "#2E6E6A",                      (from brand-guide.md; falls back to CC teal)
  "final_url": "https://...",
  "headlines": [{"text": "..."}, ...],                       (5)
  "hooks": [{"text": "...", "model": "pain"}, ...],          (5, model = neuro-emotive type)
  "primary_texts": [{"text": "..."}, ...],                   (5)
  "cta": "Book Now",
  "triggers": ["10 spots this month", "ends 31 Aug"]         (only TRUE triggers from offers.md)
}

Deterministic on purpose: every clinic gets the same lovely sheet, only the
brand accent and content change. Do not restyle ad hoc in the session.
"""
import json
import sys

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

CC_TEAL = "0F6B5C"
INK = "23302E"
WHITE = "FFFFFF"


def norm_hex(h, fallback=CC_TEAL):
    h = (h or "").strip().lstrip("#")
    return h.upper() if len(h) == 6 else fallback


def tint(hex6, factor=0.88):
    r, g, b = (int(hex6[i:i + 2], 16) for i in (0, 2, 4))
    mix = lambda c: int(round(c + (255 - c) * factor))
    return f"{mix(r):02X}{mix(g):02X}{mix(b):02X}"


def main():
    if len(sys.argv) != 2:
        sys.exit("usage: make_sheet.py <output.xlsx> < spec.json")
    spec = json.load(sys.stdin)
    accent = norm_hex(spec.get("accent_hex"))
    band = tint(accent, 0.90)
    section = tint(accent, 0.72)

    accent_fill = PatternFill("solid", fgColor=accent)
    band_fill = PatternFill("solid", fgColor=band)
    section_fill = PatternFill("solid", fgColor=section)
    thin = Side(style="thin", color=tint(accent, 0.55))
    box = Border(left=thin, right=thin, top=thin, bottom=thin)

    f_title = Font(bold=True, size=16, color=WHITE)
    f_sub = Font(size=10, color=WHITE)
    f_section = Font(bold=True, size=11, color=INK)
    f_head = Font(bold=True, size=10, color=INK)
    f_body = Font(size=11, color=INK)
    f_small = Font(size=9, italic=True, color=INK)

    wb = Workbook()
    ws = wb.active
    ws.title = "Campaign Details"
    ws.sheet_view.showGridLines = False
    for col, w in {"A": 6, "B": 22, "C": 84, "D": 9}.items():
        ws.column_dimensions[col].width = w

    row = 1

    def merged(text, font, fill=None, height=None):
        nonlocal row
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
        c = ws.cell(row=row, column=1, value=text)
        c.font = font
        if fill:
            for col in range(1, 5):
                ws.cell(row=row, column=col).fill = fill
        c.alignment = Alignment(vertical="center", horizontal="left", indent=1)
        if height:
            ws.row_dimensions[row].height = height
        row += 1

    def section_header(label):
        merged(label, f_section, section_fill, 20)

    def table_header(cells):
        nonlocal row
        for i, text in enumerate(cells, start=1):
            c = ws.cell(row=row, column=i, value=text)
            c.font = f_head
            c.fill = band_fill
            c.border = box
        row += 1

    def body_row(cells, zebra_on, tall=False):
        nonlocal row
        for i, val in enumerate(cells, start=1):
            c = ws.cell(row=row, column=i, value=val)
            c.font = f_body
            c.border = box
            c.alignment = Alignment(vertical="top", wrap_text=(i == 3))
            if zebra_on:
                c.fill = band_fill
        if tall:
            ws.row_dimensions[row].height = 58
        row += 1

    clinic = spec["clinic"]
    bits = [b for b in [spec.get("suburb"), spec.get("campaign"), spec.get("final_url")] if b]
    merged(f"{clinic} - Meta Campaign Details", f_title, accent_fill, 30)
    merged(" | ".join(bits) + "   |   Built by Clinic Catalyst", f_sub, accent_fill, 16)
    row += 1

    section_header("HEADLINES - 5 options, circle your top 2")
    table_header(["#", "", "Headline", "Chars"])
    for i, h in enumerate(spec["headlines"], start=1):
        body_row([i, "", h["text"], len(h["text"])], zebra_on=(i % 2 == 0))
    row += 1

    section_header("HOOKS - the first 3 seconds (neuro-emotive models)")
    table_header(["#", "Model", "Hook", ""])
    for i, h in enumerate(spec["hooks"], start=1):
        body_row([i, h.get("model", ""), h["text"], ""], zebra_on=(i % 2 == 0))
    row += 1

    section_header("PRIMARY TEXT - 5 variants (Andromeda-friendly)")
    table_header(["#", "", "Primary text", "Chars"])
    for i, p in enumerate(spec["primary_texts"], start=1):
        body_row([i, "", p["text"], len(p["text"])], zebra_on=(i % 2 == 0), tall=True)
    row += 1

    if spec.get("concepts"):
        section_header("AD CONCEPTS - load these first (Andromeda wants distinct concepts, not tweaks)")
        table_header(["#", "Engine", "Hook + primary text + headline", ""])
        for i, c in enumerate(spec["concepts"], start=1):
            combo = f"HOOK: {c.get('hook','')}\nPRIMARY: {c.get('primary_text','')}\nHEADLINE: {c.get('headline','')}"
            body_row([i, c.get("engine", ""), combo, ""], zebra_on=(i % 2 == 0), tall=True)
        row += 1

    section_header("CALL TO ACTION + CONVERSION TRIGGERS (true triggers only)")
    table_header(["", "Element", "Value", ""])
    body_row(["", "CTA button", spec.get("cta", ""), ""], zebra_on=False)
    for i, t in enumerate(spec.get("triggers", []), start=1):
        body_row(["", f"Trigger {i}", t, ""], zebra_on=(i % 2 == 1))
    body_row(["", "Destination", spec.get("final_url", ""), ""], zebra_on=False)
    row += 1

    merged("AHPRA screen: PASS - outcome-led, no device names, no superlatives, no before/after, "
           "no testimonials, no S4 names or S4 pricing. Draft for human approval.", f_small)

    wb.save(sys.argv[1])
    print(f"styled sheet written: {sys.argv[1]}")


if __name__ == "__main__":
    main()
