---
name: cc-metaad-builder
description: Generate AHPRA-compliant META (Facebook/Instagram) ads for aesthetic and medical clinics - the workshop Campaign Details contract: 5 headline options, 5 neuro-emotive hooks (pain / curiosity / pattern-interrupt), 5 primary text variants (Andromeda-friendly), best CTA + conversion triggers from the offer architecture, outcome-led never device-led, judged against the perfect-ad gold standards. Outputs the fixed file set (campaign CSV + styled Campaign Details sheet) and ALWAYS finishes by opening the branded sheet on screen. Use when you say cc metaad builder, meta ad builder, meta ads for [clinic], facebook ads, instagram ads, ad creative copy. For Google Search ads use /cc-googlead-builder.
user_invocable: true
---

# CC Meta Ad Builder - the Campaign Details contract

Turns a clinic's Business Brain into a complete Meta ads copy package - the exact output the
Day 1 "Ad Creation Framework" session teaches. Written copy only; the visual side is the Canva
ad templates (3 single-image + 3 video, linked on the toolkit) and the video side is /cc-script.

## Inputs (pull from the clinic Business Brain / intake, or ask)


*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/brand-guide.md` (voice spine) + `Business-Brain/offers.md` (the offer) + `Business-Brain/services-machines.md` (treatments and the actual devices/machines) and WRITES to `Ads/` - never into `Business-Brain/`. All paths are relative to your clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If a required file is missing, say which one and offer to run the skill that creates it (no `brand-guide.md` -> run `/cc-brand-guide` first); never fabricate.

- Clinic name, suburb, city - from `Business-Brain/brand-guide.md`.
- Service list - from `Business-Brain/services-machines.md`; flag which are Schedule 4 (anti-wrinkle / botulinum toxin) so pricing is blocked on those.
- USPs / credentials that are TRUE and verifiable (registered nurse, female-led, years open, AHPRA registration) - from the brand guide. Never invent these.
- The offer (e.g. free skin consult) - from `Business-Brain/offers.md`.
- Final URL - the offer's landing page, live in GHL, and it must exist BEFORE the ads. No landing page for this offer yet? PAUSE and ask the user: "This offer has no landing page yet - the ads need one to point at. Want me to build it now with /cc-landing-page [offer] --ghl-offer, or do you have a URL?" Do not silently chain into the landing-page build - the user decides. Never point ads at a homepage and never invent a URL.
- Brand voice notes (from `Business-Brain/brand-guide.md`); any genuine, named, verifiable awards.

## The AHPRA hard rules (screen EVERY line - non-negotiable)

NEVER produce:
- Superlatives: `#1`, `best`, `leading`, `top`, `most effective`, `expert` (therapeutic claims).
- Before/after wording or comparative appearance claims.
- Testimonials / patient endorsements (even paraphrased or invented).
- Guaranteed results / specific outcomes ("look 10 years younger", "wrinkle-free").
- Pricing on Schedule 4 treatments (anti-wrinkle injections). Pricing is fine for non-S4: HIFU, LED, skin needling, facials.
- Safety claims ("safe", "no risk").
- The word "Botox" in copy (trademarked + S4) - use "anti-wrinkle".

USE SPARINGLY (medium risk): "natural-looking results", "experienced injector" (never "expert").

ALWAYS: mirror the search intent in headlines; lead the offer with a low-friction action; only state a credential/USP if true for THAT clinic.

Full traffic-light reference (green / amber / red, with examples) - screen every line against it: `references/ahpra-risk-tiers.md`.


## META ADS MODE (the workshop "Campaign Details" contract)

Trigger: "meta ads for [clinic]", "facebook ads", or the workshop Day 1 ad-creation session.
Reads the same Business Brain files PLUS the offer architecture (`Business-Brain/offers.md` now
carries urgency + scarcity - use them as the conversion triggers).

**Required input: the destination URL** (landing page or lead form). No URL, no ads - ask for it.

**Output contract - generate ALL of this, every time:**
1. **5 headline options** - present all 5, ask them to circle their top 2.
2. **5 hooks using neuro-emotive models** - the first 3 seconds, must stop the scroll. Cover at
   least: a pain-based hook, a curiosity hook, a pattern-interrupt hook (the other 2 free choice).
3. **5 primary text variants** - neuro-emotive models, AHPRA-compliant, and Andromeda-suitable
   (Facebook's algo favours native-feeling, low-friction copy - no link-bait, no wall-of-claims).
4. **Best call to action** + conversion triggers pulled from the offer architecture: limited spots,
   expiry date, bonuses, urgency. Never invent triggers the clinic didn't set.
5. **The Andromeda assembly - 3 distinct ad concepts.** Meta's Andromeda delivery system targets
   by CREATIVE, not audience, and rewards conceptually DIVERSE ads (current practitioner guidance:
   10-15 distinct assets per campaign; creative quality now drives more performance than targeting,
   budget and placement combined). So finish by assembling the 5x5x5 pool into THREE ready-to-load
   ad concepts, each anchored on a different emotional engine (pain / curiosity / pattern-interrupt):
   concept = 1 hook + its best-matched primary text + top headline pairing. The concepts must differ
   in message structure and emotional appeal, not cosmetic tweaks - near-duplicates teach Andromeda
   nothing. Note in the sheet: refresh creative every 2-3 weeks; the leftover pool is the refresh bank.

**Gold-standard examples - read `references/perfect-ad-examples.md` BEFORE generating.** The two
worked examples + don't/do swaps in there are the bar; match their energy and structure, never
copy them verbatim for a client.

**Ad Copy That Works rules (apply to every line):**
- Outcome, never technology. They don't care what device you use - they care how they'll look
  and feel. ❌ "RF Microneedling Treatment" → ✅ "Tighter, brighter skin - no downtime".
- Speak to their reality, not your equipment: "I look tired even when I'm not", "my skin feels
  dull", "I've lost that glow". No device names, no brand names, no acronyms (RF, IPL) in copy.
- The four tests: speaks to the problem / shows the outcome / removes confusion / makes it easy
  to say yes.

**Manual AHPRA compliance check (the final gate, never skipped):**
After generation, re-screen every headline, hook and primary text against the AHPRA hard rules
(see `references/ahpra-risk-tiers.md`) (superlatives, before/after, testimonials, guaranteed outcomes, S4 pricing, "Botox",
safety claims) + `references/ahpra-risk-tiers.md`. Show the screen result to the user - it's a
selling point of the system, not just a safety step: the agent does the regulatory hard work so
the clinic never has to memorise the rules.

## File outputs - the STRICT contract (exactly these, nothing else)

Written to `Ads/` in the clinic workspace. Do NOT produce .md files, notes files, or any other
format - a run that emits anything outside this list is wrong.

1. `Ads/<clinic>-meta-campaign.csv` - plain-data twin: every headline, hook (with model),
   primary text, CTA, trigger and the destination URL, one row each.
2. `Ads/<clinic>-meta-campaign-sheet.xlsx` - THE styled Campaign Details sheet, built with
   `make_sheet.py` from this skill's folder (spec schema documented at the top of the script;
   `accent_hex` from the `## Brand colours` section of `brand-guide.md`). Write the spec to
   `Ads/.meta-spec.json`, run the script, delete the spec file after. Never improvise the
   styling in-session - deterministic script or nothing.

In the chat itself: the 5 headlines / 5 hooks / 5 primary texts presented for the circle-your-top-2
conversation, plus the AHPRA screen result.

## THE FINALE - open the sheet on screen (always, never ask first)

The moment `Ads/<clinic>-meta-campaign-sheet.xlsx` exists, run `open` on it so the branded sheet
lands on screen. This is the payoff moment and it waits on nothing. THEN, with the sheet open,
offer the optional after-step: push it to Google Drive as a native Google Sheet for a shareable
link (base64 upload via the Drive connector) - only after the local open, never before (the
base64 hand-off is the slowest step in the run), and skip the offer if no Drive connector exists.
A run that ends with file paths in the terminal is NOT done.
