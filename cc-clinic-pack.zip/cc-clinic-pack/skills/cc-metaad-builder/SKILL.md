---
name: cc-metaad-builder
description: Generate AHPRA-compliant META (Facebook/Instagram) ads for aesthetic and medical clinics - the workshop Campaign Details contract: 5 headline options, 5 neuro-emotive hooks (pain / curiosity / pattern-interrupt), 5 primary text variants (Andromeda-friendly), best CTA + conversion triggers from the offer architecture, outcome-led never device-led, judged against the perfect-ad gold standards. Use when you say cc metaad builder, meta ad builder, meta ads for [clinic], facebook ads, instagram ads, ad creative copy. For Google Search ads use /cc-googlead-builder.
user_invocable: true
---

# CC Meta Ad Builder - the Campaign Details contract

Turns a clinic's Business Brain into a complete Meta ads copy package - the exact output the
Day 1 "Ad Creation Framework" session teaches. Written copy only; the visual side is the Canva
ad templates (3 single-image + 3 video, linked on the toolkit) and the video side is /cc-script.

## Inputs (pull from the clinic Business Brain / intake, or ask)


*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/brand-guide.md` (voice spine) + `Business-Brain/offers.md` (the offer) + `Business-Brain/services-machines.md` (treatments and the actual devices/machines) and WRITES to `Ads/` - never into `Business-Brain/`. All paths are relative to your clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If a required file is missing, say which one and offer to run the skill that creates it (no `brand-guide.md` -> run `/cc-brand-guide` first); never fabricate.

- Clinic name, suburb, city - from `Business-Brain/brand-guide.md`.
- Service list - from `Business-Brain/services-machines.md`; flag which are Schedule 4 (anti-wrinkle / botulinum toxin) so pricing is blocked on those.
- USPs / credentials that are TRUE and verifiable (registered nurse, female-led, years open, AHPRA registration) - from the brand guide. Never invent these.
- The offer (e.g. free skin consult) - from `Business-Brain/offers.md`.
- Final URL.
- Brand voice notes (from `Business-Brain/brand-guide.md`); any genuine, named, verifiable awards.

## The AHPRA hard rules (screen EVERY line - non-negotiable)

NEVER produce:
- Superlatives: `#1`, `best`, `leading`, `top`, `most effective`, `expert` (therapeutic claims).
- Before/after wording or comparative appearance claims.
- Testimonials / patient endorsements (even paraphrased or invented).
- Guaranteed results / specific outcomes ("look 10 years younger", "wrinkle-free").
- Pricing on Schedule 4 treatments (anti-wrinkle injections). Pricing is fine for non-S4: HIFU, LED, skin needling, facials.
- Safety claims ("safe", "no risk").
- The word "Botox" in copy (trademarked + S4) - use "anti-wrinkle".

USE SPARINGLY (medium risk): "natural-looking results", "experienced injector" (never "expert").

ALWAYS: mirror the search intent in headlines; lead the offer with a low-friction action; only state a credential/USP if true for THAT clinic.

Full traffic-light reference (green / amber / red, with examples) - screen every line against it: `references/ahpra-risk-tiers.md`.


## META ADS MODE (the workshop "Campaign Details" contract)
 (the workshop "Campaign Details" contract)

Trigger: "meta ads for [clinic]", "facebook ads", or the workshop Day 1 ad-creation session.
Reads the same Business Brain files PLUS the offer architecture (`Business-Brain/offers.md` now
carries urgency + scarcity - use them as the conversion triggers).

**Required input: the destination URL** (landing page or lead form). No URL, no ads - ask for it.

**Output contract - generate ALL of this, every time:**
1. **5 headline options** - present all 5, ask them to circle their top 2.
2. **5 hooks using neuro-emotive models** - the first 3 seconds, must stop the scroll. Cover at
   least: a pain-based hook, a curiosity hook, a pattern-interrupt hook (the other 2 free choice).
3. **5 primary text variants** - neuro-emotive models, AHPRA-compliant, and Andromeda-suitable
   (Facebook's algo favours native-feeling, low-friction copy - no link-bait, no wall-of-claims).
4. **Best call to action** + conversion triggers pulled from the offer architecture: limited spots,
   expiry date, bonuses, urgency. Never invent triggers the clinic didn't set.

**Gold-standard examples - read `references/perfect-ad-examples.md` BEFORE generating.** The two
worked examples + don't/do swaps in there are the bar; match their energy and structure, never
copy them verbatim for a client.

**Ad Copy That Works rules (apply to every line):**
- Outcome, never technology. They don't care what device you use - they care how they'll look
  and feel. ❌ "RF Microneedling Treatment" → ✅ "Tighter, brighter skin - no downtime".
- Speak to their reality, not your equipment: "I look tired even when I'm not", "my skin feels
  dull", "I've lost that glow". No device names, no brand names, no acronyms (RF, IPL) in copy.
- The four tests: speaks to the problem / shows the outcome / removes confusion / makes it easy
  to say yes.

**Manual AHPRA compliance check (the final gate, never skipped):**
After generation, re-screen every headline, hook and primary text against the AHPRA hard rules
(see `references/ahpra-risk-tiers.md`) (superlatives, before/after, testimonials, guaranteed outcomes, S4 pricing, "Botox",
safety claims) + `references/ahpra-risk-tiers.md`. Show the screen result to the user - it's a
selling point of the system, not just a safety step: the agent does the regulatory hard work so
the clinic never has to memorise the rules.
