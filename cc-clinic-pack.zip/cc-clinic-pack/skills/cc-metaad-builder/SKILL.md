---
name: cc-metaad-builder
description: Generate AHPRA-compliant META (Facebook/Instagram) ads for aesthetic and medical clinics - the workshop Campaign Details contract: 5 headline options, 5 neuro-emotive hooks (pain / curiosity / pattern-interrupt), 5 primary text variants (Andromeda-friendly), 5 description options (placement-dependent), best CTA + conversion triggers from the offer architecture, outcome-led never device-led, judged against the perfect-ad gold standards. Outputs the fixed file set (campaign CSV + styled Campaign Details sheet) and ALWAYS finishes by opening the branded sheet on screen. Use when you say cc metaad builder, meta ad builder, meta ads for [clinic], facebook ads, instagram ads, ad creative copy. For Google Search ads use /cc-googlead-builder.
user_invocable: true
---

# CC Meta Ad Builder - the Campaign Details contract

Turns a clinic's Business Brain into a complete Meta ads copy package - the exact output the
Day 1 "Ad Creation Framework" session teaches. Written copy only; the visual side is the Canva
ad templates (3 single-image + 3 video, linked on the toolkit) and the video side is /cc-script.

## Inputs (pull from the clinic Business Brain / intake, or ask)


*File contract* - this skill follows the Business Brain File Contract (your workspace `CLAUDE.md` documents it). It READS `Business-Brain/resonance-messaging.md` (the emotional source of truth - see NEURO-EMOTIVE WIRING below) + `Business-Brain/brand-guide.md` (voice spine) + `Business-Brain/offers.md` (the offer) + `Business-Brain/services-machines.md` (treatments and the actual devices/machines) and WRITES to `Ads/` - never into `Business-Brain/`. All paths are relative to your clinic workspace (`~/Clinic/`) - never hardcode an absolute path. If a required file is missing, say which one and offer to run the skill that creates it (no `brand-guide.md` -> run `/cc-brand-guide` first); never fabricate.

- Clinic name, suburb, city - from `Business-Brain/brand-guide.md`.
- Service list - from `Business-Brain/services-machines.md`; flag which are Schedule 4 (anti-wrinkle / botulinum toxin) so pricing is blocked on those.
- USPs / credentials that are TRUE and verifiable (registered nurse, female-led, years open, AHPRA registration) - from the brand guide. Never invent these.
- The offer (e.g. free skin consult) - from `Business-Brain/offers.md`.
- Final URL - FIRST check `Business-Brain/offers.md` for a `Landing page:` line under this offer (that is where /cc-landing-page records the published GHL page URL) and use it. Otherwise: the offer's landing page, live in GHL, and it must exist BEFORE the ads. No landing page for this offer yet? PAUSE and ask the user: "This offer has no landing page yet - the ads need one to point at. Want me to build it now with /cc-landing-page [offer] --ghl-offer, or do you have a URL?" Do not silently chain into the landing-page build - the user decides. Never point ads at a homepage and never invent a URL.
- Brand voice notes (from `Business-Brain/brand-guide.md`); any genuine, named, verifiable awards.

## NEURO-EMOTIVE WIRING (mandatory - this is what makes the ad land, not read like any clinic)

Run the shared engine before writing a line: `cc-resonance/references/neuro-emotive-engine.md` (installed alongside this skill). In short:
1. READ `Business-Brain/resonance-messaging.md` - the emotional stack, the arc, the OPEN/CLOSE language bank, the headline angles, the proof map - as well as `brand-guide.md`. If `resonance-messaging.md` is missing, offer `/cc-resonance`; never generate off the brand-guide alone (that is what makes ads thin).
2. APPLY the 21 neuro-emotive models (`cc-resonance/references/model-library.md`), mapped to each part of the ad:
   - *hook / scroll-stopper* (first line of primary text): Curiosity Spark, Empathy Echo, Belonging Trigger
   - *primary text / body*: Pain Diffuser, Desire Dial (how she wants to feel), Emotional Proof, Believability Bridge (contrast; never an injectable/S4 before/after in public ads)
   - *CTA / close*: Ownership Shift (soft, true urgency only), Guided Choice Maker, Trust-Through-Transparency
   - *trust line*: Prestige Magnet ("has a special interest in", never expert), Voiceprint Precision (calm, no hype)
   - the 5 hooks in the output contract ARE the neuro-emotive hooks - pull phrasing from `cc-hook/references/hook-templates.md`, each tagged with the model it fires.
3. GROUND every line in the clinic's real offer (`offers.md`) and their OPEN language bank. You should be able to point at any headline, hook or primary text and name the model firing AND the OPEN word it used. A few generic sentences that ignore the resonance doc is a FAILED run - regenerate.

## The AHPRA hard rules (screen EVERY line - non-negotiable)

NEVER produce:
- Superlatives - two tiers, do not blanket-ban. HARD-BANNED (the actual breach): `#1`, `best`, `most effective`, `safe`, `painless`, `risk-free`, and `expert`/`specialist` unless the practitioner holds that registration. DISCRETIONARY (puffery, the clinic's call, not a breach): `leading`, `top`, `expertise`, `premium`, `trusted`, `boutique`. "Anti-ageing" is ALLOWED - use with care, not banned.
- Before/after images: injectable (Schedule 4) before/afters must NEVER appear in public advertising - they are permitted only in direct channels (email, or after a consult). Skin-treatment before/afters (non-Schedule-4 - IPL, skin needling, LED, HIFU, facials, peels) ARE allowed, provided they are genuine, consented, realistic (same lighting, not misleading) and never framed as a guaranteed result. Always defer to the clinic's own resonance-messaging.md / brand-guide.md boundaries (some brands use none at all). Never a patient testimonial that claims a treatment result.
- Testimonials / patient endorsements (even paraphrased or invented).
- Guaranteed results / specific outcomes ("look 10 years younger", "wrinkle-free").
- Pricing on Schedule 4 treatments (anti-wrinkle injections). Pricing is fine for non-S4: HIFU, LED, skin needling, facials.
- Safety claims ("safe", "no risk").
- The word "Botox" in copy (trademarked + S4) - use "anti-wrinkle".

USE SPARINGLY (medium risk): "natural-looking results", "experienced injector" (never "expert").

ALWAYS: mirror the search intent in headlines; lead the offer with a low-friction action; only state a credential/USP if true for THAT clinic.

Full traffic-light reference (green / amber / red, with examples) - screen every line against it: `references/ahpra-risk-tiers.md`.


## META ADS MODE (the workshop "Campaign Details" contract)

Trigger: "meta ads for [clinic]", "facebook ads", or the workshop Day 1 ad-creation session.
Reads the same Business Brain files PLUS the offer architecture (`Business-Brain/offers.md` now
carries urgency + scarcity - use them as the conversion triggers).

**Required input: the destination URL** (landing page or lead form). No URL, no ads - ask for it.

**Output contract - generate ALL of this, every time:**
1. **5 headline options** - present all 5, ask them to circle their top 2. This is Meta's *Headline*
   box (the bold line under the media) - NOT the scroll-stopper; the scroll-stopper is the hook, and it
   lives in the first line of the primary text.
2. **5 hooks using neuro-emotive models** - the first 3 seconds, must stop the scroll. Cover at
   least: a pain-based hook, a curiosity hook, a pattern-interrupt hook (the other 2 free choice).
   The chosen hook goes in the FIRST LINE of the primary text (or the video open) - not a separate Meta box.
3. **5 primary text variants** - neuro-emotive models, AHPRA-compliant, and Andromeda-suitable
   (Facebook's algo favours native-feeling, low-friction copy - no link-bait, no wall-of-claims).
   This is Meta's *Primary text* box (the main body above the media).
4. **5 description variants** - the short line under the headline that shows on SOME placements
   (feed, right column) but NOT on Stories/Reels. Punchy, ideally <= ~27 chars (Meta truncates long
   ones), AHPRA-compliant. This is Meta's *Description* box - Meta simply drops it on placements that
   don't show it, so it's safe to always supply.
That is the whole deliverable - the four blocks above map exactly to Meta's real boxes (Headline,
Primary text, Description) plus the hook that opens the primary text. Two things are deliberately NOT
generated here:
- *The CTA button* is a fixed Meta dropdown the clinic picks in-platform (usually Book Now for a
  booking page, Get Offer for a lead form) - not copy you write, so do not output one.
- *No "ad concepts" step* - the 5 headlines / 5 hooks / 5 primary texts / 5 descriptions ARE the set
  the clinic loads straight into Meta. Do not assemble or present separate concept combinations.
Where the offer has REAL urgency or scarcity (a true intro-price window, a genuine bonus, real limited
spots from `offers.md`), weave it straight INTO the primary text - never a separate section, never invented.

**Gold-standard examples - read `references/perfect-ad-examples.md` BEFORE generating.** It holds the
AD ANATOMY, the top-performing exemplars, and the two priority techniques to apply:
- *Headline formula:* every headline calls out the PROBLEM together WITH the OFFER (concern named + the
  offer / intro price / "save X"), e.g. "Say Goodbye to Sagging Skin! Save 50% Off". Not a bare price,
  not a pure curiosity line.
- *Value stacking:* in the primary text, list the offer's REAL inclusions as a 🔥/✔ stack (consult,
  each treatment step, bonus/upgrade, the plan) so the price feels like a bargain, then the price with a
  true "normally $X" anchor. Never invent an inclusion.
Match the energy and structure; never copy a client's ad verbatim, and screen every line through AHPRA.

**Ad Copy That Works rules (apply to every line):**
- Outcome, never technology. They don't care what device you use - they care how they'll look
  and feel. ❌ "RF Microneedling Treatment" → ✅ "Tighter, brighter skin - no downtime".
- Speak to their reality, not your equipment: "I look tired even when I'm not", "my skin feels
  dull", "I've lost that glow". No device names, no brand names, no acronyms (RF, IPL) in copy.
- The four tests: speaks to the problem / shows the outcome / removes confusion / makes it easy
  to say yes.

**Manual AHPRA compliance check (the final gate, never skipped):**
After generation, re-screen every headline, hook, primary text and description against the AHPRA hard rules
(see `references/ahpra-risk-tiers.md`) (superlatives, before/after, testimonials, guaranteed outcomes, S4 pricing, "Botox",
safety claims) + `references/ahpra-risk-tiers.md`. Show the screen result to the user - it's a
selling point of the system, not just a safety step: the agent does the regulatory hard work so
the clinic never has to memorise the rules.

## File outputs - the STRICT contract (exactly these, nothing else)

Written to `Ads/` in the clinic workspace. Do NOT produce .md files, notes files, or any other
format - a run that emits anything outside this list is wrong.

1. `Ads/<clinic>-meta-campaign.csv` - plain-data twin: every headline, hook (with model),
   primary text, description and the destination URL, one row each.
2. `Ads/<clinic>-meta-campaign-sheet.xlsx` - THE styled Campaign Details sheet, built with
   `make_sheet.py` from this skill's folder (spec schema documented at the top of the script;
   `accent_hex` from the `## Brand colours` section of `brand-guide.md`). Write the spec to
   `Ads/.meta-spec.json`, run the script, delete the spec file after. Never improvise the
   styling in-session - deterministic script or nothing.

In the chat itself: the 5 headlines / 5 hooks / 5 primary texts / 5 descriptions presented for the circle-your-top-2
conversation, plus the AHPRA screen result.

## THE FINALE - open the sheet on screen (always, never ask first)

The moment `Ads/<clinic>-meta-campaign-sheet.xlsx` exists, run `open` on it so the branded sheet
lands on screen. This is the payoff moment and it waits on nothing. THEN, with the sheet open,
offer the optional after-step: push it to Google Drive as a native Google Sheet for a shareable
link (base64 upload via the Drive connector) - only after the local open, never before (the
base64 hand-off is the slowest step in the run), and skip the offer if no Drive connector exists.
A run that ends with file paths in the terminal is NOT done.
