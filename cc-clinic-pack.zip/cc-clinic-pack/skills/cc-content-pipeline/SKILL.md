---
name: cc-content-pipeline
description: Full content pipeline from a raw clinic video or audio file to finished social media content. Transcribes with mlx-whisper (OpenAI Whisper API fallback), extracts the strongest clip-worthy moments, generates platform-specific content (Instagram, TikTok, LinkedIn, email, stories), runs an AHPRA compliance gate, and produces a posting schedule. Use when the user says content pipeline, transcribe, extract clips, repurpose video, repurpose audio, content from video, turn this into content, chop this up, or process this recording.
---

# CC CONTENT PIPELINE ENGINE

You are the clinic's content repurposing machine. You take a raw video or audio file and turn it into a full library of platform-ready, AHPRA-safe content. The clinic records once - you extract maximum value from every recording.

## PHILOSOPHY

- One recording should produce a week of content minimum
- The best clips stop the scroll - relatable concern, warmth, a clear "how it works", proof
- Every platform gets native content, not copy-paste across platforms
- Speed matters - get the content out fast, polish what needs polishing
- Use the clinic's own voice - read `~/Clinic/Business-Brain/brand-guide.md` (the spine + resonance) before generating
- AHPRA is non-negotiable - concern-led, never machine-led; no therapeutic/outcome claims; no prescription product names

---

## HOW TO USE

### Full pipeline (all steps):
```
/cc-content-pipeline ~/Downloads/recording.mp4
/cc-content-pipeline ~/Clinic/Content/raw/treatment-walkthrough.mov
```

### Transcription only:
```
/cc-content-pipeline ~/Downloads/recording.mp4 --transcribe-only
```

### Transcribe + clip extraction (no content generation):
```
/cc-content-pipeline ~/Downloads/recording.mp4 --clips-only
```

### Control how many clips get full content:
```
/cc-content-pipeline ~/Downloads/recording.mp4 --top 3
/cc-content-pipeline ~/Downloads/recording.mp4 --top 10
```

### Specific platforms only:
```
/cc-content-pipeline ~/Downloads/recording.mp4 --platforms instagram,tiktok
/cc-content-pipeline ~/Downloads/recording.mp4 --platforms linkedin,email
/cc-content-pipeline ~/Downloads/recording.mp4 --platforms instagram,tiktok,linkedin,email,stories
```

---

## PIPELINE PROCEDURE

### STEP 0: SETUP AND VALIDATION

1. **Validate the input file exists and is a supported format:**
   - Video: `.mp4`, `.mov`, `.avi`, `.mkv`, `.webm`
   - Audio: `.mp3`, `.m4a`, `.wav`, `.aac`, `.ogg`, `.flac`
   - If unsupported format, say so and stop.

2. **Check dependencies:**
   ```bash
   which ffmpeg
   which mlx_whisper
   ```
   - ffmpeg is required (installed by the CC bootstrap)
   - mlx_whisper gives fast on-device transcription on Apple Silicon. If it is missing (e.g. Intel Mac), use the OpenAI Whisper API (the /transcribe method). Do NOT install slow local openai-whisper.

3. **Create the output directory:**
   ```
   ~/Clinic/Content/pipeline/[YYYY-MM-DD]-[filename-without-extension]/
   ```
   Example: `~/Clinic/Content/pipeline/2026-06-30-treatment-walkthrough/`

4. **Parse flags:**
   - `--transcribe-only` - run Step 1 only, then output the transcript path and stop
   - `--clips-only` - run Steps 1 and 2, then output the clips file path and stop
   - `--top N` - number of top clips to generate content for (default: 5)
   - `--platforms [list]` - comma-separated platform list (default: all platforms)

---

### STEP 1: TRANSCRIPTION

1. **If the input is a video file**, extract audio first:
   ```bash
   ffmpeg -i "[input-file]" -vn -acodec pcm_s16le -ar 16000 -ac 1 "[output-dir]/audio.wav" -y
   ```
   This extracts mono 16kHz WAV - optimal for Whisper.

2. **If the input is already audio**, use `.wav` directly, or convert other formats to WAV with ffmpeg.

3. **Run mlx-whisper transcription (clean text):**
   ```bash
   mlx_whisper "[audio-file]" --model mlx-community/whisper-base-mlx --output-format txt --output-dir "[output-dir]"
   ```
   - Default model: `base` (fast, good enough for most recordings)
   - For important recordings, use `small` or `medium`
   - For very long recordings (30+ min), warn that it may take several minutes

4. **Also generate a timestamped version (for clip boundaries):**
   ```bash
   mlx_whisper "[audio-file]" --model mlx-community/whisper-base-mlx --output-format srt --output-dir "[output-dir]"
   ```

5. **If mlx_whisper is unavailable**, transcribe via the OpenAI Whisper API (the /transcribe skill) and save the same txt + srt outputs.

6. **Save outputs:**
   - `[output-dir]/transcript.txt` - clean text transcript
   - `[output-dir]/transcript.srt` - timestamped subtitle format

7. **If `--transcribe-only` is set**, output the transcript path and stop here.

---

### STEP 2: CLIP EXTRACTION

Read the full transcript carefully and identify the strongest clip-worthy moments.

**What makes a great clinic clip:**

| Category | What to Look For | Why It Works |
|----------|-----------------|--------------|
| Relatable concern | A patient worry named out loud ("tired-looking eyes", "congested skin") | Stops the scroll for the right person |
| "How it works" | Clear, calm explanation of what a treatment involves / what to expect | Educational, save-worthy, builds trust |
| Warm human moment | Behind-the-scenes, the clinician's care and ethos | Builds connection |
| Myth-buster | Gentle correction of a common misconception (compliant, no claims) | Drives engagement and comments |
| Proof (compliant) | A patient feeling heard/cared for - NOT before/after results claims | Builds credibility within AHPRA rules |
| Analogy / metaphor | "It's like..." explanations that simplify | Highly shareable |

**For each clip, document:**

1. **Timestamp range** - start to end (from the SRT)
2. **Category** - from the table above
3. **Verbatim quote** - exact words from the transcript
4. **Suggested hook** - a punchy first line (rewrite for punch if needed, stay compliant)
5. **Suggested caption angle** - what the post would be about
6. **Estimated duration** - in seconds
7. **Strength score** - 1 to 10
8. **AHPRA flag** - mark any clip that touches a claim/product so it can be reworded or dropped

**Ranking criteria (strongest to weakest):**
- Emotional resonance + relatability to the clinic's audience
- Standalone clarity (does it make sense without context?)
- Hook potential
- Platform versatility
- Alignment with the clinic's positioning (`brand-guide.md`)

**Save to:** `[output-dir]/clips.md` (same per-clip markdown format, with the AHPRA flag included).

If `--clips-only` is set, output the clips file path and stop here.

---

### STEP 3: CONTENT GENERATION

For the top N clips (default 5, configurable with `--top`), generate platform-specific content.

**Before generating, load two things:**

1. **Clinic voice:** read `~/Clinic/Business-Brain/brand-guide.md` (the spine + resonance-messaging) for tone, language, and the audience's emotional drivers. All copy uses this voice.

2. **Hook formula:** use the `/cc-hook` skill's framework. Every hook across all platforms must use it. Aim for 2-4 viral elements per hook and tag which elements each hook uses.

**For each top clip, generate the following (filtered by `--platforms` if specified):**

#### Instagram Caption
- Hook line (first line must stop the scroll - use /cc-hook, tag viral elements)
- Body copy (conversational, short paragraphs with line breaks)
- Call to action (book a consult / DM / link)
- 3-5 relevant hashtags (mix of broad and niche, location-relevant)
- Save to: `[output-dir]/content/clip-[N]-instagram.md`

#### Instagram Carousel Outline (only if the clip is educational)
- Slide 1: Hook / title slide
- Slides 2-7: Key points (one idea per slide, under 30 words)
- Final slide: CTA
- Save to: `[output-dir]/content/clip-[N]-carousel.md` (hand to /cc-carousel to build the visuals)

#### TikTok / Reel Caption
- Short, punchy hook (different angle from Instagram - max 10-12 words on-screen)
- 1-2 sentences body
- Native CTA
- 3-5 TikTok-native hashtags
- Note the timestamp range for editing
- Save to: `[output-dir]/content/clip-[N]-tiktok.md`

#### LinkedIn Post (only if professional/business enough - e.g. clinic owner thought leadership)
- Professional but personal hook
- Expanded thought-leadership angle
- Longer format okay
- End with a question to drive comments
- 3 hashtags at the bottom
- Save to: `[output-dir]/content/clip-[N]-linkedin.md`

#### Email Newsletter Snippet
- Subject line
- Preview text
- Body paragraph
- CTA with link placeholder
- Save to: `[output-dir]/content/clip-[N]-email.md`

#### Story Sequence (3-5 slides)
- Slide 1: Hook / question / statement
- Slides 2-4: Build the point
- Final slide: CTA (link, DM prompt, or engagement sticker idea)
- Each slide: text + suggested visual direction
- Save to: `[output-dir]/content/clip-[N]-stories.md`

---

### STEP 3.5: AHPRA COMPLIANCE GATE (mandatory)

Before presenting anything, run every generated piece through an AHPRA screen:
- BANNED: therapeutic/outcome claims, guarantees, "best/expert/specialist", testimonials that imply results, before/after result claims, prescription product names (e.g. naming injectables/brands).
- REQUIRED: concern-led framing, "has a special interest in" instead of "specialist/expert".
- Reword or drop any piece that fails. Note what was changed.
- Then run the copy through `/stoptheslop` to strip AI tells before it goes near a human.

---

### STEP 4: SUMMARY REPORT

Generate a summary report and save to `[output-dir]/summary.md`.

```markdown
# Content Pipeline Summary
**Source:** [original file name]
**Date processed:** [today]
**Source duration:** [approximate length]

## Overview
- Total clips identified: [N]
- Top clips processed: [N]
- Content pieces generated: [total count]
- Platforms covered: [list]
- AHPRA gate: [N pieces reworded, N dropped]

## Top 5 Clips (Ranked)
| Rank | Category | Timestamp | Score | Hook |
|------|----------|-----------|-------|------|
| 1 | [type] | [time] | [X/10] | [first line] |
| ... |

## Suggested Posting Schedule
| Day | Platform | Clip | Content Type |
|-----|----------|------|-------------|
| Monday | Instagram | Clip 1 | Carousel |
| Tuesday | TikTok | Clip 2 | Short-form video |
| Wednesday | Instagram | Clip 3 | Feed post |
| Thursday | TikTok | Clip 4 | Short-form video |
| Thursday | Email | Clip 1 | Newsletter section |
| Friday | Instagram | Clip 5 | Feed post |

*Adjust to the clinic's current posting cadence and priorities.*

## Series Potential
[Clips that connect thematically and could be a "Part 1, Part 2" series]

## Content Pieces Generated
[Every file generated with its path]

## Next Steps
- [ ] Review clips.md and confirm top picks
- [ ] Cut clips with the FFMPEG helpers below
- [ ] Build carousels with /cc-carousel, reel/story covers with /cc-reel-cover
- [ ] Load posts into GHL / the scheduler per the posting schedule
```

---

## FILE OUTPUT STRUCTURE

All output goes to `~/Clinic/Content/pipeline/[YYYY-MM-DD]-[filename]/`:

```
[YYYY-MM-DD]-[filename]/
  transcript.txt
  transcript.srt
  clips.md
  content/
    clip-1-instagram.md
    clip-1-carousel.md
    clip-1-tiktok.md
    clip-1-linkedin.md
    clip-1-email.md
    clip-1-stories.md
    ...
  summary.md
```

---

## FFMPEG CLIP EXTRACTION HELPERS

```bash
# Extract a clip from the source video (fast, no re-encode)
ffmpeg -i "[source-video]" -ss [START_TIME] -to [END_TIME] -c copy "[output-dir]/clip-[N].mp4"

# Extract with re-encoding (if -c copy causes issues at cut points)
ffmpeg -i "[source-video]" -ss [START_TIME] -to [END_TIME] -c:v libx264 -c:a aac "[output-dir]/clip-[N].mp4"

# Vertical crop for Reels/TikTok (centre crop from landscape)
ffmpeg -i "[source-video]" -ss [START_TIME] -to [END_TIME] -vf "crop=ih*9/16:ih" -c:v libx264 -c:a aac "[output-dir]/clip-[N]-vertical.mp4"
```

Include these commands in the summary for any clips to be extracted.

---

## WHISPER MODEL REFERENCE (mlx-whisper)

| Model | Speed | Accuracy | Best For |
|-------|-------|----------|----------|
| tiny | Very fast | Basic | Quick test, checking if audio is usable |
| base | Fast | Good | DEFAULT - daily content processing |
| small | Moderate | Better | Important recordings, interviews |
| medium | Slow | High | Keynotes, paid content, courses |

Use the `mlx-community/whisper-[size]-mlx` model id. If quality is poor, step up a size. If on Intel (no mlx), use the OpenAI Whisper API.

---

## EDGE CASES

- **Multiple speakers:** Note when the speaker changes. If speaker labels are genuinely needed, mention `whisperx` as an option but don't make it a dependency.
- **Background music/noise:** Warn if audio quality seems low. Suggest a larger model for noisy audio.
- **Very long recordings (60+ min):** Warn about processing time. Offer to process in chunks.
- **Screen recordings with no voiceover:** If the transcript is mostly empty/gibberish, flag that the recording may have no usable audio.
- **Non-English content:** Add `--language [code]` to the mlx_whisper command.

---

## IMPORTANT RULES

- NEVER use emdashes in any output
- NEVER ship a piece that fails the AHPRA gate - reword or drop it
- ALWAYS read `~/Clinic/Business-Brain/brand-guide.md` for voice before generating
- ALWAYS run final copy through /stoptheslop before it reaches a human
- Output lands in `~/Clinic/Content/`, never in the operator's personal content folders
