#!/usr/bin/env python3
"""
CC Newsletter Engine - load this month's 4 weekly newsletter emails into the
clinic's GHL newsletter template shells, via the two-step GHL email API.
Stdlib only (urllib).

The clinic's snapshot ships 4 shells the newsletter workflow already points at:
  CC Newsletter WK1 - Educate
  CC Newsletter WK2 - Connect
  CC Newsletter WK3 - Proof
  CC Newsletter WK4 - Offer
This matches them by title and overwrites their content (step 2 of the API
recipe), so the workflow itself never needs touching. If a shell is missing
(e.g. pre-snapshot location), --create makes it - then the owner must point
the matching workflow send step at it ONCE in the GHL UI.

Usage:
  # dry run (default) - matches shells, validates, writes nothing:
  python3 push_newsletter.py newsletter.json --location <LOCATION_ID>
  # actually push:
  python3 push_newsletter.py newsletter.json --location <LOCATION_ID> --push
  # create any missing shells while pushing:
  python3 push_newsletter.py newsletter.json --location <LOCATION_ID> --push --create

Auth: PIT from $GHL_PIT (the clinic's token; or --pit). $CC_GHL_PIT also
accepted (operator). A browser User-Agent is sent (a plain UA gets Cloudflare
1010-banned). Never report pushed without the verify step passing.

newsletter.json:
  {"month":"2026-08","messages":[
    {"id":"wk1","template_title":"CC Newsletter WK1 - Educate",
     "subject":"...","preview":"...","html":"<p>...</p>"}, ...]}
"""
import sys, os, json, argparse, hashlib, urllib.request, urllib.error

BASE = "https://services.leadconnectorhq.com"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

SHELL_TITLES = [
    "CC Newsletter WK1 - Educate",
    "CC Newsletter WK2 - Connect",
    "CC Newsletter WK3 - Proof",
    "CC Newsletter WK4 - Offer",
]


def api(method, path, pit, body=None):
    url = BASE + path
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {pit}")
    req.add_header("Version", "2021-07-28")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", UA)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        print(f"  ! HTTP {e.code} on {method} {path}: {e.read().decode()[:300]}")
        return None


def fetch_preview(url):
    req = urllib.request.Request(url)
    req.add_header("User-Agent", UA)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.read().decode(errors="replace")
    except Exception as e:
        print(f"  ! preview fetch failed: {e}")
        return ""


def list_builders(location, pit):
    listing = api("GET", f"/emails/builder?locationId={location}&limit=100", pit)
    if not listing:
        return None
    builders = listing.get("builders", listing.get("data", []))
    return {b.get("name", b.get("title", "")): b for b in builders}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("messages")
    ap.add_argument("--location", required=True)
    ap.add_argument("--pit", default=os.environ.get("GHL_PIT") or os.environ.get("CC_GHL_PIT"))
    ap.add_argument("--push", action="store_true", help="actually write (default: dry run)")
    ap.add_argument("--create", action="store_true", help="create any missing shells (step 1 of the API)")
    args = ap.parse_args()

    if not args.pit:
        print("No PIT. Set $GHL_PIT (the clinic's GHL token) or pass --pit."); sys.exit(2)

    data = json.load(open(args.messages))
    msgs = data.get("messages", [])
    if not msgs:
        print("No messages in JSON."); sys.exit(2)
    for m in msgs:
        for k in ("id", "template_title", "subject", "html"):
            if not m.get(k):
                print(f"Message {m.get('id','?')} missing '{k}'."); sys.exit(2)
        if m["template_title"] not in SHELL_TITLES:
            print(f"Message {m['id']}: unknown shell title '{m['template_title']}'. "
                  f"Must be one of: {SHELL_TITLES}"); sys.exit(2)

    # Preflight: booking_link. Every email CTA resolves {{custom_values.booking_link}} -
    # if it is missing or still the master-snapshot placeholder, the clinic's emails
    # would point readers at the WRONG calendar. Hard stop; set it, then re-run.
    MASTER_PLACEHOLDER = "eaHKZFycJvsXuslb3RvJ"
    cv = (api("GET", f"/locations/{args.location}/customValues", args.pit) or {}).get("customValues", [])
    bl = next((v.get("value", "") for v in cv if v.get("name") == "booking_link"), None)
    if bl is None or not bl.strip():
        print("!! STOP: the custom value 'booking_link' is not set in this location.\n"
              "   Every email CTA points at it. Set it to the clinic's real booking URL\n"
              "   (Settings > Custom Values, or tell Claude the URL and it will set it by API),\n"
              "   then re-run."); sys.exit(1)
    if MASTER_PLACEHOLDER in bl:
        print("!! STOP: 'booking_link' still holds the master-snapshot placeholder URL -\n"
              "   this clinic's emails would send readers to the WRONG booking calendar.\n"
              "   Set it to the clinic's real booking URL, then re-run."); sys.exit(1)

    print(f"=== Matching {len(msgs)} newsletter emails to shells in {args.location} ===")
    by_title = list_builders(args.location, args.pit)
    if by_title is None:
        print("Could not list builders. Check PIT + location."); sys.exit(1)

    plan, missing = [], []
    for m in msgs:
        b = by_title.get(m["template_title"])
        tid = b.get("id") if b else None
        print(f"  [{'OK' if tid else 'NOT FOUND'}] {m['template_title']} -> {tid}")
        (plan if tid else missing).append((m, tid))

    if missing and not args.create:
        print(f"\n{len(missing)} shell(s) not found. Is the CC snapshot installed here? "
              "Re-run with --create to make them (then point the workflow send steps at "
              "them once in the GHL UI).")
        sys.exit(1)

    if not args.push:
        print(f"\nDRY RUN: {len(plan)} matched"
              + (f", {len(missing)} would be created" if missing else "")
              + ". Re-run with --push to write.")
        sys.exit(0)

    if missing and args.create:
        print(f"\n=== Creating {len(missing)} missing shell(s) ===")
        created = []
        for m, _ in missing:
            res = api("POST", "/emails/builder", args.pit, {
                "locationId": args.location, "type": "html",
                "title": m["template_title"], "updatedBy": "cc-newsletter-engine",
                "builderVersion": "2", "isPlainText": False,
            })
            tid = (res or {}).get("id") or (res or {}).get("redirect", "").split("/")[-1] or None
            if not tid:
                print(f"  ! create failed for {m['template_title']}"); sys.exit(1)
            print(f"  created: {m['template_title']} -> {tid}")
            print(f"    -> REMEMBER: point the matching workflow send step at this template (GHL UI, one time).")
            created.append((m, tid))
        plan += created

    print(f"\n=== Pushing this month's copy into {len(plan)} shells ===")
    markers = {}
    ok = 0
    for m, tid in plan:
        marker = "ccne-" + hashlib.sha1((m["id"] + m["html"]).encode()).hexdigest()[:12]
        markers[tid] = (m, marker)
        res = api("POST", "/emails/builder/data", args.pit, {
            "locationId": args.location, "templateId": tid, "updatedBy": "cc-newsletter-engine",
            "html": m["html"] + f"\n<!-- {marker} -->", "editorType": "html", "isPlainText": False,
            "subject": m["subject"], "previewText": m.get("preview", ""),
        })
        if res is not None:
            ok += 1
            print(f"  pushed: {m['template_title']}")
    if ok != len(plan):
        print(f"\nOnly {ok}/{len(plan)} pushed - fix before verifying."); sys.exit(1)

    print("\n=== Updating subject custom values (the workflow's subject lines) ===")
    # The workflow's Send Email steps use {{ custom_values.nl_wkN_subject }} as the
    # subject (GHL refuses a blank action subject), so the monthly refresh must
    # update these too or clinics would edit four workflow steps by hand.
    cv_res = api("GET", f"/locations/{args.location}/customValues", args.pit) or {}
    cv_by_name = {v.get("name"): v for v in cv_res.get("customValues", [])}
    cv_ok = 0
    for m, tid in plan:
        cv_name = f"nl_{m['id']}_subject"
        body = {"name": cv_name, "value": m["subject"]}
        existing_cv = cv_by_name.get(cv_name)
        if existing_cv:
            res = api("PUT", f"/locations/{args.location}/customValues/{existing_cv['id']}", args.pit, body)
        else:
            res = api("POST", f"/locations/{args.location}/customValues", args.pit, body)
        if res is not None:
            cv_ok += 1
            print(f"  subject set: {cv_name} = {m['subject'][:60]}")
    if cv_ok != len(plan):
        print(f"\nOnly {cv_ok}/{len(plan)} subject values written - fix before verifying."); sys.exit(1)
    cv_after = {v.get("name"): v.get("value") for v in
                (api("GET", f"/locations/{args.location}/customValues", args.pit) or {}).get("customValues", [])}
    for m, tid in plan:
        if cv_after.get(f"nl_{m['id']}_subject") != m["subject"]:
            print(f"  ! subject value verify FAILED for nl_{m['id']}_subject"); sys.exit(1)
    print(f"  {cv_ok}/{len(plan)} subject values verified.")

    print("\n=== Verifying via previewUrl (the copy must actually be live) ===")
    by_title = list_builders(args.location, args.pit) or {}
    by_id = {b.get("id"): b for b in by_title.values()}
    verified = 0
    for tid, (m, marker) in markers.items():
        purl = (by_id.get(tid) or {}).get("previewUrl")
        if not purl:
            print(f"  ! no previewUrl for {m['template_title']}"); continue
        if marker in fetch_preview(purl):
            verified += 1
            print(f"  VERIFIED: {m['template_title']}")
        else:
            print(f"  ! marker not found in preview for {m['template_title']}")

    print(f"\n{verified}/{len(plan)} verified live.")
    sys.exit(0 if verified == len(plan) else 1)


if __name__ == "__main__":
    main()
