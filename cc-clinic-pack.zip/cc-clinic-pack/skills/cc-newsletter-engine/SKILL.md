---
name: cc-newsletter-engine
description: Monthly refresh for the clinic's weekly newsletter - writes the month's 4 editions (one per content pillar - Educate, Connect, Proof, Offer) in the clinic's voice from the Business Brain, aligned to the month's hero offer, SHOWS all four on screen for approval, then on the owner's yes loads them (bodies AND subject lines) into the 4 GHL newsletter template shells via the email API and verifies they landed - so the newsletter workflow NEVER needs rebuilding or editing. Use whenever the clinic says newsletter engine, refresh the newsletter, load this month's newsletter, monthly newsletter, newsletter refresh, next month's emails, new offer for the newsletter, or mentions a new month starting while a newsletter workflow is running. Companion to /cc-follow-up-agent (the ladder) and /cc-content-engine (organic social) - same pillars, one message everywhere.
---

# CC Newsletter Engine - The Monthly Newsletter Refresh

The clinic's newsletter workflow in GHL sends one email a week, forever. The workflow never changes - it always sends the same four template shells. THIS skill is the monthly refresh: it writes the month's four editions in the clinic's voice and loads them into those shells through the GHL email API. Run it once a month; the workflow does the rest.

*Why it exists* - GHL workflows are browser-only (no API), so any system where the content lives inside the workflow forces the clinic to rebuild it every month. The shells break that: content lives in 4 named email templates, the workflow just points at them, and this skill repopulates them by API. Nobody opens the workflow again.

*The shell contract (fixed names - never rename):*

| Shell | Pillar | Job |
|---|---|---|
| `CC Newsletter WK1 - Educate` | Educate (Know) | Teach one thing about the month's concern, plain language, real analogy |
| `CC Newsletter WK2 - Connect` | Connect (Like) | The human side - team, behind the scenes, the clinic's why, seasonal life |
| `CC Newsletter WK3 - Proof` | Proof (Trust) | AHPRA-safe proof - education-as-proof, special interest, experience-of-care, process |
| `CC Newsletter WK4 - Offer` | Offer (Convert) | The month's hero offer, one clear CTA, terms stated plainly |

*Boundary* - `/cc-follow-up-agent` owns the 7-email ladder, pre-appointment and win-back. `/cc-content-engine` owns organic social. THIS skill owns only the weekly newsletter shells. Same month, same hero offer, same pillars across all three - one message everywhere.

## File contract

Follows the Business Brain File Contract (your workspace `CLAUDE.md`). READS `Business-Brain/brand-guide.md`, `resonance-messaging.md`, `strategy.md`, `concerns.md`, `offers.md`. WRITES `Emails/newsletter/[YYYY-MM]-newsletter.md` (the review doc) and `[YYYY-MM]-newsletter.json` (the push payload) - never into `Business-Brain/`. Paths relative to the clinic workspace (`~/Clinic/`). If `brand-guide.md` is missing, stop and offer `/cc-brand-guide`; never fabricate the clinic's voice.

*GHL access* - BEFORE any GHL call, read the clinic's Private Integration token + Location ID from `Credentials/credentials-reference.txt` (their setup created it; only ask if a value is blank). Full contract: `../cc-reeltalkinghead/references/ghl-credentials.md`.

## HOW TO USE

```
/cc-newsletter-engine [month, e.g. August]
```

## BUILD STEPS

1. *Read the spine* - `brand-guide.md` + `resonance-messaging.md` in full (the voice, OPEN/CLOSE language bank, emotional arc), plus `strategy.md` (the month's theme + hero offer) and `concerns.md` (the concern the month answers). Run the shared engine first: `../cc-resonance/references/neuro-emotive-engine.md`. If `resonance-messaging.md` is missing, offer `/cc-resonance`; never generate off the brand-guide alone.
2. *Confirm the month brief* - the month + season, the hero offer (flag Schedule 4 - no pricing, "anti-wrinkle" never "Botox"), the single concern it answers, the booking link. Pull from the Business Brain; ask only what the files do not cover. Never invent treatments, team facts or results.
3. *Write the 4 editions* along the pillar map above, in the clinic's voice, with the neuro-emotive models per pillar (Educate = Emotional Proof + Clarity Charge; Connect = Empathy Echo + Belonging Trigger; Proof = Prestige Magnet + Believability Bridge, AHPRA-safe; Offer = Desire Dial + Guided Choice Maker, true urgency only). Each edition: subject line (from the hook bank, `../cc-hook/references/hook-templates.md` - keep under ~60 characters and put NO merge fields inside it, subjects live in custom values where nested tags may not resolve), preview text, and a clean 600px inline-styled HTML body in the clinic's brand colours from `brand-guide.md`. CTAs link to `{{custom_values.booking_link}}` - never a hardcoded URL. One CTA per email, and only WK4 asks for the booking directly.
4. *Gate every edition* - `/cc-marketing-genius` (sharpen subject + CTA), `/stoptheslop` (strip AI tells, Australian English, no emdashes, italics not bold), then the hard AHPRA screen (concern-led never claim-led, no outcome promises, no specialist/expert/best/safe/painless/guaranteed, no S4 pricing or "Botox", no result-claiming testimonials; before/afters allowed in email only if the clinic's brand guide allows them at all).
5. *Show the owner* - open the review doc (or a rendered view) so they read all four emails. Approval gate: "Happy with the month? Anything to change?" Edit the SAME files until approved. NEVER push without the owner's yes.
6. *Push* - build `[YYYY-MM]-newsletter.json` (ids wk1-wk4, the exact shell titles, subject, preview, html) and run the pusher, dry run first:
   ```
   python3 push_newsletter.py Emails/newsletter/[YYYY-MM]-newsletter.json --location <LOCATION_ID>
   python3 push_newsletter.py Emails/newsletter/[YYYY-MM]-newsletter.json --location <LOCATION_ID> --push
   ```
   (Windows: use `python` instead of `python3`.) The script preflights the clinic's `booking_link` custom value and STOPS if it is missing or still the snapshot placeholder - if it stops, ask the owner for their real booking URL, set the custom value via the API, and re-run. Never bypass that stop; it exists because every email CTA points at that value.
   (`push_newsletter.py` lives in this skill's folder; token comes from `$GHL_PIT`.) The script matches the shells by title, overwrites their content, updates the four subject custom values (`nl_wk1_subject`-`nl_wk4_subject` - the workflow's Send Email steps use `{{ custom_values.nl_wkN_subject }}` as their subject because GHL refuses a blank action subject), then VERIFIES by re-reading the custom values AND fetching each template's preview URL for the pushed marker. 4/4 templates + 4/4 subjects verified is the only pass.
7. *If a shell is missing* (older location without the CC snapshot): re-run with `--create`. The script makes the missing shells - then tell the owner exactly which workflow send step to point at which new template (GHL UI, one time each). Include the template IDs the script prints.
8. *Report* - the month loaded, 4/4 verified, plus one reminder line: the newsletter workflow itself needs no change and should stay published.

## RULES

- NEVER push without the owner reading and approving all four emails first.
- NEVER report loaded without the script's verify step passing 4/4. "I ran the push" is not "it landed".
- NEVER rename the shells or invent new ones - the workflow points at these four titles forever. Same for the `nl_wkN_subject` custom values - the workflow's subject lines read them by name.
- This skill loads templates; it never sends email and never touches contacts or the workflow.
- One hero offer per month, shared with the social content and any ads - never a different offer per channel.
- Australian English, no emdashes, italics not bold, never "it's not X, it's Y". Emoji only if the brand voice uses them.
- If the clinic has no newsletter workflow yet, point them at the CC snapshot / the operator's newsletter workflow guide - do not try to build a workflow from here (workflows are browser-only).

Pairs with `/cc-follow-up-agent` (ladder + win-back), `/cc-content-engine` (the month's social from the same pillars + offer), `/cc-marketing-genius` and `/stoptheslop` (the copy passes).
