## PART 3: AESTHETICS CLINIC GEO PLAYBOOK

Reminder: every template, heading and FAQ in this part must follow the AHPRA guardrails in SKILL.md. The examples are deliberately concern-led and outcome-neutral. Pull your real concerns, treatment categories and suburbs from `cc-keyword-research` and the clinic's brand-guide.md before filling them in.

### 3.1 Why Concern-Led Clinic Content Wins at GEO

People do not ask an AI for a drug brand. They describe a concern: "how do I treat pigmentation on my cheeks", "what helps acne scarring", "skin needling vs laser for texture", "skin clinic near [suburb]". AI engines reward pages that answer the concern plainly and accurately, with clear structure and a real practitioner behind them. A clinic that organises content by concern, with honest clinical detail and a compliant tone, is exactly what these engines prefer to reference.

Your genuine advantages:
- First-hand clinical process detail (Experience) - what actually happens in a consult and treatment
- A defined approach or assessment method that is yours (Exclusivity), described without superlatives
- Real qualifications and a practitioner with a special interest in a concern area (Expertise)
- Local relevance - a real address, suburb and service area that "near me" and local AI queries can match
- Many concern queries are under-served locally, which is low competition to be referenced

### 3.2 Content Types That Get Cited for Clinics

| Content Type | AI Citation Potential | Example (concern-led) |
|--------------|-----------------------|------------------------|
| Skin-concern guides | Very High | "Pigmentation: causes and treatment options" |
| Treatment definition pages | Very High | "What is skin needling, and what does it involve?" |
| Comparison guides | Very High | "Skin needling vs fractional laser for texture" |
| Treatment FAQ pages | High | "Skin needling FAQ: downtime, sessions, suitability" |
| How-to and preparation guides | High | "How to prepare for a skin needling appointment" |
| Glossary and definitions | High | "What is hyperpigmentation? A plain-language guide" |
| Service-area / location pages | High (local) | "Skin clinic in [suburb]: services and consults" |
| Practitioner profile pages | Medium-High | Practitioner bio with qualifications and concern focus |

Do not build "best of" or testimonial-driven pages for regulated treatments. A concern guide that fairly explains options is the compliant, high-citation alternative.

### 3.3 GEO Content Templates for Clinics

#### Template 1: Skin-Concern Page (highest AI citation potential)

```html
<h1>[Skin Concern]: Causes and Treatment Options in [Suburb]</h1>

<!-- DIRECT ANSWER - AI will quote this verbatim. Keep it factual, no promises. -->
<p><em>[Concern] is [plain-language definition of the concern]. It is commonly
caused by [factors]. At [Clinic], we assess [concern] in a consultation and may
discuss options such as [generic treatment category 1], [category 2] and a
suitable skincare plan. Suitability is determined individually.</em></p>

<p>Our practitioner has a special interest in [concern area] and will talk you
through what each option involves before anything is recommended.</p>

<h2>What Causes [Concern]?</h2>
<p><em>[Concern] develops when [mechanism, in plain accurate terms].</em></p>
[Detailed, accurate explanation. No outcome promises.]

<h2>How Is [Concern] Assessed?</h2>
<p>[What the consultation covers: skin history, examination, suitability,
discussion of options.]</p>

<h2>Treatment Options We May Discuss</h2>
<!-- Use a table. Describe what each involves, not what it guarantees. -->
<table>
  <tr><th>Option</th><th>What It Involves</th><th>Typical Considerations</th></tr>
  <tr><td>[Generic category, e.g. skin needling]</td><td>[plain description]</td><td>[number of sessions, recovery considerations]</td></tr>
  <tr><td>[Generic category]</td><td>[plain description]</td><td>[considerations]</td></tr>
</table>

<h2>[Concern] FAQ</h2>
<!-- FAQPage schema on these. Natural-language questions people actually ask. -->

<!-- AUTHOR / PRACTITIONER BOX -->
<div class="practitioner-box">
  <img src="practitioner-photo.jpg" alt="[Name], [Qualification]">
  <p><em>[Name]</em>, [Qualification, e.g. RN / Cosmetic Nurse]</p>
  <p>Special interest in [concern area]. Based at [Clinic], [Suburb].</p>
</div>

<!-- COMPLIANT DISCLAIMER -->
<p><em>This information is general in nature and is not a substitute for
individual medical or cosmetic advice. Suitability for any treatment is assessed
during a consultation. Results vary between individuals.</em></p>

<!-- LAST UPDATED -->
<p>Last reviewed: [Date] by [Practitioner Name].</p>
```

Schema markup for this page:
```json
{
  "@context": "https://schema.org",
  "@type": "MedicalWebPage",
  "name": "[Concern]: Causes and Treatment Options",
  "lastReviewed": "2026-06-15",
  "reviewedBy": {
    "@type": "Person",
    "name": "[Practitioner Name]",
    "jobTitle": "[Qualification]"
  },
  "publisher": {
    "@type": "MedicalBusiness",
    "name": "[Clinic Name]"
  }
}
```

#### Template 2: Treatment Definition Page (AI-optimised, compliant)

```html
<h1>[Treatment Category] in [Suburb] | [Clinic Name]</h1>

<p><em>[Treatment] is a [type] treatment used to address [concern]. It involves
[plain description of what happens]. At [Clinic], every [treatment] follows a
consultation to confirm suitability.</em></p>

<h2>What Does [Treatment] Involve?</h2>
<h2>Who Is [Treatment] Suitable For?</h2>
<!-- Suitability and contraindications, assessed in consult. -->
<h2>What to Expect During and After</h2>
<!-- Honest recovery considerations. Do NOT write "no downtime" or "painless". -->
<h2>How Many Sessions Are Typically Involved?</h2>
<h2>About Your Practitioner</h2>
<!-- E-E-A-T: qualification + special interest, no superlatives -->
<h2>[Treatment] FAQ</h2>
<!-- FAQPage schema -->
```

Pricing note: you may show consultation fees and ranges for non-prescription services. Do not place a price beside anti-wrinkle (muscle-relaxant) injections, dermal filler, or any other Schedule 4 treatment. For those, use "Pricing is provided during your consultation."

#### Template 3: Concern Comparison Page (high citation potential)

```html
<h1>[Option A] vs [Option B] for [Concern]: How They Differ</h1>

<p><em>For [concern], [Option A] and [Option B] work differently. [Option A]
involves [mechanism]; [Option B] involves [mechanism]. The right choice depends
on your skin, your concern and a clinical assessment.</em></p>

<table>
  <tr><th>Factor</th><th>[Option A]</th><th>[Option B]</th></tr>
  <tr><td>What it does</td><td>[plain]</td><td>[plain]</td></tr>
  <tr><td>Typical sessions</td><td>[n]</td><td>[n]</td></tr>
  <tr><td>Recovery considerations</td><td>[honest]</td><td>[honest]</td></tr>
  <tr><td>Best discussed for</td><td>[concern fit]</td><td>[concern fit]</td></tr>
</table>

<h2>How We Decide Which Is Right for You</h2>
<!-- Assessment-led, no guarantees. -->
```

#### Template 4: Service-Area / Location Page (local SEO + GEO)

```html
<h1>Skin Clinic in [Suburb] | [Clinic Name]</h1>

<p><em>[Clinic] is a skin clinic in [Suburb], [State], offering consultations and
treatments for concerns including [concern 1], [concern 2] and [concern 3]. We
also see clients from nearby [neighbouring suburb 1] and [neighbouring suburb 2].</em></p>

<h2>Treatments Available at Our [Suburb] Clinic</h2>
<h2>Our [Suburb] Location and Hours</h2>
<!-- Full NAP: name, address, phone, hours. Match Google Business Profile exactly. -->
<h2>Booking a Consultation</h2>
<h2>FAQ for [Suburb] Clients</h2>
```

### 3.4 Entity Building for Clinics

AI engines cite entities (recognised clinics and practitioners), not just pages. Build the clinic entity:

| Action | Priority | How |
|--------|----------|-----|
| Consistent NAP | Critical | Same clinic name, address and phone everywhere |
| Google Business Profile | Critical | Claim, complete, categorise correctly, post regularly |
| Wikidata entry | Medium | Easier than Wikipedia, feeds the Knowledge Graph |
| Reputable health/aesthetic directories | High | List the clinic on legitimate clinic directories |
| Practitioner profile pages | High | Bylined, consistent qualification and bio everywhere |
| Social profiles | Medium | Consistent clinic name and details across platforms |
| Local press / community mentions | Medium | Compliant mentions in local publications |
| Genuine recognition or qualifications | Medium | List real qualifications and memberships (no "expert") |

### 3.5 Clinic YMYL Considerations

Cosmetic-medical content is YMYL (Your Money Your Life). AI engines apply extra scrutiny, so trust signals are non-negotiable:

- [ ] A compliant disclaimer on every concern and treatment page
- [ ] Practitioner qualifications clearly displayed (RN, cosmetic nurse, doctor, dermal therapist)
- [ ] "Last reviewed" date on clinical pages
- [ ] Accurate clinical information, distinguishing general information from individual advice
- [ ] No testimonials about regulated (S4) treatments anywhere
- [ ] No superlatives, outcome promises, or prohibited words ("safe", "painless", "permanent", "anti-ageing")
- [ ] No prices beside S4 treatments
- [ ] Privacy policy and terms of service present
- [ ] Real physical address and service area (not a PO box)
- [ ] Real clinic and team photos (not stock)

---

## PART 4: AI CRAWLER ACCESS STRATEGY

### 4.1 Which Crawlers to Allow

| Crawler | Engine | Recommendation | Why |
|---------|--------|----------------|-----|
| GPTBot | ChatGPT/OpenAI | ALLOW | You want ChatGPT to reference your clinic |
| Claude-Web | Claude | ALLOW | You want Claude to reference your clinic |
| PerplexityBot | Perplexity | ALLOW | Highest citation rate |
| Googlebot | Google/Gemini | ALLOW | Drives local traffic and feeds Gemini |
| CCBot | Common Crawl | ALLOW | Feeds many AI training sets |

### 4.2 robots.txt for Maximum AI Visibility

```
User-agent: *
Allow: /

User-agent: GPTBot
Allow: /

User-agent: Claude-Web
Allow: /

User-agent: PerplexityBot
Allow: /

User-agent: CCBot
Allow: /

Sitemap: https://yourclinicdomain.com.au/sitemap.xml
```

### 4.3 llms.txt (helping AI understand your clinic)

Create `/llms.txt` at the domain root - a convention for helping AI parse your clinic:

```
# [Clinic Name]

> A skin clinic in [Suburb], [State], offering consultations and treatments for
> [concern 1], [concern 2] and [concern 3].

## About
[2-3 plain, compliant paragraphs: what the clinic does, who it serves, the
practitioner's qualifications and concern focus. No superlatives or promises.]

## Treatments and Concerns
- [Concern page 1]: [URL] - [Brief description]
- [Treatment page 1]: [URL] - [Brief description]

## Key Content
- [Concern guide]: [URL] - [Description]
- [Comparison guide]: [URL] - [Description]

## Practitioner
- [Name], [Qualification] - special interest in [concern area]

## Contact
- Website: [URL]
- Phone: [number]
- Address: [full address, Suburb, State]
```

### 4.4 Schema Markup (LocalBusiness / MedicalBusiness)

Use `MedicalBusiness` (a subtype of `LocalBusiness`) for the clinic, with NAP that matches the Google Business Profile exactly:

```json
{
  "@context": "https://schema.org",
  "@type": "MedicalBusiness",
  "name": "[Clinic Name]",
  "image": "https://yourclinicdomain.com.au/clinic.jpg",
  "url": "https://yourclinicdomain.com.au",
  "telephone": "+61 3 XXXX XXXX",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "[street]",
    "addressLocality": "[Suburb]",
    "addressRegion": "[State]",
    "postalCode": "[postcode]",
    "addressCountry": "AU"
  },
  "geo": { "@type": "GeoCoordinates", "latitude": 0, "longitude": 0 },
  "areaServed": ["[Suburb]", "[Neighbouring suburb 1]", "[Neighbouring suburb 2]"],
  "openingHoursSpecification": [
    { "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Tuesday","Wednesday","Thursday","Friday","Saturday"],
      "opens": "09:00", "closes": "17:00" }
  ]
}
```

Add `FAQPage` schema to every FAQ section, and `MedicalWebPage` with `lastReviewed` and `reviewedBy` to every concern and treatment page (see Part 3 templates).

---

## PART 5: GEO AUDIT PROCESS

### 5.1 Quick GEO Audit (15 minutes)

Run this checklist on any clinic page:

AI Discoverability (Can AI find you?)
- [ ] robots.txt allows AI crawlers (GPTBot, PerplexityBot, Claude-Web)
- [ ] Sitemap exists and is submitted
- [ ] Pages load fast (< 2.5s)
- [ ] Clean HTML structure (proper heading hierarchy)
- [ ] No JavaScript-only content (AI crawlers often do not execute JS)

AI Parseability (Can AI understand you?)
- [ ] Single H1 with a clear concern or treatment topic
- [ ] H2s frame subtopics as the questions people ask
- [ ] Direct, factual answer in the first 40 words after each H2
- [ ] Comparison tables present where options exist
- [ ] FAQ section with natural-language questions
- [ ] Lists for structured information
- [ ] Schema markup (MedicalWebPage, FAQPage, MedicalBusiness, Person)

AI Citability (Will AI quote you?)
- [ ] Accurate, specific clinical information (no vague claims)
- [ ] Practitioner attribution with qualification
- [ ] Clear concern definitions ("[Concern] is defined as...")
- [ ] A defined assessment or approach that is the clinic's own
- [ ] Practitioner bio with qualifications and concern focus
- [ ] Publication date plus last reviewed date
- [ ] Compliant disclaimer (for cosmetic-medical YMYL content)

AI Authority (Does AI trust you?)
- [ ] Consistent NAP across the web
- [ ] Google Business Profile claimed, complete and correctly categorised
- [ ] Practitioner has consistent profiles across platforms
- [ ] Backlinks from relevant health and local sites
- [ ] Mentioned on other reputable sites
- [ ] Social media profiles active and consistent

### 5.2 AHPRA Compliance Pass (run on every page before publishing)

- [ ] No superlatives or status claims ("expert", "specialist", "best", "leading")
- [ ] No outcome promises or prohibited words ("transform", "guaranteed", "anti-ageing", "miracle", "safe", "painless", "permanent", "no downtime")
- [ ] No testimonials or reviews tied to a regulated (S4) treatment
- [ ] No prescription product brand names (use generic treatment categories)
- [ ] No price beside any S4 treatment
- [ ] Compliant disclaimer present, "last reviewed" date present
- [ ] Page leads with the concern, not a drug or device brand

### 5.3 Full CORE-EEAT Audit

Clinic Bonus Checks:
- [ ] Process descriptions include honest recovery considerations (not "no downtime")
- [ ] Practitioner qualifications and training documented
- [ ] Concern and treatment terminology defined in plain language
- [ ] Suitability and contraindications described (assessed in consult)
- [ ] Professional association memberships listed (where genuine)
- [ ] Privacy, complaints and consent information accessible

#### Full 80-Item CORE-EEAT Audit Process

Step 1: Preparation
- Identify content source (URL, text, or file path)
- Detect or confirm content type (Skin-Concern Page, Treatment Page, Service/Location Page, About/Practitioner, FAQ Page)
- Load content-type-specific dimension weights from SKILL.md Section 2.3
- Run veto check first: T04 (Disclaimer), T05 (AHPRA breach), C01 (Intent Alignment), R10 (Clinical Consistency). If any fail, flag at the top of the report.

Step 2: Score CORE dimensions (40 items)
Score each of the 10 items per dimension as Pass (10pts), Partial (5pts), or Fail (0pts):

C - Contextual Clarity: intent alignment, direct answer, topic coverage, query variants, semantic depth, context bridges, user journey, intent types, content gaps, semantic closure

O - Organisation: heading hierarchy, scannable structure, logical flow, visual hierarchy, content chunking, navigation aids, content type signals, progressive disclosure, summary elements, structural consistency

R - Referenceability: data and fact accuracy, quotable statements, fact density, source attribution, clinical precision, methodology transparency, reference accessibility, information recency, cross-reference network, content consistency

E - Exclusivity: original clinic approach, unique perspective, defined assessment method, first-hand process detail, novel explanation, unique combinations, exclusive access, original frameworks, distinctive positioning, practical insight

Step 3: Score EEAT dimensions (40 items)

Exp - Experience: first-person clinical narrative, specific process detail, temporal evidence, process documentation, honest recovery reporting, contextual learning, complication awareness, comparative experience, sensory and practical detail, community evidence

Ept - Expertise: clinical accuracy, depth of analysis, terminology usage, methodological rigour, edge case handling, theoretical grounding, practical application, knowledge synthesis, current awareness, ability to explain clearly

A - Authority: backlink profile, industry citations, clinic recognition, editorial standards, professional affiliations, speaking/publishing, professional network, knowledge graph presence, media coverage, community standing

T - Trust: disclosure statements, editorial independence, correction policy, privacy practices, content consistency, authorship transparency, conflict management, patient safety information, version control, feedback integration

Note: Some Authority items (A01 backlinks, A05 recognition, A07 knowledge graph) need site-level data. Mark as "N/A - requires site-level data" if not available.

Step 4: Generate Report

Output format:
```
CORE-EEAT AUDIT REPORT

Content: [title]
Content Type: [type]
Audit Date: [date]
Veto Status: Pass / TRIGGERED [item]
AHPRA Compliance: Pass / FLAG [issue]

SCORES
| Dimension | Score | Weight | Weighted |
|-----------|-------|--------|----------|
| C | X/100 | X% | X |
| O | X/100 | X% | X |
| R | X/100 | X% | X |
| E | X/100 | X% | X |
| Exp | X/100 | X% | X |
| Ept | X/100 | X% | X |
| A | X/100 | X% | X |
| T | X/100 | X% | X |
| TOTAL | | | X/100 |

GEO Score (CORE avg): X/100
SEO Score (EEAT avg): X/100

TOP 5 IMPROVEMENTS (sorted by weight x points lost)
1. [ID] [Name] - [action] - potential gain: X weighted points
2-5. [same format]

ACTION PLAN
Quick wins (<30 min): [list]
Medium effort (1-2 hrs): [list]
Strategic (needs planning): [list]
```

### 5.4 Scoring Interpretation

| Score Range | Rating | What It Means |
|-------------|--------|---------------|
| 90-100 | Excellent | AI is likely already referencing you |
| 75-89 | Good | Minor tweaks will get you referenced |
| 60-74 | Medium | Significant optimisation needed |
| 40-59 | Low | Major restructuring required |
| 0-39 | Poor | Start from scratch with the GEO templates |

---

## PART 6: MEASUREMENT & TRACKING

### 6.1 How to Check If AI Is Referencing Your Clinic

Manual checks (do weekly):
1. Ask ChatGPT: "Where can I get [concern] treatment in [suburb]?" / "What clinics offer skin needling near [suburb]?"
2. Ask Perplexity: "Skin clinic in [suburb]" / "[Concern] treatment options [suburb]"
3. Ask Claude: "Tell me about [concern] and how clinics assess it"
4. Ask Gemini: the same queries
5. Check Google for AI Overviews and the local Map pack on your target concern and suburb keywords

What to record:
- Were you referenced? (Yes/No)
- Position (1st source, 2nd source, Map pack rank)
- Which page was referenced
- What was quoted (exact text)
- Competitors referenced instead

### 6.2 GEO and Local KPIs

| Metric | How to Track | Target |
|--------|--------------|--------|
| AI citation rate | Manual weekly checks | Referenced in 30%+ of relevant queries |
| Clinic mention in AI | Ask AI about your concerns and suburb | Named in responses |
| AI referral traffic | GA4 (track AI referrer sources) | Growing trend |
| Local Map pack presence | Manual checks on "[concern] [suburb]" | Top 3 |
| Google Business Profile actions | GBP insights | Calls, directions, bookings rising |
| Concern keyword visibility | Search Console | Impressions and clicks rising |
| Content freshness | CMS / lastReviewed timestamps | Reviewed within 90 days |

### 6.3 AI Visibility Dashboard Template

```markdown
## AI Visibility Report - [Clinic Name] - [Date]

### Citation Summary
| Engine | Queries Tested | Referenced | Rate | Top Page |
|--------|----------------|-----------|------|----------|
| ChatGPT | [X] | [X] | [X]% | [page] |
| Perplexity | [X] | [X] | [X]% | [page] |
| Claude | [X] | [X] | [X]% | [page] |
| Gemini | [X] | [X] | [X]% | [page] |
| AI Overviews | [X] | [X] | [X]% | [page] |
| Google Map pack | [X] | [X] | [X]% | n/a |

### Queries Where We're Referenced
1. "[query]" - referenced on [engine] as source #[X]

### Queries Where Competitors Are Referenced (Not Us)
1. "[query]" - [Competitor] referenced - our gap: [what we need]

### Actions This Week
- [ ] [Action 1]
- [ ] [Action 2]
```

---

## PART 7: 90-DAY GEO IMPLEMENTATION PLAN

### Month 1: Foundation (Weeks 1-4)

Week 1: Audit & Baseline
- [ ] Run the GEO audit on the clinic website
- [ ] Run cc-keyword-research for the concern and suburb keyword map
- [ ] Test AI citations and the Map pack for top concerns (baseline)
- [ ] Check robots.txt and schema markup
- [ ] Run the AHPRA compliance pass on existing pages and log any breaches

Week 2: Technical Fixes
- [ ] Update robots.txt to allow AI crawlers
- [ ] Create /llms.txt
- [ ] Submit/update the sitemap
- [ ] Fix any Core Web Vitals issues
- [ ] Add MedicalBusiness, MedicalWebPage and FAQPage schema

Week 3: Entity & Local
- [ ] Make NAP consistent across every platform
- [ ] Claim/complete the Google Business Profile and categorise correctly
- [ ] Update the practitioner bio everywhere (qualification + concern focus)
- [ ] List the clinic on reputable health and local directories

Week 4: Content Audit
- [ ] Identify the top 10 concern and treatment pages
- [ ] Score each with the CORE-EEAT quick audit
- [ ] Fix any AHPRA breaches found (top priority)
- [ ] Prioritise pages by GEO and local potential

### Month 2: Content Optimisation (Weeks 5-8)

Week 5-6: Restructure Existing Content
- [ ] Add direct, factual answer paragraphs after each H2
- [ ] Add FAQ sections to top pages
- [ ] Add comparison tables where options exist
- [ ] Add practitioner bios and qualifications
- [ ] Add lastReviewed dates and compliant disclaimers
- [ ] Implement FAQPage schema

Week 7-8: Create New GEO-Optimised Content
- [ ] Build skin-concern pages for your priority concerns
- [ ] Build treatment definition pages (compliant, concern-led)
- [ ] Build comparison pages ("[option] vs [option] for [concern]")
- [ ] Build service-area/location pages for your suburb and neighbours

### Month 3: Authority & Measurement (Weeks 9-12)

Week 9-10: Build Authority
- [ ] Earn mentions on relevant local and health sites (compliant)
- [ ] Publish concern guides with a consistent practitioner byline
- [ ] Post to the Google Business Profile regularly

Week 11-12: Measure & Iterate
- [ ] Re-test AI citations and the Map pack across engines
- [ ] Compare to the Month 1 baseline
- [ ] Double down on what is working
- [ ] Plan Months 4-6 based on results

---

## PART 8: LOCAL SEO FOR CLINICS (NEAR-ME AND MAP PACK)

GEO and local SEO reinforce each other. The same structured, accurate, well-attributed content that AI references also wins the Google Map pack and "near me" queries.

### 8.1 Google Business Profile (the local foundation)

- [ ] Claim and verify the profile
- [ ] Choose the most accurate primary category (for example "Skin care clinic" or "Medical clinic") plus relevant secondary categories
- [ ] NAP matches the website and schema exactly
- [ ] Add real clinic photos (exterior, interior, team), hours, and services
- [ ] Add service-area suburbs
- [ ] Post regularly (treatments offered, concern education, clinic updates) within AHPRA rules
- [ ] Respond to all reviews professionally - and never solicit or display reviews about regulated (S4) treatments

### 8.2 On-Page Local Signals

- [ ] Suburb in the H1 and title of location pages
- [ ] Embedded Google Map and full NAP in the footer of every page
- [ ] A dedicated page per suburb you genuinely serve (no doorway-page spam)
- [ ] Internal links from concern pages to the relevant location page
- [ ] Local schema (`MedicalBusiness` with `areaServed`)

### 8.3 Local Authority

- [ ] Listings on reputable Australian directories with consistent NAP
- [ ] Mentions in local community publications (compliant)
- [ ] Backlinks from local and health-relevant sites

---

## PART 9: ALERT CONFIGURATION

| Alert | Condition | Priority | Response |
|-------|-----------|----------|----------|
| AHPRA breach detected | Superlative, S4 testimonial, S4 price, brand drug, outcome promise on a page | Critical | Remove and rewrite immediately |
| Disclaimer missing | Cosmetic-medical page without a compliant disclaimer | Critical | Add immediately (YMYL) |
| Lost AI citation | Was referenced, now is not | High | Investigate content changes |
| Dropped from Map pack | Was in local top 3, now is not | High | Check GBP, NAP, reviews |
| Competitor referenced | They appear, you do not | Medium | Concern content gap analysis |
| New AI Overview | An AIO appears for your concern keyword | Medium | Optimise the page to be referenced |
| Content stale | Page not reviewed in 90+ days | Medium | Schedule a content review |

---

## PART 10: MEMORY MANAGEMENT

### Hot Cache Template (clinic CLAUDE.md / Business-Brain section)

```markdown
## GEO Tracking - [Clinic Name]

Last AI citation check: [Date]
Overall GEO Score: [X]/100
AHPRA compliance: Pass / FLAG

### AI Citation Status
| Query | ChatGPT | Perplexity | Claude | Gemini | Map pack |
|-------|---------|------------|--------|--------|----------|
| [concern + suburb] | Ref #1 | Not ref | Ref #2 | N/A | Top 3 |

### Priority Actions
1. [Action] - expected impact: [High/Med/Low]

### Content Scores (Top Pages)
| Page | GEO Score | SEO Score | Last Reviewed |
|------|-----------|-----------|---------------|
| [page] | [X]/100 | [X]/100 | [date] |
```

### Cold Storage Structure

```
memory/cc-geo-seo/
├── audits/
│   ├── YYYY-MM-DD-[clinic]-geo-audit.md
│   └── YYYY-MM-DD-[clinic]-core-eeat.md
├── citations/
│   ├── YYYY-MM-DD-citation-check.md
│   └── citation-history.csv
├── competitors/
│   └── [competitor]-geo-analysis.md
├── content-plans/
│   └── YYYY-QX-concern-content-calendar.md
└── reports/
    └── YYYY-MM-geo-report.md
```
