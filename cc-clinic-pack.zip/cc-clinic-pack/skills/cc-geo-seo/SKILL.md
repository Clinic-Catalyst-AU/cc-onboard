---
name: cc-geo-seo
description: AI search optimisation (GEO/AEO) plus local SEO for aesthetics and skin clinics. Combines the CORE-EEAT framework, AI citation strategies, and an AHPRA-aware clinic playbook for treatment, skin-concern, and FAQ pages. Use when you say GEO, AI search, get found in ChatGPT, AI visibility, AI SEO for my clinic, get cited by AI, Perplexity, AI Overviews, "skin clinic near me", local SEO for my clinic, or want your clinic surfaced by ChatGPT, Perplexity, Claude, Gemini, AI Overviews and local Google.
---

# CC GEO SEO - AI Search and Local SEO for Aesthetics Clinics

> Get your clinic surfaced when someone asks ChatGPT, Perplexity, Claude or Gemini for a skin clinic, and when they search Google for a clinic near them. Not just ranked - referenced.

## When to Invoke This Skill

- You ask about AI search optimisation, GEO, AEO, AI Overviews, or CORE-EEAT scoring
- You want your clinic to show up in ChatGPT, Perplexity, Claude or Gemini answers
- You want a GEO audit on your clinic website, or content an AI will cite
- You search-test phrases like "skin clinic near me", "skin needling [suburb]", or "pigmentation treatment [suburb]" and your clinic is missing
- You want your treatment pages, skin-concern pages and FAQs structured to be found

This skill pairs with `cc-keyword-research` (for the concern and suburb keyword map) and your clinic's Business-Brain / brand-guide.md (for tone, services list, suburbs and credentials). Run keyword research first so the examples below are filled with your real concerns and locations.

## AHPRA Guardrails (read first, applies to everything below)

This skill writes for regulated medical and cosmetic services. Every page, heading, schema field and FAQ produced here must stay inside the Australian advertising rules. Hard rules:

- Lead with the *skin concern*, not a drug or device brand. Pages are organised by concern (for example "pigmentation", "acne and congestion", "skin laxity") and by the generic treatment category.
- No superlatives or self-anointed status. Do not write "expert", "specialist", "best", "leading", "number one", "most advanced". Use "special interest in" or "with a focus on" instead.
- No before/after promises and no implied results. Do not promise outcomes, do not use "transform", "guaranteed results", "anti-ageing", "miracle", "permanent".
- No testimonials or reviews for regulated treatments. Patient testimonials about Schedule 4 treatments are prohibited. Keep social proof to general clinic experience and service, never to a regulated procedure.
- No guarantees and no comfort claims. Do not write "safe", "painless", "no downtime", "risk-free", "guaranteed".
- Never name prescription-only products. Use "anti-wrinkle injections" or "muscle-relaxant injections", not the brand. Use "dermal filler", not a brand.
- No pricing on Schedule 4 (prescription) treatments. You may state consultation fees and non-S4 service ranges. Do not put a price next to anti-wrinkle or filler treatments.
- Australian English throughout. Hyphens with spaces, never emdashes. Use italics for emphasis, not bold.

If a template field below would breach any of these, rewrite it concern-led and outcome-neutral before publishing.

---

## PART 1: THE GEO FRAMEWORK - HOW AI SEARCH ACTUALLY WORKS

### 1.1 SEO vs GEO - The Shift

| Aspect | SEO (still matters) | GEO (rising) |
|--------|---------------------|--------------|
| Goal | Rank on Google | Get *referenced* by AI engines |
| Platform | Google SERPs | ChatGPT, Perplexity, Claude, Gemini |
| Metric | Position, CTR | Citation rate, clinic mentions |
| Focus | Keywords, backlinks | Entities, authority, quotable content |
| Content | Keyword-optimised | AI-parseable, structured, citable |
| Trust | PageRank | E-E-A-T signals, consistency across web |
| User | Clicks a link | Gets your clinic info without clicking |

For a local clinic you want both: GEO gets you named when someone asks an AI "where can I get skin needling near [suburb]", and local SEO gets you in the Google Map pack and "near me" results.

### 1.2 How AI Engines Select Sources to Cite

AI engines use RAG (retrieval-augmented generation) to pull sources:

| Factor | Weight | What It Means |
|--------|--------|---------------|
| Semantic relevance | ~40% | Your content directly answers the concern query |
| Authority signals | ~20% | Consistent clinic presence across the web |
| Source diversity | ~15% | Multiple independent sources confirm your details |
| Freshness | ~10% | Recently updated, timestamped content |
| Keyword match | ~10% | Exact concern and suburb phrases people use |
| Structured data | ~5% | Schema markup, clean HTML, FAQ sections |

### 1.3 The AI Engine Landscape

| Engine | How It Cites | Best Strategy |
|--------|--------------|---------------|
| Perplexity | Numbered sources [1][2][3] | Highest citation rate - be the clearest concern source |
| ChatGPT (with browsing) | Inline mentions plus footnotes | Entity recognition - be the known clinic name in your area |
| Claude | Contextual references | Long-form, accurate, well-structured content |
| Gemini | Sources section at bottom | Google SEO and Google Business Profile crossover |
| AI Overviews | Cited in Google's AI panel | FAQ schema plus direct concern answers |

---

## PART 2: CORE-EEAT SCORING FRAMEWORK

### 2.1 What is CORE-EEAT?

An 80-item benchmark that separates GEO readiness (CORE) from SEO strength (EEAT):

CORE = GEO Score (Will AI cite this content?)
- C - Contextual Clarity (Does it directly answer the concern query?)
- O - Organisation (Is it structured for AI parsing?)
- R - Referenceability (Can AI quote specific, accurate facts?)
- E - Exclusivity (Does it offer something only this clinic can say?)

EEAT = SEO Score (Is the source trustworthy?)
- Exp - Experience (First-hand clinical knowledge, real process detail)
- Ept - Expertise (Qualifications, depth, accurate clinical information)
- A - Authority (Backlinks, mentions, recognition, directory presence)
- T - Trust (Transparency, accuracy, consistency, compliant disclaimers)

### 2.2 Scoring

Each dimension has 10 check items. Score each: Pass = 10pts, Partial = 5pts, Fail = 0pts.
GEO Score = (C + O + R + E) / 4. SEO Score = (Exp + Ept + A + T) / 4. Combined = weighted by content type.

### 2.3 Content Type Weights (Aesthetics Clinic)

| Dimension | Skin-Concern Page | Treatment Page | Service/Location Page | About/Practitioner | FAQ Page |
|-----------|-------------------|----------------|------------------------|--------------------|----------|
| C: Clarity | 25% | 20% | 20% | 15% | 25% |
| O: Organisation | 10% | 15% | 10% | 10% | 15% |
| R: Referenceability | 15% | 15% | 10% | 5% | 15% |
| E: Exclusivity | 15% | 10% | 15% | 10% | 5% |
| Exp: Experience | 15% | 15% | 15% | 25% | 10% |
| Ept: Expertise | 10% | 15% | 15% | 20% | 15% |
| A: Authority | 5% | 5% | 10% | 10% | 5% |
| T: Trust | 5% | 5% | 5% | 5% | 10% |

### 2.4 Veto Items (Instant Fails)

These override the total score - fix immediately:

| ID | Item | Why It's a Veto |
|----|------|-----------------|
| T04 | Missing or non-compliant disclaimer | Cosmetic-medical content must carry a compliant disclaimer |
| T05 | AHPRA breach (testimonial for S4, superlative, price on S4, brand-name drug, outcome promise) | Regulatory risk - remove before anything else |
| C01 | Intent misalignment | Page does not answer the concern its title promises |
| R10 | Inconsistent or inaccurate clinical info | Contradictory or wrong information across the site |

---

## Related Skills & Tools

| Need | Use |
|------|-----|
| Concern and suburb keyword map | `cc-keyword-research` skill |
| Clinic tone, services, suburbs, credentials | the clinic's Business-Brain / brand-guide.md |
| Full website SEO audit | `website-seo-audit` skill |
| Live website auditing | Playwright MCP |
| Web research and competitor checks | WebFetch + WebSearch tools |

Version: 1.0 | Created: 2026-06-30 | Next Review: Q4 2026
Built on the generic CORE-EEAT GEO/AEO engine, re-aimed for AHPRA-compliant aesthetics and skin clinics.

For the full CORE-EEAT scoring process, the clinic content playbook, schema, local SEO, AI crawler strategy, audit, measurement and 90-day roadmap, read `references/framework.md`.
