---
name: cc-reelclips
description: Stitch clinic clips into one clean edit for a TRENDING-AUDIO reel - clips in order, normalised, optional crossfades, original audio kept low or stripped, and deliberately NO music baked in and NO GHL push: trending sounds only exist inside Instagram/TikTok, so the clinic posts this natively and adds the trending audio in-app (that is where the reach comes from). Finishes by opening the edit on screen with the post-natively instructions. Use when the user says trending audio reel, trending sound, clips for a trend, stitch clips for instagram, quick clip edit, or wants a montage to put trending music over. Voiceover montage = /cc-reelvoiceover. Story edit with captions + GHL = /cc-reelassembly.
---

# CC REEL - CLIPS (the trending-audio edit: stitch, stop, post natively)

Some reels ride a sound. The clinic finds a trending audio in Instagram or TikTok, and needs a
clean visual edit to put under it. This skill makes exactly that - and deliberately STOPS there.
No music baked in (a baked track blocks using the trending sound), no GHL push (GHL cannot attach
in-app trending audio - posting this one natively IS the strategy).

*File contract* - READS nothing from the Business Brain (pure visual edit). WRITES to
`Content/reels/`. Paths relative to the clinic workspace (`~/Clinic/`).

## HOW TO USE

```
/cc-reelclips --folder Content/video/mini-clips            # sorted by name
/cc-reelclips --clips door.mp4 machine.mp4 glow.mp4        # your order
/cc-reelclips --folder X --crossfade                       # soft cuts
/cc-reelclips --folder X --keep-audio                      # keep original clip sound (default: stripped)
/cc-reelclips --folder X --square | --landscape            # default vertical
```

## PROCEDURE

### STEP 1: VALIDATE + PACE
1. `which ffmpeg ffprobe`. Gather clips (folder = sorted; or explicit order).
2. Trending-audio edits are FAST: trim clips longer than 3 seconds to their first 2.5s
   (/tmp/cc-clips/). Aim 15-30 seconds total. Report clip count + runtime before building.

### STEP 2: STITCH
```bash
python3 ~/.claude/skills/cc-assemble/assemble.py --clips [in order] \
  --aspect reel [--crossfade] --out /tmp/cc-clips/edit.mp4
```
Default: strip audio (`ffmpeg -c:v copy -an`) so the trending sound stands alone. --keep-audio
keeps the natural clip sound (some trends duet with ambient audio) - their call.
Save to `~/Clinic/Content/reels/[slug]-clips-$(date +%Y-%m-%d).mp4`.

### STEP 3: THE FINALE - show it + the native-posting hand-off (always, never ask)
`open` the edit so it plays, `open -R` in Finder. Then say the strategy out loud:
"Post this one NATIVELY: open Instagram or TikTok, create a reel, add this video, then add the
trending audio in the app - trending sounds only work in-app, which is why there is no GHL step
on this one. Caption short, 2-3 of your hashtags, go."

## Outputs - the STRICT contract (exactly these, nothing else)
1. `Content/reels/<slug>-clips-<date>.mp4` - the edit (opened on screen).
2. The native-posting instructions in chat.
NO music file, NO GHL draft, no extra files - by design, not by omission.

## IMPORTANT RULES
- NEVER bake music into this skill's output - it exists to carry an in-app trending sound.
- NEVER push this one to GHL - native posting is the point; say so, do not apologise for it.
- No agency branding. No emdashes.
- Want music baked in for other uses (a website video, a hype reel)? That is /cc-assemble.
