---
name: cc-ad-spy
description: Search the Meta (Facebook) Ads Library for a competitor aesthetics clinic or treatment keyword and return structured competitive intelligence - ad creatives, messaging angles, CTAs, spend intensity, and AHPRA-aware strategic analysis. Uses Playwright MCP (no login required). Use when you say ad spy, check competitor ads, spy on ads, research ads, what ads is [competitor clinic] running, what ads is [clinic] running, Meta ads, Facebook ads library, or want competitor advertising intelligence for the clinic.
---

# /cc-ad-spy - Meta Ads Library Clinic Competitor Intelligence

Searches the Meta (Facebook) Ads Library for any competitor clinic or treatment keyword and returns structured competitive intelligence - ad creatives, messaging angles, CTAs, spend intensity, and strategic analysis framed for an aesthetics clinic. Uses Playwright MCP (no login required).

This skill is AHPRA-aware. When it summarises competitor angles for the clinic to use, it keeps them concern-led and flags any competitor before-after imagery, superlatives, or testimonial claims as NOT to copy.

For the full step-by-step execution, parameters, and output format, read `references/procedure.md`.
