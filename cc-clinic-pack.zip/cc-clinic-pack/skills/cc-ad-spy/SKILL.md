---
name: cc-ad-spy
description: Search the Meta (Facebook) Ads Library for a competitor aesthetics clinic or treatment keyword and turn it into a branded, on-screen intelligence REPORT - every ad they are running, the angles everyone is crowding into, the gap nobody is filling, and the competitor ads that would breach AHPRA if you copied them. Finishes by opening the report on screen and asking whether to build an offer that goes straight at the gap. Uses Playwright MCP (no login required). Use when you say ad spy, check competitor ads, spy on ads, research ads, what ads is [competitor clinic] running, what ads is [clinic] running, Meta ads, Facebook ads library, or want competitor advertising intelligence for the clinic.
---

# /cc-ad-spy - Meta Ads Library clinic competitor intelligence

Searches the Meta (Facebook) Ads Library for any competitor clinic or treatment keyword, then hands
back a report the clinic can actually read: what every competitor is running, the angles they are all
crowding into, the space nobody is speaking to, and what they must NOT copy.

Uses Playwright MCP. No login required - the Ads Library is public.

## The job is not done until two things have happened

1. *The report is OPEN ON THEIR SCREEN.* A branded HTML page, in the clinic's own colours, saved to
   `Ads/ad-spy/`. A run that ends with findings scrolled past in a terminal has delivered nothing -
   they will never scroll back up to read it.

2. *You have ASKED about the offer.* Competitor intelligence is only worth something if it changes
   what the clinic SELLS. With the report open, ask whether they want an offer built against the gap
   you just found - then wait for an answer. Never write one they did not ask for.

## Two sections carry the whole value

*The gap* - everyone in a local market ends up running the same angle. Name what NOBODY is saying,
and why that space is open. This is the one thing the clinic is really paying for. If there
genuinely is no gap, say so plainly - never manufacture one to fill the section.

*Do not copy this* - the competitor ads that would breach AHPRA if the clinic ran them: injectable
before/afters, hard-banned superlatives, patient testimonials claiming a result, Schedule 4 pricing,
brand-name drugs. A competitor running it does not make it legal - AHPRA enforces against the
advertiser, not the industry. This flips a compliance rule into a competitive advantage: they are
exposed, and the clinic is not. Say it that way.

## AHPRA

Every angle borrowed from a competitor is read through the AHPRA lens before the clinic uses it.
Keep it concern-led. Never hand a competitor's outcome promise back as a suggestion.

---

Full execution steps, parameters, the report build and the offer handoff:
`references/procedure.md`. The report itself: `references/report-template.html`.
