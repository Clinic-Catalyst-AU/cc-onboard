# /cc-ad-spy - Meta Ads Library Clinic Competitor Intelligence

## Description
Searches the Meta (Facebook) Ads Library for any competitor aesthetics clinic or treatment keyword and returns structured competitive intelligence - ad creatives, messaging angles, CTAs, spend intensity, and AHPRA-aware strategic analysis. Uses Playwright MCP (no login required).

## Trigger
When you say `/cc-ad-spy [clinic or keyword]` or ask to check competitor ads, spy on ads, or research what ads a competing clinic is running.

## Usage
```
/cc-ad-spy "Skin Renu"
/cc-ad-spy "anti-wrinkle Bendigo" country:AU
/cc-ad-spy "cosmetic clinic Mornington" platform:facebook status:all
```

### Parameters
- *query* (required): Competitor clinic name or treatment keyword to search
- *country*: 2-letter code, default `AU` (Australia). Common: US, GB, NZ, CA
- *platform*: `all` (default), `facebook`, `instagram`, `messenger`, `audience_network`
- *status*: `active` (default) or `all` (includes inactive)
- *limit*: Max ads to extract, default 10. Set higher for deeper analysis.

---

## Step-by-Step Execution

### Step 1: Parse Input
Extract the search query and any optional parameters from the message.
- Default country: `AU`
- Default status: `active`
- Default limit: `10`

Map country codes for the URL:
- AU = Australia, US = United States, GB = United Kingdom, NZ = New Zealand, CA = Canada

### Step 2: Navigate to Meta Ad Library

Build the URL:
```
https://www.facebook.com/ads/library/?active_status={status}&ad_type=all&country={COUNTRY_CODE}&q={URL_ENCODED_QUERY}
```

Example for "anti-wrinkle Bendigo" in Australia:
```
https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=AU&q=anti-wrinkle%20Bendigo
```

Use Playwright to navigate:
```
mcp__playwright__browser_navigate to the constructed URL
```

### Step 3: Wait for Results to Load

After navigation, wait for the page to finish loading dynamic content:
```
mcp__playwright__browser_wait_for with timeout 10000ms
```

Then take a snapshot to see what loaded:
```
mcp__playwright__browser_snapshot
```

### Step 4: Handle Cookie/Privacy Popups

The snapshot may show a cookie consent or privacy popup. If so:
- Look for "Allow all cookies", "Accept all", "Allow essential and optional cookies", or similar button
- Click it with `mcp__playwright__browser_click`
- Wait briefly and snapshot again

### Step 5: Verify Search Results Loaded

Check the snapshot for ad cards. The page should show:
- A search bar with the query
- Filter buttons (country, platform, media type, etc.)
- Ad result cards OR a "no results" message

If *no results found*:
- Report: "No active ads found for [query] in [country]. Try broadening the search or changing country."
- Suggest alternative search terms (shorter clinic name, treatment keyword, suburb, parent company, etc.)
- STOP here.

If results are present, continue.

### Step 6: Extract Ad Data

For each visible ad card in the snapshot, extract:

1. *Page Name* - the Facebook page running the ad
2. *Ad Text* - the primary text/copy of the ad (may be truncated - note if "See more" is present)
3. *Media Type* - image, video, or carousel (look for video play buttons or multiple image indicators)
4. *CTA Button* - "Learn More", "Book Now", "Sign Up", "Send Message", "Download", etc.
5. *Start Date* - listed as "Started running on [date]"
6. *Platforms* - Facebook, Instagram, Messenger, Audience Network (shown as icons or text)
7. *Landing Page URL* - if visible in the CTA or ad card (often shown as a domain under the CTA)

*For each ad, if the text is truncated (shows "See more"):*
- Click "See more" to expand the full ad text
- Snapshot to capture the full copy
- This is important for messaging analysis

### Step 7: Scroll for More Results

If fewer than the requested limit of ads have been captured and more exist:
- Use `mcp__playwright__browser_press_key` with key `End` or scroll down
- Wait 2-3 seconds for dynamic loading: `mcp__playwright__browser_wait_for` with timeout 3000ms
- Snapshot again
- Extract additional ads
- Repeat up to 3 scroll cycles (avoid infinite scrolling)

### Step 8: Compile Structured Report

Present the data in this format:

---

## Ad Spy Report: [QUERY]
*Country:* [country] | *Status:* [active/all] | *Scanned:* [date] | *Total Active Ads Found:* [count]

### Active Ads

For each ad:
```
---
**Ad #[N] - [Page Name]**
- Started: [date]
- Platforms: [Facebook, Instagram, etc.]
- Media: [Image/Video/Carousel]
- CTA: [button text]
- Landing: [URL if visible]
- Copy:
> [Full ad text, cleaned up]
---
```

### Messaging Analysis

Group the ads by theme/angle. Common categories:
- *Patient concern* - what concern or problem does the ad call out (lines, volume loss, skin texture)?
- *Outcome/promise* - what result do they promise (and note if it crosses AHPRA lines)?
- *Social proof* - reviews, numbers, practitioner authority/credentials
- *Urgency/scarcity* - limited time, spots filling, seasonal offer, etc.
- *Education/value* - free consults, skin guides, treatment explainers
- *Direct offer* - pricing, discounts, packages, bundles

For each theme found:
```
**[Theme Name]** ([X] ads)
- Key phrases: "[quote from ad]", "[quote from ad]"
- Angle: [1-sentence description of the approach]
```

### Competitive Intelligence Summary

| Metric | Value |
|--------|-------|
| Total active ads | [count] |
| Longest-running ad | [date - indicates proven winner] |
| Most common CTA | [CTA text] |
| Primary platform focus | [based on platform distribution] |
| Estimated spend intensity | [Low/Medium/High - see below] |

*Spend Intensity Guide:*
- *Low* (1-5 active ads): Testing or minimal ad spend
- *Medium* (6-20 active ads): Consistent advertiser, moderate budget
- *High* (21+ active ads): Aggressive advertiser, significant budget, likely split-testing heavily

### Strategic Takeaways

Provide 3-5 actionable observations:
1. What messaging angles are working (longest-running = proven)
2. What CTAs they prefer and why
3. Gaps or angles they are NOT using that the clinic could own (keep these concern-led)
4. How their ad strategy compares to the clinic's current advertising
5. Any creative patterns (video vs image, long copy vs short)

### AHPRA Compliance Note (always include)

The aesthetics clinic operates under AHPRA advertising rules. When recommending angles the clinic can adopt:
- Keep every suggested angle *concern-led* (speak to the patient concern and the consultation/assessment), never a guaranteed outcome.
- Flag any competitor ad that uses before-and-after imagery, superlatives ("best", "#1", "amazing results"), patient testimonials about regulated treatments, or named/priced prescription-only treatments. List these explicitly as *NOT to copy* - they may breach AHPRA rules even if a competitor is running them.
- Note where a competitor is non-compliant: it is a positioning gap the clinic can win with a trustworthy, compliant message rather than a reason to match them.

---

## Error Handling

- *Page won't load / timeout*: Meta may be blocking. Try: clear browser, wait 30 seconds, retry. If persistent, report that the Ad Library may be temporarily unavailable.
- *CAPTCHA appears*: Report: "Meta is showing a CAPTCHA. This happens with repeated searches. Wait a few minutes and try again."
- *Results load but ads are empty/broken*: The page may need JavaScript to fully render. Try scrolling first, then snapshot again.
- *"See more" click doesn't work*: Skip full text extraction for that ad, note it as truncated.

## Tips
- Search competitor CLINIC NAMES for direct intelligence
- Search TREATMENT KEYWORDS (e.g., "anti-wrinkle [suburb]", "skin needling [city]", "cosmetic injectables") to see the whole local landscape
- Check the US or UK market for trends that have not hit AU yet
- Longest-running ads = proven winners worth studying
- Compare the clinic's messaging to theirs - find the concern-led gap they are missing
- Run this monthly on the top 3-5 local competitors to track changes
- Always read every borrowed angle through the AHPRA lens before the clinic uses it
