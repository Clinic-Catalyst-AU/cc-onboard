---
name: cc-cover
description: Generate a reel/story cover (1080x1920) in the CLINIC'S OWN branding - their accent colour, their font, their voice - read from their brand-guide.md. A photo background with a punchy headline and one accent word. Use when the user says cover, reel cover, story cover, make a cover, instagram cover, tiktok cover, or thumbnail for a reel. This is the clinic-branded cover skill; it carries NO agency branding.
---

# CC COVER - Clinic-Branded Reel/Story Cover

Makes a 1080x1920 cover for a reel or story, styled in the CLINIC's own brand (their colours, their font, their voice). The output is the clinic's content - it carries no Clinic Catalyst branding. (The CC-branded cover tool, `/cc-reel-cover`, is a separate operator-only skill for CC's own marketing - do not use it for a clinic.)

## INPUTS (the file contract)
- READS the clinic's brand straight from the Business Brain:
  - `Business-Brain/brand-guide.md` -> the `## Brand colours` accent hex + the tone of voice.
  - `Business-Brain/brand-assets/headline-font.ttf` -> the clinic's font (auto-found).
  - `Business-Brain/brand-assets/logo.png` -> the clinic's logo (auto-found, optional).
  - `Business-Brain/brand-assets/accent.txt` -> a one-line hex, used if brand-guide.md has no colour.
- WRITES the finished cover to `Content/covers/`.
- You do NOT pass font or logo paths - the renderer reads them from `brand-assets/` via `--brand-dir`. If an asset is missing it falls back (clean system font, no logo) and says so, so the clinic can add the real file to `brand-assets/`.
- If there is no `brand-guide.md`, say so and offer to run `/cc-brand-guide` first. Never invent the clinic's brand.

## PROCEDURE
1. READ the brand from the Business Brain:
   - **Accent colour:** read the `## Brand colours` accent hex from `brand-guide.md`. If it is described ("warm gold"), convert to the closest hex. Pass it as `--accent`. (If you have no colour, leave `--accent` off and the renderer uses `brand-assets/accent.txt`, else a neutral.)
   - **Font + logo:** do NOT hunt for these. Pass `--brand-dir <workspace>/Business-Brain` and the renderer auto-loads `brand-assets/headline-font.ttf` and `brand-assets/logo.png`. If they are missing it falls back and reports it.
   - **Voice:** use the brand-guide tone for any headline you write.
2. GET the content:
   - **Background photo:** the clinic supplies it (their treatment room, their work, a stock image they are licensed to use). Never substitute a random image.
   - **Headline:** either the user gives it, or pull the hook from a `/cc-content-engine` post. Split into 1-2 words per line with `|`. Pick ONE accent word - the most punchy.
   - Keep it AHPRA-safe: no claims, no "best/expert/specialist", no before/after.
3. RENDER (font + logo come from the Business Brain via --brand-dir; you only pass the photo, words, accent):
   ```bash
   python3 ~/.claude/skills/cc-cover/cover.py \
     --bg "[clinic-photo]" \
     --headline "WORD ONE|WORD TWO|WORD THREE" \
     --accent "#RRGGBB" --accent-words "ACCENTWORD" \
     --brand-dir "[workspace]/Business-Brain" \
     [--subtext "Smaller line." --accent-sub "accent phrase"] \
     --output [workspace]/Content/covers/[slug]-cover.png
   ```
   - The clinic's logo (if present in `brand-assets/logo.png`) is added automatically. Never add any agency logo.
4. REPORT: give the output path, note the accent colour + whether the brand font or a fallback was used, and offer `/cc-reel` (to caption the reel this covers) as the next step.

## DESIGN NOTES (inherited quality bar)
- 1-2 words per headline line. One accent word, on its own line where possible.
- The headline auto-scales to fit. A neutral dark readability card sits behind the text so it reads on any photo (text zone and photo zone never compete).
- Subtext is short and optional.

## IMPORTANT RULES
- This is the CLINIC-branded cover. NEVER add Clinic Catalyst branding (no CC arrow, no CC teal) - that is `/cc-reel-cover`, a different skill.
- Only use photos the clinic is licensed to use.
- AHPRA-safe headline text only. No emdashes.
- Output lands in `~/Clinic/Content/covers/`.
