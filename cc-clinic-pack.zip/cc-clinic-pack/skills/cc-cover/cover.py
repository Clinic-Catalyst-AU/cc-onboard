#!/usr/bin/env python3
"""
Clinic reel/story cover generator - renders in the CLINIC's OWN branding.
No agency branding. Accent colour + font are passed in by the cc-cover skill
after it reads the clinic's brand-guide.md. This is a dumb renderer: the skill
supplies the brand params.

Usage:
    python3 cover.py --bg photo.jpg \
        --headline "YOUR|SKIN|DESERVES|HONESTY" \
        --accent "#C9A24B" --accent-words "HONESTY" \
        --font-path "/path/Clinic-Bold.ttf" \
        --subtext "Book a winter skin consult." --accent-sub "winter skin" \
        --logo clinic-logo.png \
        --output cover.png
"""
import argparse, os
from PIL import Image, ImageDraw, ImageFont, ImageOps

W, H = 1080, 1920
WHITE = (255, 255, 255)

# Font fallback chain (clinic font first, then sensible system bolds, then PIL default)
SYSTEM_BOLD_CANDIDATES = [
    os.path.expanduser("~/Library/Fonts/Montserrat-ExtraBold.ttf"),
    os.path.expanduser("~/Library/Fonts/Montserrat-Bold.ttf"),
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/System/Library/Fonts/Supplemental/Futura.ttc",
    "/System/Library/Fonts/HelveticaNeue.ttc",
    "/Library/Fonts/Arial Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
]
SYSTEM_REG_CANDIDATES = [
    os.path.expanduser("~/Library/Fonts/Inter-Medium.ttf"),
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "/System/Library/Fonts/HelveticaNeue.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]

# Layout (forked from the CC cover system: card 24-78%, 49px line gaps, auto-scale)
CARD_TOP, CARD_BOTTOM = 0.24, 0.78
CARD_MARGIN, CARD_RADIUS = 70, 18
CARD_COLOR, CARD_ALPHA = (28, 28, 32), 150
LOGO_Y_PCT = 0.29
HEADLINE_SIZE, LINE_GAP = 100, 49
SUBTEXT_SIZE, SUBTEXT_LINE_GAP = 42, 8
TEXT_LEFT_PAD = 60


def hex_rgb(h):
    h = h.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    except ValueError:
        return (61, 189, 179)  # safe teal-ish fallback


def first_existing(paths):
    for p in paths:
        if p and os.path.isfile(p):
            return p
    return None


def font(path_pref, size, candidates):
    p = first_existing(([path_pref] if path_pref else []) + candidates)
    if p:
        try:
            return ImageFont.truetype(p, size)
        except (IOError, OSError):
            pass
    return ImageFont.load_default()


def prep_bg(path):
    img = ImageOps.exif_transpose(Image.open(path).convert("RGBA"))
    ratio, ir = W / H, img.width / img.height
    if ir > ratio:
        nw = int(img.height * ratio); left = (img.width - nw) // 2
        img = img.crop((left, 0, left + nw, img.height))
    else:
        nh = int(img.width / ratio); img = img.crop((0, 0, img.width, nh))
    return img.resize((W, H), Image.LANCZOS)


def accent_set(words):
    s = set()
    for phrase in words:
        for w in phrase.upper().strip().split():
            if w:
                s.add(w)
    return s


def draw_words(draw, lines, accent_words, accent_rgb, x, start_y, f, gap):
    sp = draw.textbbox((0, 0), " ", font=f)[2]
    cy = start_y
    for line in lines:
        cx = x
        for word in line.split():
            c = accent_rgb if word.upper().rstrip(".,!?:;") in accent_words else WHITE
            draw.text((cx, cy), word, fill=c, font=f)
            cx += draw.textbbox((cx, cy), word, font=f)[2] - cx + sp
        bb = draw.textbbox((0, 0), line, font=f)
        cy += (bb[3] - bb[1]) + gap
    return cy


def wrap(draw, text, f, max_w):
    words, lines, buf = text.split(), [], []
    for w in words:
        if draw.textbbox((0, 0), " ".join(buf + [w]), font=f)[2] > max_w and buf:
            lines.append(" ".join(buf)); buf = [w]
        else:
            buf.append(w)
    if buf:
        lines.append(" ".join(buf))
    return lines


def generate(a):
    accent_rgb = hex_rgb(a.accent)
    canvas = prep_bg(a.bg)

    card_x, card_y = CARD_MARGIN, int(H * CARD_TOP)
    card_w, card_h = W - CARD_MARGIN * 2, int(H * (CARD_BOTTOM - CARD_TOP))
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    box = (card_x, card_y, card_x + card_w, card_y + card_h)
    ld.rounded_rectangle(box, radius=CARD_RADIUS, fill=(*CARD_COLOR, CARD_ALPHA))
    ld.rounded_rectangle(box, radius=CARD_RADIUS, outline=(255, 255, 255, 35), width=1)
    canvas = Image.alpha_composite(canvas, layer)
    draw = ImageDraw.Draw(canvas)

    has_logo = a.logo and os.path.isfile(a.logo)
    if has_logo:
        try:
            logo = Image.open(a.logo).convert("RGBA")
            tw = 280; logo = logo.resize((tw, int(logo.height * tw / logo.width)), Image.LANCZOS)
            canvas.paste(logo, ((W - tw) // 2, int(H * LOGO_Y_PCT) - logo.height // 2), logo)
            draw = ImageDraw.Draw(canvas)
        except Exception as e:
            print(f"  (logo skipped: {e})")

    fh = font(a.font_path, a.headline_size or HEADLINE_SIZE, SYSTEM_BOLD_CANDIDATES)
    fs = font(a.subtext_font or a.font_path, SUBTEXT_SIZE, SYSTEM_REG_CANDIDATES)

    lines = [l.strip() for l in a.headline.split("|")]
    a_words = accent_set([w.strip() for w in a.accent_words.split(",")] if a.accent_words else [])
    text_x = card_x + TEXT_LEFT_PAD
    max_w = card_w - TEXT_LEFT_PAD - 30

    longest = max(draw.textbbox((0, 0), l, font=fh)[2] for l in lines)
    if longest > max_w:
        fh = font(a.font_path, int((a.headline_size or HEADLINE_SIZE) * max_w / longest), SYSTEM_BOLD_CANDIDATES)

    headline_y = int(H * (0.38 if has_logo else 0.33))
    draw_words(draw, lines, a_words, accent_rgb, text_x, headline_y, fh, LINE_GAP)

    if a.subtext:
        sub_words = accent_set([a.accent_sub] if a.accent_sub else [])
        draw_words(draw, wrap(draw, a.subtext, fs, max_w), sub_words, accent_rgb,
                   text_x, int(H * 0.65), fs, SUBTEXT_LINE_GAP)

    os.makedirs(os.path.dirname(os.path.abspath(a.output)), exist_ok=True)
    canvas.convert("RGB").save(a.output, "PNG", quality=95)
    print(f"Saved: {a.output}  (accent {a.accent}, font {'clinic' if a.font_path else 'fallback'})")


def resolve_brand_assets(a):
    """Refer to the Business Brain: auto-find the clinic's font + logo in
    <brand-dir>/brand-assets/ when not explicitly passed. Also read the accent
    hex from brand-assets/accent.txt if --accent was left at the default."""
    bd = os.path.expanduser(a.brand_dir) if a.brand_dir else ""
    assets = os.path.join(bd, "brand-assets") if bd else ""
    if assets and os.path.isdir(assets):
        if not a.font_path:
            f = os.path.join(assets, "headline-font.ttf")
            if os.path.isfile(f):
                a.font_path = f
        if not a.subtext_font:
            f = os.path.join(assets, "body-font.ttf")
            if os.path.isfile(f):
                a.subtext_font = f
        if not a.logo:
            lg = os.path.join(assets, "logo.png")
            if os.path.isfile(lg):
                a.logo = lg
        if a.accent == "__from_brain__":
            ac = os.path.join(assets, "accent.txt")
            if os.path.isfile(ac):
                a.accent = open(ac).read().strip() or "#3DBDB3"
    if a.accent == "__from_brain__":
        a.accent = "#3DBDB3"  # neutral fallback if nothing supplied the colour
    return a


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--bg", required=True)
    p.add_argument("--headline", required=True)
    # default accent is a sentinel: the skill passes a real hex from brand-guide.md,
    # else cover.py tries brand-assets/accent.txt, else a neutral.
    p.add_argument("--accent", default="__from_brain__")
    p.add_argument("--accent-words", default="", dest="accent_words")
    p.add_argument("--subtext", default="")
    p.add_argument("--accent-sub", default="", dest="accent_sub")
    p.add_argument("--brand-dir", default="~/Clinic/Business-Brain", dest="brand_dir",
                   help="the clinic's Business-Brain folder; font + logo are read from its brand-assets/")
    p.add_argument("--font-path", default="", dest="font_path")
    p.add_argument("--subtext-font", default="", dest="subtext_font")
    p.add_argument("--logo", default="")
    p.add_argument("--headline-size", type=int, default=None, dest="headline_size")
    p.add_argument("--output", default="cover.png")
    generate(resolve_brand_assets(p.parse_args()))


if __name__ == "__main__":
    main()
