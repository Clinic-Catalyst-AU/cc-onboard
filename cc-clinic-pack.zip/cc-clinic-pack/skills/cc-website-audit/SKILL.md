---
name: cc-website-audit
description: Full SEO audit for an aesthetics or skin clinic website - on-page optimisation, internal linking, content gaps, content refresh priorities, technical SEO health, SERP analysis, and AHPRA-aware best practices. Covers both Google and AI crawler readiness. Use when auditing a clinic website, optimising treatment or concern pages, finding content gaps for a skin clinic, refreshing stale clinic content, checking technical SEO, or when the user mentions clinic SEO audit, skin clinic SEO, aesthetics website audit, treatment page audit, on-page SEO, internal links, content refresh, technical audit, or clinic site optimisation.
---

# CC WEBSITE AUDIT

Comprehensive SEO audit for aesthetics and skin clinic websites. Covers on-page optimisation, internal linking structure, content health, SERP positioning, and modern best practices. Works for both Google rankings AND AI crawler visibility.

Every recommendation is AHPRA-aware. This is a regulated advertising environment - the audit must never push a clinic toward non-compliant content.

---

## FILE CONTRACT

Before auditing, read the clinic's brand guide for voice, tone, services, and word bank:

- `Business-Brain/brand-guide.md`

If the file is missing, ask for it or proceed with neutral clinic-appropriate language. Pull the clinic's approved service names, concern language, and word bank from this file and use them in every title, meta, and header recommendation. Never invent a treatment name, claim, or credential that is not in the brand guide.

---

## AHPRA COMPLIANCE GUARDRAILS (READ FIRST)

Australian aesthetics and skin clinics advertise regulated health services. Every recommendation in this audit must hold to these rules. If an SEO best practice conflicts with these, compliance wins.

- Concern-led, not product-led. Optimise around the concern the patient searches (fine lines, pigmentation, skin laxity, acne scarring), not around prescription product names.
- Never use prescription drug brand names in copy, titles, metas, alt text, file names, or schema. Say _anti-wrinkle injections_ or _muscle relaxant injections_, not the brand. Say _dermal filler_ generically. Do not name Schedule 4 products.
- No before and after imagery as an SEO asset, and no alt text, file names, or schema describing before and after results. Do not recommend a results gallery as a ranking play.
- No testimonials or reviews about regulated treatments. AHPRA prohibits testimonials that reference a regulated health service. Do not recommend Review or AggregateRating schema on treatment or concern pages. Reviews are acceptable only for non-clinical aspects (front-of-house experience, ease of booking) and even then keep them off regulated-service pages.
- No superlatives or comparative claims. Strip _best, safest, leading, number one, painless, guaranteed, permanent_ from any recommended title or meta. These create unrealistic expectations and breach the advertising guidelines.
- Balanced, accurate, honest. Recommend that treatment pages include risks, recovery, and that results vary. This also strengthens EEAT.
- AU English everywhere. Optimise, colour, centre, specialise, enquiry, jewellery. Recommended copy must match.
- No emdashes in any recommended copy. Use hyphens with spaces ( - ) or rewrite.
- Use italics, not bold, for emphasis in any recommended copy.

---

## WHEN TO USE

- Auditing a clinic website before or after launch
- Diagnosing why treatment or concern pages are not ranking
- Finding content gaps and opportunities for a skin clinic
- Identifying stale clinic content that needs refreshing
- Optimising internal link architecture across treatment and concern pages
- Pre-publish checks on new clinic content
- Clinic Catalyst client website audits

---

## AUDIT MODULES

Run all modules for a full audit, or pick specific ones.

### MODULE 1: ON-PAGE SEO

Audit each page for:

**Title Tags**
- Length: 50-60 characters (display limit)
- Primary concern or treatment keyword within first 60 chars
- Unique across site (no duplicates)
- Compelling for CTR (not just keyword-stuffed)
- Format: `Primary Concern - Suburb | Clinic Name`
- No superlatives, no prescription product names (AHPRA)

**Meta Descriptions**
- Length: 150-160 characters
- Includes primary concern keyword naturally
- Has a clear value proposition or booking CTA (no superlatives or guarantees)
- Unique per page
- Reads like a human wrote it (AI crawlers judge quality)

**Header Hierarchy**
- Single H1 per page containing the primary concern or treatment keyword
- H2s cover main subtopics (use for content structure)
- H3-H6 for supporting detail
- No skipped levels (H1 -> H3 without H2)
- Headers should read as a table of contents

**Content Quality**
- Minimum 300 words for standard pages, 1500+ for pillar content
- Primary keyword in first 100 words
- Related/semantic keywords throughout (not forced)
- Original insights, not rehashed generic advice
- Answers the actual search intent (informational vs transactional)
- Concern-led framing, with risks, recovery, and a results-vary note on treatment pages (AHPRA + EEAT)
- Structured with lists, tables, callouts where appropriate
- EEAT signals: practitioner credentials (AHPRA registration), citations, first-hand clinical experience

**Image Optimisation**
- Descriptive alt text on every image (not "image1.png"), concern-led, no before and after, no product brand names
- File names use concern keywords (e.g., `pigmentation-treatment-richmond.webp`)
- WebP or AVIF format preferred
- Compressed (under 200KB for most images)
- Lazy loading on below-fold images
- Width/height attributes set (prevents CLS)

**URL Structure**
- Short, descriptive, lowercase
- Concern or treatment keywords in URL path
- No special characters, IDs, or query strings
- Canonical tags set correctly
- HTTPS enforced

---

### MODULE 2: INTERNAL LINKING

**Site Architecture Audit**
- Map all pages and their link relationships
- Identify orphan pages (no internal links pointing to them)
- Check for broken internal links
- Verify navigation includes all key treatment and concern pages plus the booking page

**Authority Flow**
- Homepage should link to pillar pages (key concern hubs)
- Pillar pages should link to cluster content (individual treatments under that concern)
- Every page should be reachable within 3 clicks from homepage
- High-value pages (top treatments, booking) should have more internal links pointing to them

**Pillar-Cluster Strategy**
```
PILLAR PAGE (broad concern, e.g. "skin pigmentation")
  |-- Cluster 1 (treatment) -- links back to pillar
  |-- Cluster 2 (treatment) -- links back to pillar
  |-- Cluster 3 (treatment) -- links back to pillar
  All clusters link to each other where relevant
```

**Anchor Text**
- Descriptive, keyword-relevant anchor text
- Avoid "click here" or "read more" as anchor text
- Vary anchor text (don't use the same text for every link to a page)
- Match anchor text to the target page's primary concern keyword

**Common Issues**
- Too many links on one page (dilutes value - aim for under 100)
- Footer/sidebar link bloat (low value, high noise)
- Orphan pages with no internal links
- Deep pages requiring 5+ clicks to reach

---

### MODULE 3: CONTENT GAP ANALYSIS

**Topic Coverage Audit**
Without paid tools, identify gaps by:

1. **Map existing content** - list every page and its target concern/treatment keyword
2. **List clinic services** - does each treatment have a dedicated, concern-led page?
3. **Patient journey mapping** - is there content for each stage?
   - Awareness: "What causes [skin concern]?"
   - Consideration: "How is [skin concern] treated?"
   - Decision: "What to expect from [treatment] at our clinic"
   - Post-treatment: "Aftercare and how to maintain results"
4. **FAQ mining** - what do patients ask at consults? Each FAQ = potential content
5. **Competitor scan** - visit other local clinics, note concerns and treatments they cover that you do not

**Content Format Gaps**
Check if you have:
- [ ] Long-form concern guides (2000+ words)
- [ ] Treatment explainers with what-to-expect steps
- [ ] Concern comparison pages (e.g. which treatment for which concern)
- [ ] FAQ pages with schema markup
- [ ] Patient education pages on risks, recovery, and realistic outcomes
- [ ] Video content with transcripts (practitioner-led education, no testimonials)
- [ ] Tools/quizzes (like a skin concern assessment quiz)

**AI-Answerable Content Gaps**
Content that LLMs love to cite:
- Definitive "What is [skin concern]" explainers
- Step-by-step "what to expect" treatment processes
- Data-backed claims with sources (dermatology references)
- Original, clinic-owned frameworks with names (e.g., "The Clinic Catalyst Skin Roadmap")
- Lists and concern-to-treatment comparisons

---

### MODULE 4: CONTENT REFRESH

**Identify Stale Content**
- Pages not updated in 6+ months
- Pages with outdated statistics or references
- Pages mentioning discontinued treatments, old pricing, or former practitioners
- Pages with broken external links
- Pages with thin content (under 300 words)

**Refresh Priority Matrix**

| Priority | Signal | Action |
|----------|--------|--------|
| HIGH | Was ranking, now dropped | Update content, add new sections, refresh references |
| HIGH | High traffic page with old info | Update facts, add new insights, refresh date |
| MEDIUM | Relevant concern, thin content | Expand to 1500+ words, add media, improve structure |
| MEDIUM | Good content, poor structure | Add headers, lists, schema, internal links |
| LOW | Evergreen concern, still accurate | Light refresh - update date, add 1-2 new points |
| KILL | Irrelevant, no traffic, no value | Redirect to relevant page or remove |

**Refresh Checklist**
- [ ] Update any statistics, references, or dates
- [ ] Add new sections for recent developments
- [ ] Improve header structure
- [ ] Add internal links to newer treatment and concern content
- [ ] Add/update schema markup
- [ ] Refresh meta description
- [ ] Add FAQ section if missing
- [ ] Update images and alt text (concern-led, no before and after, no product names)
- [ ] Confirm AHPRA compliance: no testimonials on regulated pages, no superlatives, no prescription brand names
- [ ] Add "Last updated: [date]" signal

**CORE-EEAT Quick Assessment Before Refresh**
Before refreshing, quickly score each CORE-EEAT dimension (estimate 0-100) to focus effort on the weakest areas:
- C (Contextual Clarity), O (Organisation), R (Referenceability), E (Exclusivity)
- Exp (Experience), Ept (Expertise), A (Authority), T (Trust)
Focus refresh on dimensions scoring below 60. For clinics, Authority and Trust lean heavily on AHPRA registration and practitioner credentials.

**GEO Enhancement During Refresh**
Every refresh is a GEO opportunity:
- Add a clear definition at the start ("[Skin concern] is...")
- Include quotable statistics with sources
- Add Q&A formatted sections for AI citation
- Update source citations with recent dermatology references
- Create standalone factual statements AI can quote (no claims, no superlatives)

**Republishing Strategy**
- Major overhaul (50%+ new): Update published date
- Moderate update (20-50%): Add "Last Updated" date
- Minor update (<20%): Keep original date
- Always update dateModified in schema + sitemap lastmod
- Resubmit to search console after publishing

---

### MODULE 5: SERP & CONTENT FORMAT ANALYSIS

**Before creating content, check what is ranking:**

1. Search the target concern or treatment keyword
2. Note the content format of the top 5 results:
   - Concern guide? Treatment explainer? FAQ? Tool? Video?
   - Word count range
   - Number of images/media
   - Header structure pattern
3. Check for SERP features:
   - Featured snippet (what format triggered it?)
   - People Also Ask (mine these for content sections)
   - AI Overview (what sources are cited?)
   - Video carousel
   - Local pack (critical for clinics - check Google Business Profile presence)
4. Match or exceed the winning format, within AHPRA limits

**AI Overview Analysis**
When Google shows an AI Overview:
- What sources does it cite?
- What format gets cited? (lists, definitions, steps)
- What question is it answering?
- Can you create content that answers it better and stays compliant?

---

### MODULE 6: MODERN SEO BEST PRACTICES (2025-2026)

**Entity SEO**
- Build topical authority (cover a concern completely, not just one keyword)
- Use schema markup (Organization, LocalBusiness, MedicalBusiness, FAQPage, Article)
- Consistent NAP (Name, Address, Phone) across web and Google Business Profile
- Practitioner entities with AHPRA registration and expertise signals

**Core Web Vitals**
- LCP (Largest Contentful Paint): under 2.5s
- INP (Interaction to Next Paint): under 200ms
- CLS (Cumulative Layout Shift): under 0.1
- Test at: PageSpeed Insights, Chrome DevTools

**Mobile-First**
- Responsive design (not a separate mobile site)
- Touch targets 48px minimum
- No horizontal scroll
- Font size 16px minimum
- Test on real devices, not just desktop emulators

**Structured Data / Schema**
Priority schema types for clinics:
- `Organization` - on homepage
- `LocalBusiness` or `MedicalBusiness` - clinic identity, hours, address
- `Article` / `BlogPosting` - on concern and education pages
- `FAQPage` - on any page with Q&A
- `BreadcrumbList` - site-wide
- `Person` (or `Physician`) - on practitioner/about pages with credentials
- Do NOT add `Review` or `AggregateRating` to regulated treatment pages (AHPRA)

**Content Freshness Signals**
- Publish dates on articles
- "Last updated" dates (search engines value recency)
- Regular publishing cadence
- Update old content rather than only creating new

**Brand Voice + SEO Integration**
- Write for patients first, optimise for search second
- Brand voice consistency across all content (pull from `Business-Brain/brand-guide.md`)
- Use the clinic's word bank in meta tags and headers
- Authenticity and clarity over keyword density

---

### MODULE 7: TECHNICAL SEO

**Crawlability**
- robots.txt: exists, valid syntax, sitemap declared, important pages not blocked, AI crawlers allowed (GPTBot, PerplexityBot, Claude-Web)
- XML Sitemap: exists, valid format, submitted to search console, only indexable URLs, accurate lastmod dates
- Crawl budget: check for redirect chains, duplicate content, thin pages, orphan pages

**Indexability**
- Index coverage: pages in sitemap vs pages indexed (should be >90%)
- Index blockers: noindex tags, canonical pointing elsewhere, 4xx/5xx errors, redirect loops
- Canonical tags: present, self-referencing, consistent (HTTP/HTTPS, www/non-www)
- Duplicate content: exact dupes, near dupes, parameter dupes, protocol dupes

**Core Web Vitals**
- LCP (Largest Contentful Paint): target <2.5s
- INP (Interaction to Next Paint): target <200ms
- CLS (Cumulative Layout Shift): target <0.1
- Check both mobile and desktop

**Mobile-Friendliness**
- Viewport configured, text readable (16px min), tap targets 48px min
- Content fits viewport, no horizontal scroll
- Mobile version has the same content, schema, and meta tags as desktop

**Security**
- SSL certificate valid, HTTPS enforced, no mixed content
- Security headers: CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, HSTS

**Structured Data**
- Check for existing schema and validation errors
- Missing schema opportunities: Article, FAQPage, Organization, LocalBusiness, MedicalBusiness, Person, BreadcrumbList
- For aesthetics clinics: LocalBusiness or MedicalBusiness plus Physician/Person with credentials. Avoid Review schema on regulated pages.

**URL Structure**
- Clean, lowercase, descriptive, keyword-relevant
- No special characters, session IDs, or excessive parameters
- Redirect chains and loops identified and fixed

---

## AUDIT OUTPUT FORMAT

When running a full audit, produce:

```
WEBSITE SEO AUDIT: [Clinic Name]
Date: [Date]
Auditor: Clinic Catalyst

OVERALL HEALTH SCORE: [X/100]

CRITICAL ISSUES (Fix immediately)
1. [Issue] - [Page] - [Impact]

HIGH PRIORITY (Fix this week)
1. [Issue] - [Page] - [Recommendation]

MEDIUM PRIORITY (Fix this month)
1. [Issue] - [Page] - [Recommendation]

AHPRA COMPLIANCE FLAGS
- [Page] - [Non-compliant element] - [Fix]

CONTENT GAPS
- [Missing concern/treatment] - [Recommended format] - [Priority]

REFRESH TARGETS
- [Page] - [What is stale] - [Refresh action]

INTERNAL LINKING FIXES
- [Orphan page] - [Suggested links from]
- [Broken link] - [Fix]

QUICK WINS (under 30 minutes each)
1. [Action] - [Expected impact]
```

---

## INDUSTRY-SPECIFIC NOTES

### Aesthetics & Skin Clinics
- Schema: use `LocalBusiness` or `MedicalBusiness` + `Person`/`Physician` with AHPRA registration
- Local SEO is critical - optimise Google Business Profile, NAP consistency, and suburb-level concern pages
- Do NOT recommend `Review` or `AggregateRating` schema on regulated treatment pages (AHPRA)
- Concern hub pages (e.g. pigmentation, ageing, acne) as pillars, individual treatments as clusters
- FAQ pages answering "what causes [concern]" and "what to expect from [treatment]" (AI loves these and they suit patient education)
- Patient education pages covering risks, recovery, and realistic outcomes (compliance + EEAT)

### Multi-Location Clinics
- Dedicated, unique page per location (not one page listing all)
- Location-specific NAP, hours, and Google Business Profile
- Suburb-level concern and treatment pages where search volume supports it
- Consistent schema across locations

### Service / Treatment Pages
- One concern-led page per treatment (not one page listing all treatments)
- What-to-expect and aftercare content per treatment
- Pricing or "from" guidance where appropriate, with no guarantees
- Process/how-it-works pages framed around the patient concern

---

## REMEMBER

Good SEO is good UX, and for clinics good UX is also good compliance. If a page is well-structured, clearly written, fast-loading, genuinely helpful, and AHPRA-compliant, it will rank on Google AND get cited by AI. Do not optimise for algorithms at the expense of patients or compliance. The best-performing clinic pages are the ones real patients trust and want to share.
