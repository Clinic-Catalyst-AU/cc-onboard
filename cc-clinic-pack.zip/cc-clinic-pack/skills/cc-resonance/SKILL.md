---
name: cc-resonance
description: Run the neuro-emotive resonance process for ANY brand or clinic - interview them through the 13 Context Questions, audit + apply the 21 neuro-emotive models across the 5-step method, and produce their resonance-messaging.md (the emotional source-of-truth that then powers their brand guide and content engine). Works for any business; AHPRA-aware layer for Clinic Catalyst clinics. Use when you say resonance, neuro-emotive, messaging intake, run resonance for [brand/clinic], build their messaging/positioning, structural/embedded/language models, or BEFORE building any brand guide, content engine, website, ads or sales copy - the resonance-messaging.md comes first.
---

# CC RESONANCE - Neuro-Emotive Messaging 

This is the neuro-emotive method as a repeatable skill. You take a brand THROUGH the process -
interview them, then audit and apply the models - and produce their **resonance-messaging.md**. That
document is the foundation everything else is built on:

`resonance-messaging.md  ->  brand guide  ->  content engine`

Generic by design (coaches, healers, NDIS, clinics - any brand). For aesthetics clinics, apply the
AHPRA layer flagged in each reference.

*File contract* - for a clinic this skill follows the Business Brain File Contract
(your workspace `CLAUDE.md` documents it). It is a foundation skill: it READS the live interview
answers and WRITES `Business-Brain/resonance-messaging.md` (a fixed name, never renamed). All paths are
relative to the active clinic workspace - the root is `~/Clinic/` (your clinic workspace). Never hardcode one clinic's
absolute path.

## The method has 3 reference files - read them when you run it
- `references/intake-questions.md` - the 13 Context Questions (the interview). START HERE.
- `references/model-library.md` - the 21 models (3 families) with triggers + examples (the menu).
- `references/neuro-emotive-method.md` - the 5-step process + worked integration examples.

## How to use
- `/cc-resonance [Brand/Clinic]` - run the full intake interview, then build resonance-messaging.md
- `/cc-resonance [Brand/Clinic] --build` - build the document from already-captured intake answers
- FOUNDATION WORKBOOK HAND-OFF: if the user provides a `*-foundation.md` intake (the file the workshop
  Foundation Workbook generates - header says "Feed this to /cc-resonance then /cc-brand-guide"), that IS
  the captured intake. Run `--build` mode from it: the ideal-patient, pain, desire and voice answers are
  the resonance raw material - expand them through the models, never re-ask what the workbook already
  answered. Only ask follow-ups for answers marked "(to fill in together)". Then run /cc-brand-guide.
- `/cc-resonance [Brand/Clinic] --audit [url or file]` - audit existing copy against their models/profile

## Workflow
1. **Interview** - work through the 13 Context Questions (intake-questions.md), one at a time, reflecting
   back what you hear. Capture their strong phrases verbatim - their words seed the language bank. Don't guess.
2. **Apply the method** - run the 5 steps (neuro-emotive-method.md), pulling from the model library:
   Structural Audit -> Embedded Models -> Language Precision -> Alignment Check -> Integration.
   Select the few models that genuinely fit this brand; don't force all 21.
3. **Integrate** - rewrite their core offer/messaging using 1 Structural + 1 Embedded + 1 Language model.
   Layered but soft. Psychological but ethical. Power stays with the customer.
4. **Output** the resonance-messaging.md (template below) and save it:
   - A clinic -> `Business-Brain/resonance-messaging.md` in the active clinic workspace (root
     `~/Clinic/` (your clinic workspace)). Fixed name - never rename. Never hardcode one clinic's absolute path.
   - Any other brand -> that brand's folder, `resonance-messaging.md`

## AHPRA layer (aesthetics clinics only)
Concern-led, never claim-led. NO specialist/expert (use "special interest in"); NO best/safe/painless/
guaranteed/anti-ageing claims; NO patient testimonials about regulated treatments; NO before/after as a
promise. The Alignment Check (Step 04) must also pass AHPRA. The beauty-clinic example in the method file
shows the tone ceiling.

## Output: resonance-messaging.md
This file is the INPUT to the brand-guide generator (and then the content engine), so keep the section
headings below EXACTLY as named and fill every one - the brand guide pulls Audience, Language Bank,
Voice models, Positioning and Values straight from here. Formatting: no emdashes (hyphens with spaces),
italics for emphasis not bold (bold only for the section headers).
```markdown
# RESONANCE MESSAGING - [Brand/Clinic]
# Neuro-emotive method | [date]

## 1. The Brand Truth (intake)
[the 13 Context Question answers, distilled - audience, offer/positioning, journey, emotion to create,
desired action, competitive noise, values, framework, special magic, non-negotiables, language boundaries, outcomes]

## 2. Model Map
- Structural: present / missing / to-strengthen
- Embedded: active / overused / underused (pick the ones to lean into)
- Language: which models to use

## 3. Language Bank
OPEN words (use - from their boundaries + the language models): ...
CLOSE words (never - from their boundaries + AHPRA if a clinic): ...

## 4. Integrated Core Messaging
The rewritten core offer using [1 Structural] + [1 Embedded] + [1 Language] model, with WHY it works.
Plus 3-5 headline options (each tagged with the language model used).

## 5. Alignment Check
Creates clarity? reduces fear? encourages autonomy? maintains integrity? [+ AHPRA pass if a clinic]

## Handoff to the brand guide
This document is consumed by the brand-guide generator: Section 1 (Brand Truth) -> audience + positioning
+ values; Section 3 (Language Bank) -> the voice do/don't words; Section 4 (Integrated Core Messaging +
headlines) -> the brand voice + messaging pillars. Keep it complete so that handoff is clean. Then the
brand guide feeds the content engine. It's a living document - update as real data + feedback come in.
```

## Rules
- Run it WITH them - the feeling of being deeply understood is half the value. Don't fill it in for them.
- Select models that fit; layered but SOFT. Never hypey, never manipulative (Step 04 is the ethics gate).
- Capture their real words - the language bank should sound like them, not like marketing.
- No emdashes (hyphens with spaces). It's a LIVING document - update as results + feedback come in.
- The method/models are proprietary IP - share the OUTPUT document, never the framework or this skill.
