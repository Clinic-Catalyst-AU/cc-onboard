# The Neuro-Emotive Method - 5-step process 

Run AFTER the intake (see `intake-questions.md`). Pull models from `model-library.md`.
The point: layered but soft, psychological but ethical. Never hypey, never manipulative.

## STEP 01 - Structural Model Audit
Look at the offer. Which STRUCTURAL models are clearly present? (Trust Anchor, Possibility Lens,
Prestige Magnet, Ownership Shift, Believability Bridge, Price Harmony, Trust-Through-Transparency)
- Which are present? Which are missing? How could the structure be strengthened?

## STEP 02 - Embedded Emotional Models
Review a recent piece of their content. Which EMBEDDED models are active? (Urgency with Integrity,
Social Mirror, Belonging Trigger, Desire Dial, Pain Diffuser, Binge-Worthy Flow, Guided Choice Maker,
Relevance Lock, Retention Resonator)
- Which are overused? Which are underused (and would help)?

## STEP 03 - Language Precision
Does their content use the LANGUAGE models? (Curiosity Spark, Empathy Echo, Emotional Proof,
Clarity Charge, Voiceprint Precision)
- Pick one weak sentence and rewrite it using Curiosity Spark (pattern interrupt + open loop).
  Example: "Here are 5 ways to grow your business" -> "What if the problem isn't your strategy... but the way you're making decisions?"

## STEP 04 - Alignment Check
Does the messaging: create clarity? reduce fear? encourage autonomy? maintain integrity?
If not, what needs adjusting? (This is the ethical gate - power stays with the client/customer.)

## STEP 05 - Integration
Rewrite the core offer description using 1 Structural + 1 Embedded + 1 Language model. Layered but soft.

### Worked examples

HEALER (Reiki/intuitive 6-session package): Believability Bridge + Pain Diffuser + Empathy Echo ->
"This 6-session guided healing journey is designed for sensitive, overwhelmed women who are tired of
holding everything together alone - offering gentle, structured energetic support so you can feel calm,
clear, and grounded again."

BUSINESS COACH (12-week mentorship): Trust Anchor + Social Mirror + Curiosity Spark ->
"If you're exhausted from trying to 'figure it out alone,' this 12-week structured mentorship gives you a
clear, step-by-step growth framework - so you can stop second-guessing your strategy and finally build a
business that feels stable, scalable, and aligned." (Grounded, not hypey.)

BEAUTY / AESTHETIC CLINIC (signature skin program): Trust Anchor + Desire Dial + Voiceprint Precision ->
"Our Signature Skin Rejuvenation Program is a clinically guided, step-by-step treatment plan designed for
women who want visible results without looking 'overdone.' Using advanced technology and tailored protocols,
we restore smoothness, firmness, and glow - so you can feel confident in your skin again, naturally."
WHY: Trust Anchor = "signature program / clinically guided / step-by-step / tailored protocols" (safety +
expertise); Desire Dial = "visible results without looking overdone / feel confident again" (identity +
aspiration); Voiceprint Precision = calm, premium, no hype, no exaggerated promises.

> CLINIC CATALYST / AHPRA NOTE: for regulated cosmetic/medical clinics, the beauty-clinic example shows the
> ceiling - calm, premium, concern-led. Even so, run the output through AHPRA: NO "best/safe/painless/
> guaranteed/anti-ageing" claims, NO specialist/expert (use "special interest in"), NO patient testimonials
> about regulated treatments, NO before/after as a promise. Layered + soft, never a result claim.
