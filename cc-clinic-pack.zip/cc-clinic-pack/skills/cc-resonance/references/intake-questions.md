# The Intake - 13 Context Questions (the generic process)

Ask these BEFORE applying the models. This is what makes it work for ANY brand - it gathers the raw
emotional + strategic truth of the business. Ask one at a time, reflect back what you hear, capture
verbatim where the language is good (their words become the language bank). Don't guess - if an answer is
thin, dig: "say more", "what does that feel like for them?".

1. **Audience Identity** - who exactly are they for? (the real human, life stage, what they're tired of, what they crave - NOT a demographic)
2. **Offer Type & Price Positioning** - what's the offer, the price, and how is it positioned? (premium/accessible/value-not-price)
3. **Medium of Delivery** - how is it delivered + what's this specific piece of content/asset for?
4. **Stage of Customer Journey** - cold/warm/hot? what do they already know/believe? what's the emotional starting point?
5. **Emotional State to Create** - the exact feeling the messaging should produce (e.g. "calm urgency", "relief -> hope -> trust")
6. **Desired Action** - the primary action + any secondary actions
7. **Competitive Noise** - what the market sounds like, and how this brand is different/quieter/truer
8. **Core Values** - the non-negotiable values the messaging must embody
9. **Unique Modality or Framework** - their signature method/IP/framework (name it)
10. **Your Special Magic** - what only THEY bring (lived experience, voice, perspective)
11. **Non-Negotiables** - what they will NEVER do in marketing (shame, hype, guru vibes, etc.)
12. **Language Boundaries** - words to AVOID and words to PREFER (this directly seeds the language bank)
13. **Desired Client Outcomes** - the real transformation the client/customer experiences

## Worked example A - a skin clinic (Winter Skin Reset)
- Audience: women 35-55 whose skin feels tired, dull and tight; self-conscious, often been burned by a clinic that pushed too hard.
- Positioning: a $199 skin consult as the calm, honest first step - a proper look at your skin, a plan that fits, no pressure to book anything on the day.
- Emotional state to create: from nervous and self-conscious to safe, seen and quietly hopeful.
- Language boundaries: AVOID "anti-ageing, flawless, fix, transform, cheap, deal". PREFER "refreshed, yourself again, looked after, no pressure, in good hands".
- Non-negotiables: never promise a result, never before/after as a promise, never push more than they want, concern-led always (AHPRA).

## Worked example B - an injectables-led clinic (the front-door consult)
- Audience: women 40-60 considering anti-wrinkle or filler but worried about looking "done" or overdone.
- Positioning: a complimentary skin and facial assessment as the door in (the front end, since Schedule 4 treatments cannot be advertised directly) - they get a personalised plan, the clinic gets a warm lead with their concerns mapped.
- Journey: curious-but-nervous -> reassured -> confident; move them Uncertainty -> Relief -> Confidence.
- Emotional state: from sceptical and nervous-about-looking-done to reassured and in control.
- Language boundaries: AVOID naming Schedule 4 products, "anti-ageing", "best", superlatives. PREFER "natural, subtle, refreshed, in good hands", and "has a special interest in" not "specialist/expert".
- Non-negotiables: never name Schedule 4 products in ads, redirect injectable enquiries to a consult, concern-led always.

> For your clinic: keep all 13 questions, and layer AHPRA over Q5/Q12/Q13 - the emotion + outcomes
> must be concern-led and never a treatment-result promise; language boundaries must include the AHPRA banned
> words (specialist/expert, best/safe/painless/guaranteed/anti-ageing) and the "special interest in" pattern.
