# The Neuro-Emotive Copy Engine

Every piece of clinic copy - ads, hooks, scripts, nurture, newsletters, carousels, landing pages, content - runs through this. It is the wiring that turns the Business Brain into copy that actually lands, instead of a few generic sentences. If a generator ignores this, its output is a failed run.

The rule in one line: *nothing generic ever ships. Every line traces to (a) the clinic's real offer, (b) their language bank, and (c) the neuro-emotive models mapped to that output.*

---

## STEP 1 - Read the Brain first (both files, every time)

Before writing a single line, read BOTH:

- `Business-Brain/resonance-messaging.md` - the emotional source of truth. Pull from it:
  - the *emotional stack* (ranked) - what she is actually feeling, strongest first
  - the *arc* (FROM → TO, and the beats) - the emotional journey the copy must move her along
  - the *language bank* - OPEN words to use (her exact felt-experience phrases) and CLOSE words to never use
  - the *headline / subject angles* already written for this clinic
  - the *proof map* - the AHPRA-safe proof mapped to each unspoken objection
- `Business-Brain/brand-guide.md` - the voice spine (tone do/don't, key messages, elevator pitch, the Claude context block).

If `resonance-messaging.md` is missing, say so and offer to run `/cc-resonance` - do NOT generate off the brand-guide alone. The resonance doc is the richest asset; skipping it is exactly what makes copy thin.

---

## STEP 2 - Apply the 21 models (the menu is `model-library.md`)

The 21 neuro-emotive models across 3 families live in `model-library.md` (installed alongside, in the cc-resonance skill) with full purpose + triggers + examples. Read it for the mechanics of any model you fire. The 5-step application method is `neuro-emotive-method.md`. Names:

- *Structural (7):* Trust Anchor, Possibility Lens, Prestige Magnet, Ownership Shift, Believability Bridge, Price Harmony, Trust-Through-Transparency
- *Embedded Emotional (9):* Urgency with Integrity, Social Mirror, Belonging Trigger, Desire Dial, Pain Diffuser, Binge-Worthy Flow, Guided Choice Maker, Relevance Lock, Retention Resonator
- *Language Precision (5):* Curiosity Spark, Empathy Echo, Emotional Proof, Clarity Charge, Voiceprint Precision

*Layered but soft.* A single line usually fires 1-3 models, never a pile-up. Voiceprint Precision (calm, premium, no hype) is on almost everything. The point is psychological but ethical - Step 04 Alignment (create clarity / reduce fear / encourage autonomy / maintain integrity) is the gate, and for a clinic it doubles as the AHPRA gate.

---

## STEP 3 - Map models to the output (channel affinities)

Fire the models that fit the job of the specific piece. Starting map (extend with judgement, always grounded in the clinic's resonance doc):

| Output | Lead models to fire |
|---|---|
| *Ad hook / scroll-stopper* (first line) | Curiosity Spark (open loop / pattern interrupt), Empathy Echo (her felt experience), Belonging Trigger |
| *Ad primary text / body* | Pain Diffuser, Desire Dial (how she wants to feel, not just what to fix), Emotional Proof, Believability Bridge (contrast; before/afters per the AHPRA overlay below - skin fine in ads, injectables never public) |
| *Ad CTA / close* | Ownership Shift (soft urgency only), Guided Choice Maker (one clear next step), Trust-Through-Transparency |
| *Ad trust line* | Prestige Magnet (real authority - "special interest in", never expert), Voiceprint Precision |
| *Nurture sequence* | the arc: Empathy Echo + Belonging Trigger (connect) → Desire Dial + Trust-Through-Transparency (trust) → Price Harmony + Social Mirror (belief) → Guided Choice Maker + Voiceprint (permission) |
| *Newsletter* | Social Mirror, Relevance Lock, Belonging Trigger, Possibility Lens, Retention Resonator |
| *Video script* | Curiosity Spark (3-second hook) + Emotional Proof + Empathy Echo + Voiceprint Precision |
| *Landing / thank-you page* | Trust Anchor, Price Harmony (claim + AHPRA-safe proof), Guided Choice Maker, Desire Dial, Voiceprint Precision |
| *Organic content (pillars)* | Educate = Emotional Proof + Clarity Charge; Connect = Empathy Echo + Belonging Trigger + Possibility Lens; Proof = Prestige Magnet + Believability Bridge (AHPRA-safe); Offer = Desire Dial + Ownership Shift (soft) + Guided Choice Maker |
| *Hooks (standalone)* | Curiosity Spark + Empathy Echo + Belonging Trigger; pull the phrasing from `cc-hook/references/hook-templates.md` |

---

## STEP 4 - The quality bar (what "genuinely amazing" means, and what fails)

A FAILED run (what we are fixing):
- a few generic sentences that could belong to any clinic
- copy that names the treatment/device instead of her felt experience
- "neuro-emotive" named but no model actually applied
- ignores the language bank - uses words from the CLOSE list, or none from the OPEN list

A PASSED run:
- every line is in HER words (from the OPEN language bank), about HER felt experience (from the emotional stack)
- each section fires named models mapped to its job, layered but soft
- grounded in the clinic's real offer and real proof (no invented stats, no before/after promise)
- moves her along the arc; ends on the one clear action
- passes Step 04 Alignment + the AHPRA gate

When you finish, you should be able to point at any line and name the model firing and the OPEN word it used. If you cannot, it is not done.

---

## AHPRA overlay (aesthetics clinics)

The models never override AHPRA. Ownership Shift / Urgency with Integrity = soft, true urgency only (real limited spots, never manufactured). Prestige Magnet = "has a special interest in", never expert/specialist/best. Concern-led, never claim-led. Australian English, no emdashes, italics not bold, never "it's not X, it's Y".

*Before/after images - the real rule (by treatment type, then surface):*
- *Skin treatments (non-Schedule-4 - IPL, skin needling, LED, HIFU, facials, peels):* fine on ANY surface - public ads, social, landing pages, AND email. Must be genuine, consented, realistic (same lighting, not misleading), and never framed as a guaranteed result.
- *Injectables (Schedule 4):* NEVER shown or marketed publicly - no paid ads, no public social, no public pages. They ARE fine in DIRECT, opted-in channels only: email, and one-to-one after a consult. Same consent / realistic / no-guaranteed-result conditions.
- *The clinic's own boundary wins:* some concern-led brands (e.g. Bonnie Lass) use no before/afters at all - check the `resonance-messaging.md` / `brand-guide.md` CLOSE list before using any.
- Separate rule, every surface: no patient testimonial that CLAIMS a treatment result (that is distinct from a before/after image and stays out regardless).
