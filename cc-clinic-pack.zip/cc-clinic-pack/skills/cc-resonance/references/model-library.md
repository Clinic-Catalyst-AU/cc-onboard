# Neuro-Emotive Model Library 

21 models across 3 families. Use this as the menu when running the 5-step process. For each model:
Purpose, Key Triggers (the levers), and a real-world Example. Source: A&A Neuro-Emotive Models.

> TABLE OF CONTENTS
> - STRUCTURAL MODELS (7) - the architecture/positioning of the offer
> - EMBEDDED EMOTIONAL MODELS (9) - the emotional drivers woven into content
> - LANGUAGE PRECISION MODELS (5) - the word-level craft

## STRUCTURAL MODELS (the offer's architecture + positioning)

### Trust Anchor
Purpose: establish luxury/exclusivity that drives high-value buyers to invest at premium prices.
Triggers: aspirational messaging (status, uniqueness); intentional inaccessibility (deliberate friction); prestige pricing (no discounts); prestige anchors (luxury colours, symbols).
Example: Supreme's limited drops; Rolls Royce "the eighth wonder of the world"; Tiffany rejecting 99.96% of diamonds.

### Possibility Lens
Purpose: create emotional connection that drives loyalty, forgiveness, word-of-mouth.
Triggers: likeability markers (humour, warmth, optimism, imperfection); mimicry (mirror their language/culture); mere exposure/propinquity (visibility, familiarity); social licence (integrity, responsibility).
Example: Samsung airport charging stations; Chipotle "Together" Zoom sessions; Virgin Mobile meme marketing.

### Prestige Magnet
Purpose: position the brand as an authority and attract high-caliber buyers.
Triggers: authority by numbers/results; authority by association; authority by experience; perceived-value bias (titles, tone, symbols).
Example: HubSpot "7 million monthly visitors"; Apple "Geniuses" instead of tech support.

### Ownership Shift
Purpose: move people to act now rather than postpone.
Triggers: external urgency markers (limited-time, early-bird); internal urgency markers (deadlines, natural constraints); urgency of uncertainty (risk of indecision).
Example: "Register before midnight", "Offer closes in 60 minutes".

### Believability Bridge
Purpose: differentiate by positioning the offer as superior via character-based storytelling.
Triggers: character contrast (hero vs dud); relatable struggles; visual side-by-side comparison.
Example: Mac vs Windows ads.

### Price Harmony
Purpose: make big/seemingly-impossible claims believable; dissolve doubt.
Triggers: present the claim then proof; put the product in action; put the result in action; show how to test the claims.
Example: skincare that "wipes out 70% of spots in three minutes" (shown + testable).

### Trust-Through-Transparency
Purpose: frame the offer as unmissable by surfacing the cost of the alternatives.
Triggers: cost of inaction; cost of wrong action; cost of late action.
Example: "Do you want to be the one telling your grandchildren about the opportunity you missed?"

## EMBEDDED EMOTIONAL MODELS (drivers woven into content)

### Urgency with Integrity
Purpose: create perceived omnipresence / niche domination without being everywhere.
Triggers: multiple platforms; content repurposing; PR/third-party media; brand cohesion.
Example: Kardashians repurposing across platforms; Hormozi routing podcast listeners to YouTube.

### Social Mirror
Purpose: turn one-time buyers into repeat customers; long-term loyalty. (Also: reflect the audience's lived experience back to them.)
Triggers: customer appreciation; encourage consumption; post-purchase offers; loyalty programs.
Example: Curology skincare check-ins; Chewy surprise pet portraits.

### Belonging Trigger
Purpose: foster trust/loyalty by being seen as "one of them".
Triggers: Forer/Barnum effect (vague-but-personal resonance); identifiable-victim effect (one detailed story for empathy).
Example: Marie Forleo's relatable, behind-the-scenes content.

### Desire Dial
Purpose: turn buyer anxiety into confidence; make the purchase feel safe. (Also: speak to how they want to FEEL, not just what to fix.)
Triggers: future anxiety; physical-change anxiety; mental-change anxiety; regret anxiety (risk-reversal).
Example: clear "what happens after you buy" instructions; "feel confident in your skin again".

### Pain Diffuser
Purpose: build belief in the solution, the brand, and the buyer's own self-efficacy.
Triggers: workability evidence (real users succeeding); self-belief building; foot-in-the-door (free trial/demo).
Example: Canva try-before-signup; FAQ sections that answer doubts.

### Binge-Worthy Flow
Purpose: increase engagement via expectancy-violation + novelty.
Triggers: expectancy-violation bias; innovation bias; state vs situation (specific, situational descriptions).
Example: "This guy is killing me" subject line driving curiosity clicks.

### Guided Choice Maker
Purpose: foster community + loyalty around shared values. (Note: PDF groups this as embedded; sheet frames it as community-building.)
Triggers: social-cause support; common-interest communities; non-core merch as membership signal; community-specific social proof.
Example: Harley Davidson clothing line; Patagonia pledges; The Ordinary fan chat room.

### Relevance Lock
Purpose: create a binge-worthy experience that keeps people consuming.
Triggers: personalized onboarding; structured consumption paths; varying content lengths; micro-content teasers.
Example: Netflix "Continue Watching"; YouTube autoplay.

### Retention Resonator
Purpose: help buyers navigate choices confidently; avoid decision paralysis.
Triggers: reduce choice fatigue (grouping, clear CTAs); architect choices strategically; post-purchase reassurance.
Example: ASOS "Complete the Look"; L'Oreal product quizzes.

## LANGUAGE PRECISION MODELS (word-level craft)

### Curiosity Spark
Purpose: prime the audience to respond favorably / interrupt expectation and open a loop.
Triggers: pattern interrupt; open loop; challenge an assumption; invite reflection. (Also pre-suasion: premium/affordability/attainability/right-behavior cues.)
Example: "What if the problem isn't your strategy... but the way you're making decisions?" / "What if underpricing isn't about money... but nervous system safety?"

### Empathy Echo
Purpose: reflect the buyer's felt experience; justify value via loss-aversion. (Soft, "I see you" language.)
Triggers: apple-to-apple comparison; apple-to-orange comparison; price of "no"; price of "yes".
Example: "for sensitive, overwhelmed women tired of holding everything together alone".

### Emotional Proof
Purpose: structure the offer to create a compelling vision of transformation + desire.
Triggers: what is it? why is it valuable? what benefit (emotional, physical, prestige)?
Example: "A 10K in Three Months Game Plan - earn more in 12 weeks than most do in a year."

### Clarity Charge
Purpose: make the buyer feel personally invested; increase perceived value via ownership.
Triggers: endowment effect (early ownership); IKEA effect (they help create it); engagement/interaction.
Example: Build-A-Bear; Nike By You; Warby Parker home try-on.

### Voiceprint Precision
Purpose: build trust via trust-markers + a consistent premium, calm voice (not salesy).
Triggers: trust-bias markers (secure icons, guarantees); halo effect (trust from first touch); bandwagon (widespread adoption). Plus a calm, professional, premium tone with no hype.
Example: relatable testimonials, "As seen in" logos; clinical-calm copy with no exaggerated promises.
