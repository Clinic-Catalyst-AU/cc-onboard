# Master Keyword Map - Australian Skin & Aesthetics Clinics

*Source: Semrush, Australia database - Keyword Magic pull 5 July 2026 + full API pull 6 July 2026 (all priority seeds now measured). REAL measured data - volumes are monthly AU searches, KD = keyword difficulty %, CPC in USD. Intent: I=informational, C=commercial, T=transactional, N=navigational (brand - ignore these).*

CONCERN-FIRST. Patients search their PROBLEM, not our machines. Every page, ad group and post leads with the concern; the treatment appears as the answer. This map is organised by concern, with the measured treatment-demand data underneath each concern it serves.

HOW TO USE: A clinic's slice = the CONCERNS in their `Business-Brain/concerns.md` (their special interests), served by the treatments in `services-machines.md`, with their suburbs applied to the local patterns at the bottom. `/cc-keyword-research` reads this FIRST and only researches gaps; `/cc-googlead-builder` builds concern-led ad groups seeded from these terms. Never fabricate volumes for keywords not on this map - mark them "estimate".

## The concern index (organising axis)

| Concern (what she searches/feels) | Measured demand below |
|---|---|
| Skin laxity - sagging, loose skin, jowls | sagging skin, jowls, crepey skin, skin tightening, hifu clusters |
| Weight-loss skin changes (GLP-1 era) | weight-loss laxity cluster - "ozempic face" is 12.1K/mo |
| Lines + wrinkles | anti-wrinkle cluster + wrinkles concern notes |
| Pigmentation + sun damage | pigmentation, melasma, sun spots clusters |
| Acne + congestion + scarring | acne, acne scars, skin needling + microneedling clusters |
| Dull, tired, textured skin | dull skin, chemical peel, hydrafacial clusters |
| Redness + rosacea | rosacea cluster |
| Volume loss / facial ageing | dermal filler, lip filler clusters |
| Menopause skin | menopause skin cluster (symptom-led - itch + dryness) |
| Unwanted hair | laser hair removal cluster |
| Finding a clinic (local intent) | skin clinic + cosmetic clinic clusters |

## Cluster totals (whole-cluster monthly AU volume, 5 Jul Keyword Magic)

| Cluster | Keywords | Total volume | Avg KD |
|---|---|---|---|
| skin clinic (generic + local) | 33,500 | 559,180 | 23% |
| laser hair removal | 49,100 | 479,780 | 23% |
| pigmentation | 63,100 | 409,130 | 26% |
| skin tightening | 16,100 | 149,390 | 20% |
| hifu | 10,900 | 105,900 | 11% |
| chemical peel | 14,800 | 89,590 | 26% |
| acne treatment | 22,900 | 71,730 | 31% |
| dermal filler | 9,500 | 62,420 | 17% |
| skin needling | 3,300 | 49,560 | 1%* |
| anti wrinkle injections | 1,400 | 18,750 | 13% |

*Semrush displayed avg KD 1 for skin needling cluster - treat head-term KDs below as the real signal. (6 Jul API pull returns top terms per seed, not cluster totals - totals above stay as the 5 Jul reference.)

## CONCERN-LANGUAGE CLUSTERS (measured 6 Jul 2026)

### sagging skin (skin laxity concern - the words she actually types)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| sagging skin | I | 260 | 35 | 1.02 |
| sagging skin treatment | I | 260 | 12 | 1.04 |
| skin sagging | I | 140 | 43 | 0.82 |
| cure for sagging skin | I | 110 | 36 | 1.04 |
| sagging skin after weight loss | I | 110 | 18 | 0.52 |
| tightening sagging skin | I | 90 | 41 | 0.98 |
| skin sag from weight loss | I | 70 | 38 | 1.25 |

("sagging skin treatment" at KD 12 is the concern-page keyword. The single biggest query in this space is "best collagen supplement for sagging skin" 390/mo - supplement shoppers, not clinic demand; ignore. Weight-loss variants appear even in this seed - see next cluster.)

### weight-loss skin laxity (NEW concern cluster - the GLP-1 wave)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| ozempic face | I | 12,100 | 68 | 0 |
| ozempic face before and after | I | 1,300 | 51 | 0 |
| what is ozempic face | I | 1,000 | 49 | 0 |
| loose skin after weight loss | I | 880 | 22 | 0.62 |
| dermal fillers for ozempic face | I | 390 | - | 0 |
| how to tighten skin after weight loss naturally | I | 390 | 40 | 0.61 |
| how to prevent loose skin after weight loss (+variants) | I | ~210 ea | 32-38 | 0.33 |
| how to get rid of loose skin after weight loss | I | 170 | 18 | 0.54 |
| how to tighten loose skin after weight loss (+variants) | I | ~170 ea | 31-40 | 0.55 |
| how to tighten saggy skin after weight loss | I | 140 | 20 | 0.55 |
| sagging skin after weight loss | I | 110 | 18 | 0.52 |

(THE opportunity of this map: "ozempic face" is 12,100/mo with ZERO ad competition - CPC $0 because nobody can legally advertise on it. AHPRA: "Ozempic" is an S4 brand name - it must NEVER appear in ads or promotional copy. The play is organic/GEO educational content: a "facial volume loss after rapid weight loss - what helps" page answers every one of these searches concern-led, names no drug in any promo context, and maps to filler/skin-tightening/hifu treatment pages. The how-to long-tail (KD 18-40, all informational) is a content pillar on its own.)

### jowls (skin laxity concern)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| jowls | I | 4,400 | 27 | 1.41 |
| how to get rid of jowls | I | 590 | 28 | 0.70 |
| jowls treatment | I | 480 | 28 | 1.00 |
| jowl treatment | I | 210 | 28 | 1.00 |
| best treatment for jowls | C | 110 | 20 | 1.11 |
| at home treatment for sagging jowls | I | 110 | 35 | 0.75 |
| treatment for jowls | I | 90 | 19 | 1.07 |
| sagging/drooping jowls treatment | I | 70 ea | 27-33 | 0.98 |

(Generic "jowls" volume includes pork-cut and dictionary searches - the treatment slice above is the clinic demand. KD ~20-28 across the board: winnable concern page.)

### crepey skin (skin laxity concern)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| crepey skin | I | 590 | 20 | 0.75 |
| crepey skin on arms | I | 170 | 25 | 0.60 |
| crepey skin on neck | I | 140 | 12 | 1.03 |
| how to get rid of crepey skin | I | 140 | 36 | 0.37 |
| what causes crepey skin | I | 140 | 19 | 1.43 |
| crepey skin treatment | I | 110 | 42 | 0.65 |
| how to fix crepey skin | I | 90 | 29 | 0.48 |

(Body-area variants (arms, neck) are distinct searches - a crepey-skin page should name the areas. Cream/lotion variants excluded - product shoppers.)

### melasma (pigmentation concern)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| melasma | I | 9,900 | 63 | 0.55 |
| melasma treatment | C | 2,400 | 14 | 1.24 |
| what is melasma | I | 720 | 69 | 0.08 |
| melasma cream | C | 390 | 29 | 1.00 |
| best treatment for melasma on face | C | 320 | 26 | 0.92 |

("melasma treatment" at KD 14 with commercial intent is the standout - big volume, easy target, clear clinic intent. The KD-63 head term feeds the education pillar.)

### rosacea (redness concern)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| rosacea | I | 22,200 | 83 | 0.13 |
| rosacea treatment | I | 4,400 | 50 | 0.29 |
| ocular rosacea | I | 1,900 | 49 | 0 |
| papulopustular rosacea | I | 1,300 | 35 | 0.65 |
| rosacea cream | I | 1,300 | 45 | 0.69 |
| what is rosacea / symptoms cluster | I | ~1,000-1,300 ea | 59-70 | ~0.05 |

(Huge informational demand, high KD - rosacea is a long-game content/GEO pillar, not a quick ad win. CPCs near zero = almost nobody advertises; a genuinely good rosacea page has the organic field to itself.)

### sun spots (pigmentation concern)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| sun spots | I | 1,900 | 31 | - |
| sun spots on face | I | 1,000 | 13 | 0.71 |
| how to remove sun spots (+variants) | I | 480 ea | 15-22 | 0.71 |
| sun spot removal | I | 390 | 8 | 0.97 |
| clear sun spots | I | 390 | 17 | 0.97 |

("sun spot removal" KD 8 and "sun spots on face" KD 13 - both winnable, both map straight to IPL/laser pages.)

### dull skin (texture concern)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| dull skin | I | 590 | 13 | 1.59 |
| skin dullness | I | 140 | 15 | 1.48 |
| dull skin treatment | I | 110 | 16 | 1.49 |
| skincare for dull skin | I | 110 | 15 | 1.94 |
| dull skin treatment melbourne | C | 50 | 6 | - |

(Small but ultra-low KD and strong CPCs - an easy concern page that feeds chemical peel / hydrafacial / LED.)

### menopause skin (hormonal concern)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| itchy skin menopause | I | 320 | 32 | 0.23 |
| menopause itchy skin | I | 260 | 27 | 0.16 |
| menopause skin care | I | 110 | 26 | 1.66 |
| menopause skin rash | I | 110 | 31 | 0.72 |
| skincare for menopausal skin | I/C | 90 | 17 | 1.66 |
| menopause and dry skin | I | 90 | 19 | 0.35 |
| best skincare for menopausal skin australia | I | 70 | 7 | 1.56 |

(The demand is SYMPTOM-led - itching and dryness dominate, not "ageing". Content that opens with the symptom builds the trust that converts to laxity/dullness treatments. Volumes are modest - this is a differentiation pillar, not a traffic pillar.)

### acne scars (scarring concern)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| acne scars | I | 2,400 | 27 | 1.28 |
| acne scar treatment | C | 2,400 | 10 | 1.32 |
| how to get rid of acne scars | I | 2,400 | 51 | 1.08 |
| laser treatment for acne scars | I | 880 | 17 | - |
| acne scars and laser | I | 880 | 31 | 1.10 |
| acne scarring | I | 590 | 16 | - |

("acne scar treatment" KD 10 confirmed again - still the standout commercial keyword of the whole map. "laser treatment for acne scars" KD 17 is the machine-specific runner-up.)

### wrinkles (lines concern - read the note)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| wrinkles | I | 1,300 | 78 | 1.84 |
| best treatment for deep wrinkles on face | C | 260 | 20 | 0.96 |
| how to get rid of wrinkles on face fast | I | 170 | 40 | 0.81 |
| wrinkles on face | I | 140 | 39 | 0.91 |
| best treatment for wrinkles on face | I | 50 | 24 | 1.14 |

(Generic wrinkle demand is dominated by cream/product shoppers and KD-78+ head terms - do NOT chase them. The clinic slice is "treatment for wrinkles" phrasings (KD 20-24) plus the anti-wrinkle injections cluster below. "anti wrinkle injections" remains the demand keyword: 2,400/mo at KD 7.)

## Head terms per cluster (top 10 by volume, AU)

### skin needling / microneedling (serves: texture, scarring, laxity concerns)

AU searches BOTH names - "microneedling" (12,100/mo) now outsearches "skin needling" (6,600/mo). Concern pages should carry both terms; ad groups can split them.

| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| microneedling | I | 12,100 | 32 | 1.25 |
| skin needling | C | 6,600 | 17 | 1.10 |
| microneedling before and after | I | 2,900 | 23 | 1.33 |
| skin needling before and after | I | 2,400 | 23 | 0.80 |
| rf microneedling | C | 2,400 | 13 | 1.61 |
| skin needling benefits | I | 1,600 | 25 | 0.60 |
| microneedling melbourne | C | 1,300 | 13 | 1.49 |
| microneedling near me | T | 1,300 | 20 | 1.37 |
| microneedling sydney | C | 1,300 | 16 | 1.50 |
| skin needling near me | T | 1,300 | 47 | 1.38 |
| skin needling perth | C | 1,000 | 7 | 1.84 |
| microneedle radio frequency | I | 880 | 13 | 1.46 |
| microneedling brisbane | C | 720 | 16 | 1.51 |
| microneedling perth | I | 590 | 12 | 1.47 |
| skin needling brisbane | C | 590 | 11 | 1.64 |

("rf microneedling" KD 13 commercial - the premium-machine keyword. Home dermapen/dr-pen searches excluded - device shoppers.)

### skin clinic (local/booking demand - "finding a clinic" intent)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| skin cancer clinic | C | 4,400 | 39 | 1.35 |
| skin clinic | C | 3,600 | 60 | 1.38 |
| skin cancer clinic near me | T | 2,900 | 44 | 1.17 |
| skin clinic near me | T | 2,900 | 52 | 1.51 |
| skin clinic [suburb] pattern (e.g. robina) | N/C | 2,400 | 23 | 1.45 |

(Excluded: "australian skin clinic/s" 9.9K+8.1K, "clear skin clinic" 2.9K - navigational brand searches for competitor chains, not demand a new clinic can win. Skin cancer terms only relevant if the clinic offers checks.)

### cosmetic clinic (local intent - measured 6 Jul)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| cosmetic clinic | C | 1,300 | 59 | 2.27 |
| cosmetic clinic sydney | C | 880 | 56 | 1.74 |
| cosmetic clinic melbourne | C | 720 | 58 | 2.16 |
| cosmetic clinic near me | T | 590 | 61 | 2.01 |

(High KD everywhere and half the cluster is competitor brand names (elita, lumiere, my cosmetic clinic) - same verdict as skin clinic: the generic city terms are expensive; the suburb-level page is the winnable local play.)

### anti wrinkle injections (serves: lines + wrinkles concern. S4 - NEVER price in ads, concern-led copy only)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| anti wrinkle injections | C | 2,400 | 7 | 1.93 |
| anti wrinkle injections melbourne | C | 1,000 | 12 | 3.75 |
| anti-wrinkle injections | I | 720 | 23 | 1.97 |
| anti wrinkle injections near me | T | 590 | 17 | 2.29 |
| anti wrinkle injections perth | C | 390 | 20 | 2.09 |
| anti wrinkle injections sydney | I | 390 | 10 | 2.67 |
| anti wrinkle injectables | I | 320 | 9 | 1.97 |
| anti wrinkle injections frown line | I | 320 | 9 | - |
| anti wrinkle injections brisbane | I | 260 | 21 | 2.23 |

(All "botox" searches map here for demand estimation - the word never appears in copy.)

### dermal filler (serves: volume loss / facial ageing concern)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| dermal fillers | C | 2,900 | 13 | 1.24 |
| dermal filler | C | 1,000 | 11 | 1.27 |
| dermal fillers cheekbones | I | 1,000 | 26 | 1.33 |
| dermal fillers melbourne | C | 1,000 | 18 | 2.18 |
| dermal fillers cheeks | I | 720 | 11 | 1.59 |
| dermal fillers perth | C | 720 | 18 | 1.11 |
| dermal fillers sydney | C | 720 | 10 | 1.73 |
| dermal fillers under eyes | I | 720 | 35 | 1.13 |
| cheek dermal fillers | I | 590 | 36 | 1.33 |

### lip filler (serves: volume loss / lips concern. S4 rules apply - measured 6 Jul)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| lip filler | C | 6,600 | 25 | 1.20 |
| lip injection fillers | I | 5,400 | 15 | 1.20 |
| lip filler near me | T | 2,400 | 20 | 1.40 |
| lip augmentation filler | I | 2,400 | 29 | 1.20 |
| lip filler melbourne | C | 1,300 | 12 | 2.76 |
| lip fillers melbourne | C | 1,300 | 11 | 2.55 |
| lip filler perth | C | 1,300 | 16 | 1.23 |
| lip filler sydney | C | 1,000 | 15 | 1.08 |
| lip filler before and after | I | 1,000 | 21 | 1.38 |
| lip filler cost | I | 1,000 | 2 | 0.74 |
| how long does lip filler last | I | 880 | 16 | 0.94 |

("lip filler cost" KD 2: S4 means NO pricing in ads - answer it with an organic consultation-first FAQ page instead. City terms KD 11-16 are the ad-group core.)

### hifu (serves: skin laxity - sagging, jowls. KD is LOW across this cluster - big organic opportunity)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| hifu treatment | I | 6,600 | 13 | 1.05 |
| hifu | I | 5,400 | 17 | 1.19 |
| hifu before and after | I | 1,900 | 8 | 1.38 |
| hifu near me | I/T | 880 | 23 | 1.45 |
| hifu treatment near me | T | 880 | 29 | 1.17 |
| hifu brisbane | I | 720 | 17 | 1.24 |
| hifu melbourne | C | 720 | 7 | 1.13 |
| what is hifu | I | 590 | 29 | 0.69 |

### laser hair removal (serves: unwanted hair concern. Biggest volume, competitive)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| laser hair removal | C | 22,200 | 31 | 0.88 |
| laser hair removal near me | T | 4,400 | 38 | 0.89 |
| laser hair removal melbourne | T | 2,400 | 28 | 0.88 |
| laser treatment for hair removal | C | 2,900 | 39 | 0.88 |

### pigmentation (CONCERN cluster - measured concern language)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| pigmentation | I | 2,400 | 35 | 1.21 |
| pigmentation removal | I | 1,600 | 18 | 1.21 |
| skin pigmentation | I | 1,300 | 60 | 0.92 |

(Cluster is 63K keywords/409K volume but heavily mixed with product/brand searches - the treatment-intent slice above is what clinics target. "pigmentation removal" at KD 18 is the concern-page keyword. See also melasma + sun spots clusters above.)

### acne treatment (CONCERN cluster - measured concern language)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| acne treatment | I | 4,400 | 74 | 1.36 |
| acne scar treatment | C | 2,400 | 10 | 1.32 |
| fungal acne treatment | I | 1,300 | 29 | - |
| hormonal acne treatment | I | 1,000 | 66 | 0.63 |
| back acne treatment | I | 880 | 24 | 0.99 |

("acne scar treatment" at KD 10 with commercial intent is the standout clinic keyword, not the KD-74 head term. Full acne-scars cluster above.)

### skin tightening (serves: skin laxity concern - note searchers already use this concern-adjacent phrase)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| skin tightening treatment | C | 2,400 | 17 | 1.26 |
| rf skin tightening | I | 1,900 | 12 | 1.26 |
| radio frequency to tighten skin | I | 1,900 | 45 | 1.26 |
| skin tightening | C | 1,900 | 23 | 1.35 |
| radio frequency skin tightening | I | 1,300 | 19 | 1.13 |
| non invasive skin tightening treatments | I | 880 | 20 | 1.14 |
| laser skin tightening | I | 590 | 26 | 1.12 |

### chemical peel (serves: dull skin, texture, pigmentation concerns)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| chemical peel | C | 2,900 | 32 | 0.81 |
| chemical peel before and after | I | 880 | 14 | 1.01 |
| tca chemical peel | I | 590 | 19 | 0.92 |
| chemical peel near me | T | 480 | 12 | 0.97 |
| chemical peel and facial | C | 390 | 33 | 0.81 |

### hydrafacial (serves: dull skin, congestion concerns - measured 6 Jul)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| hydrafacial | C | 6,600 | 22 | 0.87 |
| hydrafacial near me | T | 2,400 | 23 | 1.11 |
| hydrafacial perth | C | 1,000 | 11 | 1.51 |
| hydrafacial sydney | C | 1,000 | 8 | 1.39 |
| hydrafacial melbourne | C | 880 | 16 | 1.16 |
| hydrafacial brisbane | C | 590 | 9 | 1.41 |
| hydrafacial benefits | I | 390 | 17 | 0.71 |
| hydrafacial treatment | I | 320 | 19 | 0.85 |
| hydrafacial adelaide | C | 260 | 7 | 0.48 |

(Strong commercial intent, city terms KD 7-16 - one of the easiest treatment ad groups on the map. "HydraFacial" is a trademark: only use if the clinic runs the genuine device.)

### ipl treatment (serves: pigmentation, redness, sun damage concerns - measured 6 Jul)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| ipl treatment | I | 1,000 | 22 | - |
| ipl skin treatment | I | 320 | 19 | - |
| ipl laser treatment | C | 210 | 20 | - |
| what is ipl treatment | I | 170 | 20 | - |
| ipl skin rejuvenation treatment | C | 140 | 17 | - |
| ipl treatment melbourne | C | 140 | 13 | - |
| ipl treatment near me | T | 110 | 15 | - |
| ipl treatment gold coast | C | 90 | 6 | - |

(CPC shows $0 across the cluster - low ad competition. Watch the contamination: a chunk of IPL demand is DRY-EYE IPL (optometry) - keep ad groups phrased around skin/pigmentation.)

### led light therapy (serves: dull skin, redness, collagen concerns - measured 6 Jul)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| led light therapy | I | 3,600 | 50 | 1.19 |
| led light therapy mask | I | 1,000 | 43 | 1.22 |
| led light therapy treatment | I | 480 | 33 | 1.19 |
| led light therapy near me | T | 390 | 21 | 1.03 |
| led light therapy benefits | I | 390 | 31 | 0.34 |
| led light therapy facial | I/C | 320 | 43 | 1.31 |

(Home-mask demand mixes heavily into this cluster - the in-clinic slice is "treatment" / "facial" / "near me". Best used as an add-on line inside concern pages, not a standalone pillar.)


## Concern-language head terms (measured 6 Jul - what she actually types)

| Concern keyword | Intent | Vol | KD | Note |
|---|---|---|---|---|
| acne scar treatment | C | 2,400 | 10 | STANDOUT - high volume, easy, commercial |
| melasma treatment | C | 2,400 | 14 | STANDOUT - the pigmentation money term |
| melasma | I | 9,900 | 63 | education page feeds the treatment term |
| rosacea | I | 22,200 | 83 | huge + hard - long-game education only |
| rosacea treatment | I | 4,400 | 50 | competitive; pair with local modifier |
| jowls | I | 4,400 | 27 | (cluster noisy with pork jowls - filter) |
| jowls treatment / jowls face | I | 480 | 16-28 | laxity money terms |
| how to get rid of jowls | I | 590 | 28 | question content |
| sun spots on face | I | 1,000 | 13 | easy education win |
| sun spot removal | I | 390 | 8 | EASIEST buy-intent term on the map |
| laser treatment for acne scars | I | 880 | 17 | device-adjacent, still concern-led |
| dull skin | I | 590 | 13 | low competition everywhere in cluster (avg KD 14) |
| dull skin treatment melbourne | C | 50 | 6 | local pattern confirmed on concerns too |
| sagging skin treatment | I | 260 | 12 | winnable laxity entry |
| sagging skin after weight loss | I | 110 | 18 | niche whitespace (weight-loss skin) |
| crepey skin | I | 590 | 20 | arms/neck variants KD 12-14 |
| menopause skin care / menopausal skincare | I/C | 110/90 | 17-26 | WHITESPACE - tiny volume, zero owners; a menopause-skin clinic owns the category |
| wrinkles (cluster) | - | 715K total | - | product-dominated (creams); clinics capture via anti-wrinkle injections cluster instead |

Cluster totals added 6 Jul: sagging skin 15,270 | wrinkles 715,400 | melasma 123,000 | rosacea 349,020 | dull skin 12,570 | menopause skin 12,070 | acne scars 78,580 | crepey skin 27,330 | jowls 83,700 | sun spots 58,420 (monthly AU).

## Universal patterns (apply any cluster x the clinic's location)

- `[treatment] near me` - transactional, present in EVERY cluster (vol 110-4,400, KD 12-52). Always an ad group + a GBP-optimised page.
- `[treatment] [city]` - commercial, KD usually LOWER than generic (e.g. skin needling perth KD 7, hydrafacial adelaide KD 7). The suburb/city page is the winnable local play.
- `[treatment] before and after` - informational, high volume everywhere. AHPRA: answer with a what-to-expect page, NEVER before/after photo galleries as advertising.
- `what is [treatment]` / `[treatment] benefits` - informational, feeds educational content (Educate pillar).
- `how to [fix/get rid of/tighten] [concern]` - informational long-tail present in every CONCERN cluster (KD mostly 18-40). The concern page answers the how-to question first, then presents the treatment.
- CPC benchmark: AU aesthetics clicks run USD $0.80-2.70; injectables-adjacent terms are the priciest ($1.90-3.75).

## Map status (6 Jul 2026)

ALL priority seeds measured - the launch map is complete. Concern language: sagging skin, weight-loss laxity/ozempic face, jowls, crepey skin, melasma, rosacea, sun spots, dull skin, menopause skin, acne scars, wrinkles. Treatment gaps: ipl, microneedling, hydrafacial, led light therapy, lip filler, cosmetic clinic. Future extensions (pull per clinic need via /cc-keyword-research): double chin, under eye bags, skin tags, thread lift, bio-remodelling, body contouring.

## AHPRA reminder for keyword USE

Targeting a keyword is not the same as saying it. "botox", "ozempic", "before and after", "best" may describe DEMAND - the pages and ads that capture it stay concern-led, no brand-name S4 drugs, no comparisons, no superlatives, no S4 pricing. "Ozempic face" demand in particular: capture with educational content about post-weight-loss skin changes - the drug name never appears in advertising. See the skill's ahpra rules.
