# Master Keyword Map - Australian Skin & Aesthetics Clinics

*Source: Semrush Keyword Magic Tool, Australia database, pulled 5 July 2026. REAL measured data - volumes are monthly AU searches, KD = keyword difficulty %, CPC in USD. Intent: I=informational, C=commercial, T=transactional, N=navigational (brand - ignore these).*

HOW TO USE: This is the shared demand map for ALL AU skin clinics. A clinic's slice = the clusters matching their `Business-Brain/services-machines.md` + `concerns.md` (their special interests), with their suburbs applied to the local patterns at the bottom. `/cc-keyword-research` reads this FIRST and only researches gaps; `/cc-googlead-builder` uses the cluster head terms + intent tags to seed ad groups. Never fabricate volumes for keywords not on this map - mark them "estimate".

## Cluster totals (whole-cluster monthly AU volume)

| Cluster | Keywords | Total volume | Avg KD |
|---|---|---|---|
| skin clinic (generic + local) | 33,500 | 559,180 | 23% |
| laser hair removal | 49,100 | 479,780 | 23% |
| pigmentation | 63,100 | 409,130 | 26% |
| skin tightening | 16,100 | 149,390 | 20% |
| hifu | 10,900 | 105,900 | 11% |
| chemical peel | 14,800 | 89,590 | 26% |
| acne treatment | 22,900 | 71,730 | 31% |
| dermal filler | 9,500 | 62,420 | 17% |
| skin needling | 3,300 | 49,560 | 1%* |
| anti wrinkle injections | 1,400 | 18,750 | 13% |

*Semrush displayed avg KD 1 for skin needling cluster - treat head-term KDs below as the real signal.

## Head terms per cluster (top 10 by volume, AU)

### skin needling / microneedling
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| skin needling | C | 6,600 | 17 | 1.10 |
| skin needling before and after | I | 2,400 | 23 | 0.80 |
| skin needling benefits | I | 1,600 | 25 | 0.60 |
| skin needling near me | T | 1,300 | 47 | 1.38 |
| skin needling perth | C | 1,000 | 7 | 1.84 |
| dermapen skin needling | I | 880 | 5 | 1.62 |
| needling skin | I/C | 720 | 26 | 1.21 |
| skin needling before after | I | 720 | 14 | 1.25 |
| benefits of skin needling | I | 590 | 26 | 0.46 |
| skin needling brisbane | C | 590 | 11 | 1.64 |

### skin clinic (local/booking demand)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| skin cancer clinic | C | 4,400 | 39 | 1.35 |
| skin clinic | C | 3,600 | 60 | 1.38 |
| skin cancer clinic near me | T | 2,900 | 44 | 1.17 |
| skin clinic near me | T | 2,900 | 52 | 1.51 |
| skin clinic [suburb] pattern (e.g. robina) | N/C | 2,400 | 23 | 1.45 |

(Excluded: "australian skin clinic/s" 9.9K+8.1K, "clear skin clinic" 2.9K - navigational brand searches for competitor chains, not demand a new clinic can win. Skin cancer terms only relevant if the clinic offers checks.)

### anti wrinkle injections (S4 - NEVER price in ads, concern-led copy only)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| anti wrinkle injections | C | 2,400 | 7 | 1.93 |
| anti wrinkle injections melbourne | C | 1,000 | 12 | 3.75 |
| anti-wrinkle injections | I | 720 | 23 | 1.97 |
| anti wrinkle injections near me | T | 590 | 17 | 2.29 |
| anti wrinkle injections perth | C | 390 | 20 | 2.09 |
| anti wrinkle injections sydney | I | 390 | 10 | 2.67 |
| anti wrinkle injectables | I | 320 | 9 | 1.97 |
| anti wrinkle injections frown line | I | 320 | 9 | - |
| anti wrinkle injections brisbane | I | 260 | 21 | 2.23 |

(All "botox" searches map here for demand estimation - the word never appears in copy.)

### dermal filler
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| dermal fillers | C | 2,900 | 13 | 1.24 |
| dermal filler | C | 1,000 | 11 | 1.27 |
| dermal fillers cheekbones | I | 1,000 | 26 | 1.33 |
| dermal fillers melbourne | C | 1,000 | 18 | 2.18 |
| dermal fillers cheeks | I | 720 | 11 | 1.59 |
| dermal fillers perth | C | 720 | 18 | 1.11 |
| dermal fillers sydney | C | 720 | 10 | 1.73 |
| dermal fillers under eyes | I | 720 | 35 | 1.13 |
| cheek dermal fillers | I | 590 | 36 | 1.33 |

### hifu (KD is LOW across this cluster - big organic opportunity)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| hifu treatment | I | 6,600 | 13 | 1.05 |
| hifu | I | 5,400 | 17 | 1.19 |
| hifu before and after | I | 1,900 | 8 | 1.38 |
| hifu near me | I/T | 880 | 23 | 1.45 |
| hifu treatment near me | T | 880 | 29 | 1.17 |
| hifu brisbane | I | 720 | 17 | 1.24 |
| hifu melbourne | C | 720 | 7 | 1.13 |
| what is hifu | I | 590 | 29 | 0.69 |

### laser hair removal (biggest volume, competitive)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| laser hair removal | C | 22,200 | 31 | 0.88 |
| laser hair removal near me | T | 4,400 | 38 | 0.89 |
| laser hair removal melbourne | T | 2,400 | 28 | 0.88 |
| laser treatment for hair removal | C | 2,900 | 39 | 0.88 |

### pigmentation (concern cluster - filter to treatment intent)
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| pigmentation | I | 2,400 | 35 | 1.21 |
| pigmentation removal | I | 1,600 | 18 | 1.21 |
| skin pigmentation | I | 1,300 | 60 | 0.92 |

(Cluster is 63K keywords/409K volume but heavily mixed with product/brand searches - the treatment-intent slice above is what clinics target. "pigmentation removal" at KD 18 is the concern-page keyword.)

### acne treatment
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| acne treatment | I | 4,400 | 74 | 1.36 |
| acne scar treatment | C | 2,400 | 10 | 1.32 |
| fungal acne treatment | I | 1,300 | 29 | - |
| hormonal acne treatment | I | 1,000 | 66 | 0.63 |
| back acne treatment | I | 880 | 24 | 0.99 |

("acne scar treatment" at KD 10 with commercial intent is the standout clinic keyword, not the KD-74 head term.)

### skin tightening
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| skin tightening treatment | C | 2,400 | 17 | 1.26 |
| rf skin tightening | I | 1,900 | 12 | 1.26 |
| radio frequency to tighten skin | I | 1,900 | 45 | 1.26 |
| skin tightening | C | 1,900 | 23 | 1.35 |
| radio frequency skin tightening | I | 1,300 | 19 | 1.13 |
| non invasive skin tightening treatments | I | 880 | 20 | 1.14 |
| laser skin tightening | I | 590 | 26 | 1.12 |

### chemical peel
| Keyword | Intent | Vol | KD | CPC |
|---|---|---|---|---|
| chemical peel | C | 2,900 | 32 | 0.81 |
| chemical peel before and after | I | 880 | 14 | 1.01 |
| tca chemical peel | I | 590 | 19 | 0.92 |
| chemical peel near me | T | 480 | 12 | 0.97 |
| chemical peel and facial | C | 390 | 33 | 0.81 |

## Universal patterns (apply any cluster x the clinic's location)

- `[treatment] near me` - transactional, present in EVERY cluster (vol 480-4,400, KD 12-52). Always an ad group + a GBP-optimised page.
- `[treatment] [city]` - commercial, KD usually LOWER than generic (e.g. skin needling perth KD 7). The suburb/city page is the winnable local play.
- `[treatment] before and after` - informational, high volume everywhere. AHPRA: answer with a what-to-expect page, NEVER before/after photo galleries as advertising.
- `what is [treatment]` / `[treatment] benefits` - informational, feeds educational content (Educate pillar).
- CPC benchmark: AU aesthetics clicks run USD $0.80-2.70; injectables-adjacent terms are the priciest ($1.90-3.75).

## Not yet pulled (free-tier daily limit - extend when refreshed)

ipl treatment, microneedling (as its own seed), rosacea treatment, hydrafacial, led light therapy, lip filler, cosmetic clinic, melasma treatment, skin consultation, facial near me.

## AHPRA reminder for keyword USE

Targeting a keyword is not the same as saying it. "botox", "before and after", "best" may describe DEMAND - the pages and ads that capture it stay concern-led, no brand-name S4 drugs, no comparisons, no superlatives, no S4 pricing. See the skill's ahpra rules.
