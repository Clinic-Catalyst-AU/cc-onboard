---
name: cc-keyword-research
description: Discovers high-value keywords for an aesthetics or skin clinic with search intent analysis, difficulty assessment, and content opportunity mapping. Maps treatment, skin-concern, and local "near me" keywords for SEO and GEO. Essential before starting any clinic content strategy. Use when you say keyword research, find keywords for my clinic, what should my clinic rank for, skin concern keywords, treatment keywords, "near me" keywords, search terms, or before starting any SEO, GEO, or content work for your clinic. Pairs with /cc-geo-seo and reads your clinic's Business-Brain / brand-guide.md.
---

# CC Keyword Research - Keyword Discovery for Aesthetics Clinics

This skill helps you discover, analyse, and prioritise the keywords that bring new patients to an aesthetics or skin clinic. It maps treatment keywords, skin-concern keywords, and local "near me" search terms, then scores each by search volume, competition, intent, and clinic relevance so you know exactly what to write next.

It pairs with `cc-geo-seo` (which turns the keyword map into AI-citable, locally-ranked clinic pages) and reads your clinic's Business-Brain / brand-guide.md for your real services, suburbs, credentials and tone. Run this skill first so the GEO work is filled with your actual concerns and locations.

## AHPRA Guardrails (read first, applies to every keyword and example below)

Keyword research for a regulated clinic still has to respect the Australian advertising rules, because the keywords you choose become page titles, headings and content. Hard rules:

- Lead with the *skin concern*, not a drug or device brand. Build keyword groups around concerns (for example "pigmentation", "acne and congestion", "skin laxity", "fine lines") and generic treatment categories ("skin needling", "anti-wrinkle injections", "dermal filler").
- Never target prescription-only brand names as keywords. Use "anti-wrinkle injections" or "muscle-relaxant injections", not the brand. Use "dermal filler", not a brand name.
- No superlatives or self-anointed status in keywords or headings. Avoid "best", "leading", "number one", "expert", "specialist", "most advanced". Use concern-led phrasing instead.
- No outcome promises, before/after language, or guarantees in target phrases. Avoid "transform", "anti-ageing", "guaranteed results", "miracle", "permanent", "painless", "risk-free".
- No pricing keywords on Schedule 4 (prescription) treatments. You may target consultation and non-S4 service phrasing.
- Australian English throughout. Hyphens with spaces, never emdashes. Use italics for emphasis, not bold.

If an expansion below produces a phrase that breaches any of these, rewrite it concern-led and outcome-neutral before it goes into the keyword map.

## When to Use This Skill

- Starting a new content or SEO/GEO strategy for the clinic
- Launching a new treatment or skin-concern service line
- Finding the phrases patients actually search before booking
- Identifying long-tail and "near me" opportunities for your suburbs
- Understanding search intent across the patient journey (research to booking)
- Planning a content calendar of concern and treatment pages
- Researching keywords before a `cc-geo-seo` build

## What This Skill Does

1. *Keyword discovery*: Generates concern, treatment and local keyword lists from seed terms
2. *Intent classification*: Sorts keywords by patient intent (informational, navigational, commercial, booking)
3. *Difficulty assessment*: Estimates competition and ranking difficulty for each phrase
4. *Opportunity scoring*: Prioritises keywords by likely return for the clinic
5. *Clustering*: Groups related keywords into concern and treatment clusters
6. *GEO relevance*: Flags keywords likely to trigger an AI answer (ChatGPT, Perplexity, Claude, Gemini, AI Overviews)

## How to Use

### Basic Keyword Research

```
Research keywords for my clinic's [treatment or skin concern]
```

```
Find keyword opportunities for a skin clinic in [suburb] targeting [patient type]
```

### With Specific Goals

```
Find low-competition keywords for [skin concern] with booking intent
```

```
Identify question-based keywords for [treatment] that AI systems might answer
```

### Local and Competitive Research

```
Research "near me" keywords for [treatment] across my suburbs
```

```
What concern and treatment keywords is [competitor clinic URL] ranking for that I should target?
```

## Data Sources

*With an SEO data tool and search console connected:*
Automatically pull historical search volume, keyword difficulty, SERP makeup, current clinic rankings, and competitor keyword overlap. The skill will fetch seed keyword metrics, related suggestions and trend data. For Australian clinics, set the location to the relevant state or suburb so volumes reflect local demand.

*With manual data only:*
Ask the clinic owner to provide:
1. Seed concerns and treatments (or read them from Business-Brain / brand-guide.md)
2. Target patient type and the suburbs you serve
3. Business goal (new patient bookings, a specific service line, foot traffic)
4. Website maturity (new site or established) if known
5. Any known performance data or search volume estimates

Proceed with the full analysis using whatever is available. Note in the output which metrics came from automated tools versus owner-provided or estimated, and never fabricate a volume or difficulty number.

## Instructions

When the clinic owner requests keyword research:

1. *Understand the Context*

   Read Business-Brain / brand-guide.md first, then confirm anything missing:
   - Which treatments and skin concerns does the clinic actually offer?
   - Who is the target patient? (concern, age range, life stage)
   - What is the goal? (new bookings, a new service line, a quiet treatment)
   - New website or established?
   - Which suburbs and surrounding areas do you serve?

2. *Generate Seed Keywords*

   Start concern-led, then layer treatments and location:
   - Skin-concern terms (pigmentation, acne and congestion, redness, fine lines, skin laxity, dryness, texture)
   - Treatment-category terms (skin needling, chemical peel, LED, anti-wrinkle injections, dermal filler, laser, skin checks, facials)
   - Patient-language terms (the words patients use, not clinical jargon)
   - Local terms (treatment plus suburb, "near me", "in [region]")

3. *Expand Keyword List*

   For each seed keyword, generate clinic-appropriate variations:

   ```markdown
   ## Keyword Expansion Patterns

   ### Modifiers (concern-led, AHPRA-safe)
   - [skin concern] treatment
   - [treatment] for [skin concern]
   - [treatment] [suburb]
   - [treatment] near me
   - [skin concern] clinic [suburb]
   - how to treat [skin concern]
   - what helps with [skin concern]
   - [treatment] consultation
   - what is [treatment]
   - [treatment] for [skin type or life stage]

   ### Long-tail variations
   - [skin concern] treatment for [age range or life stage]
   - [treatment] for sensitive skin
   - what to expect from [treatment]
   - is [treatment] right for [skin concern]
   - [treatment] aftercare
   - [skin concern] options [suburb]
   ```

   Do not generate brand-name, superlative, price-on-S4, or outcome-promise variations. Drop or rewrite any that slip through.

4. *Classify Search Intent*

   Categorise each keyword:

   | Intent | Signals | Clinic Example | Content Type |
   |--------|---------|----------------|--------------|
   | Informational | what, how, why, options, aftercare | "what helps with pigmentation" | Concern page, FAQ, guide |
   | Navigational | clinic name, brand-adjacent | "[clinic name] booking" | Homepage, contact page |
   | Commercial | treatment plus compare, options, consultation | "skin needling options [suburb]" | Treatment page, consult page |
   | Booking | near me, book, [treatment] [suburb], appointment | "skin needling [suburb]" | Service/location page, booking CTA |

5. *Assess Keyword Difficulty*

   Score each keyword (1 to 100):

   ```markdown
   ### Difficulty Factors

   High Difficulty (70 to 100)
   - Large clinic groups and franchises ranking
   - High-authority skin and beauty publishers on page one
   - Generic single-word treatment terms
   - Paid ads dominating the results

   Medium Difficulty (40 to 69)
   - Mix of clinic and directory sites
   - Room for a well-structured concern or treatment page
   - Treatment plus broad city term

   Low Difficulty (1 to 39)
   - Few clinics ranking with thin content
   - Long-tail concern and aftercare queries
   - Treatment plus specific suburb or "near me"
   - Question-format concern queries
   ```

6. *Calculate Opportunity Score*

   Formula: `Opportunity = (Volume x Intent Value) / Difficulty`. For a local clinic, weight booking and local intent highest, since those phrases convert into appointments.

   ```markdown
   ### Opportunity Matrix

   | Scenario | Volume | Difficulty | Intent | Priority |
   |----------|--------|------------|--------|----------|
   | Quick Win (local + booking) | Low-Med | Low | High | 5 stars |
   | Growth (broad treatment) | High | Medium | High | 4 stars |
   | Long-term (single-word treatment) | High | High | High | 3 stars |
   | Awareness (concern education) | Low-Med | Low | Med | 2 stars |
   ```

7. *Identify GEO Opportunities*

   Keywords likely to trigger an AI answer (hand to `cc-geo-seo`):

   ```markdown
   ### GEO-Relevant Keywords

   High GEO Potential
   - Question formats: "what helps with...", "how does [treatment] work", "what is..."
   - Concern queries: "[skin concern] causes", "[skin concern] treatment options"
   - Comparison queries: "[treatment A] vs [treatment B]" (generic categories only)
   - "Near me" and local: "skin clinic near me", "[treatment] [suburb]"
   - Aftercare and expectation queries: "what to expect from [treatment]"

   AI Answer Indicators
   - Query is a concern or how-it-works question an AI can answer clearly
   - Answer can be summarised in a few sentences (good for FAQ schema)
   - Topic is well-documented and clinically accurate
   - Local intent that benefits from Google Business Profile crossover
   ```

8. *Create Topic Clusters*

   Group keywords into concern and treatment clusters:

   ```markdown
   ## Topic Cluster: [Skin Concern or Treatment]

   Pillar Content: [Primary concern or treatment keyword]
   - Search volume: [X]
   - Difficulty: [X]
   - Content type: Comprehensive concern or treatment page

   Cluster Content:

   ### Sub-topic 1: [Secondary keyword]
   - Volume: [X]
   - Difficulty: [X]
   - Links to: Pillar
   - Content type: [FAQ / aftercare / treatment detail]

   ### Sub-topic 2: [Secondary keyword]
   - Volume: [X]
   - Difficulty: [X]
   - Links to: Pillar + Sub-topic 1
   - Content type: [Concern guide / consultation page]
   ```

9. *Generate Output Report*

   ```markdown
   # Keyword Research Report: [Clinic / Concern / Treatment]

   Generated: [Date]
   Target Patient: [Patient type]
   Suburbs: [List]
   Business Goal: [Goal]

   ## Executive Summary
   - Total keywords analysed: [X]
   - High-priority opportunities: [X]
   - Estimated monthly demand: [X] (state if estimated)
   - Recommended focus areas: [List]

   ## Top Keyword Opportunities

   ### Quick Wins (Low difficulty, local + booking intent)

   | Keyword | Volume | Difficulty | Intent | Score |
   |---------|--------|------------|--------|-------|
   | [keyword 1] | [X] | [X] | [type] | [X] |

   ### Growth Keywords (Medium difficulty, broad treatment)

   | Keyword | Volume | Difficulty | Intent | Score |
   |---------|--------|------------|--------|-------|
   | [keyword 1] | [X] | [X] | [type] | [X] |

   ### GEO Opportunities (AI-citation potential)

   | Keyword | Type | AI Potential | Recommended Format |
   |---------|------|--------------|--------------------|
   | [keyword 1] | Question | High | FAQ / concern answer |

   ## Topic Clusters
   [Include cluster maps]

   ## Content Calendar Recommendations

   | Week | Content | Target Keyword | Type |
   |------|---------|----------------|------|
   | [Week] | [Title] | [Keyword] | [Type] |

   ## Next Steps
   1. [Action item 1]
   2. [Action item 2]
   3. [Action item 3]
   ```

## Validation Checkpoints

### Input Validation
- [ ] Seed concerns and treatments provided or read from Business-Brain / brand-guide.md
- [ ] Target patient, suburbs and business goal specified
- [ ] Location targeting set for Australian local volumes
- [ ] Website maturity established

### Output Validation
- [ ] Every recommendation cites a specific data point, not generic advice
- [ ] Volume and difficulty included for each keyword (or marked estimated)
- [ ] Keywords grouped by intent and mapped to clinic page types
- [ ] Clusters show clear pillar-to-cluster relationships
- [ ] Source of each data point stated (tool data, owner-provided, or estimated)
- [ ] AHPRA check passed: no brand-name drug keywords, no superlatives, no S4 pricing, no outcome promises

## Example

*Owner*: "Research keywords for my skin clinic in Box Hill that wants more pigmentation and skin needling bookings"

*Output*:

```markdown
# Keyword Research Report: Box Hill Skin Clinic

Generated: June 2026
Target Patient: Women 30 to 55 with pigmentation and skin-texture concerns
Suburbs: Box Hill and surrounding eastern suburbs
Business Goal: New bookings for pigmentation care and skin needling

## Executive Summary
- Total keywords analysed: 140+
- High-priority opportunities: 18
- Estimated monthly demand: ~6,500 (mix of tool data and estimates)
- Recommended focus areas:
  - Pigmentation concern education
  - Skin needling treatment and aftercare
  - Local "near me" booking phrases

## Top Keyword Opportunities

### Quick Wins (Priority: Immediate)

| Keyword | Volume | Difficulty | Intent | Score |
|---------|--------|------------|--------|-------|
| skin needling box hill | 210 | 22 | Booking | 90 |
| pigmentation treatment box hill | 170 | 24 | Booking | 88 |
| skin clinic near me box hill | 320 | 30 | Booking | 84 |
| what helps with pigmentation on face | 880 | 28 | Informational | 82 |
| skin needling aftercare | 590 | 20 | Informational | 80 |

### Growth Keywords (Priority: 3 to 6 months)

| Keyword | Volume | Difficulty | Intent | Score |
|---------|--------|------------|--------|-------|
| pigmentation treatment | 9,900 | 66 | Commercial | 60 |
| skin needling | 14,000 | 70 | Commercial | 56 |
| chemical peel for pigmentation | 1,300 | 48 | Commercial | 58 |

### GEO Opportunities (AI-citation potential)

| Keyword | Type | AI Potential | Recommended Format |
|---------|------|--------------|--------------------|
| what causes pigmentation on the face | Concern | High | Concern page + FAQ |
| how does skin needling work | How-it-works | High | Treatment page explainer |
| chemical peel vs skin needling | Comparison | High | Generic side-by-side guide |
| what to expect from skin needling | Expectation | High | FAQ with clear steps |
| pigmentation treatment options | List | High | Concern page with options |

## Topic Clusters

### Cluster 1: Pigmentation
Pillar: "Pigmentation treatment in Box Hill" (concern page)
Cluster articles:
1. What causes pigmentation on the face (880 volume)
2. Pigmentation treatment options explained (estimated)
3. How to care for skin prone to pigmentation (estimated)

### Cluster 2: Skin Needling
Pillar: "Skin needling at our Box Hill clinic" (treatment page)
Cluster articles:
1. How does skin needling work (estimated)
2. Skin needling aftercare (590 volume)
3. What to expect from your first skin needling appointment (estimated)

## Content Calendar Recommendations

| Week | Content | Target Keyword | Type |
|------|---------|----------------|------|
| Week 1 | Skin Needling in Box Hill | skin needling box hill | Treatment/Location Page |
| Week 2 | Pigmentation Treatment in Box Hill | pigmentation treatment box hill | Concern/Location Page |
| Week 3 | What Causes Pigmentation on the Face | what causes pigmentation on the face | Concern Guide + FAQ |
| Week 4 | Skin Needling Aftercare | skin needling aftercare | FAQ / Guide |

## Next Steps
1. Immediate: Build local treatment and concern pages for the top 5 quick-win keywords, then run /cc-geo-seo on them
2. Week 1 to 2: Publish the pigmentation pillar and link cluster articles to it
3. Week 3 to 4: Add FAQ schema to the GEO question keywords
4. Ongoing: Track rankings and local "near me" visibility, adjust each quarter
```

## Advanced Features

### Intent Mapping
```
Map all keywords for [treatment] by intent and patient-journey stage
```

### Seasonal Analysis
```
Identify seasonal keyword trends for [skin concern] (for example sun-damage and pigmentation in autumn)
```

### Competitor Gap
```
What concern and treatment keywords do [competitor clinic 1] and [competitor clinic 2] rank for that my clinic is missing?
```

### Local Keywords
```
Research "near me" and suburb keywords for [treatment] across my service area
```

## Tips for Success

1. *Start concern-led* - patients search the problem before they know the treatment
2. *Don't ignore long-tail and local* - "near me" and suburb phrases convert into bookings
3. *Match content to intent* - informational queries need concern guides, booking queries need treatment and location pages
4. *Group into clusters* for topical authority around each concern and treatment
5. *Prioritise local quick wins* to build momentum fast
6. *Include GEO keywords* so the clinic is named by AI engines, then hand them to /cc-geo-seo
7. *Re-check the AHPRA guardrails* before any keyword becomes a page title
8. *Review quarterly* - search demand and seasonality shift

## Related Skills & Tools

| Need | Use |
|------|-----|
| Turn the keyword map into AI-citable, locally-ranked pages | `cc-geo-seo` skill |
| Clinic tone, services, suburbs, credentials | the clinic's Business-Brain / brand-guide.md |
| Full website SEO audit | `website-seo-audit` skill |
| Live website and SERP checks | Playwright MCP |
| Web research and competitor checks | WebFetch + WebSearch tools |

Version: 1.0 | Created: 2026-06-30 | Next Review: Q4 2026
Built on the generic keyword-research engine, re-aimed for AHPRA-compliant aesthetics and skin clinics.
