---
name: cc-reeltalkinghead
description: The COMPLETE talking-head reel job - raw talking-to-camera clinic video in, approval-ready GHL draft out. Cuts the dead air and rambling gaps (auto-editor), transcribes on-device (mlx-whisper / faster-whisper), burns animated word-by-word captions (Remotion, vertical/square/landscape), AHPRA-screens the spoken words, writes the post copy + hook + hashtags from the Business Brain, uploads to the clinic's GHL Media Library and creates a Social Planner DRAFT for their approval. Finishes by opening the reel on screen. Use when the user says talking head, reel, caption this, caption my video, I filmed myself, make this postable, add captions, captioned reel, or gives a video of a person talking to camera. For clip montages use /cc-reelclips, /cc-reelvoiceover or /cc-reelassembly.
---

# CC REEL - TALKING HEAD (the complete job: raw video -> GHL draft)

One skill, one finished thing. A clinic films themselves talking (phone, TikTok camera, whatever),
hands over the raw file, and gets back: a tightened, captioned reel + the post copy + a DRAFT
sitting in their GHL Social Planner waiting for approval. No agency branding ever appears on the
video - the output is THEIR content.

*File contract* - READS `Business-Brain/brand-guide.md` (voice, hashtags) + `offers.md` (CTA).
WRITES to `Content/reels/` only. Paths relative to the clinic workspace (`~/Clinic/`).

## HOW TO USE

```
/cc-reeltalkinghead ~/Downloads/me-talking.mp4              # vertical, full job
/cc-reeltalkinghead clip.mp4 --square | --landscape
/cc-reeltalkinghead clip.mp4 --no-cut                       # skip the dead-air cut
/cc-reeltalkinghead clip.mp4 --no-push                      # stop after the reel (no GHL)
/cc-reeltalkinghead clip.mp4 --name skin-consult --model small
```

## ENGINE

Remotion project (compositions: `CaptionedReel` 1080x1920, `CaptionedSquare` 1080x1080,
`CaptionedLandscape` 1920x1080). Location depends on install:
```bash
REEL_ENGINE=~/Clinic/.reel-render
[ -d "$REEL_ENGINE" ] || REEL_ENGINE=~/Systems/cc-aios/reel-render
[ -d "$REEL_ENGINE/node_modules" ] || (cd "$REEL_ENGINE" && npm install)
```

## PROCEDURE

### STEP 0: VALIDATE
1. Input exists and is video (`.mp4`, `.mov`, `.webm`, `.mkv`).
2. `which ffmpeg ffprobe`; transcription: `mlx_whisper` (Apple Silicon) else faster-whisper
   (`python3 -c "import faster_whisper"`) else the OpenAI Whisper API via /transcribe. Never
   install slow local openai-whisper.
3. Dead-air cutter: `auto-editor --version` (pip package `auto-editor`; the clinic installer
   ships it - `pip3 install auto-editor --break-system-packages` if missing).
4. Parse flags. Composition: CaptionedReel (default) / CaptionedSquare / CaptionedLandscape.

### STEP 1: THE TIGHTEN CUT (skip with --no-cut)
Talking-head phone videos carry dead air - pauses, restarts, the gap before they start talking.
auto-editor removes the silence and keeps the speech:
```bash
mkdir -p /tmp/cc-reel
auto-editor "[input]" --margin 0.2sec --no-open -o /tmp/cc-reel/tight.mp4
```
- Use /tmp/cc-reel/tight.mp4 as the working input from here on.
- Report the before/after duration so they see what was trimmed.
- This cuts SILENCE, not words - their umms and personality stay (that is their voice, and
  word-surgery on a human sounds robotic). If the user filmed it as a finished piece and says
  don't trim, honour it (--no-cut).

### STEP 2: TRANSCRIBE (word-level timestamps)
```bash
mlx_whisper /tmp/cc-reel/tight.mp4 --model mlx-community/whisper-small-mlx \
  --output-format json --word-timestamps True --output-dir /tmp/cc-reel/
```
faster-whisper fallback (Windows / Intel Mac - same JSON shape):
```bash
python3 - /tmp/cc-reel/tight.mp4 /tmp/cc-reel/tight.json <<'PY'
import json, sys
from faster_whisper import WhisperModel
segs, _ = WhisperModel("small", compute_type="int8").transcribe(sys.argv[1], word_timestamps=True)
out = {"segments": [{"start": s.start, "end": s.end, "text": s.text,
       "words": [{"word": w.word, "start": w.start, "end": w.end} for w in (s.words or [])]} for s in segs]}
json.dump(out, open(sys.argv[2], "w"))
PY
```

### STEP 3: BUILD CAPTIONS
```bash
python3 "$REEL_ENGINE"/src/scripts/captions_from_mlx.py /tmp/cc-reel/tight.json /tmp/cc-reel/captions.json
```

### STEP 4: AHPRA + LANGUAGE SCREEN (mandatory)
Read /tmp/cc-reel/captions.json - these words go ON SCREEN. Flag: therapeutic/outcome claims,
guarantees, best/expert/specialist, named S4 products, before/after promises. ALSO flag swearing
or anything they would not want captioned publicly (tell them the timestamp). These are the
speaker's own words - never silently rewrite; they decide to re-record, trim, or accept.
Non-compliant words = STOP, do not render.

### STEP 5: RENDER
```bash
PUB="$REEL_ENGINE"/public
cp /tmp/cc-reel/tight.mp4 "$PUB/clip.mp4"; cp /tmp/cc-reel/captions.json "$PUB/captions.json"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 /tmp/cc-reel/tight.mp4)
FRAMES=$(python3 -c "import sys;print(max(1,round(float(sys.argv[1])*30)))" "$DUR")
cat > /tmp/cc-reel/props.json <<JSON
{"videoSrc":"clip.mp4","captionsFile":"captions.json","brandKey":"cc","showLogo":false,"durationInFrames":$FRAMES}
JSON
OUT=~/Clinic/Content/reels; mkdir -p "$OUT"
cd "$REEL_ENGINE" && npx remotion render src/index.ts [CompId] \
  "$OUT/[slug]-[platform]-$(date +%Y-%m-%d).mp4" --props=/tmp/cc-reel/props.json
```

### STEP 6: THE FINALE part 1 - show it (always, never ask)
`open` the rendered reel so it plays on screen, and `open -R` it in Finder. Watching their own
captioned video IS the payoff. A run that ends with a file path is not done.

### STEP 7: THE GHL KIT (skip only with --no-push)
Follow `references/ghl-social-push.md` exactly: write the copy package (hook + caption + their
hashtags + CTA, all from the Business Brain, AHPRA-screened, shown in chat), upload the reel to
their GHL Media Library, create the Social Planner DRAFT, verify via posts/list, and hand them
the closing line: "Draft waiting in your Social Planner - review and hit post."
Missing token/socials: deliver the reel + copy package anyway and say exactly what to set up.

### STEP 8: CLEAN UP
```bash
rm -f "$REEL_ENGINE"/public/clip.mp4 "$REEL_ENGINE"/public/captions.json; rm -rf /tmp/cc-reel
```

## Outputs - the STRICT contract (exactly these, nothing else)
1. `Content/reels/<slug>-<platform>-<date>.mp4` - the reel (opened on screen).
2. The copy package in chat (hook, caption, hashtags, CTA).
3. The GHL Social Planner DRAFT (verified id) - unless --no-push or blocked (say why).
No .md files, no extra drafts, no other formats.

## IMPORTANT RULES
- NEVER stamp agency branding on the clinic's video (showLogo stays false).
- NEVER render on-screen words that breach AHPRA - flag and stop.
- The GHL push is DRAFT-only. Never schedule, never post. The human approves in GHL.
- NEVER use emdashes in any output.
- Caption styling lives in `$REEL_ENGINE/src/theme.ts` - edit there for all reels.
- Pairs with /cc-cover (make the cover next) and /cc-find-clip (long video? find the moment first).
