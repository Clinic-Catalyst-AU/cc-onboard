---
name: cc-reeltalkinghead
description: The COMPLETE talking-head reel job - the clinic drops a raw phone video into their Talking Head folder and gets back an approval-ready GHL draft. Finds the video itself (no file paths to type), cuts the dead air AND the ums and ahs, catches spoken retakes ("take out that last line") and cuts those too, transcribes on-device (mlx-whisper / faster-whisper), burns word-by-word captions in THEIR brand colours from their Business Brain, adds a transition at every cut, AHPRA-screens the spoken words, opens the RAW and the EDITED side by side so they can see the difference, then asks permission before writing the caption + their top 5 hashtags and pushing a DRAFT to their GHL Social Planner. Use when the user says talking head, reel, caption this, caption my video, I filmed myself, make this postable, add captions, captioned reel, or gives a video of a person talking to camera. For clip montages use /cc-reelclips, /cc-reelvoiceover or /cc-reelassembly.
---

# CC REEL - TALKING HEAD (raw phone video -> approval-ready GHL draft)

The clinic films themselves talking, drops the file in their Talking Head folder, and runs one
command. They get back a tightened, captioned, on-brand reel and a draft waiting in their Social
Planner. No agency branding ever touches the video - the output is THEIR content, in THEIR colours.

*File contract*
- READS `Content/Talking Head/` (the raw video), `Business-Brain/brand-guide.md` (voice, colours,
  fonts, their top 5 hashtags), `Business-Brain/offers.md` (the CTA),
  `Credentials/credentials-reference.txt` (GHL token + Location ID).
- WRITES `Content/Ready to Post/` only.
- Paths are relative to the clinic workspace (`~/Clinic/`).

*GHL access* - BEFORE any GHL call, read the clinic's Private Integration token + Location ID from `Credentials/credentials-reference.txt`. They are already in there - the clinic created that file during setup and their CLAUDE.md points at it. Use them and push. Only if a value is genuinely blank, ask for it and save it. Full contract, scope list and failure handling: `../cc-reeltalkinghead/references/ghl-credentials.md`.

## HOW TO USE

```
/cc-reeltalkinghead                          # finds the video in their Talking Head folder
/cc-reeltalkinghead ~/Downloads/clip.mp4     # or point it at a specific file
/cc-reeltalkinghead --square | --landscape   # default is vertical
/cc-reeltalkinghead --keep-fillers           # leave the ums and ahs in
/cc-reeltalkinghead --aggressive             # also cut "you know", "I mean", "basically"
/cc-reeltalkinghead --no-push                # stop after the reel, no GHL
```

## ENGINE

```bash
REEL_ENGINE=~/Clinic/.reel-render
[ -d "$REEL_ENGINE" ] || REEL_ENGINE=~/Systems/cc-aios/reel-render
[ -d "$REEL_ENGINE/node_modules" ] || (cd "$REEL_ENGINE" && npm install)
```
Compositions: `CaptionedReel` 1080x1920 / `CaptionedSquare` 1080x1080 / `CaptionedLandscape` 1920x1080.

---

## PROCEDURE

### STEP 0: FIND THE VIDEO (never make them type a path)

If no file argument was given, look in the clinic's Talking Head folder. Accept every spelling -
clinics rename these folders and it must not matter:

```bash
# no path given - look in the Talking Head folder of the default install
for d in "$HOME/Clinic/Content/Talking Head" "$HOME/Clinic/Content/Talking-Head" \
         "$HOME/Clinic/Assets/Talking Head" "$HOME/Clinic/Assets/Talking-Head"; do
  [ -d "$d" ] && TH="$d" && break
done
find "$TH" -maxdepth 1 -type f \( -iname '*.mp4' -o -iname '*.mov' -o -iname '*.webm' -o -iname '*.mkv' \) \
  -not -name '._*' | sort
```
- Exactly one video -> use it, say which one you picked.
- More than one -> list them with their durations and ASK which. Never guess.
- None -> tell them the exact folder to drop a video into, and stop.

*Then derive the Content root FROM THE FILE - do not hardcode `~/Clinic`.* The clinic's Content folder
may live anywhere (Desktop, Downloads, Dropbox), and the finished reel MUST come back out beside the
raw one so everything stays in the one folder they can see:
```bash
CONTENT="$(dirname "$(dirname "$INPUT_FILE")")"   # .../Content/Talking Head/x.mov -> .../Content
READY="$CONTENT/Ready to Post"; mkdir -p "$READY"
```
Raw in `<anywhere>/Talking Head/` means finished in `<anywhere>/Ready to Post/`. Always.

Then validate: `which ffmpeg ffprobe`, and a transcriber - `mlx_whisper` (Apple Silicon), else
faster-whisper, else the OpenAI Whisper API. `auto-editor` is NOT used any more (see Step 2).

### STEP 1: TRANSCRIBE THE RAW VIDEO (word-level)

The transcription happens BEFORE the cut, not after. This is the whole reason the skill can remove
filler WORDS instead of only silence - you cannot cut a word you have not located yet.

```bash
mkdir -p /tmp/cc-reel
ffmpeg -loglevel error -i "[input]" -ar 16000 -ac 1 -y /tmp/cc-reel/audio.wav
mlx_whisper /tmp/cc-reel/audio.wav --model mlx-community/whisper-small-mlx \
  --output-format json --word-timestamps True --output-dir /tmp/cc-reel/
```
faster-whisper fallback (Windows / Intel Mac - same JSON shape):
```bash
python3 - /tmp/cc-reel/audio.wav /tmp/cc-reel/audio.json <<'PY'
import json, sys
from faster_whisper import WhisperModel
segs, _ = WhisperModel("small", compute_type="int8").transcribe(sys.argv[1], word_timestamps=True)
out = {"segments": [{"start": s.start, "end": s.end, "text": s.text,
       "words": [{"word": w.word, "start": w.start, "end": w.end} for w in (s.words or [])]} for s in segs]}
json.dump(out, open(sys.argv[2], "w"))
PY
```

### STEP 2: READ THE TRANSCRIPT AND FIND THE RETAKES (your judgement, not a regex)

Print the transcript. Read it as a human editor would, looking for the speaker correcting
themselves out loud. These are the giveaways:
- an explicit instruction to the editor: "take out that last line", "cut that", "scratch that",
  "ignore that bit", "delete that"
- a restart: "let me start again", "sorry, again", "one more time", "take two"
- a false start immediately re-said a different way

For each one, the span to cut is *the botched line AND the instruction itself* - the clinic does
not want "take out that last line" in their reel either. Get the start and end seconds from the
word timestamps and pass them as `--drop-span START:END` (repeatable).

If you are not sure whether something is a retake or just their natural speech, ASK. Cutting real
content is far worse than leaving a stumble in.

### STEP 3: PLAN THE CUTS (filler words, silence, retakes) + REMAP THE CAPTIONS

```bash
python3 "$REEL_ENGINE"/src/scripts/plan_cuts.py \
  /tmp/cc-reel/audio.json /tmp/cc-reel/plan.json \
  [--drop-span 12.4:15.1] [--keep-fillers] [--aggressive]
```
This removes the ums and ahs, cuts the silences, drops any retake spans you passed, and - critically
- rewrites every caption timestamp onto the new shortened timeline. It writes
`/tmp/cc-reel/captions.json` (already in the @remotion/captions shape) alongside the plan.

Report what it removed, out loud: the filler count, the retakes, the silences, and the
before/after duration. That report is the value - they should SEE the tightening.

### STEP 4: MAKE THE CUT (hard cuts, exact timeline)

```bash
python3 - <<'PY' > /tmp/cc-reel/filter.txt
import json
r = json.load(open("/tmp/cc-reel/plan.json"))["keep_ranges"]
p = []
for i, (s, e) in enumerate(r):
    p.append(f"[0:v]trim={s}:{e},setpts=PTS-STARTPTS[v{i}];")
    p.append(f"[0:a]atrim={s}:{e},asetpts=PTS-STARTPTS[a{i}];")
p.append("".join(f"[v{i}][a{i}]" for i in range(len(r))) + f"concat=n={len(r)}:v=1:a=1[v][a]")
print("".join(p))
PY
ffmpeg -loglevel error -i "[input]" -filter_complex_script /tmp/cc-reel/filter.txt \
  -map "[v]" -map "[a]" -c:v libx264 -preset fast -crf 20 -c:a aac -y /tmp/cc-reel/tight.mp4
```
Hard cuts on purpose. A crossfade would change the duration and desync every caption after it -
the transition is drawn by the renderer instead (Step 6), where it costs no time.

### STEP 5: AHPRA + LANGUAGE SCREEN (mandatory, before any render)

These words are about to be burned ON SCREEN. Read the captions and flag: therapeutic or outcome
claims, guarantees, hard-banned superlatives (best / #1 / most effective / safe / painless, and
expert / specialist unless they hold that registration), named Schedule 4 products, before/after
promises. ALSO flag swearing or anything they would not want captioned publicly - give the
timestamp. These are the speaker's own words: never silently rewrite them. They decide to
re-record, cut the line, or accept. A breach = STOP, do not render.

### STEP 6: RENDER IN THEIR BRAND (never in Clinic Catalyst's)

Pull the clinic's caption colours and font from `Business-Brain/brand-guide.md` (and
`brand-assets/accent.txt` as the accent fallback). The accent becomes the active-word highlight.
Every field is optional - anything missing falls back to a clean readable default.

```bash
PUB="$REEL_ENGINE"/public
cp /tmp/cc-reel/tight.mp4 "$PUB/clip.mp4"; cp /tmp/cc-reel/captions.json "$PUB/captions.json"
CUTS=$(python3 -c "import json;print(json.dumps(json.load(open('/tmp/cc-reel/plan.json'))['cut_points']))")
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 /tmp/cc-reel/tight.mp4)
FRAMES=$(python3 -c "print(max(1,round(float('$DUR')*30)))")
cat > /tmp/cc-reel/props.json <<JSON
{"videoSrc":"clip.mp4","captionsFile":"captions.json","brandKey":"cc","showLogo":false,
 "cutPoints":$CUTS,
 "brand":{"captionHighlight":"[their accent hex]","captionText":"#FFFFFF",
          "stroke":"[their dark/ink hex]","fontFamily":"[their heading font]"},
 "durationInFrames":$FRAMES}
JSON
OUT="$READY"   # the Ready to Post folder in the SAME Content root the raw video came from (Step 0)
cd "$REEL_ENGINE" && npx remotion render src/index.ts [CompId] \
  "$OUT/[slug]-[platform]-$(date +%Y-%m-%d).mp4" --props=/tmp/cc-reel/props.json
```
`cutPoints` puts a fast flourish at every cut so the jump reads as a deliberate edit.
Captions sit at 63% of the frame height - below the centre fold, above the zone where Instagram
and TikTok lay their own caption and UI chrome. That is proportional, so it holds on all three
formats. Do not hardcode a pixel value here again.

### STEP 7: SHOW THEM THE BEFORE AND THE AFTER (always, never ask first)

```bash
open "[the original raw video]"
open "$OUT/[slug]-[platform]-[date].mp4"
```
Open BOTH. The whole point is the difference - they watch their rambling 22-second phone video
next to a tight, captioned, on-brand 10-second reel. Say the numbers out loud: what it was, what
it is now, what came out. A run that ends with a file path is not done.

### STEP 8: THE APPROVAL GATE (nothing goes to GHL until they say yes)

With both videos open, write the copy package and SHOW IT IN CHAT before pushing anything:
- the HOOK (first line, concern-led, scroll-stopping)
- the CAPTION in their voice, written for THIS video's actual content
- their TOP 5 HASHTAGS from `Business-Brain/brand-guide.md`. Use theirs. If the brain does not
  have a hashtag set, say so and ask - never invent trending tags.
- one CTA from `offers.md`

AHPRA-screen every line of it. Then ask, plainly:

> "Happy with the reel and this caption? Say yes and I'll put it in your Social Planner as a
> draft - you approve and schedule it there."

WAIT for a yes. No yes, no push. If they want changes, change them and ask again.

### STEP 9: PUSH THE DRAFT (skip with --no-push)

Only after they said yes. Follow `references/ghl-social-push.md` exactly: upload the reel to their
GHL Media Library, create the Social Planner DRAFT, verify it exists via posts/list, then:

> "Draft waiting in your Social Planner - review, pick your time, and hit post."

DRAFT only. Never scheduled, never published, never sent. They press go, in GHL, always.
Missing token or no socials connected: deliver the reel + copy package anyway and say exactly
what to set up.

### STEP 10: CLEAN UP
```bash
rm -f "$REEL_ENGINE"/public/clip.mp4 "$REEL_ENGINE"/public/captions.json; rm -rf /tmp/cc-reel
```

## Outputs - the STRICT contract (exactly these, nothing else)
1. `Content/Ready to Post/<slug>-<platform>-<date>.mp4` - the reel (opened on screen, next to the raw).
2. The copy package in chat (hook, caption, their top 5 hashtags, CTA).
3. The GHL Social Planner DRAFT (verified id) - only after they approved, unless --no-push.
No .md files, no extra drafts, no other formats.

## IMPORTANT RULES
- NEVER stamp agency branding on the clinic's video. No logo (showLogo stays false) and NEVER
  Clinic Catalyst's teal in the captions - the colours come from THEIR brand guide.
- NEVER render on-screen words that breach AHPRA - flag and stop.
- NEVER push to GHL without an explicit yes. The draft is for their approval and scheduling.
- Cutting real content is worse than leaving a stumble in. Unsure if it is a retake? Ask.
- NEVER use emdashes in any output.
- Caption position is proportional (63% of height). A hardcoded pixel value renders the captions
  off the bottom of the square and landscape formats - that bug shipped once already.
- Pairs with /cc-cover (make the cover next) and /cc-find-clip (long video? find the moment first).
