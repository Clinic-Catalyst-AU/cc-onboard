# THE GHL KIT - push a finished reel into the clinic's Social Planner as a DRAFT

Shared by /cc-reeltalkinghead and /cc-reelassembly (other skills reference this file at
`../cc-reeltalkinghead/references/ghl-social-push.md`). This is the PROVEN recipe (certified
2026-07-05, draft verified in the Social Planner via posts/list).

## The rule that never bends
Everything lands as a DRAFT for the clinic to approve inside GHL. status is always "draft".
Never "scheduled", never "published", never a send. The human presses go, always.

## Credentials (from the clinic workspace - never in prompts)
Read `Credentials/credentials-reference.txt`:
- `GHL Private Integration token` - the Bearer token (created in Settings > Private Integrations)
- `GHL Location ID`
If either is missing, STOP the push step (the reel itself is still delivered) and tell them
exactly where to create it: Settings > Private Integrations (token shows ONCE) + Settings >
Business Profile (Location ID). Setup guide step 8 covers it.

## The copy package (write BEFORE pushing)
From `Business-Brain/brand-guide.md` (+ `offers.md`, `concerns.md`):
- HOOK first line (scroll-stopper, concern-led - /cc-hook method)
- caption copy in the clinic's voice (short for IG; the reel does the talking)
- their hashtag set from the brand guide (never invent trending tags - if the brain has none, say so)
- one CTA aligned to the current offer/booking link
AHPRA screen every line. No emdashes. Show the package in chat as part of the approval story.

## The push (3 calls, all with the PIT token + a BROWSER user agent - GHL 403s bot UAs)

Headers for ALL calls:
`Authorization: Bearer <PIT>` , `Version: 2021-07-28` , browser User-Agent string.

1. UPLOAD the video -> `POST https://services.leadconnectorhq.com/medias/upload-file`
   multipart form: `file=@reel.mp4`, `hosted=true` -> returns the GHL CDN `url`.
2. RESOLVE userId (REQUIRED by the posts API - omitting it fails):
   `GET https://services.leadconnectorhq.com/users/?locationId=<LOC>` -> use the owner/admin id.
   Cache it as a `GHL User ID:` line in credentials-reference.txt so this is a one-time lookup.
3. CREATE THE DRAFT -> `POST https://services.leadconnectorhq.com/social-media-posting/<LOC>/posts`
   ```json
   {"accountIds": [<their connected FB/IG account ids>],
    "summary": "<hook + caption + hashtags>",
    "media": [{"url": "<CDN url from step 1>", "type": "video/mp4"}],
    "status": "draft", "type": "post", "source": "composer",
    "userId": "<from step 2>"}
   ```
   Account ids: `GET .../social-media-posting/<LOC>/accounts` - if NO socials are connected yet,
   stop the push and point them at GHL > Marketing > Social Planner > connect accounts.
4. VERIFY (never report "pushed" without this) -> `POST .../social-media-posting/<LOC>/posts/list`
   with dates formatted `"YYYY-MM-DD HH:mm:ss"` (ISO-with-Z 422s). Confirm the draft id exists,
   then tell the clinic: "Draft waiting in your Social Planner - review and hit post."

## The empty-creative guard
NEVER create a draft whose media array is empty. No rendered media = no push - stop and name the
render step that produces it. A caption-only draft in the Social Planner reads as broken to the
clinic and wastes their approval time.

## Failure honesty
Any step fails: deliver the reel + the copy package anyway, say exactly which call failed and
what to check (token scopes, socials connected). Never claim a draft exists that step 4 didn't see.
