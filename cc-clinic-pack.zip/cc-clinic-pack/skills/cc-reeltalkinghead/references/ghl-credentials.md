# GHL credentials - the ONE way every skill asks for them

Every skill that touches the clinic's GHL needs the same two values. Ask for them the same way,
store them in the same place, once. Referenced by `/cc-reeltalkinghead`, `/cc-reelassembly`,
`/cc-carousel`, `/cc-content-engine`, `/cc-follow-up-agent`, `/cc-nurture-sequence`, `/cc-social`.

Other skills point here as `../cc-reeltalkinghead/references/ghl-credentials.md`.

## The normal path: READ THE FILE. It is already there.

The clinic created `Credentials/credentials-reference.txt` during setup and pointed their
`CLAUDE.md` at it. The keys are already in it. So before any GHL call, just read them:

```
GHL Private Integration token (Settings > Private Integrations - shown ONCE when created):
GHL Location ID (Settings > Business Profile, or the /location/ part of your GHL URL):
```

That is the whole story in the normal case. Read the two values, use them, push. Do not ask the
clinic for something they already gave you - checking the file first is the difference between a
skill that just works and one that interrogates them every time.

Never put a token in a prompt, never echo one back in chat, never write one anywhere but that file.

## Only if a value is genuinely blank - ASK. Do not stall.

If the file is missing, or a line is empty, do NOT stop and point them at a setup guide. Ask them
now, walk them through it a step at a time, save it into that same file, and carry straight on.

> "Before I can put this into your GHL I need two things from your account. Two minutes, and you
> will never have to do it again."

*1. The Location ID.* Open GHL and look at the address bar. The URL has `/location/` in it followed
by a string of letters and numbers. That string is the Location ID. Copy it and paste it here.
(It is also under Settings > Business Profile.)

*2. The Private Integration token.* In GHL: *Settings* > *Private Integrations* > *Create new
integration*. Name it "Claude". Tick these scopes - all of them, or things fail later in ways that
are hard to diagnose:

| Scope | Why |
|---|---|
| `socialplanner/post.write` | create the draft |
| `socialplanner/post.readonly` | verify the draft actually landed |
| `socialplanner/account.readonly` | find which socials they have connected |
| `medias.write` | upload the video or image |
| `medias.readonly` | read it back |
| `users.readonly` | the posts API requires a userId - omitting it fails |
| `contacts.write` + `contacts.readonly` | tags, contacts, the nurture flows |
| `emails/builder.write` | the follow-up agent writes email templates |

Create it. GHL shows the token *once* - tell them to copy it right then, before they click away.
Paste it here.

Then write both into `Credentials/credentials-reference.txt` on the lines above, confirm they are
saved, and continue what you were doing.

## Every call needs a browser User-Agent

GHL 403s a bot user-agent. Every request:
```
Authorization: Bearer <PIT>
Version: 2021-07-28
User-Agent: Mozilla/5.0
```

## When a call fails

- *401 / 403* -> the token is wrong or is missing a scope. Say so plainly, name the scope the call
  needed, and ask them to create a new token with it. A wrong-scope token is the single most common
  failure. Do not guess, and do not silently skip the step.
- *Anything else* -> say exactly which call failed and what you were trying to do. Never claim
  something landed in GHL that you have not verified with a read-back.
