# The clinic's Content folder - everything media lives here

Shared by every video skill (`/cc-reeltalkinghead`, `/cc-reelclips`, `/cc-reelvoiceover`,
`/cc-reelassembly`, `/cc-find-clip`, `/cc-assemble`, `/cc-cover`, `/cc-carousel`). Other skills
reference this file at `../cc-reeltalkinghead/references/workspace-folders.md`.

## One folder. Everything in it.

All media lives under `Content/`. What the clinic drops in and what the system finishes sit side
by side, so there is only ever one place to look.

```
~/Clinic/Content/

  --- THEY drop files in here ---
  Talking Head/      them talking to camera
  Long Videos/       full-length footage to pull clips out of
  Raw Clips/         short b-roll - the room, hands, machines, product
  Photos/            clinic, team, treatments

  --- THE SYSTEM writes here ---
  Clips/             segments pulled out of a long video, not finished yet
  Ready to Post/     EVERY finished video, cover and carousel
```

Never make the clinic type a file path. Find the file for them.

## The flow, end to end

```
Long Videos ──/cc-find-clip──> Clips ──┐
Talking Head ──────────────────────────┤
Raw Clips ─────────────────────────────┼──> a reel skill ──> Ready to Post
                                       │                         │
                                       │             ask permission to push
                                       │                         │
                                       │        yes ──> GHL Social Planner DRAFT
                                       └        no  ──> they grab the file and post
                                                        natively (that is how you add
                                                        a trending sound)
```

## Resolving the folders - THE OUTPUT GOES BACK BESIDE THE INPUT

The finished video must land in the SAME Content folder the raw video came out of. Never write to a
hardcoded `~/Clinic`. The Content folder may live anywhere - Desktop, Downloads, Dropbox - and the
whole promise of this system is that everything is in one place they can see. Writing the output
somewhere else silently breaks that.

So: find the input, then derive the Content root FROM IT.

```bash
pick() { for d in "$@"; do [ -d "$d" ] && { printf '%s' "$d"; return; }; done; }

# 1. Find the Content root. The default install is ~/Clinic/Content, but if the user handed us a
#    file, the root is simply the PARENT of the folder that file was sitting in.
if [ -n "$INPUT_FILE" ]; then
  CONTENT="$(dirname "$(dirname "$INPUT_FILE")")"     # .../Content Folder/Talking Head/x.mov -> .../Content Folder
else
  CONTENT=$(pick "$HOME/Clinic/Content" "$HOME/Clinic/Assets")
fi

# 2. The typed folders inside it. Accept every spelling - never fail over a hyphen or a capital.
TALKING=$(pick "$CONTENT/Talking Head" "$CONTENT/Talking-Head" "$CONTENT/talking head")
LONG=$(pick    "$CONTENT/Long Videos"  "$CONTENT/Long-Videos")
BROLL=$(pick   "$CONTENT/Raw Clips"    "$CONTENT/Raw-Clips" "$CONTENT/Video" \
               "$CONTENT/video/mini-clips" "$CONTENT/footage")
PHOTOS=$(pick  "$CONTENT/Photos")

# 3. Output - ALWAYS a sibling of the input folders, inside the same Content root.
READY="$CONTENT/Ready to Post"; mkdir -p "$READY"
SEGMENTS="$CONTENT/Clips";      mkdir -p "$SEGMENTS"
```

The test: if the raw video was in `<anywhere>/Talking Head/`, the finished reel MUST come out in
`<anywhere>/Ready to Post/`. Same tree, one folder up and across. If you ever find yourself writing
to a path the input did not come from, stop - that is the bug.

Finding the video in a folder:
```bash
find "$FOLDER" -maxdepth 1 -type f \
  \( -iname '*.mp4' -o -iname '*.mov' -o -iname '*.webm' -o -iname '*.mkv' \) -not -name '._*' | sort
```
- One file -> use it, and say which one you picked.
- Several -> list them with durations and ASK. Never guess.
- None -> name the exact folder to drop a file into, and stop.

## The ending EVERY video skill shares

Once the finished video exists, all skills do the same four things. Do not invent a different
ending.

1. *Save it to `Content/Ready to Post/`.* Filename: `<slug>-<platform>-<date>.mp4`.
   (`/cc-find-clip` is the exception - its segments are not finished, so they go to `Content/Clips/`
   and it tells them which skill to run next.)

2. *Open it on screen.* For anything that was cut or edited, open the RAW as well, so they see the
   before and the after. A run that ends with a file path is not done.

3. *ASK before anything leaves the machine:*
   > "Want this in your GHL Social Planner as a draft?"

   Wait for an answer. This is a real fork, not a formality:
   - *Yes* -> write the copy package (hook, caption in their voice for THIS video, their top 5
     hashtags from `Business-Brain/brand-guide.md`, one CTA from `offers.md`), AHPRA-screen every
     line, show it in chat, then follow `ghl-social-push.md`: upload, create the DRAFT, verify it
     exists, and confirm: *"Draft is in your Social Planner - approve it and pick your time."*
   - *No* -> *"It's in your Ready to Post folder. Grab it and post it natively - that's how you add
     a trending sound, because those only exist inside Instagram and TikTok."*

4. *Never schedule, never publish, never send.* The draft is for THEIR approval and THEIR
   scheduling, inside GHL. The human presses go, always.

## Hashtags

Their top 5 come from `Business-Brain/brand-guide.md`. Use theirs. If the brain has no hashtag set,
say so and ask - never invent trending tags, and never pad the list to five.
