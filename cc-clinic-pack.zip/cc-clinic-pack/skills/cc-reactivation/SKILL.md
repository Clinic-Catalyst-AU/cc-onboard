---
name: cc-reactivation
description: Build a clinic's win-back reactivation campaign - the 10-touch sequence (5 texts + 5 emails, alternating) that brings lapsed and cold past clients back into the clinic with its front-door offer. Reads the clinic's Business Brain, writes every touch in their voice (Reveal -> Offer -> Connect -> Coming Back -> Last Note), screens it against AHPRA, shows an approval page, then pushes the 5 email bodies into the CC Reactivation 01-05 shells via the GHL API and hands over the 5 SMS + subject lines as clean copy-paste (workflow SMS cannot be API'd). Use PROACTIVELY whenever a clinic or operator says reactivation, reactivation campaign, win back, win-back, cold clients, lapsed clients, bring back past clients, reactivate my list, or has a reactivation workflow that needs its copy written and loaded. Sibling to /cc-newsletter-engine (weekly newsletter) and /cc-follow-up-agent (the nurture ladder) - same Business Brain, one voice everywhere.
---

# CC Reactivation - the win-back campaign

Past clients are a clinic's warmest audience. This skill writes their reactivation
campaign in the clinic's own voice and loads the emails into GHL, so the clinic just
imports their lapsed list and the sequence does the rest. It is the reactivation
counterpart to `/cc-newsletter-engine` - built the same way, feels the same.

*The shape:* 10 touch points, alternating text and email (SMS 1 -> Email 1 -> ... ->
Email 5). The emails live as API-pushable template shells; the SMS live in the workflow
(browser-only) so they are handed over as copy-paste. Full structure, the 5-email arc,
the offer/merge-field contract and the AHPRA rules are in
`references/reactivation-structure.md` - read it first.

## Before you start - read these

- `references/reactivation-structure.md` - the arc, what-pushes-vs-what-is-copy-paste, AHPRA.
- The clinic's `Business-Brain/brand-guide.md` + `resonance-messaging.md` (voice) and
  `offers.md` + `services-machines.md` (the real reactivation offer + services). Never
  invent an offer or a service. If `brand-guide.md` is missing, run `/cc-brand-guide` first.

*GHL access:* read the clinic's Private Integration token + Location ID from their
`Credentials/credentials-reference.txt` (their setup created it). Only ask if a value is blank.

## Steps

1. *Read the spine* - brand-guide + resonance (voice, word bank, AHPRA line), offers.md
   (the reactivation front-door offer + any take-home value-add), services-machines.md (the
   full menu - the Reveal email often hinges on "the clinic does more than you knew"), team.md
   (owner + their "special interest in"). Confirm the `reactivation_offer` booking link.
2. *Write the 10 touches* along the arc (Reveal -> Offer -> Connect -> Coming Back -> Last
   Note; a text before each email). Clinic voice, concern-led, one CTA per email to
   `{{OFFER}}`, at most one small inline image per email. Use the `{{FIRST}}` / `{{OFFER}}`
   tokens - never hardcode a name or URL.
3. *Gate every message* - run the copy through `/cc-marketing-genius` (sharpen subjects +
   CTAs) and `/stoptheslop` (strip AI tells, Australian English, no emdashes), then the hard
   AHPRA screen from the reference. Fix and re-check.
4. *Render* - write a `content.json` (schema in `scripts/render_reactivation.py`) and:
   ```bash
   python3 scripts/render_reactivation.py content.json <out_dir> <slug> --open
   ```
   This emits three consistent views from the one source: the *approval* page (owner reads
   all 10, buttons work), the *copy-paste* page (subjects + SMS with merge fields), and the
   *push JSON* (email bodies with merge fields). Fixing the render keeps the format clean and
   the three views in sync - you only write the words.
5. *Approval gate* - show the owner the approval page. Edit `content.json` and re-render until
   they say yes. NEVER push without their yes.
6. *Push the emails* - dry run then push:
   ```bash
   GHL_PIT=<clinic PIT> python3 scripts/push_reactivation.py <slug>-reactivation-push.json --location <LOCATION_ID>
   GHL_PIT=<clinic PIT> python3 scripts/push_reactivation.py <slug>-reactivation-push.json --location <LOCATION_ID> --push
   ```
   It matches/creates the `CC Reactivation 01-05` shells and verifies 4/4... 5/5 via
   previewUrl. "I ran the push" is not "it landed" - only 5/5 verified passes.
7. *Hand over the rest* - give the owner the copy-paste page for the *5 SMS* (paste into the
   workflow text steps) and the *5 subject lines*. Remind them: SMS stay off until the clinic
   mobile number is live; email steps just pick the matching `CC Reactivation` template.
8. *Report* - emails loaded + verified (5/5), SMS + subjects handed over as copy-paste, and
   the one-time wiring note if the shells were freshly created (point each workflow email step
   at its template).

## Boundaries

- Loads emails only; never sends, never touches contacts or the workflow wiring (browser-only).
- Never invents an offer or service - clinic's real menu only.
- One reactivation offer per campaign, shared with the clinic's other channels.
- Ships in the clinic pack (sibling to `/cc-newsletter-engine`) so clinics can run it themselves.
