# Reactivation campaign - the 10-touch structure

The reactivation campaign wins back a clinic's lapsed/cold clients. It is 10 touch
points, alternating text and email, over roughly two to three weeks:

`SMS 1 -> Email 1 -> SMS 2 -> Email 2 -> SMS 3 -> Email 3 -> SMS 4 -> Email 4 -> SMS 5 -> Email 5`

## The 5-email arc (write to the clinic's real offer + voice)

1. *Reveal* - the warm re-open. If the clinic has grown beyond what these clients knew
   it for (very common - e.g. "you knew me for injectables, but I now offer a full skin
   menu"), reveal that here, and put a booking option in front of them from touch one.
   Lead with the clinic's reactivation front-door offer.
2. *Offer* - the front-door offer in full (what it targets, any included value-add /
   take-home gift). Concern-led, never a promise.
3. *Connect* - why the owner does this - the human, the story, the values. Least
   treatment, most heart.
4. *Coming Back* - reassurance. What a visit is like, no pressure, tailored plan, in good
   hands. Answers "it's been a while, is it awkward to come back".
5. *Last Note* - a gentle last invitation. No rush, door always open, full menu is here too.

Every email ends with ONE CTA to the offer (`{{custom_values.reactivation_offer}}`). Each
email carries at most one *small inline* image (~240px, centred in the flow - never a
full-width hero; that lesson is learned). Each SMS is short, warm, and carries the same
offer link.

## The offer link + names

- Booking CTA: `{{custom_values.reactivation_offer}}` (the clinic's specific reactivation
  offer booking link - set as a custom value; distinct from `{{custom_values.booking_link}}`
  which is the general consult link).
- Personalisation: `{{contact.first_name}}`.
- In the content JSON these are the tokens `{{OFFER}}` and `{{FIRST}}`; the render script
  swaps them (readable in the approval preview, real merge fields in copy-paste + push).

## What can be pushed vs what is copy-paste (the key mechanic)

- *Emails* -> pushed by API into 5 email template shells named `CC Reactivation 01-05`
  (`push_reactivation.py`). Verified via previewUrl. No copy-paste.
- *SMS* -> live inside the workflow's text steps. GHL workflows are browser-only: there is
  no API for a workflow SMS step. So the 5 SMS are always handed over as copy-paste, and
  the owner pastes them into the 5 text steps. Never claim SMS were "pushed".
- *Subject lines* -> set on the templates by the push AND handed over as copy-paste (the
  workflow's email steps show/confirm the subject in the UI).

## Snapshot vs skill (how this scales)

The reactivation *workflow* + the 5 email *shells* + the `reactivation_offer` custom value
belong in the CC snapshot (built once, imported per clinic), with the email steps
pre-pointed at the shells and the SMS steps written generically with merge fields so a
clinic that just wants "send them to the booking link" works out of the box. THIS skill is
the brand-pack layer: it writes each clinic's bespoke copy in their voice and pushes the
emails into the shells - the premium version on top of the generic snapshot default.

## AHPRA (screen every message - non-negotiable for clinics)

- No "specialist"/"expert" (use "has a special interest in"); no "safe/painless/guaranteed/
  anti-ageing"; no Schedule 4 brand names (e.g. do not name the well-known wrinkle-injection
  brand) or S4 pricing; no before/after as a promise; no patient testimonials for regulated
  treatments; concern-led, never claim-led (describe what a treatment targets).
- Non-S4 treatments (IPL, carbon/laser facials, radiofrequency, skin needling, peels,
  body contouring) can be named, described and offered with a price - they are the natural
  reactivation front-door.
- Australian English, no emdashes (hyphens with spaces), italics not bold, no emoji,
  never the "it's not X, it's Y" pattern. Read the clinic's brand-guide.md for their exact
  voice + word bank and let it win.
