#!/usr/bin/env python3
"""
push_reactivation.py - load the 5 reactivation EMAIL bodies into the clinic's GHL.

The reactivation campaign is 10 alternating touch points (5 SMS + 5 emails). Only
the EMAILS live as email templates and can be pushed by API - the SMS live inside
the workflow steps (browser-only, no API), so this script never touches them; the
skill hands the SMS over as copy-paste.

Matches/creates the 5 shells by title, overwrites their content, verifies each via
its previewUrl marker. Mirrors push_newsletter.py so the two feel the same.

Usage:
  python3 push_reactivation.py reactivation.json --location <LOCATION_ID>            # dry run
  python3 push_reactivation.py reactivation.json --location <LOCATION_ID> --push     # write
Token from $GHL_PIT (or $CC_GHL_PIT).

reactivation.json:
  {"messages":[
     {"id":"01","template_title":"CC Reactivation 01 - Reveal",
      "subject":"...","preview":"...","html":"<div ...>...</div>"}, ... x5]}
Bodies must already carry the GHL merge fields {{contact.first_name}} and
{{custom_values.reactivation_offer}} (never a hardcoded booking URL or [first name]).
"""
import sys, os, json, argparse, hashlib, urllib.request, urllib.error

BASE = "https://services.leadconnectorhq.com"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/125.0 Safari/537.36")
SHELL_TITLES = [f"CC Reactivation 0{i}" for i in range(1, 6)]  # prefix match


def api(method, path, pit, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method)
    req.add_header("Authorization", "Bearer " + pit)
    req.add_header("Version", "2021-07-28")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", UA)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            t = r.read().decode()
            return json.loads(t) if t.strip() else {}
    except urllib.error.HTTPError as e:
        print("  HTTP", e.code, e.read().decode()[:180]); return None


def fetch(url):
    try:
        return urllib.request.urlopen(url, timeout=20).read().decode("utf-8", "ignore")
    except Exception:
        return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("messages")
    ap.add_argument("--location", required=True)
    ap.add_argument("--pit", default=os.environ.get("GHL_PIT") or os.environ.get("CC_GHL_PIT"))
    ap.add_argument("--push", action="store_true", help="actually write (default: dry run)")
    args = ap.parse_args()
    if not args.pit:
        print("No token. Set $GHL_PIT (the clinic's Private Integration Token)."); sys.exit(2)

    data = json.load(open(args.messages))
    msgs = data.get("messages", [])
    if len(msgs) != 5:
        print(f"Expected 5 reactivation emails, got {len(msgs)}."); sys.exit(2)

    listing = api("GET", f"/emails/builder?locationId={args.location}&limit=100", args.pit) or {}
    builders = listing.get("builders", listing.get("data", []))
    by_title = {b.get("name", ""): b.get("id") for b in builders}

    print(f"=== Matching 5 reactivation emails to shells in {args.location} ===")
    plan, missing = [], []
    for m in msgs:
        tid = by_title.get(m["template_title"])
        print(f"  [{'OK' if tid else 'MISSING'}] {m['template_title']} -> {tid}")
        (plan if tid else missing).append((m, tid))

    if not args.push:
        print(f"\nDRY RUN: {len(plan)} matched, {len(missing)} would be created. Re-run with --push.")
        return

    if missing:
        print(f"\n=== Creating {len(missing)} shell(s) ===")
        for i, (m, _) in enumerate(missing):
            res = api("POST", "/emails/builder", args.pit, {
                "locationId": args.location, "type": "html", "title": m["template_title"],
                "updatedBy": "cc-reactivation", "builderVersion": "2", "isPlainText": False})
            tid = (res or {}).get("id")
            if not tid:
                print(f"  ! create failed for {m['template_title']}"); sys.exit(1)
            print(f"  created: {m['template_title']} -> {tid}")
            print("    -> point the workflow's matching email step at this template (GHL UI, one time).")
            plan.append((m, tid))

    print(f"\n=== Pushing copy into {len(plan)} shells ===")
    markers = {}
    for m, tid in plan:
        marker = "ccre-" + hashlib.sha1((m["id"] + m["html"]).encode()).hexdigest()[:12]
        markers[tid] = (m, marker)
        res = api("POST", "/emails/builder/data", args.pit, {
            "locationId": args.location, "templateId": tid, "updatedBy": "cc-reactivation",
            "html": m["html"] + f"\n<!-- {marker} -->", "editorType": "html",
            "isPlainText": False, "subject": m["subject"], "previewText": m.get("preview", "")})
        print(f"  {'pushed' if res is not None else '! FAILED'}: {m['template_title']}")

    print("\n=== Verifying via previewUrl ===")
    listing = api("GET", f"/emails/builder?locationId={args.location}&limit=100", args.pit) or {}
    by_id = {b.get("id"): b for b in listing.get("builders", [])}
    ok = 0
    for tid, (m, marker) in markers.items():
        if marker in fetch((by_id.get(tid) or {}).get("previewUrl", "")):
            ok += 1; print(f"  VERIFIED: {m['template_title']}")
        else:
            print(f"  ! NOT verified: {m['template_title']}")
    print(f"\n{ok}/5 reactivation email shells verified live.")
    if ok != 5:
        sys.exit(1)
    print("\nReminder: the 5 SMS + the 5 subject lines are copy-paste (workflow SMS has no API).")


if __name__ == "__main__":
    main()
