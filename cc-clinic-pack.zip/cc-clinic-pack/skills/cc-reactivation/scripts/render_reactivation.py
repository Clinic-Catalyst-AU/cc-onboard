#!/usr/bin/env python3
"""
render_reactivation.py - one content source -> three consistent outputs.

Given a content JSON (the 5 emails + 5 SMS a clinic's reactivation campaign, written
in their voice), this renders:
  1. <slug>-reactivation-approval.html  - the 10-touch review page for the owner (SMS
     bubbles + email cards, small inline images, WORKING booking buttons + readable names)
  2. <slug>-reactivation-copy-paste.html - clean copy-button page: the 5 subject lines +
     5 SMS in workflow order, with GHL merge fields (for pasting into the workflow)
  3. <slug>-reactivation-push.json      - payload for push_reactivation.py (email bodies
     with merge fields, ready to load into the CC Reactivation 01-05 shells)

Fixing the render here keeps the font/format clean every time and guarantees the three
views never drift. The model only writes the words.

Usage: python3 render_reactivation.py content.json <out_dir> <slug> [--open]

content.json:
{
  "business_name": "The Clinic", "short_name": "Clinic", "accent": "#0f5a54",
  "offer_url": "https://bookings.example.com/book?product=...",   # real reactivation-offer URL (preview buttons)
  "emails": [                                       # exactly 5, in touch order
    {"label":"Reveal","subject":"...","preview":"...","cta":"Book your Carbon Facial",
     "body_html":"<inner 600px html with {{FIRST}} and {{OFFER}} tokens and any <img> inline>"},
    ... x5
  ],
  "sms": ["Hi {{FIRST}}, ... {{OFFER}} x", ... x5]   # exactly 5, in touch order
}
Tokens: {{FIRST}} and {{OFFER}} - the render swaps them per view (readable in the
approval, GHL merge fields in copy-paste + push). Never hardcode names or URLs in content.
"""
import sys, os, json, html as H, subprocess

def esc(s): return H.escape(s or "", quote=True)

def sub_readable(s, offer):
    return s.replace("{{FIRST}}", "{{contact.first_name}}").replace("{{OFFER}}", offer)

def sub_merge(s):
    return s.replace("{{FIRST}}", "{{contact.first_name}}").replace("{{OFFER}}", "{{custom_values.reactivation_offer}}")


def approval_page(c):
    a = c.get("accent", "#0f5a54"); name = c["business_name"]; offer = c["offer_url"]
    parts = [f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(name)} - reactivation (draft)</title>
<style>body{{margin:0;background:#e9e7e3;font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#2B2B2B}}
.page{{max-width:680px;margin:0 auto;padding:24px 16px 70px}}
.head{{background:#1d2a28;color:#fff;border-radius:12px;padding:24px;margin-bottom:18px}}
.head h1{{margin:0 0 6px;font-size:20px}}.head p{{margin:0;color:#c9c8c6;font-size:14px;line-height:1.5}}
.wklabel{{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:{a};font-weight:700;margin:0 2px 8px;display:flex;align-items:center;gap:8px}}
.subj{{background:#fff;border:1px solid #d9d6d2;border-radius:8px 8px 0 0;padding:11px 15px;font-size:13px}}
.subj .pv{{color:#7a7772;display:block;margin-top:3px;font-size:12.5px}}
.email{{background:#fff;border:1px solid #d9d6d2;border-top:0;border-radius:0 0 10px 10px}}
.smswrap{{margin:0 0 22px}}.smslabel{{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#3f7d5b;font-weight:700;margin:0 2px 6px;display:flex;align-items:center;gap:8px}}
.sms{{background:#e7f3dd;border:1px solid #cfe6bd;border-radius:4px 16px 16px 16px;padding:12px 16px;font-size:14px;color:#233318;max-width:80%;line-height:1.5}}
.wk{{margin:0 0 22px}}
.copybtn{{cursor:pointer;border:1px solid {a};background:{a};color:#1A1A1A;font-size:10.5px;font-weight:700;letter-spacing:0;text-transform:none;padding:3px 10px;border-radius:5px}}
.copybtn.done{{background:#3f7d5b;border-color:#3f7d5b;color:#fff}}
.subj .copybtn{{float:right}}</style></head><body><div class="page">
<div class="head"><h1>{esc(name)} - reactivation campaign</h1>
<p>Draft for approval. Ten touch points (5 texts + 5 emails, alternating) welcoming past clients back. Nothing sends until you say yes. Texts send once the clinic mobile number is added; emails work now.</p>
<p>Every Copy button copies the real GHL merge fields ({{{{contact.first_name}}}}, {{{{custom_values.reactivation_offer}}}}), ready to paste straight into a workflow step.</p></div>"""]
    sms = c["sms"]; emails = c["emails"]
    for i in range(5):
        sms_copy = esc(sub_merge(sms[i]))
        parts.append(f'<div class="smswrap"><div class="smslabel">Touch {2*i+1} &middot; Text'
                     f'<button class="copybtn" onclick="cp(this)" data-copy="{sms_copy}">Copy</button></div>'
                     f'<div class="sms">{esc(sub_readable(sms[i], offer))}</div></div>')
        e = emails[i]
        body = sub_readable(e["body_html"], offer)
        subj_copy = esc(e["subject"])
        parts.append(f'<div class="wk"><div class="wklabel">Touch {2*i+2} &middot; Email {i+1} &middot; {esc(e["label"])}</div>'
                     f'<div class="subj"><button class="copybtn" onclick="cp(this)" data-copy="{subj_copy}">Copy subject</button>'
                     f'<b>Subject:</b> {esc(e["subject"])}<span class="pv">Preview: {esc(e.get("preview",""))}</span></div>'
                     f'<div class="email">{body}</div></div>')
    parts.append("""</div>
<script>function cp(b){var t=b.getAttribute('data-copy');var d=function(){var o=b.textContent;b.textContent='Copied';b.classList.add('done');setTimeout(function(){b.textContent=o;b.classList.remove('done')},1300)};if(navigator.clipboard){navigator.clipboard.writeText(t).then(d).catch(function(){fb(t,d)})}else fb(t,d)}
function fb(t,d){var a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();try{document.execCommand('copy');d()}catch(e){}document.body.removeChild(a)}</script>
</body></html>""")
    return "\n".join(parts)


def copypaste_page(c):
    a = c.get("accent", "#0f5a54"); name = c["business_name"]
    rows = []
    sms = c["sms"]; emails = c["emails"]
    for i in range(5):
        rows.append(('sms', f"Touch {2*i+1} &middot; Text", sub_merge(sms[i])))
        rows.append(('subj', f"Touch {2*i+2} &middot; Email {i+1} subject ({esc(emails[i]['label'])})", emails[i]["subject"]))
    items = ""
    for kind, label, text in rows:
        cls = " sms" if kind == "sms" else ""
        items += (f'<div class="item{cls}"><div class="ihead"><span class="lbl">{label}</span>'
                  f'<button class="copy" onclick="cp(this)">Copy</button></div>'
                  f'<div class="txt">{esc(text)}</div></div>\n')
    return f"""<title>{esc(name)} reactivation - copy &amp; paste</title>
<style>:root{{--a:{a};--ink:#1d2a28;--bg:#f2f1ee;--line:#e2e0dd;--ok:#3f7d5b;--sms:#e7f3dd;--smsl:#cfe6bd}}
*{{box-sizing:border-box}}body{{margin:0;font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;background:var(--bg);color:var(--ink);line-height:1.5}}
header{{background:var(--ink);color:#fff;padding:26px}}header h1{{margin:0 0 5px;font-size:20px}}header p{{margin:0;color:#bcd3cf;font-size:13.5px}}
.wrap{{max-width:760px;margin:0 auto;padding:20px 18px 70px}}
.item{{background:#fff;border:1px solid var(--line);border-radius:10px;margin:0 0 12px;overflow:hidden}}
.item.sms{{background:var(--sms);border-color:var(--smsl)}}
.ihead{{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 15px;border-bottom:1px solid var(--line)}}
.lbl{{font-size:11.5px;letter-spacing:.1em;text-transform:uppercase;font-weight:700;color:var(--a)}}
button.copy{{cursor:pointer;border:1px solid var(--a);background:var(--a);color:#fff;font-size:12px;font-weight:600;padding:6px 15px;border-radius:6px}}
button.copy.done{{background:var(--ok);border-color:var(--ok)}}
.txt{{padding:13px 15px;font-size:15px;white-space:pre-wrap;word-wrap:break-word}}</style>
<header><h1>{esc(name)} reactivation - copy &amp; paste</h1><p>5 subjects + 5 texts, in workflow order. Emails: pick the CC Reactivation template + paste its subject. Texts: paste the whole message.</p></header>
<div class="wrap">
{items}</div>
<script>function cp(b){{var t=b.closest('.item').querySelector('.txt').innerText;var d=function(){{var o=b.textContent;b.textContent='Copied';b.classList.add('done');setTimeout(function(){{b.textContent=o;b.classList.remove('done')}},1300)}};if(navigator.clipboard){{navigator.clipboard.writeText(t).then(d).catch(function(){{fb(t,d)}})}}else fb(t,d)}}
function fb(t,d){{var a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();try{{document.execCommand('copy');d()}}catch(e){{}}document.body.removeChild(a)}}</script>"""


def push_json(c):
    msgs = []
    for i, e in enumerate(c["emails"], 1):
        msgs.append({"id": f"0{i}", "template_title": f"CC Reactivation 0{i} - {e['label']}",
                     "subject": e["subject"], "preview": e.get("preview", ""),
                     "html": sub_merge(e["body_html"])})
    return {"messages": msgs}


def main():
    if len(sys.argv) < 4:
        print("usage: render_reactivation.py content.json <out_dir> <slug> [--open]"); sys.exit(1)
    c = json.load(open(sys.argv[1])); outdir = sys.argv[2]; slug = sys.argv[3]
    do_open = "--open" in sys.argv[4:]
    assert len(c["emails"]) == 5 and len(c["sms"]) == 5, "need exactly 5 emails and 5 sms"
    os.makedirs(outdir, exist_ok=True)
    ap = os.path.join(outdir, f"{slug}-reactivation-approval.html")
    cp = os.path.join(outdir, f"{slug}-reactivation-copy-paste.html")
    pj = os.path.join(outdir, f"{slug}-reactivation-push.json")
    open(ap, "w").write(approval_page(c))
    open(cp, "w").write(copypaste_page(c))
    json.dump(push_json(c), open(pj, "w"), indent=2, ensure_ascii=False)
    print(f"wrote:\n  {ap}\n  {cp}\n  {pj}")
    if do_open:
        subprocess.run(["open", ap], check=False)


if __name__ == "__main__":
    main()
