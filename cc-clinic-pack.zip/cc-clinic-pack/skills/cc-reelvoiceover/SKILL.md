---
name: cc-reelvoiceover
description: Build a voiceover-ready clip montage for an aesthetics clinic - takes their 2-3 second mini clips (treatment room, machines, hands, door, product shots), assembles them into one paced silent montage, and writes the voiceover script (timed to the cut) for the owner to record over it. NO baked audio, NO GHL push - they record their voice in-app (CapCut/IG/TikTok) and post. Finishes by opening the montage + script on screen. Use when the user says voiceover reel, voice over, b-roll for my voice, montage for voiceover, clips for me to talk over, or has a folder of short clinic clips and wants to narrate them. Talking-to-camera video = /cc-reeltalkinghead instead. Story-order edit with captions = /cc-reelassembly.
---

# CC REEL - VOICEOVER (silent montage + the script to speak over it)

The clinic has a camera roll of little moments - the door, the machine warming up, hands prepping,
the treatment bed. This skill turns those into ONE paced montage with no sound, plus a voiceover
script timed to the cut. They open it in CapCut / Instagram / TikTok, record their voice over the
top, done. Their voice on their clinic - the most human content there is.

*File contract* - READS `Business-Brain/brand-guide.md` + `offers.md` + `concerns.md` (script
voice + CTA). WRITES to `Content/Ready to Post/`. Paths relative to the clinic workspace (`~/Clinic/`).


*Folders + the shared ending* - read `../cc-reeltalkinghead/references/workspace-folders.md`. EVERY media folder lives under `Content/`. They drop files into Talking Head / Long Videos / Raw Clips / Photos; the system writes into Clips and Ready to Post. Never make the clinic type a file path. Every video skill ends the same way: save to Ready to Post, open it on screen, ASK before pushing to GHL, and if they say no, tell them the file is there to post natively (that is how they add a trending sound).

## HOW TO USE

```
/cc-reelvoiceover --folder Content/Raw Clips          # all clips in folder, sorted
/cc-reelvoiceover --clips a.mp4 b.mp4 c.mp4                  # explicit order
/cc-reelvoiceover --folder X --topic "winter skin reset"     # script angle
/cc-reelvoiceover --folder X --crossfade                     # soft dissolves between clips
/cc-reelvoiceover --folder X --text "Winter skin reset|At [Clinic]|Book your consult"  # optional on-screen hook text
/cc-reelvoiceover --folder X --square | --landscape          # default vertical
```

## PROCEDURE

### STEP 1: VALIDATE + PLAN THE CUT
1. `which ffmpeg ffprobe`. Gather the clips (folder = sorted by name; or the explicit list).
2. Probe each clip's duration. Montage maths: aim for a 20-40 second total. Clips longer than
   3 seconds get trimmed to their FIRST 2.5 seconds (`ffmpeg -t 2.5`) into /tmp/cc-voreel/ -
   mini-clip pacing is the format. Tell the user the clip count + total runtime before building.
3. Too few clips (under ~6 / under 15 seconds)? Say so - suggest what to film (door, machine,
   hands, product, room, smile) rather than padding with repeats.

### STEP 2: ASSEMBLE SILENT
Reuse the deterministic engine from /cc-assemble, then strip ALL audio - the montage must be
silent so their recorded voice is the only sound:
```bash
python3 ~/.claude/skills/cc-assemble/assemble.py --clips [trimmed in order] \
  --aspect reel [--crossfade] --out /tmp/cc-voreel/montage.mp4
ffmpeg -y -i /tmp/cc-voreel/montage.mp4 -c:v copy -an \
  ~/Clinic/Content/Ready to Post/[slug]-voiceover-$(date +%Y-%m-%d).mp4
```
(--aspect square/landscape per flag. --crossfade adds 0.5s dissolves. No --music EVER in this skill.)

### STEP 2b: OPTIONAL - ON-SCREEN HOOK TEXT (only if --text is given)
Silent montages usually go out clean for the voiceover. If --text is passed, burn the hook
lines on screen by REUSING the installed reel engine (the same one the captioned reels use - no
new dependency). Split on `|`. AHPRA-screen every line FIRST (no claims, no superlatives, no S4
names/pricing, no before/after) - a breaching line STOPS the render, it is not silently reworded.
The video stays SILENT (text is visual only) so their recorded voice is still the sole audio.
```bash
REEL_ENGINE=~/Clinic/.reel-render; [ -d "$REEL_ENGINE" ] || REEL_ENGINE=~/Systems/cc-aios/reel-render
SILENT=~/Clinic/Content/Ready to Post/[slug]-voiceover-$(date +%Y-%m-%d).mp4
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$SILENT")
python3 "$REEL_ENGINE"/src/scripts/overlay_from_lines.py --out /tmp/cc-voreel/overlay.json \
  --duration "$DUR" --lines "line 1" "line 2" "line 3"     # one per hook line, in order
PUB="$REEL_ENGINE"/public
cp "$SILENT" "$PUB/clip.mp4"; cp /tmp/cc-voreel/overlay.json "$PUB/captions.json"
FRAMES=$(python3 -c "import sys;print(max(1,round(float(sys.argv[1])*30)))" "$DUR")
printf '{"videoSrc":"clip.mp4","captionsFile":"captions.json","brandKey":"cc","showLogo":false,"durationInFrames":%s}' "$FRAMES" > /tmp/cc-voreel/props.json
cd "$REEL_ENGINE" && npx remotion render src/index.ts MontageReel "$SILENT" --props=/tmp/cc-voreel/props.json
rm -f "$PUB/clip.mp4" "$PUB/captions.json"
```
(MontageReel holds each line ~4s to read - NOT the word-by-word CaptionedReel. --square -> MontageSquare,
--landscape -> MontageLandscape. Text overlay never adds audio.)

### STEP 3: WRITE THE VOICEOVER SCRIPT (timed to the cut)
From the Business Brain voice + the topic (or this month's `strategy.md` focus if none given):
- One line per 3-4 seconds of runtime, marked with its timestamp window, so they know what to
  say over which shot. Conversational, first person, their voice - written to be SPOKEN.
- Opens with a hook line, closes with the CTA from `offers.md`.
- AHPRA screen every line (no claims, no superlatives, no S4 names/pricing, no before/after).
- Show the script in chat AND nowhere else - no script files (they read it off the screen or
  their phone while recording).

### STEP 4: THE FINALE - show it (always, never ask)
`open` the silent montage so it plays, `open -R` in Finder. Then the hand-off, said plainly:
"Open CapCut / Instagram / TikTok, import this video, hit record voiceover, and read the script.
Your voice makes it yours - do a couple of takes, keep the one that sounds like you."

## Outputs - the STRICT contract (exactly these, nothing else)
1. `Content/Ready to Post/<slug>-voiceover-<date>.mp4` - the silent montage (opened on screen).
2. The timed voiceover script in chat.
No baked audio, no GHL push (their voiced final cut is made in-app), no extra files.

## IMPORTANT RULES
- SILENT means silent - never leave clip audio or add music under a voiceover montage.
- Never invent claims for the script - Business Brain facts only.
- No agency branding on the video. No emdashes anywhere.
- Pairs with /cc-cover (cover for the post) and /cc-script (longer educational scripts).
