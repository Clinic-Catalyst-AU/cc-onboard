import { Composition } from "remotion";
import { CaptionedClip, type CaptionedClipProps } from "./compositions/CaptionedClip";

// Platform presets
const PLATFORMS = {
  reel: { width: 1080, height: 1920, fps: 30 }, // IG Reels / TikTok / Shorts
  square: { width: 1080, height: 1080, fps: 30 }, // IG Feed / LinkedIn
  landscape: { width: 1920, height: 1080, fps: 30 }, // YouTube / LinkedIn landscape
};

const DEFAULT_PROPS: CaptionedClipProps = {
  videoSrc: "sample.mp4",
  captionsFile: "captions.json",
  brandKey: "cc",
  showLogo: false,
};

// Auto-fit any clip length: the skill passes durationInFrames (from ffprobe) via --props.
const calc = ({ props }: { props: CaptionedClipProps }) => ({
  durationInFrames: Math.max(1, Math.round(props.durationInFrames ?? 30 * 60)),
});

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="CaptionedReel"
        component={CaptionedClip}
        durationInFrames={30 * 60}
        {...PLATFORMS.reel}
        defaultProps={DEFAULT_PROPS}
        calculateMetadata={calc}
      />
      <Composition
        id="CaptionedSquare"
        component={CaptionedClip}
        durationInFrames={30 * 60}
        {...PLATFORMS.square}
        defaultProps={DEFAULT_PROPS}
        calculateMetadata={calc}
      />
      <Composition
        id="CaptionedLandscape"
        component={CaptionedClip}
        durationInFrames={30 * 60}
        {...PLATFORMS.landscape}
        defaultProps={DEFAULT_PROPS}
        calculateMetadata={calc}
      />
    </>
  );
};
