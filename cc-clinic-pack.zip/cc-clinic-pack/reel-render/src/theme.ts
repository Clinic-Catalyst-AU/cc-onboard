// Clinic Catalyst reel theme. Single brand - this IS the Clinic Catalyst system.
// NOTE: the on-screen output is the CLINIC's social content, so we do NOT stamp an
// agency logo on it (showLogo defaults to false). The teal is the caption styling only.

export const brands = {
  cc: {
    name: "Clinic Catalyst",
    slug: "cc",
    colors: {
      primary: "#FFFFFF",
      secondary: "#06292A",
      accent: "#3DBDB3",
      background: "#0F3D3E",
      text: "#FFFFFF",
      captionHighlight: "#3DBDB3", // active word = bright teal
      captionText: "#FFFFFF",
      overlay: "rgba(6, 41, 42, 0.55)",
    },
    fonts: {
      heading: "Montserrat",
      body: "Montserrat",
    },
    caption: {
      fontSize: 72,
      fontWeight: "800" as const,
      stroke: "#06292A",
      strokeWidth: 4,
    },
  },
} as const;

export type BrandKey = keyof typeof brands;
export type Brand = (typeof brands)[BrandKey];

/**
 * The clinic's OWN brand, read from their Business-Brain/brand-guide.md by the skill and passed
 * in as props. This exists because the output is the CLINIC's social content - burning Clinic
 * Catalyst's teal into every clinic's captions is agency branding on their video, which is the
 * one thing this system must never do.
 *
 * Everything is optional: any field the clinic has not defined falls back to the `cc` defaults,
 * so a clinic with no brand guide still gets a clean, readable reel.
 */
export type BrandOverride = {
  captionHighlight?: string; // the active word - their accent colour
  captionText?: string;      // the inactive words
  stroke?: string;           // the outline that keeps text readable on any footage
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: string;
  strokeWidth?: number;
};

export const resolveBrand = (
  base: Brand,
  o?: BrandOverride,
): Brand => {
  if (!o) return base;
  return {
    ...base,
    colors: {
      ...base.colors,
      captionHighlight: o.captionHighlight ?? base.colors.captionHighlight,
      captionText: o.captionText ?? base.colors.captionText,
    },
    fonts: {
      ...base.fonts,
      heading: o.fontFamily ?? base.fonts.heading,
      body: o.fontFamily ?? base.fonts.body,
    },
    caption: {
      ...base.caption,
      fontSize: o.fontSize ?? base.caption.fontSize,
      fontWeight: (o.fontWeight ?? base.caption.fontWeight) as Brand["caption"]["fontWeight"],
      stroke: o.stroke ?? base.caption.stroke,
      strokeWidth: o.strokeWidth ?? base.caption.strokeWidth,
    },
  } as Brand;
};
