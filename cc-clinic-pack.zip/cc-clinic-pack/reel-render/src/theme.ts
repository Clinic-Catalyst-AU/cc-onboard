// Clinic Catalyst reel theme. Single brand - this IS the Clinic Catalyst system.
// NOTE: the on-screen output is the CLINIC's social content, so we do NOT stamp an
// agency logo on it (showLogo defaults to false). The teal is the caption styling only.

export const brands = {
  cc: {
    name: "Clinic Catalyst",
    slug: "cc",
    colors: {
      primary: "#FFFFFF",
      secondary: "#06292A",
      accent: "#3DBDB3",
      background: "#0F3D3E",
      text: "#FFFFFF",
      captionHighlight: "#3DBDB3", // active word = bright teal
      captionText: "#FFFFFF",
      overlay: "rgba(6, 41, 42, 0.55)",
    },
    fonts: {
      heading: "Montserrat",
      body: "Montserrat",
    },
    caption: {
      fontSize: 72,
      fontWeight: "800" as const,
      stroke: "#06292A",
      strokeWidth: 4,
    },
  },
} as const;

export type BrandKey = keyof typeof brands;
export type Brand = (typeof brands)[BrandKey];
