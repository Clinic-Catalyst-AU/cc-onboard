#!/usr/bin/env python3
"""Plan the cuts for a talking-head reel, and remap the captions onto the cut timeline.

The problem this solves: to remove filler WORDS (not just silence) you must transcribe the raw
video first, then cut. But cutting shifts every timestamp, so the captions must be remapped onto
the new, shorter timeline or they drift out of sync with the speech.

Reads a whisper word-level JSON. Writes:
  - keep ranges (SOURCE time)  -> what ffmpeg should keep
  - captions   (NEW time)      -> word list remapped onto the cut timeline
  - cut points (NEW time)      -> where a cut landed, so the renderer can put a transition there
  - a human-readable report of exactly what was removed

Division of labour: this script handles the deterministic mechanics (fillers, silence, arithmetic).
Spoken retakes ("take out that last line", "let me start again") are a judgement call - the SKILL
reads the transcript, decides, and passes them in via --drop-span. Never guess intent in here.

Usage:
  plan_cuts.py IN.json OUT.json [--min-gap 0.35] [--pad-in 0.06] [--pad-out 0.12]
               [--keep-fillers] [--aggressive] [--drop-span 3.1:5.4 --drop-span 12.0:14.2]
"""
import argparse, json, re, sys

# "ums and ahs" - the ones that are pure hesitation noise, never meaning.
FILLERS = {
    "um", "umm", "ummm", "uhm", "uh", "uhh", "uhhh", "er", "erm", "err",
    "ah", "ahh", "eh", "hmm", "hm", "mm", "mmm", "mhm",
}
# Discourse crutches. Real words, so removing them can change meaning or rhythm.
# Behind --aggressive on purpose.
AGGRESSIVE_FILLERS = {"basically", "literally", "actually", "honestly"}
AGGRESSIVE_PHRASES = [("you", "know"), ("i", "mean"), ("sort", "of"), ("kind", "of")]


def norm(w):
    """Strip punctuation/whitespace for matching; keep the original for display."""
    return re.sub(r"[^a-z]", "", w.lower())


def load_words(path):
    d = json.load(open(path))
    words = []
    for seg in d.get("segments", []):
        for w in (seg.get("words") or []):
            if w.get("start") is None or w.get("end") is None:
                continue
            words.append({
                "word": w["word"],
                "start": float(w["start"]),
                "end": float(w["end"]),
            })
    words.sort(key=lambda x: x["start"])
    return words


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("infile")
    ap.add_argument("outfile")
    ap.add_argument("--min-gap", type=float, default=0.35,
                    help="silence longer than this between kept words gets cut")
    ap.add_argument("--pad-in", type=float, default=0.06)
    ap.add_argument("--pad-out", type=float, default=0.12)
    ap.add_argument("--keep-fillers", action="store_true", help="do not remove ums and ahs")
    ap.add_argument("--aggressive", action="store_true",
                    help="also remove 'you know', 'i mean', 'basically', 'literally'")
    ap.add_argument("--drop-span", action="append", default=[], metavar="START:END",
                    help="source-time span to cut (spoken retakes - the skill decides these)")
    a = ap.parse_args()

    words = load_words(a.infile)
    if not words:
        print("ERROR: no word-level timestamps in the transcript", file=sys.stderr)
        sys.exit(1)

    drop_spans = []
    for s in a.drop_span:
        try:
            lo, hi = s.split(":")
            drop_spans.append((float(lo), float(hi)))
        except ValueError:
            print(f"ERROR: bad --drop-span {s!r}, want START:END in seconds", file=sys.stderr)
            sys.exit(1)

    # ---- decide which words survive -------------------------------------------------
    removed_fillers, removed_retakes = [], []

    def in_drop_span(w):
        mid = (w["start"] + w["end"]) / 2
        return any(lo <= mid <= hi for lo, hi in drop_spans)

    fillers = set(FILLERS)
    if a.aggressive:
        fillers |= AGGRESSIVE_FILLERS

    kept = []
    i = 0
    while i < len(words):
        w = words[i]
        n = norm(w["word"])

        if in_drop_span(w):
            removed_retakes.append(w)
            i += 1
            continue

        if not a.keep_fillers:
            if n in fillers:
                removed_fillers.append(w)
                i += 1
                continue
            if a.aggressive and i + 1 < len(words):
                pair = (n, norm(words[i + 1]["word"]))
                if pair in AGGRESSIVE_PHRASES:
                    removed_fillers.extend([w, words[i + 1]])
                    i += 2
                    continue

        kept.append(w)
        i += 1

    if not kept:
        print("ERROR: every word was cut - nothing left to render", file=sys.stderr)
        sys.exit(1)

    # ---- group kept words into keep-ranges, cutting long silences -------------------
    ranges = []          # [start, end] in SOURCE time
    group = [kept[0]]
    for prev, cur in zip(kept, kept[1:]):
        if cur["start"] - prev["end"] > a.min_gap:
            ranges.append([group[0]["start"], group[-1]["end"], group])
            group = [cur]
        else:
            group.append(cur)
    ranges.append([group[0]["start"], group[-1]["end"], group])

    # pad, then clamp so padding can never make ranges overlap or invert
    padded = []
    for idx, (s, e, grp) in enumerate(ranges):
        ps = max(0.0, s - a.pad_in)
        pe = e + a.pad_out
        if padded and ps < padded[-1][1]:
            ps = padded[-1][1]           # butt up against the previous range, never overlap
        if pe <= ps:
            pe = ps + 0.02
        padded.append([ps, pe, grp])

    # ---- remap onto the new timeline -----------------------------------------------
    # Emitted directly in the @remotion/captions shape so there is no second conversion step
    # that could drift out of sync with the cut.
    def ms(x):
        return int(round(x * 1000))

    captions, cut_points = [], []
    new_t = 0.0
    for idx, (s, e, grp) in enumerate(padded):
        if idx > 0:
            cut_points.append(round(new_t, 3))   # a cut landed here -> transition goes here
        for w in grp:
            ns = new_t + (w["start"] - s)
            ne = new_t + (w["end"] - s)
            captions.append({
                "text": " " + w["word"].strip(),
                "startMs": ms(ns),
                "endMs": ms(ne),
                "timestampMs": ms((ns + ne) / 2),
                "confidence": 1.0,
            })
        new_t += (e - s)

    src_dur = words[-1]["end"]
    # captions.json is written as its own file - it is what Remotion fetches at render time
    import os
    cap_path = os.path.join(os.path.dirname(os.path.abspath(a.outfile)) or ".", "captions.json")
    json.dump(captions, open(cap_path, "w"))

    out = {
        "keep_ranges": [[round(s, 3), round(e, 3)] for s, e, _ in padded],
        "cut_points": cut_points,
        "captions_file": cap_path,
        "caption_count": len(captions),
        "new_duration": round(new_t, 3),
        "report": {
            "source_speech_span": round(src_dur, 2),
            "final_duration": round(new_t, 2),
            "words_kept": len(captions),
            "fillers_removed": [w["word"].strip() for w in removed_fillers],
            "filler_count": len(removed_fillers),
            "retake_words_removed": len(removed_retakes),
            "silences_cut": max(0, len(padded) - 1),
        },
    }
    json.dump(out, open(a.outfile, "w"), indent=1)

    r = out["report"]
    print(f"  kept {r['words_kept']} words across {len(padded)} segment(s)")
    print(f"  removed {r['filler_count']} filler(s): {', '.join(r['fillers_removed']) or 'none'}")
    if r["retake_words_removed"]:
        print(f"  removed {r['retake_words_removed']} word(s) from spoken retakes")
    print(f"  cut {r['silences_cut']} silence gap(s)")
    print(f"  duration: {r['source_speech_span']}s -> {r['final_duration']}s")


if __name__ == "__main__":
    main()
