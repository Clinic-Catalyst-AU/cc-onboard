#!/usr/bin/env python3
"""overlay_from_lines.py - build a captions.json for on-screen TEXT OVERLAYS on a
silent clip montage (no transcript needed). Reuses the exact {text,startMs,endMs}
shape the reel-render CaptionedReel comp already renders - so montage skills
(cc-reelvoiceover / cc-reelclips) get optional on-screen text with zero new render code.

Text lines are spread evenly across the montage runtime (one line held per window),
OR mapped to explicit clip windows if --clip-durations is given.

Usage:
  # even spread across a known total duration:
  python3 overlay_from_lines.py --out captions.json --duration 18.0 \
    --lines "Winter skin reset" "At Harbourlight" "Book your consult"

  # per-clip timing (line i shown over clip i; pass the clip durations in order):
  python3 overlay_from_lines.py --out captions.json \
    --clip-durations 2.5 2.5 2.5 2.5 \
    --lines "Your winter reset" "" "Gentle, considered" "Book your consult"
"""
import argparse, json, sys


def spans_even(total, n):
    step = total / n
    return [(i * step, (i + 1) * step) for i in range(n)]


def spans_from_clips(durs, n):
    # cumulative clip windows; a blank line just skips that clip's window
    out, t = [], 0.0
    for d in durs:
        out.append((t, t + d))
        t += d
    # if more lines than clips, fall back to even spread over the whole timeline
    if n > len(out):
        return spans_even(t, n)
    return out[:n]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--lines", nargs="+", required=True)
    ap.add_argument("--duration", type=float, help="total montage seconds (even spread)")
    ap.add_argument("--clip-durations", nargs="*", type=float,
                    help="per-clip seconds in order (line i -> clip i)")
    a = ap.parse_args()

    lines = a.lines
    if a.clip_durations:
        windows = spans_from_clips(a.clip_durations, len(lines))
    elif a.duration:
        windows = spans_even(a.duration, len(lines))
    else:
        sys.exit("need --duration or --clip-durations")

    caps = []
    for (start, end), text in zip(windows, lines):
        text = (text or "").strip()
        if not text:  # blank = clean clip, no overlay
            continue
        s_ms, e_ms = int(start * 1000), int(end * 1000)
        caps.append({
            "text": text,
            "startMs": s_ms,
            "endMs": e_ms,
            "timestampMs": (s_ms + e_ms) // 2,
            "confidence": 1.0,
        })
    json.dump(caps, open(a.out, "w"), indent=2)
    print(f"wrote {len(caps)} overlay line(s) -> {a.out}")


if __name__ == "__main__":
    main()
