#!/usr/bin/env python3
"""Convert mlx-whisper word-timestamp JSON into the @remotion/captions format.

Usage:
    python3 captions_from_mlx.py <mlx_whisper.json> <out_captions.json>

mlx-whisper (with --word-timestamps True --output-format json) emits:
    {"segments": [{"words": [{"word": " And", "start": 0.0, "end": 0.3, "probability": 0.9}, ...]}]}

@remotion/captions wants an array of:
    {"text": " And", "startMs": 0, "endMs": 300, "timestampMs": 150, "confidence": 0.9}
"""
import json
import sys


def ms(x):
    return int(round(float(x) * 1000))


def main():
    if len(sys.argv) != 3:
        print("usage: captions_from_mlx.py <mlx_whisper.json> <out_captions.json>", file=sys.stderr)
        sys.exit(2)

    src, dst = sys.argv[1], sys.argv[2]
    with open(src) as f:
        data = json.load(f)

    captions = []
    for seg in data.get("segments", []):
        words = seg.get("words")
        if words:
            for w in words:
                text = w.get("word", "")
                if not text.strip():
                    continue
                start, end = w.get("start"), w.get("end")
                if start is None or end is None:
                    continue
                captions.append({
                    "text": " " + text.strip(),
                    "startMs": ms(start),
                    "endMs": ms(end),
                    "timestampMs": ms((float(start) + float(end)) / 2),
                    "confidence": w.get("probability", 1.0),
                })
        else:
            # no word-level data - fall back to one caption per segment
            text = seg.get("text", "").strip()
            start, end = seg.get("start"), seg.get("end")
            if text and start is not None and end is not None:
                captions.append({
                    "text": " " + text,
                    "startMs": ms(start),
                    "endMs": ms(end),
                    "timestampMs": ms((float(start) + float(end)) / 2),
                    "confidence": 1.0,
                })

    with open(dst, "w") as f:
        json.dump(captions, f)
    print(f"wrote {len(captions)} captions -> {dst}")


if __name__ == "__main__":
    main()
