import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import type { TikTokPage } from "@remotion/captions";
import type { Brand } from "../theme";

// Where the caption band sits, as a fraction of the frame height: below the centre fold,
// but above the zone where Instagram and TikTok overlay their own caption and UI chrome.
// MUST be proportional. It used to be a hardcoded 1210px, which is correct on the 1080x1920
// vertical and lands BELOW THE BOTTOM EDGE on the 1080x1080 square and 1920x1080 landscape -
// those renders came out with no visible captions at all.
const CAPTION_BAND = 0.63;

export const CaptionPage: React.FC<{
  page: TikTokPage;
  brand: Brand;
}> = ({ page, brand }) => {
  const frame = useCurrentFrame();
  const { fps, height, width } = useVideoConfig();

  const currentTimeMs = (frame / fps) * 1000;
  const absoluteTimeMs = page.startMs + currentTimeMs;

  // The caption sizing is authored against a 1080-wide frame; scale it for any other width
  // so landscape does not end up with comically small text.
  const scale = width / 1080;

  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-start",
        alignItems: "center",
        paddingTop: Math.round(height * CAPTION_BAND),
      }}
    >
      <div
        style={{
          fontSize: Math.round(brand.caption.fontSize * scale),
          fontWeight: brand.caption.fontWeight,
          fontFamily: brand.fonts.heading,
          textAlign: "center",
          whiteSpace: "pre-wrap",
          maxWidth: "85%",
          lineHeight: 1.1,
          textShadow: (() => {
            const s = Math.max(1, Math.round(brand.caption.strokeWidth * scale));
            const c = brand.caption.stroke;
            return `0 0 ${s * 2}px ${c},
              ${s}px ${s}px 0 ${c},
              -${s}px -${s}px 0 ${c},
              ${s}px -${s}px 0 ${c},
              -${s}px ${s}px 0 ${c}`;
          })(),
        }}
      >
        {page.tokens.map((token) => {
          const isActive =
            token.fromMs <= absoluteTimeMs && token.toMs > absoluteTimeMs;

          return (
            <span
              key={token.fromMs}
              style={{
                color: isActive
                  ? brand.colors.captionHighlight
                  : brand.colors.captionText,
                transition: "color 0.05s",
                textTransform: "uppercase",
              }}
            >
              {token.text}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
