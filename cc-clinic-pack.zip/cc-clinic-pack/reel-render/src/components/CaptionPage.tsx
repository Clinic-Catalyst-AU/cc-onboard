import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import type { TikTokPage } from "@remotion/captions";
import type { Brand } from "../theme";

export const CaptionPage: React.FC<{
  page: TikTokPage;
  brand: Brand;
}> = ({ page, brand }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const currentTimeMs = (frame / fps) * 1000;
  const absoluteTimeMs = page.startMs + currentTimeMs;

  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-start",
        alignItems: "center",
        // below the centre fold, above the native social caption/UI zone
        paddingTop: 1210,
      }}
    >
      <div
        style={{
          fontSize: brand.caption.fontSize,
          fontWeight: brand.caption.fontWeight,
          fontFamily: brand.fonts.heading,
          textAlign: "center",
          whiteSpace: "pre-wrap",
          maxWidth: "85%",
          lineHeight: 1.1,
          textShadow: `0 0 ${brand.caption.strokeWidth * 2}px ${brand.caption.stroke},
            ${brand.caption.strokeWidth}px ${brand.caption.strokeWidth}px 0 ${brand.caption.stroke},
            -${brand.caption.strokeWidth}px -${brand.caption.strokeWidth}px 0 ${brand.caption.stroke},
            ${brand.caption.strokeWidth}px -${brand.caption.strokeWidth}px 0 ${brand.caption.stroke},
            -${brand.caption.strokeWidth}px ${brand.caption.strokeWidth}px 0 ${brand.caption.stroke}`,
        }}
      >
        {page.tokens.map((token) => {
          const isActive =
            token.fromMs <= absoluteTimeMs && token.toMs > absoluteTimeMs;

          return (
            <span
              key={token.fromMs}
              style={{
                color: isActive
                  ? brand.colors.captionHighlight
                  : brand.colors.captionText,
                transition: "color 0.05s",
                textTransform: "uppercase",
              }}
            >
              {token.text}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
