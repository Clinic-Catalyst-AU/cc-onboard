import { AbsoluteFill } from "remotion";
import type { Brand } from "../theme";

// Readability overlay only. By design this stamps NO agency name on the clinic's
// video - the output is the clinic's own social content. showLogo stays off unless
// a caller explicitly opts in (e.g. the clinic's own name, never "Clinic Catalyst").
export const Overlay: React.FC<{
  brand: Brand;
  showLogo?: boolean;
  logoText?: string;
}> = ({ brand, showLogo = false, logoText }) => {
  return (
    <AbsoluteFill>
      {showLogo && logoText ? (
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            height: 80,
            background: `linear-gradient(180deg, ${brand.colors.overlay} 0%, transparent 100%)`,
            display: "flex",
            alignItems: "center",
            padding: "0 30px",
          }}
        >
          <div
            style={{
              fontFamily: brand.fonts.heading,
              fontSize: 24,
              fontWeight: 700,
              color: brand.colors.primary,
              letterSpacing: 2,
            }}
          >
            {logoText.toUpperCase()}
          </div>
        </div>
      ) : null}

      {/* Bottom gradient for caption readability */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: 320,
          background: `linear-gradient(0deg, ${brand.colors.overlay} 0%, transparent 100%)`,
        }}
      />
    </AbsoluteFill>
  );
};
