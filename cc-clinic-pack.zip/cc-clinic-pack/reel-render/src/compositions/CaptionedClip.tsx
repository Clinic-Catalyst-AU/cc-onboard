import { useState, useEffect, useCallback, useMemo } from "react";
import {
  AbsoluteFill,
  OffthreadVideo,
  Sequence,
  staticFile,
  useVideoConfig,
  delayRender,
  continueRender,
} from "remotion";
import { createTikTokStyleCaptions } from "@remotion/captions";
import type { Caption } from "@remotion/captions";
import { CaptionPage } from "../components/CaptionPage";
import { Overlay } from "../components/Overlay";
import { brands, type BrandKey } from "../theme";

const SWITCH_CAPTIONS_EVERY_MS = 1200;

export type CaptionedClipProps = {
  videoSrc: string;
  captionsFile: string;
  brandKey: BrandKey;
  showLogo?: boolean;
  logoText?: string;
  // set by the skill (from ffprobe) so any clip length fits exactly
  durationInFrames?: number;
};

export const CaptionedClip: React.FC<CaptionedClipProps> = ({
  videoSrc,
  captionsFile,
  brandKey,
  showLogo = false,
  logoText,
}) => {
  const [captions, setCaptions] = useState<Caption[] | null>(null);
  // Block frame capture until captions are loaded - without this, headless
  // renders capture frames before the async fetch resolves (blank captions).
  const [handle] = useState(() => delayRender("load captions"));
  const { fps } = useVideoConfig();
  const brand = brands[brandKey] ?? brands.cc;

  const fetchCaptions = useCallback(async () => {
    try {
      const response = await fetch(staticFile(captionsFile));
      const data = await response.json();
      setCaptions(data);
    } catch (e) {
      console.error("Failed to load captions:", e);
      setCaptions([]);
    } finally {
      continueRender(handle);
    }
  }, [captionsFile, handle]);

  useEffect(() => {
    fetchCaptions();
  }, [fetchCaptions]);

  const { pages } = useMemo(() => {
    return createTikTokStyleCaptions({
      captions: captions ?? [],
      combineTokensWithinMilliseconds: SWITCH_CAPTIONS_EVERY_MS,
    });
  }, [captions]);

  return (
    <AbsoluteFill style={{ backgroundColor: "black" }}>
      <OffthreadVideo
        src={staticFile(videoSrc)}
        style={{ width: "100%", height: "100%", objectFit: "cover" }}
      />

      <Overlay brand={brand} showLogo={showLogo} logoText={logoText} />

      {pages.map((page, index) => {
        const nextPage = pages[index + 1] ?? null;
        const startFrame = (page.startMs / 1000) * fps;
        const endFrame = Math.min(
          nextPage ? (nextPage.startMs / 1000) * fps : Infinity,
          startFrame + (SWITCH_CAPTIONS_EVERY_MS / 1000) * fps
        );
        const durationInFrames = Math.round(endFrame - startFrame);

        if (durationInFrames <= 0) return null;

        return (
          <Sequence
            key={index}
            from={Math.round(startFrame)}
            durationInFrames={durationInFrames}
          >
            <CaptionPage page={page} brand={brand} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};
