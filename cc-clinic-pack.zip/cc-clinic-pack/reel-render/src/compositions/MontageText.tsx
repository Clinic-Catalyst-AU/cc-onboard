import { useState, useEffect, useCallback } from "react";
import {
  AbsoluteFill,
  OffthreadVideo,
  Sequence,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  delayRender,
  continueRender,
} from "remotion";
import { Overlay } from "../components/Overlay";
import { brands, type BrandKey } from "../theme";

// Montage text overlays: DISTINCT hook lines held long enough to READ, one at a
// time, spread across the video. NOT word-by-word speech captions (that is
// CaptionedClip). Each line = one {text,startMs,endMs} entry; it holds for its
// window (capped so long gaps stay clean) with a soft fade in/out.
const MAX_HOLD_MS = 4000; // longest a single line stays up (readability + breathing room)
const FADE_IN_MS = 300;
const FADE_OUT_MS = 450;

type Line = { text: string; startMs: number; endMs: number };

export type MontageTextProps = {
  videoSrc: string;
  captionsFile: string;
  brandKey: BrandKey;
  showLogo?: boolean;
  logoText?: string;
  durationInFrames?: number;
};

const LineCard: React.FC<{ text: string; holdFrames: number; brand: any }> = ({
  text,
  holdFrames,
  brand,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const fadeIn = (FADE_IN_MS / 1000) * fps;
  const fadeOut = (FADE_OUT_MS / 1000) * fps;
  const opacity = interpolate(
    frame,
    [0, fadeIn, holdFrames - fadeOut, holdFrames],
    [0, 1, 1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );
  const lift = interpolate(frame, [0, fadeIn], [24, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-start",
        alignItems: "center",
        paddingTop: 1210, // below centre fold, above native social UI
      }}
    >
      <div
        style={{
          opacity,
          transform: `translateY(${lift}px)`,
          fontSize: 58,
          fontWeight: 800,
          fontFamily: brand.fonts.heading,
          color: brand.colors.captionText,
          textAlign: "center",
          textTransform: "uppercase",
          whiteSpace: "pre-wrap",
          maxWidth: "82%",
          lineHeight: 1.12,
          letterSpacing: 1,
          textShadow: `0 0 ${brand.caption.strokeWidth * 2}px ${brand.caption.stroke},
            ${brand.caption.strokeWidth}px ${brand.caption.strokeWidth}px 0 ${brand.caption.stroke},
            -${brand.caption.strokeWidth}px -${brand.caption.strokeWidth}px 0 ${brand.caption.stroke},
            ${brand.caption.strokeWidth}px -${brand.caption.strokeWidth}px 0 ${brand.caption.stroke},
            -${brand.caption.strokeWidth}px ${brand.caption.strokeWidth}px 0 ${brand.caption.stroke}`,
        }}
      >
        {text}
      </div>
    </AbsoluteFill>
  );
};

export const MontageText: React.FC<MontageTextProps> = ({
  videoSrc,
  captionsFile,
  brandKey,
  showLogo = false,
  logoText,
}) => {
  const [lines, setLines] = useState<Line[] | null>(null);
  const [handle] = useState(() => delayRender("load overlay lines"));
  const { fps } = useVideoConfig();
  const brand = brands[brandKey] ?? brands.cc;

  const fetchLines = useCallback(async () => {
    try {
      const res = await fetch(staticFile(captionsFile));
      setLines(await res.json());
    } catch (e) {
      console.error("Failed to load overlay lines:", e);
      setLines([]);
    } finally {
      continueRender(handle);
    }
  }, [captionsFile, handle]);

  useEffect(() => {
    fetchLines();
  }, [fetchLines]);

  return (
    <AbsoluteFill style={{ backgroundColor: "black" }}>
      <OffthreadVideo
        src={staticFile(videoSrc)}
        style={{ width: "100%", height: "100%", objectFit: "cover" }}
      />
      <Overlay brand={brand} showLogo={showLogo} logoText={logoText} />

      {(lines ?? []).map((line, i) => {
        const startFrame = Math.round((line.startMs / 1000) * fps);
        const windowMs = Math.max(0, line.endMs - line.startMs);
        const holdMs = Math.min(windowMs, MAX_HOLD_MS);
        const holdFrames = Math.round((holdMs / 1000) * fps);
        if (holdFrames <= 0) return null;
        return (
          <Sequence key={i} from={startFrame} durationInFrames={holdFrames}>
            <LineCard text={line.text} holdFrames={holdFrames} brand={brand} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};
