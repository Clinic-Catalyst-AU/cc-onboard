Clinic Catalyst - your skill pack.
1. Unzip this folder.
2. In Terminal, run:  bash INSTALL.sh
3. Open Claude Code in ~/Clinic and run /cc-resonance then /cc-brand-guide.
That builds your Business Brain - then /cc-content-engine, /cc-reeltalkinghead, /cc-cover and the rest read it.
